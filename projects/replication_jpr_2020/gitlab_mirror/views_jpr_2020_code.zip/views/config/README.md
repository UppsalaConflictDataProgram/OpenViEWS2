# Configuration

This directory contains config files with **placeholder** values.
Do not edit these files with actual configuration settings, they are not read!
These are copied by the installer (install.sh) to `~/.views/` where you should edit them
to reflect your system.
By default the "test" settings are used.
To use the "prod" settings set your environment variable VIEWS_MODE to "prod"
like so
`export VIEWS_MODE=prod`
in your shell before invoking a script or starting a notebook server manually.
Starting a notebook with services/notebook_start.sh sets mode to prod by default.

The point of keeping host specific configs on each users home directory instead
of in the repo is that we will be less likely to put our private information
in this public repo.
It also allows us to map storage differently across systems and keep secrets,
such as the qualtrics or twitter tokens, out of the repo.

## views.utils.config

The configuration for each applications happens through the `views.utils.config`
module.
The config is accessible to other modules like so:

```
from views.utils.config import CONFIG, SECRETS
CONFIG = config.CONFIG
SECRETS = config.SECRETS
dir_data_raw = CONFIG['dirs']['dir_data_raw']
qualtrics_token = SECRETS['qualtrics']['token']

```

If the test or prod section of the config is loaded depends on the `VIEWS_MODE`
environment var. If it is not set or is set to "test" then test settings are
used.
Only if it is set to "prod" are "prod" values used.
