# ViEWS rewrite repo

This is a new repo for the ViEWS project
https://github.com/UppsalaConflictDataProgram/OpenViEWS .
The current codebase at the OpenViEWS has a lot of technical debt and is difficult
to maintain.
The goal of this repo is to start fresh and build a more solid foundation for
the project going forward.

The main advantages of this new repo are

* An installable `views` python package
* All private information like IP's and usernames kept out of the repo through the config system
* An environment file for managing dependencies
* A clear structure.

## Installation

This installation procedure depends on Conda, preferably Miniconda.
Get it at https://docs.conda.io/en/latest/miniconda.html

The installer creates a new conda environment called "views".
The installer installs the package views and makes it importable whenever
the views conda environment is activated with `source activate views`.

To use a component of views you can then simply create a python script anywhere
and if it is started while the views conda environment is activated you will be
able to import each component like

`from views.utils import dbutils`

without messing with `sys.path` or the location of your scripts.

### Get started

* Install Miniconda from https://conda.io/miniconda.html
* Run `bash install.sh` in the root dir of the repo

####  Configuration

Configuration is stored in the users home directory in `~/.views/`.
The config file has two sections "test" and "prod".
To get started it is enough to make sure that the options for the test section
look sane.
These sections can be adapted for the diverse systems we use and for each user.

* Open the config file `~/.views/config.json` and populate it with values
  for your system
* Open the secrets file `~/.views/secrets.json` and populate it with values
  from your accounts for the APIs we use if you need them.


## Please

* Follow the Google style guide:
  https://github.com/google/styleguide/blob/gh-pages/pyguide.md
* Use run_suite.sh that runs formatting, tests and lints for the full code.
* Separate code from data! No more column names in application code.
  Ideally each app should be data-agnostic within reason.

### Branching

The goal is to have each forecast be produced by a version-number git tagged
commit in the master branch. This makes it easy for people wishing to replicate
to find the commit to checkout to replicate a specific run.

Development happens in the develop branch.
The master branch should be well-functioning and be the branch used to produce
the published forecasts.

* Don't break the master branch.
* Try not to break the develop branch too bigly.
* Feel free to make branches from develop and break them, merge to develop
  when they're useful.

## Structure

* `views/` is the views package root directory. All .py files in it are importable in python.
* `views/apps/` a directory for each application
* `views/tests/` tests for apps and utils
* `views/utils/` common utility modules.
* `scripts/` scripts for development. No misc stuff! Put misc things under projects.
* `notebooks/` Jupyter notebooks
* `projects/` Ad-hoc projects containing code not useful outside the specific project.

## Conventions

### timevar-groupvar indexing
Much of the code uses pandas.
In many places there is an assumption that dataframes are indexed by
`[timevar, groupvar]`. In that order.
This is done so that functions that depend on groupby operations
can do so by index position, without having to explicitly pass the name
of that identifier.


