#!/bin/bash
# Start a jupyter notebook server in the notebooks dir with VIEWS_MODE=prod
# This allows connection to the production database

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
cd "$parent_path"
cd ../notebooks
source activate views
export VIEWS_MODE=prod
jupyter notebook