# Services

## Notebook server

To start a jupyter notebook server that is
* Pointed to the notebooks dir
* Has VIEWS_MODE=prod set to connect to the production DB

`cd` into this dir and run `bash notebook_start.sh`

