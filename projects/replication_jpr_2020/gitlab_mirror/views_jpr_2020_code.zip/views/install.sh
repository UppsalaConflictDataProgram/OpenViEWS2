echo "Updating conda"
conda update --all --yes
echo "Removing existing views env"
conda remove --name views --all --yes
echo "Creating env from environment.yml"
conda env create -f environment.yml
echo "Activating env"
source activate views
echo "Running python setup.py develop to install"
python setup.py develop
#jupyter nbextension install --py --symlink --sys-prefix qgrid
#jupyter nbextension enable --py --sys-prefix qgrid

# Host-specific configuration

echo "Creating ~/.views/ for config and secrets if it doesn't exist"
mkdir -p ~/.views

# Copy the default config file to default config dir ~/.views/
if [ ! -f ~/.views/config.json ];
    then
        echo "No current ~/.views/config.json found, copying the defaults"
        cp config/config.json ~/.views/config.json
    else
        echo "~/.views/config.json already exists, not changing it"
fi

# Copy the default secrets file to default config dir ~/.views/
if [ ! -f ~/.views/secrets.json ];
    then
        echo "No current ~/.views/secrets.json found, copying the defaults"
        cp config/secrets.json ~/.views/secrets.json
    else
        echo "~/.views/secrets.json already exists, not changing it"
fi