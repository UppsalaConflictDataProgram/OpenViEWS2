# Python module

This directory is the python package.
After running the install.sh script and then `source activate views`
in your terminal all modules in the directories below are importable.
For example
`from views.utils import dbutils` will give access to all the database
utilities.