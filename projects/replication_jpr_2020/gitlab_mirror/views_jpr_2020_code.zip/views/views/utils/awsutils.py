""" Utils for interacting with AWS """

import os

import boto3


def create_s3_bucket(name, region, if_exists="pass"):
    """ Create an S3 bucket """
    s3 = boto3.client("s3")

    if name in list_s3_bucket_names():
        print(f"Bucket {name} in {region} exists.")

        if if_exists == "pass":
            pass
        else:
            msg = f"Bucket {name} already exists."
            raise RuntimeError(msg)
    else:
        print(f"Creating bucket {name} in {region}.")
        conf = {"LocationConstraint": "eu-north-1"}
        s3.create_bucket(Bucket=name, CreateBucketConfiguration=conf)


def upload_file(path, name_bucket, name_target=None):
    """ Upload file from path to S3 bucket """
    s3 = boto3.client("s3")

    # Use the name of the file on disk as the filename in S3 as default
    if not name_target:
        name_target = os.path.basename(path)

    s3.upload_file(path, name_bucket, name_target)
    print(f"Uploaded {path} to {name_bucket}/{name_target}")


def list_s3_bucket_names():
    """ List S3 bucket names in the system configured region """
    s3 = boto3.client("s3")
    response = s3.list_buckets()
    bucket_names = [bucket["Name"] for bucket in response["Buckets"]]
    return bucket_names
