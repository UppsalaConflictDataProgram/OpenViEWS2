""" Spatial IO utils """
import logging
import subprocess

import geopandas as gpd

from views.utils import dbutils, config

Logger = logging.getLogger(__name__)


def gdf_to_shp(gdf, path):
    """ Write geometry and index cols of gdf to path as .shp file """

    Logger.debug(f"Writing {path}")

    if not path.endswith(".shp"):
        raise RuntimeError(f"path:{path} should end in .shp")
    gdf[["geom"]].reset_index().to_file(path)
    Logger.debug(f"Wrote {path}")


def gdf_to_geojson(gdf, path):
    """ Write geometry and index cols of gdf to path as .geojson """

    Logger.debug(f"Writing {path}")

    if not path.endswith(".geojson"):
        msg = f"path:{path} should end in .geojson"
        raise RuntimeError(msg)

    gdf[["geom"]].reset_index().to_file(path, driver="GeoJSON")
    Logger.debug(f"Wrote {path}")


def shp_to_gdf(path, groupvar):
    """ Load gdf from .shp file at path """

    Logger.debug(f"Reading {path} to gdf")

    if not path.endswith(".shp"):
        raise RuntimeError(f"path:{path} should end in .shp")

    gdf = gpd.read_file(path)
    gdf = gdf.set_index(keys=[groupvar])

    # geopandas isn't consistent with geometry column naming,
    # not sure why.
    if "geometry" in gdf.columns:
        gdf = gdf.rename(columns={"geometry": "geom"})
    gdf = gdf.set_geometry("geom")

    return gdf


def invoke_shp2pgsql(fqtable, path_shp, srid=4326):
    """ Push shapefile to fqtable """
    psql_string = config.CONFIG["db"]["psql_string"]
    cmd = f"shp2pgsql -D -s {srid} -I {path_shp} {fqtable} | {psql_string}"
    result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    Logger.info(f"shp2pgsql output: {result}")

    # Raise if we didn't push successfully
    if not fqtable in dbutils.list_tables_in_schema(fqtable.split(".")[0]):
        msg = (
            "Something wen't wrong with shp2pgsql, is shp2pgsql installed? "
            "Is your psql_string set correctly in your config file?"
        )
        raise RuntimeError(msg)
