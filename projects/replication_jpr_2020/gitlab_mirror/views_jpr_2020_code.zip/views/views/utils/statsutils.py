""" Statistics utility functions """

import warnings

import numpy as np


def prob_to_odds(p, clip=True):
    """ Cast probability into odds """

    if isinstance(p, list):
        p = np.array(p)

    if clip:
        offset = 1e-10
        offset = 1e-10
        upper = 1 - offset
        lower = 0 + offset
        p = np.clip(p, lower, upper)

    # Check for probs greq 1 because odds of 1 is inf which might break things
    if np.any(p >= 1):
        msg = "probs >= 1 passed to get_odds, expect infs"
        warnings.warn(msg)

    odds = p / (1 - p)
    return odds


def prob_to_logodds(p):
    """ Cast probability to log-odds """
    return np.log(prob_to_odds(p))


def odds_to_prob(odds):
    """ Cast odds ratio to probability """
    return odds / (odds + 1)


def logodds_to_prob(logodds):
    """ Cast logodds to probability """
    return odds_to_prob(np.exp(logodds))


def format_prob_to_pct(p):
    """ Cast probabilities to pct (%) formatted strings """

    msg = "Casting probabilities greater than 1 to pct is silly"
    if not 0 < p < 1:
        warnings.warn(msg)

    pct = p * 100
    if pct == int(pct):
        pct = int(pct)
    pct = str(pct)
    pct = f"{pct}%"
    return pct


def logit(p):
    """ Logit is just logodds """
    return prob_to_logodds(p)
