""" Data utilities """

import logging
import itertools
import string
import functools
import math
from typing import List

import pyarrow
import pyarrow.parquet as pq

import pandas as pd
import numpy as np

from views.utils import pyutils

Logger = logging.getLogger(__name__)


def list_columns_in_parquet(path):
    """ List the columns in .parquet file at path """
    file = pq.ParquetFile(path)
    colnames = [col.name for col in file.schema]
    return colnames


def load_parquet(path, cols=None, silent=False):
    """ Load parquet from file to dataframe """
    try:
        if cols:
            data = pd.read_parquet(path, columns=cols)
        else:
            data = pd.read_parquet(path)
    except pyarrow.lib.ArrowIOError as exc:  # pylint: disable=c-extension-no-member
        Logger.error(f"Failed reading {path} with exception {exc}")
        raise

    if not silent:
        msg = f"Read {path} with {len(data.columns)} cols and {len(data)} rows"
        Logger.info(msg)
    return data


def write_parquet(data, path):
    """ Write data to parquet. Both pd.Series and pd.DataFrame supported """
    # Series dont have to_parquet() yet, only dataframes do

    path = pyutils.resole_vars_and_home(path)
    if isinstance(data, pd.Series):
        data = pd.DataFrame(data.copy())
    data.to_parquet(path)

    msg = f"Wrote {path} with {len(data.columns)} cols and {len(data)} rows."
    Logger.info(msg)


def load_hdf(path):
    """ Read dataframe or series from hdf """

    data = pd.read_hdf(path)
    Logger.info(f"Read {path}")
    return data


def write_hdf(data, path):
    """ Write data to hdf """

    data.to_hdf(path, key="data", complevel=1)
    Logger.info(f"Wrote {path}")


def share_obs_missing(df):
    """ Get share of observations missing """
    return df.isnull().sum().sum() / (df.shape[0] * df.shape[1])


def inf_to_nan(df):
    """ Replace inifinity values in df with np.nan """
    return df.replace([np.inf, -np.inf], np.nan)


def get_share_missing_str(df):
    """ Return a string of shares of missing values in df's cols """

    missing = df.isnull().sum() / len(df)
    missing = missing[missing > 0]
    missing = missing.sort_values(ascending=False)
    missing = missing.to_string()

    return missing


def interpolate(data, extrapolate=True):
    """ Groupwise linear interpolation with optional extrapolation"""
    msg = f"Interpolating {len(data)} rows with extrapolation: {extrapolate}"
    Logger.debug(msg)
    if extrapolate:
        y = data.groupby(level=1).apply(
            lambda group: group.interpolate(limit_direction="both")
        )
    else:
        y = data.groupby(level=1).apply(
            lambda group: group.interpolate(limit_area="inside")
        )

    return y


def merge_dfs(dfs, how="inner"):
    """ Merge list of dfs by index """

    df = functools.reduce(
        lambda left, right: pd.merge(
            left, right, left_index=True, right_index=True, how=how
        ),
        dfs,
    )
    return df


def get_df_index_from_file(path: str):
    """ Get index from pandas dataframe in hdf5 file at path. """

    df = pd.read_hdf(path)
    index = df.index
    return index


def get_df_colnames_from_file(path: str):
    """ Get colnames from pandas dataframe in hdf5 file at path. """

    df = pd.read_hdf(path)
    colnames = list(df.columns)
    return colnames


def assert_df_has_multiindex(df):
    """ Make sure df has a MultiIndex """

    message = "A pandas object was expected to have a MultiIndex, but it don't"
    if not isinstance(df.index, pd.MultiIndex):
        raise RuntimeError(message)


def fill_forwards_backwards(df, varlist=False):
    """ Fill missing values by forwards then backwards filling, by group """

    # If no varlist is passed use all columns
    if not varlist:
        varlist = list(df.columns)

    assert_df_has_multiindex(df)
    df.sort_index(inplace=True)
    # group by groupvar and forward fill then backward fill
    df[varlist] = df[varlist].groupby(level=1).fillna(method="ffill")
    df[varlist] = df[varlist].groupby(level=1).fillna(method="bfill")
    return df


def generate_probs(n, seed=False, distribution="normal"):
    """ Generate vector of normal probabilities with length n"""

    def scale_to_0_1(y):
        """ Scale a vector to have values in range 0-1 """

        y = (y - np.min(y)) / (np.max(y) - np.min(y))
        return y

    if seed:
        np.random.seed(seed)  # pragma: no cover

    if distribution == "normal":
        y = np.random.normal(0, 1, n)
        y = scale_to_0_1(y)
    elif distribution == "uniform":
        y = np.random.uniform(0, 1, n)
    else:
        raise NotImplementedError

    return y


def generate_bools(n):
    """ Generate a vector of random bools of length n """

    allowed_values = [0, 1]
    y = np.random.choice(allowed_values, size=n)

    return y


def generate_counts(n, max_value=10):
    """ Generate a vector of positive integers """

    y = np.random.randint(low=0, high=max_value, size=n)

    return y


def generate_reals(n, min_value=-100, max_value=100, distribution="uniform"):
    """ Generate a vector of real numbers from distribution """

    if distribution == "uniform":
        y = np.random.uniform(size=n, low=min_value, high=max_value)
    else:
        raise NotImplementedError

    return y


def make_random_links(groups_h, groups_l, times=False):
    """ Return one random value of groups_l for each element in
    groups_h. The random value corresponds to a lower resolution id
    being assigned to a higher resolution id

    Args:
        groups_h: a list of groupvar values for high res
        groups_l: a list of groupvar values for low res
        times: optional list of times to multiply in to the groups list
    Returns:
        groups_links: A list of random values of group_l matching length
        of groups_h
    """

    np.random.seed(1)

    groups_links = []

    # make probabilities for each low level group
    groups_l_probs = generate_probs(n=len(groups_l))
    groups_l_probs = groups_l_probs / sum(groups_l_probs)

    for _ in groups_h:
        group_l = np.random.choice(groups_l, p=groups_l_probs)
        groups_links.append(group_l)

    # If times is
    if times:
        groups_links = itertools.repeat(groups_links, len(times))
        groups_links = pyutils.flatten_list(list(groups_links))
    else:
        pass

    return groups_links


# pylint: disable=too-many-instance-attributes
class DfMocker:
    """ Makes mock dataframes

    Args:
        n_t: Number of time periods
        n_groups: Number of individuals/groups
        n_cols: Number of data columns
        timevar: Name of timevar
        groupvar: Name of groupvar
        prefix: Prefix to add to column names
        datatypes (list): Allowed values: probs, bools, counts, reals
        seed: Random seed
    """

    # pylint: disable=too-many-arguments,too-many-locals
    def __init__(
        self,
        n_t=10,
        n_groups=5,
        n_cols=5,
        timevar="timevar",
        groupvar="groupvar",
        prefix=None,
        datatypes=None,
        seed=1,
    ):

        np.random.seed(seed)

        self.n_t = n_t
        self.n_groups = n_groups
        self.n_cols = n_cols
        self.n_rows = n_t * n_groups

        self.timevar = timevar
        self.groupvar = groupvar

        if not datatypes:
            datatypes = ["probs", "bools", "counts", "reals"]
        else:
            pass

        # Make the index
        idx = self.make_idx_from_n(
            n_t=self.n_t,
            n_groups=self.n_groups,
            timevar=self.timevar,
            groupvar=self.groupvar,
        )

        # distribute the cols between datatypes
        col_ids_per_datatype = np.array_split(
            range(self.n_cols), len(datatypes)
        )
        datadicts = []
        for datatype, col_ids in zip(datatypes, col_ids_per_datatype):
            n_cols_this_datatype = len(col_ids)
            datadicts.append(
                self.make_datadict(
                    n_cols_this_datatype, self.n_rows, datatype=datatype
                )
            )

        datadict = pyutils.merge_dicts(datadicts)

        self.df = pd.DataFrame(datadict, index=idx)
        self.df.sort_index(inplace=True)
        if prefix:
            self.df = self.df.add_prefix(prefix)

    @staticmethod
    def make_idx_from_n(n_t, n_groups, timevar="timevar", groupvar="group"):
        """ Create named Multiindex """
        times = list(range(n_t))
        groups = list(range(n_groups))

        idx_tuples = list(itertools.product(times, groups))
        idx = pd.MultiIndex.from_tuples(idx_tuples, names=(timevar, groupvar))
        return idx

    @staticmethod
    def make_idx_from_lists(times, groups, timevar="timevar", groupvar="group"):
        """ Create named Multiindex """

        idx_tuples = list(itertools.product(times, groups))
        idx = pd.MultiIndex.from_tuples(idx_tuples, names=(timevar, groupvar))
        return idx

    def make_datadict(self, n_cols=False, n_rows=False, datatype="probs"):
        """ Make a dict of vectors for df construction

        Args:
            n_cols: number of columns
            n_rows: number of rows
            datatype: "probs", "bools", "counts", "reals", default "probs".
                      specifies the type of data to put in the columns

        """

        def data_generator_switch(datatype):
            """ Switcher for datatype to corresponding generators """

            if datatype == "probs":
                generator = generate_probs
            elif datatype == "bools":
                generator = generate_bools
            elif datatype == "counts":
                generator = generate_counts
            elif datatype == "reals":
                generator = generate_reals
            else:
                msg = "unkown datatype: {}".format(datatype)
                raise RuntimeError(msg)

            return generator

        def set_prefix(datatype):
            """ Column prefix is just the first letter of datatype """

            prefix = datatype[0]

            return prefix

        if not n_cols:
            n_cols = self.n_cols
        if not n_rows:
            n_rows = self.n_rows

        datadict = {}
        data_generator = data_generator_switch(datatype)
        prefix = set_prefix(datatype)
        for _, letter in zip(range(n_cols), string.ascii_lowercase):
            data = data_generator(n_rows)
            name = "{}_{}".format(prefix, letter)
            datadict.update({name: data})

        return datadict


def resample(df, cols, share_positives, share_negatives, threshold=0):
    """ Resample a dataframe with respect to cols

    Resampling is a technique for changing the positive/negative balance
    of a dataframe. Positives are rows where any of the specified cols
    are greater than the threshold. Useful for highly unbalanced
    datasets where positive outcomes are rare.

    Args:
        df: input dataframe cols: which columns to consider as
            outcomes when downsampling can be a single column as string
            or list of strings
        share_positives: share of positive rows to return. 1 for
            all
        share_negatives: share of negative rows to return. 1 for all
    threshold: threshold value. "Positives" are values larger than this

    Returns:
        df: Dataframe with rows sampled according to parameters

    Raises: RuntimeError if cols is neither list nor string

    """

    def parse_cols(cols):
        """ If cols is a string cast it to a list of one, else do nothing


        If cols is neither string nor list, raise a RuntimeError"""

        if isinstance(cols, str):
            cols = [cols]
        elif isinstance(cols, list):
            pass
        else:
            msg = "{} is neither a string or a list".format(cols)
            raise RuntimeError(msg)

        return cols

    # If both shares are 1 just return the unaltered df
    if share_positives == 1 and share_negatives == 1:
        return df

    cols = parse_cols(cols)

    # Those rows where at least one of the cols are greater than threshold
    df_positives = df[(df[cols] > threshold).max(axis=1)]
    # it's inverse
    df_negatives = df[~(df[cols] > threshold).max(axis=1)]

    len_positives = len(df_positives)
    len_negatives = len(df_negatives)

    n_positives_wanted = int(share_positives * len_positives)
    n_negatives_wanted = int(share_negatives * len_negatives)

    replacement_pos = share_positives > 1
    replacement_neg = share_negatives > 1
    df = pd.concat(
        [
            df_positives.sample(n=n_positives_wanted, replace=replacement_pos),
            df_negatives.sample(n=n_negatives_wanted, replace=replacement_neg),
        ]
    )

    return df


def get_var_bounds(df, varname):
    """ Get the min-max-bounds of var from df as tuple """
    lower, upper = df[varname].min(), df[varname].max()
    plotvar_bounds = (lower, upper)
    return plotvar_bounds


def get_df_index_limits(df, indexvar):
    """ Get the min and max of indexvar """

    idx_var_values = df.index.get_level_values(indexvar)
    mini = int(idx_var_values.min())
    maxi = int(idx_var_values.max())

    return (mini, maxi)


def priogrid(lat, lon):
    """ Get pg_id from latitide and longitude """

    if not -90 <= lat <= 90:
        raise ValueError(f"Latitude {lat} out of bounds")
    if not -180 <= lon <= 180:
        raise ValueError(f"Longitude {lon} out of bounds.")

    lat_part = ((int((90 + (math.floor(lat * 2) / 2)) * 2) + 1) - 1) * 720
    lon_part = (180 + (math.floor(lon * 2) / 2)) * 2
    pg_id = lat_part + lon_part + 1

    return pg_id


# pylint: disable=too-many-arguments, too-many-locals
def balance_df_panel_index(
    df, timevar, groupvar, t_start=None, t_end=None, groupvars=None
):
    """ Balances the index of a dataframe to groups at t_end

    If a group appears between t_start and t_end it is "filled back"
    to t_start.
    If a group dissappears between t_start and t_end it is removed.

    Args:
        df: The dataframe to expand the index of
        timevar: column in dataframe to use as timevar
        groupvar: column in dataframe to use as groupvar
        t_start: first t of period to balance, defaults to first t in df
        t_end: last t of period to balance, defaults to last t in df
    Returns:
        df_balanced: a df with altered index columns
    """

    # Check if df has a multiindex already
    df_has_multiindex = isinstance(df.index, pd.MultiIndex)

    # Set it if we don't have it
    if not df_has_multiindex:
        df.set_index([timevar, groupvar], inplace=True)

    df.sort_index(inplace=True)

    # If no time limits are supplied use the min and max in the data
    if not t_start:
        t_start = int(df.index.get_level_values(timevar).min())
    if not t_end:
        t_end = int(df.index.get_level_values(timevar).max())

    # If not supplied, use the groupvars present at last t in data
    if not groupvars:
        groupvars = df.loc[t_end].index.get_level_values(groupvar)
        groupvars = sorted(list(groupvars))

    # Get list of times for the balanced period
    times_balanced = df.loc[t_start:t_end].index.get_level_values(timevar)
    times_balanced = sorted(list(set(times_balanced)))
    # new index of the balanced period
    idx_balanced = list(itertools.product(times_balanced, groupvars))

    t_start_prebalance = int(df.index.get_level_values(timevar).min())
    t_end_prebalance = t_start - 1

    # keep old index for pre-balance period
    idx_unbalanced = list(
        df.loc[t_start_prebalance:t_end_prebalance].index.values
    )

    # idx_old = list(df.index)
    idx_new = sorted(list(idx_balanced + idx_unbalanced))

    # idx_old_not_in_new = sorted(list(set(idx_old) - set(idx_new)))
    # idx_new_not_in_old = sorted(list(set(idx_new) - set(idx_old)))

    # Select the rows by this new index to a new df
    df_balanced = df.loc[idx_new]

    # Another sort for good measure
    df_balanced.sort_index(inplace=True)

    # Respect that df had no multiindex set when we got it
    if not df_has_multiindex:
        df_balanced.reset_index(inplace=True)

    # delta_rows = len(df_balanced) - len(df)

    return df_balanced


def nan_to_mean(df):
    """ Impute NaN to group-level (first) or global means. """

    for col in df.columns:
        # impute with group level mean
        df[col].fillna(df.groupby(level=1)[col].transform("mean"), inplace=True)
        # fill remaining NaN with df level mean
        df[col].fillna(df[col].mean(), inplace=True)

    return df


def df_is_balanced(df):
    """ Return True if df is a balanced panel, else False

    Uses a naive approach that number of times in index multiplied by
    number of groups in index should equal number of rows.
    @TODO: Make less naive and check all times exist for all groups.

    """
    assert_df_has_multiindex(df)
    n_t = len(df.index.levels[0])
    n_g = len(df.index.levels[1])

    return len(df) == n_t * n_g


def make_df_with_mindex(times: List[int], groups: List[int]) -> pd.DataFrame:
    """ Return an empty panel dataframe indexed with times, groups """
    return pd.DataFrame(
        index=pd.MultiIndex.from_tuples(itertools.product(times, groups))
    ).sort_index()
