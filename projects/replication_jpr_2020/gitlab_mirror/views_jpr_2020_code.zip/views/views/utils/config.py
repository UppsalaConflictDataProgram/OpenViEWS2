""" Config module to read environment specific config for host """

import os
import json

from views.utils import pyutils


def is_production():
    """ Determine if this is production """

    default_mode = "test"
    env_var_name = "VIEWS_MODE"

    # If mode environment variable is set use it
    if env_var_name in os.environ.keys():
        env_var_val = os.environ[env_var_name]

        # Check is "prod" or "test"
        allowed_modes = ["prod", "test"]
        if env_var_val not in allowed_modes:
            msg = f"{env_var_name} must be prod or test, not {env_var_val}"
            raise RuntimeError(msg)

        mode = env_var_val

    # If the environment var isn't set assume we're testing.
    else:
        mode = default_mode

    # Set the production bool
    if mode == "prod":
        production = True
    elif mode == "test":
        production = False
    else:
        raise RuntimeError()

    return production


def load_config():
    """ Load config from home dir """

    def load_default_dir():
        path_config = "~/.views/config.json"
        path_secrets = "~/.views/secrets.json"
        path_config = os.path.expanduser(path_config)
        path_secrets = os.path.expanduser(path_secrets)

        with open(path_config, "r") as f:
            config = json.load(f)
        with open(path_secrets, "r") as f:
            secrets = json.load(f)

        return config, secrets

    config, secrets = load_default_dir()

    if is_production():
        config = config["prod"]
    else:
        config = config["test"]

    # Resolve any ~'s or env vars in the 'dirs' paths
    for key in config["dirs"]:
        config["dirs"][key] = pyutils.resole_vars_and_home(config["dirs"][key])

    # Resolve any ~'s or env vars in the references to certs
    if "connect_args" in config["db"]:
        for key in config["db"]["connect_args"]:
            path = config["db"]["connect_args"][key]
            path = pyutils.resole_vars_and_home(path)
            config["db"]["connect_args"][key] = path

    return config, secrets


CONFIG, SECRETS = load_config()
