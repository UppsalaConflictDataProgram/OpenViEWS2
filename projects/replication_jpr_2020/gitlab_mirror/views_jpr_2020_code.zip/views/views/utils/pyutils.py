""" General Python Utilities """
import copy
import functools
import itertools
import json
import logging
import os
import re
import shutil
import string
import subprocess
import time
import warnings

import yaml

LOGFORMAT = "[%(asctime)s] - %(name)s:%(lineno)d - %(levelname)s - %(message)s"

Logger = logging.getLogger(__name__)

def delete_file(path):
    if os.path.exists(path):
        os.remove(path)
        Logger.info(f"Deleted {path}")
    else:
        Logger.info(f"Nothing to delete at {path}")

def scp_upload_file(path_local, host, path_remote):
    cmd = ["scp", path_local, f"{host}:{path_remote}"]
    run_subproc(cmd)

def scp_fetch_file(host, path_remote, path_local):
    cmd = ["scp", f"{host}:{path_remote}", path_local]
    run_subproc(cmd)

def debug_timer(func):
    """Log to debug the runtime of the decorated function"""

    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.perf_counter()
        value = func(*args, **kwargs)
        end_time = time.perf_counter()
        run_time = end_time - start_time
        Logger.debug(f"Ran {func.__name__!r} in {run_time:.4f} secs")
        return value

    return wrapper_timer


def get_nested_dict_values(nested_dict):
    """ Get all values from nested dicts

    Source: https://stackoverflow.com/a/31439438
    """

    def inner(nested_dict):
        """ Recursive function that yields values from dicts """
        for val in nested_dict.values():
            if isinstance(val, dict):
                yield from inner(val)
            else:
                yield val

    return list(inner(nested_dict))


def copy_file_to_dir(path_file, path_dir):
    """ Copy a file to a directory """
    destination = os.path.join(path_dir, os.path.basename(path_file))
    shutil.copy2(src=path_file, dst=destination)
    Logger.info(f"Copied {path_file} to {destination}")


def copy_file(path_src, path_dst):
    """ Copy file from path_src to path_dst """
    path_src = resole_vars_and_home(path_src)
    path_dst = resole_vars_and_home(path_dst)
    shutil.copy2(path_src, path_dst)
    Logger.info(f"Copied {path_src} to {path_dst}")


def run_subproc(cmd):
    """ Run cmd in subprocess and log output to debug """

    Logger.info(f"Running cmd: {cmd}")
    with subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
        universal_newlines=True,
    ) as p:
        for line in p.stdout:
            Logger.info(line.strip("\n"))

    if p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, p.args)


def fname_matches_pattern(path, pattern):
    """ True if the name of file at path matches pattern

    Useful for filters.

    Args:
        path: path to a file
        pattern: regex pattern
    Returns: True if fname at path matches regex pattern, else False

    """
    return bool(re.match(pattern, os.path.basename(path)))


def get_paths_from_dir(path_dir):
    """ Get list of paths to files below path_dir """

    if not os.path.isdir(path_dir):
        raise RuntimeError(f"{path_dir} is not a directory")

    paths = []
    for root, _, files in os.walk(path_dir):
        for file in files:
            path = os.path.join(root, file)
            paths.append(path)
    return sorted(paths)


def chunker(seq, size):
    """Returns seq as an iterable over chunks of seq of size.
    Used for splitting ranges of rows in an array into subsets.
    """
    return (seq[pos : pos + size] for pos in range(0, len(seq), size))


def resole_vars_and_home(path):
    """ Resolve environment variables and home directory ~ from path """
    path = os.path.expanduser(path)
    path = os.path.expandvars(path)
    return path


def subset_dict(original_dict, keys):
    """ Subset a dictionary by keys """
    return {k: original_dict[k] for k in keys}


def flatten_list(nested_list, warn_not_nested=True):
    """ Return a flat list if given a list of lists"""

    # Warn if none of the list elements are a actually list
    if warn_not_nested:
        if not any(isinstance(element, list) for element in nested_list):
            warnings.warn("A flat list was passed to flatten_list()")

    # While we still have lists left in the nested list
    while any(isinstance(element, list) for element in nested_list):
        # Unpack that list
        nested_list = list(itertools.chain.from_iterable(nested_list))

    # Now we don't have any lists left in the "nested" list, say its flat
    flat_list = nested_list

    try:
        flat_list = sorted(flat_list)
    except TypeError:
        pass

    return flat_list


def dedup_list(this_list):
    """ Remove duplicates from list """
    deduped_list = sorted(list(set(this_list)))

    return deduped_list


def merge_dicts(list_of_dicts):
    """ Merge a list of dictionaries to one dictionary.

    If duplicate keys are found raise a RuntimeError
    """

    def has_duplicate_keys(list_of_dicts):
        """ Return True if dicts in list have duplicate keys """

        has_duplicates = False
        keys = []

        for this_dict in list_of_dicts:
            for key in this_dict:
                if key in keys:  # pylint: disable=no-else-return, no-else-break
                    has_duplicates = True
                    break
                else:
                    keys.append(key)

        return has_duplicates

    if has_duplicate_keys(list_of_dicts):
        msg = "Duplicate keys found"
        raise RuntimeError(msg)

    merged = {}
    for this_dict in list_of_dicts:
        merged.update(this_dict)

    return merged


def get_prefixes(n):
    # @TODO: Come up with better solution for filtering out bad prefixes
    """ Get a list of short strings, useful as prefixes. LIMITED AT 576"""

    if n > 576:
        msg = "Don't use get_prefixes() with n>576, n={}".format(n)
        raise RuntimeError(msg)

    abc = string.ascii_lowercase
    combined = list(itertools.product(abc, abc))

    # Remove SQL keywords
    keywords = [
        "as",
        "at",
        "by",
        "do",
        "go",
        "in",
        "is",
        "ln",
        "no",
        "of",
        "on",
        "or",
        "to",
    ]
    for keyword in keywords:
        word = (keyword[0], keyword[1])
        if word in combined:
            combined.remove(word)

    prefixes = ["{}{}".format(word[0], word[1]) for word in combined[:n]]

    return prefixes


def create_dir(path):  # pragma: no cover
    """ Create a dir at path if it doesn't exist """
    path = resole_vars_and_home(path)
    if not os.path.isdir(path):
        os.makedirs(path)
        Logger.debug(f"Created dir {path}")


def delete_dir(path):
    """ Delete dir at path if it exists """

    if os.path.isdir(path):
        shutil.rmtree(path)
        Logger.debug(f"Deleted dir {path}")
    elif os.path.isfile(path):
        msg = f"delete_dir() was called on file {path}, only dirs allowed."
        raise RuntimeError(msg)


def match_var(var, matchings):
    """ Match var to 'contains' key in matchings dict """

    matches = []
    for match in matchings:
        if match["contains"] in var:
            matches.append(match["match"])

    # More than one match
    if len(matches) > 1:
        msg = "Found multiple matches for {var}: {matches}"
        raise RuntimeError(msg)
    # Exactly one match
    elif len(matches) == 1:
        this_match = matches[0]
    # No matches
    elif not matches:
        this_match = None

    return this_match


def deep_copy_params(to_call):
    """ Deep copy all params to a function, suitable as decorator """

    def f(*args, **kwargs):
        return to_call(
            *(copy.deepcopy(x) for x in args),
            **{k: copy.deepcopy(v) for k, v in kwargs.items()},
        )

    return f


def load_yaml(path):
    """ Loads a YAML files contents from path """

    path = resole_vars_and_home(path)
    with open(path, "r") as yaml_file:
        content = yaml.safe_load(yaml_file)
    Logger.debug(f"Read YAML at {path}")
    return content


def load_json(path):
    """ Loads a JSON files contents from path """

    path = resole_vars_and_home(path)
    with open(path, "r") as f:
        content = json.load(f)
    Logger.debug(f"Read JSON at {path}")
    return content


def write_json(content, path):
    """ Writes content to a JSON file """

    path = resole_vars_and_home(path)
    with open(path, "w") as f:
        json.dump(content, f, indent=2)
    Logger.debug(f"Wrote JSON to {path}")

def write_str(to_write, path):
    with open(path, "w") as f:
        f.write(to_write)
    Logger.info(f"Wrote {path}")

def pprint(content):
    """ Pretty print a JSON-serializable dict """

    print("#" * 80)
    print(json.dumps(content, indent=2))
