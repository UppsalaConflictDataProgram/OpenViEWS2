""" dbutils provides database utilities for a PostgreSQL database

@TODO: query_to_df **params for sqlalchemy text bindparams
@TODO: Rewrite as class so we can instantiate multiple db connections

"""
import os
import json
import logging
import csv
from io import StringIO
import tempfile

import geopandas as gpd
import pandas as pd
import psycopg2
import sqlalchemy

from views.utils import pyutils
from views.utils.config import CONFIG

Logger = logging.getLogger(__name__)

CONNECTSTRING = CONFIG["db"]["connectstring"]
VERBOSE = False


def create_table_index(fqtable, cols, unique=False):
    """ Create index on fqtable on cols in cols """

    comma_sep_cols = ", ".join(cols)
    if unique:
        q = f"CREATE UNIQUE INDEX ON {fqtable}({comma_sep_cols});"
    else:
        q = f"CREATE INDEX ON {fqtable}({comma_sep_cols});"
    Logger.debug(f"create_table_index(): {q}")
    execute_query(q)


def make_engine():  # pragma: no cover
    """ Create an sqlalchemy engine

    @TODO: Fix saner db connection config
    """

    if "connect_args" in CONFIG["db"].keys():
        connect_args = CONFIG["db"]["connect_args"]
        engine = sqlalchemy.create_engine(
            CONNECTSTRING, echo=VERBOSE, connect_args=connect_args
        )
        msg = (
            f"make_engine() {CONNECTSTRING} "
            f"with args: {json.dumps(connect_args)}"
        )
        Logger.debug(msg)

    else:
        engine = sqlalchemy.create_engine(CONNECTSTRING, echo=VERBOSE)
        msg = f"make_engine() {CONNECTSTRING}"
        Logger.debug(msg)

    return engine


def drop_db(db_name):
    """ Drop database """

    Logger.info(f"Dropping database {db_name}")
    host = CONFIG["db"]["host"]
    user = CONFIG["db"]["user"]
    with psycopg2.connect(database="template1", host=host, user=user) as conn:
        with conn.cursor() as cur:
            conn.autocommit = True
            cur.execute(f"DROP DATABASE IF EXISTS {db_name}")
    Logger.info(f"Finished dropping database {db_name}")


def create_db(db_name):
    """ Create database """

    Logger.info(f"Creating database {db_name}")
    host = CONFIG["db"]["host"]
    user = CONFIG["db"]["user"]
    with psycopg2.connect(database="template1", host=host, user=user) as conn:
        with conn.cursor() as cur:
            conn.autocommit = True
            cur.execute(f"CREATE DATABASE {db_name}")
    Logger.info(f"Finished creating database {db_name}")


def init_postgis():
    """ Initalise PostGIS extension """

    Logger.info(f"Initialising PostGIS")
    query = """
    -- Enable PostGIS (includes raster)
    CREATE EXTENSION postgis;
    """

    execute_query(query)

    Logger.info(f"Finished Initialising PostGIS")


# @TODO: Test this properly then replace db_to_df with it
def db_to_df_fast(fqtable, columns=None, ids=None):
    """ Read fqtable from db using COPY to tempfile for speed

    Args:
        fqtable: fully qualifed tablename like schemaname.tablename
        columns: list of columns to fetch, fetches all if None
        ids: set index using these colums, default index if None
    Returns:
        df:
    """

    def read_sql_tmpfile(query):

        db_engine = make_engine()
        with tempfile.TemporaryFile() as tmpfile:
            copy_sql = "COPY ({query}) TO STDOUT WITH CSV {head}".format(
                query=query, head="HEADER"
            )
            conn = db_engine.raw_connection()
            cur = conn.cursor()
            cur.copy_expert(copy_sql, tmpfile)
            tmpfile.seek(0)
            df = pd.read_csv(tmpfile)
        return df

    Logger.debug(f"Fetching {fqtable}")
    # @TODO: When columns is empty list it is not passed, fix
    # if we have ids supplied then add them to the list of cols to get
    if columns and ids:
        columns = columns + ids
        columns = pyutils.dedup_list(columns)

    if not columns:
        columns = list_columns(fqtable)

    comma_separated_cols = ", ".join(columns)
    query = f"SELECT {comma_separated_cols} FROM {fqtable}"
    df = read_sql_tmpfile(query)

    if ids:
        df.set_index(ids, inplace=True)
        df.sort_index(inplace=True)

    return df


def db_to_df(fqtable, columns=None, ids=None):
    """Read a table from the database and return as pandas DataFrame

    Args:
        fqtable: fully qualifed tablename like schemaname.tablename
        columns: list of columns to fetch, fetches all if None
        ids: set index using these colums, default index if None
    Returns:
        df:
        """

    Logger.info(f"Fetching {fqtable}")
    engine = make_engine()

    # @TODO: When columns is empty list it is not passed, fix
    # if we have ids supplied then add them to the list of cols to get
    if columns and ids:
        columns = columns + ids
        columns = pyutils.dedup_list(columns)

    schema, table = unpack_fqtable(fqtable)
    df = pd.read_sql_table(
        table_name=table, con=engine, schema=schema, columns=columns
    )

    if ids:
        df.set_index(ids, inplace=True)
        df.sort_index(inplace=True)

    Logger.info("Fetched table %s", fqtable)
    return df


# pylint
def df_to_db(
    df,
    fqtable,
    if_exists="replace",
    write_index=True,
    copy=True,
    drop_cascade=False,
):
    """Pushes a pandas dataframe to table
    Args:
        df:
        schema:
        table:
        if_exists: 'fail', 'replace', 'append'
        write_index:
    Returns:
        None
    """

    def fqtable_exists(fqtable):
        """ True if fqtable exists """
        schema, table = unpack_fqtable(fqtable)
        return table in list_tables_in_schema(schema)

    def psql_insert_copy(table, conn, keys, data_iter):
        """ Alternative to_sql() *method* for DBs that support COPY FROM

        See: https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html
        """

        # gets a DBAPI connection that can provide a cursor
        dbapi_conn = conn.connection
        with dbapi_conn.cursor() as cur:
            s_buf = StringIO()
            writer = csv.writer(s_buf)
            writer.writerows(data_iter)
            s_buf.seek(0)

            columns = ", ".join('"{}"'.format(k) for k in keys)
            if table.schema:
                table_name = "{}.{}".format(table.schema, table.name)
            else:
                table_name = table.name

            sql = "COPY {} ({}) FROM STDIN WITH CSV".format(table_name, columns)
            cur.copy_expert(sql=sql, file=s_buf)

    def sqlcol(dfparam):  # pragma: no cover
        """Matches pandas datatypes to their sqlalchemy equivalents,
        returns the mapping as a dict"""

        dtypedict = {}
        for i, j in zip(dfparam.columns, dfparam.dtypes):
            if "object" in str(j):
                dtypedict.update({i: sqlalchemy.types.VARCHAR()})

            if "datetime" in str(j):
                dtypedict.update({i: sqlalchemy.types.DateTime()})

            # Underflow errors can happen when precision is set
            if "float" in str(j):
                dtypedict.update({i: sqlalchemy.types.Float(asdecimal=True)})

            if "int" in str(j):
                dtypedict.update({i: sqlalchemy.types.INT()})

        return dtypedict

    typedict = sqlcol(df)

    engine = make_engine()

    if drop_cascade:
        execute_query(f"DROP TABLE IF EXISTS {fqtable} CASCADE;")

    schema, table = unpack_fqtable(fqtable)
    Logger.debug(f"Pushing {len(df)} rows to {schema}.{table}")

    # @TODO: Cleanup
    if copy:
        df.to_sql(
            name=table,
            con=engine,
            if_exists=if_exists,
            schema=schema,
            index=write_index,
            dtype=typedict,
            chunksize=10000,
            method=psql_insert_copy,
        )
    else:
        df.to_sql(
            name=table,
            con=engine,
            if_exists=if_exists,
            schema=schema,
            index=write_index,
            dtype=typedict,
            chunksize=10000,
        )

    Logger.info(f"Pushed to {fqtable}")


def get_query_rows(query, **params):
    """ Get result rows of query as a list """

    response = execute_query(query, **params)

    result_rows = []
    for row in response:
        result_rows.append(row)

    return result_rows


def get_query_rows_from_file(path, **params):
    """ Get result rows of query at path, optionally bind **params to query """

    with open(path, "r") as f:
        query = f.read()

    result_rows = get_query_rows(query, **params)

    return result_rows


def execute_query(query, **params):
    """ Execute a query

    Args:
        query: SQL query string, can include SQLAlchemy parameters
        **params: dict of parameter bindings
    Returns:
        response: Iterable response

    """

    Logger.debug(
        f"Executing query \n{query} \nwith params {json.dumps(params)}"
    )

    engine = make_engine()

    query = sqlalchemy.sql.text(query)

    if params:
        query = query.bindparams(**params)

    # engine.begin() rolls the entire query execution into a transaction block
    # as opposed to engine.connect()
    # engine.begin() saves us from manually placing COMMIT in our queries.
    # I'm note 100% on the differences here
    with engine.begin() as con:
        response = con.execute(query)

    return response


# @TODO: Figure out param parsing consistently
def execute_query_from_file(path, **params):
    """ Execute query from file at path, optionally bind **params to query """

    if not params:
        params = dict()
    Logger.info(f"Read query from {path}")
    with open(path, "r") as f:
        query = f.read()

    response = execute_query(query, **params)

    return response


def count_rows(fqtable):
    """ Return the number of rows in fqtable """

    query = f"SELECT COUNT(*) as n_rows FROM {fqtable}"
    response = execute_query(query)

    for row in response:
        n_rows = row["n_rows"]

    return n_rows


def recreate_schema(schema):
    """ Drop schema and create it again """
    drop_schema(schema)
    query_create = f"CREATE SCHEMA {schema};"
    execute_query(query_create)


def drop_schema(schema):
    """ Drop a schema and all its tables """
    query = f"DROP SCHEMA IF EXISTS {schema} CASCADE;"
    execute_query(query)


def drop_table(fqtable):
    """ Drop the table if it exists """
    query = f"DROP TABLE IF EXISTS {fqtable};"
    execute_query(query)


def drop_view(fqview):
    """ Drop a view if it exists """
    query = f"DROP VIEW IF EXISTS {fqview} CASCADE;"
    execute_query(query)


def query_to_df(query):
    """ Return DataFrame from SELECT query

    Given a valid SQL SELECT query, return a Pandas DataFrame
    with the response data.

    Args:
        query: Valid SQL, containing a SELECT query
    Returns:
        df: A Pandas DataFrame containing the response of query


    """

    engine = make_engine()

    df = pd.read_sql_query(sql=query, con=engine)

    return df


def list_columns(fqtable):
    """ Get list of all columns in a table """

    query = "SELECT * FROM {} LIMIT 1;".format(fqtable)
    df = query_to_df(query)
    cols = list(df.columns)

    return cols


def list_tables_in_schema(schema):
    """ List all tables in a schema """

    query = """
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = '{}';"""
    query = query.format(schema)

    df = query_to_df(query)

    tables = list(df["table_name"].values)
    tables = sorted(tables)

    fqtables = [pack_fqtable(schema, table) for table in tables]

    return fqtables


def list_views_in_schema(schema):
    """ List all views in a schema """

    query = f"""
    SELECT table_name
    FROM INFORMATION_SCHEMA.views
    WHERE
    table_schema = '{schema}';"""

    df = query_to_df(query)

    views = list(df["table_name"].values)
    views = sorted(views)

    fqviews = [pack_fqtable(schema, view) for view in views]

    return fqviews


def list_schemas_in_db():
    """ Get list of schemas in database """
    query = "select schema_name from information_schema.schemata;"
    df = query_to_df(query)
    schemas = list(df["schema_name"].values)
    schemas = sorted(schemas)

    return schemas


def _build_selects_join(table_specs, tables):
    """ Build the select column list part of the query

    @TODO: Test
    """
    sep = ",\n"
    selects = []
    spec_base = table_specs[tables[0]]
    prefix_base = spec_base["prefix"]

    for col_id in spec_base["cols_ids"]:
        select_id = f"{prefix_base}.{col_id}"
        selects.append(select_id)

    for spec in table_specs:
        prefix = table_specs[spec]["prefix"]
        cols_data = table_specs[spec]["cols_data"]
        these_selects = ["{}.{}".format(prefix, col) for col in cols_data]
        these_selects = sep.join(these_selects)
        selects.append(these_selects)
    selects = sep.join(selects)

    return selects


def _build_joins(specs, tables, ids, how="INNER"):
    """ Build the join part of the query

    @TODO: Test

    """
    # pylint: disable=too-many-locals

    # Use the first table as base
    spec_base = specs.pop(tables[0])
    prefix_base = spec_base["prefix"]

    first = "FROM {} AS {} \n".format(tables[0], prefix_base)

    query_parts = []
    for name in specs:
        prefix = specs[name]["prefix"]
        part_one = f"{how} JOIN {name} AS {prefix} ON"

        matchers = []
        for col_id in ids:
            matcher = f"{prefix_base}.{col_id}={prefix}.{col_id}"
            matchers.append(matcher)
        part_two = "\nAND\n".join(matchers)

        query_parts.append(part_one)
        query_parts.append(part_two)

    query_parts = "\n".join(query_parts)

    query = first + query_parts

    return query


def _build_table_specs(tables, ids):
    """ Build a spec dict for each table

    @TODO: Test
    """
    specs = {}
    for table in tables:

        # init a key for this table
        specs[table] = {}

        # Get the data columns for the table
        cols_all = list_columns(table)

        # Sort the cols into either data or ids
        cols_data = []
        cols_ids = []
        for col in cols_all:
            if col in ids:
                cols_ids.append(col)
            else:
                cols_data.append(col)

        info = {"cols_data": cols_data.copy(), "cols_ids": cols_ids.copy()}
        specs[table].update(info)

    return specs


def build_query_joined_tablecollection(
    name, ids, tables, type_collection="view", how="INNER"
):
    """ Query that creates a view or table of the join of tables on ids

    @TODO: Refactor.
    """

    type_collection = type_collection.upper()
    message = "type_collection must be view or table"
    assert type_collection in ["VIEW", "TABLE"], message

    # specs is a dict that holds a dict for each table
    specs = _build_table_specs(tables, ids)

    # Add table prefixes for the join
    prefixes = pyutils.get_prefixes(len(tables))
    for spec_key, prefix in zip(specs, prefixes):
        specs[spec_key].update({"prefix": prefix})

    query_head = f"CREATE {type_collection} {name} AS SELECT"
    selects = _build_selects_join(specs, tables)
    joins = _build_joins(specs, tables, ids, how=how)

    query = "\n".join([query_head, selects, joins, ";"])

    return query


def create_joined_view(name, ids, tables, if_exists="replace"):
    """ Create a view of joined tables on ids """

    query = build_query_joined_tablecollection(
        name, ids, tables, type_collection="VIEW"
    )

    if if_exists == "replace":
        drop_view(name)
    else:
        pass

    execute_query(query)


def create_joined_table(name, ids, tables, if_exists="replace", how="INNER"):
    """ Create a table of joined tables on ids """

    query = build_query_joined_tablecollection(
        name, ids, tables, type_collection="TABLE", how=how
    )

    if if_exists == "replace":
        drop_table(name)
    else:
        pass

    execute_query(query)

    Logger.info(f"Created joined table {name}")


def unpack_fqtable(fqtable):
    """ returns schema, table from "schema.table" """

    schema, table = fqtable.split(".")

    # Postgres don't like mIxEd cAsE, all lower please
    return schema.lower(), table.lower()


def pack_fqtable(schema, table):
    """ returns schema, table from "schema.table" """

    # Postgres don't like mIxEd cAsE, all lower please
    fqtable = "{}.{}".format(schema.lower(), table.lower())

    return fqtable


def create_full_outer_joined_view(name, ids, tables):
    """ Create a VIEW of the full outer join of tables

    All tables must have the same unique identifier cols (ids).
    Different coverage of tables is OK.

    Args:
        name: schema.view_name to create
        ids: list of columns to join by
        tables: list of tables to join


    """
    # pylint: disable=too-many-locals
    def build_joins_outer(specs, tables, ids):
        """ Build the join part of the query """

        # Use the first table as base
        spec_base = specs.pop(tables[0])
        prefix_base = spec_base["prefix"]

        first = "FROM {} AS {} \n".format(tables[0], prefix_base)

        query_parts = []
        prefixes_previous = [prefix_base]
        for name in specs:
            prefix = specs[name]["prefix"]
            part_one = f"FULL OUTER JOIN {name} AS {prefix} ON"

            matchers = []
            for col_id in ids:
                previous_prefixes_ids = [
                    f"{prefix_prev}.{col_id}"
                    for prefix_prev in prefixes_previous
                ]
                str_prev = ", ".join(previous_prefixes_ids)
                matcher = f"{prefix}.{col_id}=coalesce({str_prev})"
                matchers.append(matcher)
            part_two = "\nAND\n".join(matchers)

            query_parts.append(part_one)
            query_parts.append(part_two)
            prefixes_previous.append(prefix)

        query_parts = "\n".join(query_parts)

        query = first + query_parts

        return query

    def build_selects_join_outer(table_specs, tables):
        """ Build the select column list part of the query """
        sep = ",\n"
        selects = []
        spec_base = table_specs[tables[0]]

        for col_id in spec_base["cols_ids"]:
            prefixes = [spec["prefix"] for spec in table_specs.values()]
            prefix_ids = [f"{prefix}.{col_id}" for prefix in prefixes]
            prefix_ids = ", ".join(prefix_ids)
            col_id = f"coalesce({prefix_ids}) AS {col_id}"
            selects.append(col_id)

        for spec in table_specs:
            prefix = table_specs[spec]["prefix"]
            cols_data = table_specs[spec]["cols_data"]
            these_selects = ["{}.{}".format(prefix, col) for col in cols_data]
            these_selects = sep.join(these_selects)
            selects.append(these_selects)
        selects = sep.join(selects)

        return selects

    specs = _build_table_specs(tables, ids)

    prefixes = pyutils.get_prefixes(len(tables))

    for spec_key, prefix in zip(specs, prefixes):
        specs[spec_key].update({"prefix": prefix})

    query_head = f"CREATE VIEW {name} AS SELECT"
    selects = build_selects_join_outer(table_specs=specs, tables=tables)
    joins = build_joins_outer(specs, tables, ids)

    query = "\n".join([query_head, selects, joins, ";"])
    drop_view(fqview=name)
    execute_query(query)


# pylint: disable=too-many-arguments
def get_downsampled_table(
    fqtable, cols, col_samp, share_zeros, timevar, groupvar, t_start, t_end
):
    """ Get fqtable with database-side downsampling """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_queries = os.path.join(this_dir, "queries")
    path_query = os.path.join(dir_queries, "downsampled_table.sql")

    for id_col in [timevar, groupvar]:
        if not id_col in cols:
            cols.append(id_col)

    with open(path_query, "r") as f:
        query = f.read()

    query = query.format(
        fqtable=fqtable,
        comma_sep_cols=", ".join(cols),
        col_samp=col_samp,
        share_zeros=share_zeros,
        timevar=timevar,
        t_start=t_start,
        t_end=t_end,
    )

    df = query_to_df(query)
    df.set_index([timevar, groupvar], inplace=True)

    return df


def register_funcs():
    """ Register functions from dbutils/queries/functions.sql """
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(this_dir, "queries", "functions.sql")
    execute_query_from_file(path)


def db_to_gdf(query, groupvar):
    """ Read geopandas dataframe from query and assign groupvar index

    Ex:
        gdf_geom = db_to_gdf(
        query="SELECT pg_id, geom FROM staging.priogrid",
        groupvar="pg_id"
        )

    """

    msg = f"Fetching geometry with query: {query} groupvar: {groupvar}"
    Logger.info(msg)
    gdf = gpd.read_postgis(sql=query, con=make_engine(), geom_col="geom")
    gdf = gdf.set_index(keys=[groupvar])
    gdf.sort_index(inplace=True)

    Logger.info(f"Finished fetching geometry")

    return gdf
