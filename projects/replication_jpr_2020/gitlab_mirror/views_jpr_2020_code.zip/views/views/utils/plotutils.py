""" Plotting utilities """


class ScalableBox:
    """ A scalable box, useful when placing graphics """

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.aspect_ratio = self.width / self.height

    def __str__(self):
        stri = f"width: {self.width} \th:{self.height} \tar:{self.aspect_ratio}"
        return stri

    def scale_to_target_w(self, width):
        """ Scale to a target width """
        self.width = width
        self.height = width / self.aspect_ratio

    def scale_to_target_h(self, height):
        """ Scale to a target height """
        self.height = height
        self.width = height * self.aspect_ratio
