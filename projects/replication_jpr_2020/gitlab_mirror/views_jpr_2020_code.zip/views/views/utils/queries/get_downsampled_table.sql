SELECT {comma_sep_cols}
FROM {fqtable}
WHERE {depvar} = 1
AND
{timevar} BETWEEN {t_start}  AND {t_end}
UNION ALL
(
SELECT {comma_sep_cols}
FROM {fqtable}
WHERE {depvar} = 0
AND
{timevar} BETWEEN {t_start} AND {t_end}
ORDER BY RANDOM()
LIMIT (
    SELECT {share_zeros}*count(*)
    FROM {fqtable}
    WHERE {depvar}=0
    AND {timevar} BETWEEN {t_start} AND {t_end})
)
;