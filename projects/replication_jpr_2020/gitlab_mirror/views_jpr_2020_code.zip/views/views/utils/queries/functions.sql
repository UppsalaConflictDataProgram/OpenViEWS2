-- takes a date and returns the date of the last day in that month
-- example: last_day_month('2012-08-12'::date) -> '2012-08-31'
-- date -> date

CREATE OR REPLACE FUNCTION last_day_month(date) RETURNS date AS
$$
select (date_trunc('month', $1) + interval '1 month -1 day')::date;
$$
LANGUAGE SQL
IMMUTABLE
RETURNS NULL ON NULL INPUT;


-- Last Obseration Carried Forward
CREATE OR REPLACE FUNCTION locf_state( FLOAT, FLOAT )
RETURNS FLOAT
LANGUAGE SQL
AS $f$
  SELECT COALESCE($2,$1)
$f$;



DROP AGGREGATE IF EXISTS locf(FLOAT);
CREATE AGGREGATE locf(FLOAT) (
  SFUNC = locf_state,
  STYPE = FLOAT
);

-- Source: https://stackoverflow.com/questions/29612441/impute-via-fill-forward-locf-a-column-over-a-range-of-sequential-rows-in-sql
-- Example:
-- SELECT pg_id, year,
--        locf(gwno) OVER( PARTITION BY pg_id ORDER BY year)
-- FROM   staging.priogrid_year;


CREATE OR REPLACE FUNCTION priogrid(float, float) RETURNS integer AS
'SELECT ((((90 + (floor($1*2)/2))*2)::int+1)-1)*720 + ((180+(floor($2*2)/2))*2)::int + 1;'
LANGUAGE SQL
IMMUTABLE
RETURNS NULL ON NULL INPUT;