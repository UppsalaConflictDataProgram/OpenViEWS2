import logging
import os
import subprocess

Logger = logging.getLogger(__name__)

def get_fnames(host, dir_remote):
    res = subprocess.run(
        ["ssh", host, "ls", dir_remote],
        check=True,
        capture_output=True,
        text=True,
        )

    return [fname for fname in res.stdout.split("\n") if fname]

def get_remote_paths(host, dir_remote):
    fnames = get_fnames(host, dir_remote)
    return [os.path.join(dir_remote, fname) for fname in fnames]

def scp_file(host, path_remote, path_local):
    remote_adress = f"{host}:{path_remote}"
    Logger.info(f"SCP started copying {remote_adress} to {path_local}")
    subprocess.run(
        ["scp", remote_adress , path_local],
        check=True,
        )
    Logger.info(f"SCP fininshed copying {remote_adress} to {path_local}")