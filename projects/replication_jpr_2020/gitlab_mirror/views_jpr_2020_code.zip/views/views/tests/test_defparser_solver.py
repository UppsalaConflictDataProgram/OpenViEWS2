""" Test apps/defparser/solver.py """

import json
import os
import unittest

from views.utils import pyutils
from views.apps.defparser import solver


class TestDefparserSolver(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        this_dir = os.path.dirname(os.path.abspath(__file__))
        dir_data = os.path.join(this_dir, "data", "defparser")
        self.specs = pyutils.load_yaml(os.path.join(dir_data, "specs.yaml"))
        self.defis = pyutils.load_yaml(os.path.join(dir_data, "defis.yaml"))
        self.tasks = pyutils.load_yaml(os.path.join(dir_data, "tasks.yaml"))

    def test_defis_datasets(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["datasets"]
        got = solver.defis_datasets(self.specs)
        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_models(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["models"]
        got = solver.defis_models(self.specs)
        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_trains(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["trains"]

        # Give defis_trains only info on datasets and models
        defis_source = ["datasets", "models"]
        defis_source_subset = pyutils.subset_dict(self.defis, defis_source)
        got = solver.defis_trains(defis_source_subset, self.specs)
        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_predicts_memt(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["predicts_memt"]

        defis_source = [
            "models",
            "datasets",
            "trains",
            "predict_train_siblings",
        ]
        defis_source_subset = pyutils.subset_dict(self.defis, defis_source)
        got = solver.defis_predicts_memt(defis_source_subset)

        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_predicts_semt(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["predicts_semt"]

        defis_source = [
            "models",
            "datasets",
            "trains",
            "predict_train_siblings",
        ]
        defis_source_subset = pyutils.subset_dict(self.defis, defis_source)
        got = solver.defis_predicts_semt(defis_source_subset)

        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_cols(self):
        """ Test that solver returns the expectation """

        got = solver.defis_cols(self.specs)
        wanted = self.defis["cols"]
        for defi_name, defi in wanted.items():

            self.assertEqual(got[defi_name], defi)

    def test_defis_colsets(self):
        """ Test that solver returns the expectation """

        wanted = self.defis["colsets"]

        defis_source = ["cols"]
        defis_source_subset = pyutils.subset_dict(self.defis, defis_source)
        got = solver.defis_colsets(defis_source_subset, self.specs)

        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis_datacols(self):
        """ Test that solver returns the expectation """

        defis_source = ["cols", "datasets"]
        defis_subset = pyutils.subset_dict(self.defis, defis_source)
        wanted = self.defis["datacols"]
        got = solver.defis_datacols(defis_subset)
        for defi_name, defi in wanted.items():
            self.assertEqual(got[defi_name], defi)

    def test_defis(self):
        """ Test that solver returns the expectation """

        defis_to_test = [
            "datasets",
            "models",
            "trains",
            "cols",
            "colsets",
            "predicts_semt",
            "predicts_memt",
            "estimators",
        ]
        wanted = pyutils.subset_dict(self.defis, defis_to_test)

        got = solver.defis(self.specs)
        for defi_category_name, defi_category in wanted.items():
            for defi_name, defi in defi_category.items():
                self.assertEqual(got[defi_category_name][defi_name], defi)

    def test_tasks_trains(self):
        """ Test that solver returns the expectation """
        wanted = self.tasks["trains"]
        got = solver.tasks_trains(self.defis, self.specs)
        for task_name, task_wanted in wanted.items():
            self.assertEqual(got[task_name], task_wanted)

    def test_tasks_predicts(self):
        """ Test that solver returns the expectation """

        wanted = self.tasks["predicts"]
        got = solver.tasks_predicts(self.defis, self.specs)
        for task_name, task_wanted in wanted.items():
            self.assertEqual(got[task_name], task_wanted)

    def test_tasks_datasets(self):
        """ Test that solver returns the expectation """

        wanted = self.tasks["datasets"]
        got = solver.tasks_datasets(self.defis, self.specs)
        for task_name, task_wanted in wanted.items():
            self.assertEqual(got[task_name], task_wanted)

    def test_tasks_datacols(self):
        """ Test that solver returns the expectation """

        wanted = self.tasks["datacols"]
        got = solver.tasks_datacols(self.defis, self.specs)
        for task_name, task_wanted in wanted.items():
            self.assertEqual(got[task_name], task_wanted)

    def test_tasks(self):
        """ Test that solver returns the expectation """

        wanted = self.tasks
        got = solver.tasks(self.defis, self.specs)

        for task_category_name, task_category in wanted.items():
            for task_name, task in task_category.items():
                self.assertEqual(got[task_category_name][task_name], task)

    def test_flow(self):
        """ Test that solver returns the expectation """
        task_categories_to_test = ["trains", "predicts", "datasets", "datacols"]
        tasks_to_test = pyutils.subset_dict(self.tasks, task_categories_to_test)

        defis_solved = solver.defis(self.specs)
        tasks_solved = solver.tasks(defis_solved, self.specs)

        for task_category_name, tasks_category in tasks_to_test.items():
            for task_name, task in tasks_category.items():
                self.assertEqual(
                    tasks_solved[task_category_name][task_name], task
                )

    def _test_write_out_result(self):
        """ Write current defis and tasks to file """

        path_defis = os.path.expanduser("~/views/scratch/defis.json")
        path_tasks = os.path.expanduser("~/views/scratch/tasks.json")

        defis = solver.defis(self.specs)
        tasks = solver.tasks(defis, self.specs)
        with open(path_defis, "w") as f:
            json.dump(defis, f, indent=2)
        with open(path_tasks, "w") as f:
            json.dump(tasks, f, indent=2)


if __name__ == "__main__":
    unittest.main()
    # @TODO: re-enable and fix
    # print("Skipping test_defparser_solver()")
