""" Empty unit-test module to copy to new projects """

# pylint: disable=protected-access

import unittest
import os

import pandas as pd

try:
    from views.apps.plot.maps import mapdata
    from views.apps.plot.maps import worker
    from views.apps.plot.maps import maputils
except ImportError:
    # Needs work to make portable
    pass


from views.utils import dbutils


# pylint: disable=too-many-instance-attributes
class TestMaps(unittest.TestCase):
    """ Test apps.plot.map.mapdata """

    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    def setUp(self):
        """ Setup the test data """

        def push_tables(path, fq_pred, fq_act, cols_plot, cols_act):
            """ Push the test data from files to db """

            # @TODO: Don't assume people have data on disk
            df = pd.read_hdf(path)
            df_pred = df[cols_plot]
            df_act = df[cols_act]

            # ValueError is raised if table exists already
            try:
                dbutils.df_to_db(df_pred, fq_pred, if_exists="fail")
            except ValueError:
                pass

            try:
                dbutils.df_to_db(df_act, fq_act, if_exists="fail")
            except ValueError:
                pass

        self.plotvar_pgm = "average_select_sb"
        self.plotvar_cm = "average_base_sb"
        self.var_actual = "ged_dummy_sb"
        self.feat_1 = "decay_12_cw_ged_dummy_sb_0"
        self.feat_pgm = "gcp_li_mer"
        self.feat_cm = "ln_fvp_population200"

        path_wd_pgm = "/storage/temp/maps/workdata/df_pgm.hdf5"
        path_wd_cm = "/storage/temp/maps/workdata/df_cm.hdf5"
        path_wd_months = "/storage/temp/maps/workdata/df_months.hdf5"
        path_wd_priogrid = "/storage/temp/maps/workdata/df_priogrid.hdf5"

        fq_pred_pgm = "maps.maps_pred_pgm"
        fq_act_pgm = "maps.maps_act_pgm"
        fq_pred_cm = "maps.maps_pred_cm"
        fq_act_cm = "maps.maps_act_cm"
        fq_months = "maps.maps_months"
        fq_priogrid = "maps.maps_priogrid"

        # push tables
        cols_plot_pgm = [self.plotvar_pgm, self.feat_pgm]
        cols_plot_cm = [self.plotvar_cm, self.feat_cm]
        cols_act = [self.var_actual, "ged_dummy_ns", "ged_dummy_os"]
        cols_plot_pgm = [
            "average_select_sb",
            "average_select_ns",
            "average_select_os",
            self.feat_pgm,
        ]
        cols_plot_cm = [
            "average_base_sb",
            "average_base_ns",
            "average_base_os",
            self.feat_cm,
        ]

        push_tables(
            path_wd_pgm, fq_pred_pgm, fq_act_pgm, cols_plot_pgm, cols_act
        )
        push_tables(path_wd_cm, fq_pred_cm, fq_act_cm, cols_plot_cm, cols_act)
        df_months = pd.read_hdf(path_wd_months)

        df_priogrid = pd.read_hdf(path_wd_priogrid)
        try:
            dbutils.df_to_db(df_months, fq_months)
        except ValueError:
            pass
        try:
            dbutils.df_to_db(df_priogrid, fq_priogrid)
        except ValueError:
            pass

        self.job_pred_pgm_file = {
            "name": "job_pred_pgm_file",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "file",
                "loa": "pgm",
                "source_plotvar": path_wd_pgm,
                "source_actual": path_wd_pgm,
                "name_plotvar": self.plotvar_pgm,
                "name_actual": self.var_actual,
            },
        }

        self.job_pred_cm_file = {
            "name": "job_pred_cm_file",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "file",
                "loa": "cm",
                "source_plotvar": path_wd_cm,
                "source_actual": path_wd_cm,
                "name_plotvar": self.plotvar_cm,
                "name_actual": self.var_actual,
            },
        }

        self.job_pred_pgm_db = {
            "name": "job_pred_pgm_db",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "db",
                "loa": "pgm",
                "source_plotvar": fq_pred_pgm,
                "source_actual": fq_act_pgm,
                "name_plotvar": self.plotvar_pgm,
                "name_actual": self.var_actual,
            },
        }

        self.job_pred_cm_db = {
            "name": "job_pred_cm_db",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "db",
                "loa": "cm",
                "source_plotvar": fq_pred_cm,
                "source_actual": fq_act_cm,
                "name_plotvar": self.plotvar_cm,
                "name_actual": self.var_actual,
            },
        }

        self.job_pred_cm_db_noact = {
            "name": "job_pred_cm_db_noact",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transform": [],
                "source": "db",
                "loa": "cm",
                "source_plotvar": fq_pred_cm,
                "source_actual": "",
                "name_plotvar": self.plotvar_cm,
                "name_actual": "",
            },
        }

        self.job_pred_cm_file_noact = {
            "name": "job_pred_cm_file_noact",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "file",
                "loa": "cm",
                "source_plotvar": path_wd_cm,
                "source_actual": "",
                "name_plotvar": self.plotvar_cm,
                "name_actual": "",
            },
        }

    def _test_get_ids_pgm(self):
        """ Test that data._get_ids() gets correct """

        wanted = ["month_id", "pg_id"]
        job_data = {"loa": "pgm"}
        got = mapdata._get_ids(job_data)
        self.assertEqual(got, wanted)

    def _test_get_ids_cm(self):
        """ Test cm ids """

        wanted = ["month_id", "country_id"]
        job_data = {"loa": "cm"}
        got = mapdata._get_ids(job_data)
        self.assertEqual(got, wanted)

    def test_plot_linear_gcp(self):
        """ Make a map of gcp_li_mer with interval scale """

        job_gcp_linear = {
            "name": "gcp_linear",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "interval",
            "data": {
                "transforms": [],
                "source": "file",
                "loa": "pgm",
                "source_plotvar": "/storage/temp/maps/workdata/df_pgm.hdf5",
                "source_actual": "",
                "name_plotvar": "gcp_li_mer",
                "name_actual": "",
            },
        }

        worker.worker(job_gcp_linear)

        worker.worker(job_gcp_linear)
        path = "/storage/temp/maps/gcp_linear_421.png"
        file_exists = os.path.exists(path)
        self.assertTrue(file_exists)

    def test_plot_logodds_gcp(self):
        """ Make a map of gcp_li_mer with logodds scale """

        job_gcp_linear = {
            "name": "gcp_logodds",
            "destination": "/storage/temp/maps/",
            "proj": "cyl",
            "crop": "africa",
            "var_scale": "logodds",
            "data": {
                "transforms": [],
                "source": "file",
                "loa": "pgm",
                "source_plotvar": "/storage/temp/maps/workdata/df_pgm.hdf5",
                "source_actual": "",
                "name_plotvar": "gcp_li_mer",
                "name_actual": "",
            },
        }

        worker.worker(job_gcp_linear)
        path = "/storage/temp/maps/gcp_logodds_421.png"
        file_exists = os.path.exists(path)
        self.assertTrue(file_exists)

    def test_fetch_data_cm_from_db_is_df(self):
        """ Make sure CM data from db is a dataframe """

        df = mapdata.get_data(self.job_pred_cm_db)
        self.assertIsInstance(df, pd.DataFrame)

    def test_fetch_data_cm_from_file_is_df(self):
        """ Test CM data from file is dataframe """

        df = mapdata.get_data(self.job_pred_cm_file)
        self.assertIsInstance(df, pd.DataFrame)

    def test_fetch_data_pgm_from_db_is_df(self):
        """ Test PGM data from db is dataframe """

        df = mapdata.get_data(self.job_pred_pgm_db)
        self.assertIsInstance(df, pd.DataFrame)

    def test_fetch_data_pgm_from_file_is_df(self):
        """ Test PGM data from file is dataframe """

        df = mapdata.get_data(self.job_pred_pgm_file)
        self.assertIsInstance(df, pd.DataFrame)

    def test_fetch_data_pgm_from_db_has_cols(self):
        """ Test PGM data from db has actual and plotvar """

        df = mapdata.get_data(self.job_pred_pgm_file)
        got = list(df.columns)
        self.assertIn("actual", got)
        self.assertIn("plotvar", got)

    def test_fetch_data_db_no_act_cols(self):
        """ Test get_data db with job with no actual gets no actual column """

        df = mapdata.get_data(self.job_pred_cm_db_noact)
        unwanted = "actual"
        got = list(df.columns)
        self.assertNotIn(unwanted, got)

    def test_fetch_data_file_no_act_cols(self):
        """ Test get_data file with no actual gets no actual column  """

        df = mapdata.get_data(self.job_pred_cm_file_noact)
        unwanted = "actual"
        got = list(df.columns)
        self.assertNotIn(unwanted, got)

    def test_df_events_has_lon_lat(self):
        """ Test df_events has lon and lat """
        df = mapdata.get_data(self.job_pred_pgm_db)
        extras = mapdata.get_extras(self.job_pred_pgm_db)
        df_events = maputils.make_df_events(df, self.job_pred_pgm_db, extras)

        wanted = ["longitude", "latitude"]
        for want in wanted:
            self.assertIn(want, df_events.columns)

    def test_worker_pgm_db(self):
        """ Test that worker makes some maps, don't always run beause slow """
        worker.worker(self.job_pred_pgm_db)

    def test_worker_pgm_file(self):
        """ Test that worker makes some maps, don't always run beause slow """
        worker.worker(self.job_pred_pgm_file)

    def test_worker_cm_db(self):
        """ Test that worker makes some maps, don't always run beause slow """
        worker.worker(self.job_pred_cm_db)

    def test_worker_cm_file(self):
        """ Test that worker makes some maps, don't always run beause slow """
        worker.worker(self.job_pred_cm_file)


if __name__ == "__main__":
    print("Skipping test_plot_map because slow and not portable")
    # unittest.main()
