""" test suite for calibration. """

# pylint: disable=invalid-name


import warnings
import unittest
import tempfile
import os
from views.utils import pyutils


class TestMergeDicts(unittest.TestCase):
    """ Test pyutils.merge_dicts """

    def test_merges(self):
        """ Test that merge_dicts() merges dicts """
        first = {"a": "value_a"}
        second = {"b": "value_b"}

        manual = {"a": "value_a", "b": "value_b"}

        merged = pyutils.merge_dicts([first, second])

        self.assertDictEqual(merged, manual)

    def test_checks_duplicates(self):
        """ merge_dicts() should raise RuntimeError if duplicate keys found """
        first = {"a": "value_a"}
        second = {"a": "value_a", "b": "value_b"}

        with self.assertRaises(RuntimeError) as _:
            pyutils.merge_dicts([first, second])


class TestFlattenList(unittest.TestCase):
    """Tests for pyutils.flatten_list module"""

    def setUp(self):
        """ Setup state for testing pyutils"""
        self.nested_list = [["a", "b"], ["c", "d"]]
        self.flat_list = ["a", "b", "c", "d"]

        self.deep_list = [[["a", "b"], ["c", "d"]], [["e", "f"], ["g", "h"]]]
        self.deep_list_flat = ["a", "b", "c", "d", "e", "f", "g", "h"]

    def test_basic_functionality(self):
        """ Test that flatten list returns a flat list """
        flattened_list = pyutils.flatten_list(self.nested_list)
        self.assertEqual(self.flat_list, flattened_list)

    def test_deep_list(self):
        """ Test that a list of list of list is flattened """
        flattened_list = pyutils.flatten_list(self.deep_list)
        self.assertEqual(self.deep_list_flat, flattened_list)

    def test_warns_flat_list(self):
        """ Test that a warning is raised when a flat list is passed """

        with self.assertWarns(Warning) as _:
            pyutils.flatten_list(self.flat_list)

    def test_dont_change_unnested_list(self):
        """ Test that a list that is already flat isnt changed """

        # Supress the warning
        warnings.simplefilter("ignore")
        flattened_list = pyutils.flatten_list(self.flat_list)

        # List should be unchanged
        self.assertEqual(self.flat_list, flattened_list)


class TestDedupList(unittest.TestCase):
    """ Tests for pyutils.dedup_list """

    def setUp(self):
        self.list_w_dups = ["a", "a", "b"]
        self.list_wo_dups = ["a", "b"]

    def test_drops_dups(self):
        """ Test that deduped list is returned as expected """
        deduped = pyutils.dedup_list(self.list_w_dups)
        self.assertListEqual(deduped, self.list_wo_dups)


class TestGetPrefixes(unittest.TestCase):
    """ Test get_prefixes() """

    def setUp(self):

        self.n = 100
        self.prefixes = pyutils.get_prefixes(self.n)

    def test_get_prefixes_unique(self):
        """ Test that get_prefixes only return unique strings """

        deduped = pyutils.dedup_list(self.prefixes)

        self.assertEqual(self.prefixes, deduped)

    def test_get_prefixes_length(self):
        """ Test that get_prefixes only return unique strings """

        self.assertEqual(len(self.prefixes), self.n)

    def test_get_prefixes_n_error(self):
        """ Test that get_prefixes raises RuntimeError for n>576 """

        with self.assertRaises(RuntimeError) as _:
            pyutils.get_prefixes(577)


class TestMatchVar(unittest.TestCase):
    """ Test the var matcher """

    def setUp(self):
        """ Setup some matching """

        self.matching = [
            {"contains": "conf", "match": "conflict"},
            {"contains": "gdp", "match": "gross_domestic_product"},
        ]

    def test_match_simple(self):
        """ Test that a simple match can be made """

        var = "some_var_with_conflict"

        want = "conflict"
        got = pyutils.match_var(var, self.matching)
        self.assertEqual(want, got)

    def test_match_raises_on_multiple_matches(self):
        """ If var matching multiple contains we should raise RuntimeError """

        var = "some_var_matching_both_conflict_and_gdp"
        with self.assertRaises(RuntimeError) as _:
            pyutils.match_var(var, self.matching)

    def test_match_returns_none_for_nomatch(self):
        """ If no match is found just return None """

        var = "some_var_doesn't match"
        wanted = None
        got = pyutils.match_var(var, self.matching)
        self.assertEqual(wanted, got)


class TestPathstuff(unittest.TestCase):
    """ Test python utils related to paths """

    def test_get_paths_from_dir(self):
        """ Test get_paths_from_dir finds files in subdirs """

        def create_dir_structure(tempdir):
            path_d1 = os.path.join(tempdir, "d1")
            path_d2 = os.path.join(tempdir, "d2")
            path_f1 = os.path.join(path_d1, "f1.file")
            path_f2 = os.path.join(path_d2, "f2.file")
            pyutils.create_dir(path_d1)
            pyutils.create_dir(path_d2)
            with open(path_f1, "w") as f:
                f.write("content 1")
            with open(path_f2, "w") as f:
                f.write("content 2")

        with tempfile.TemporaryDirectory() as tempdir:
            create_dir_structure(tempdir)
            got = pyutils.get_paths_from_dir(tempdir)
            wanted = [
                os.path.join(tempdir, "d1", "f1.file"),
                os.path.join(tempdir, "d2", "f2.file"),
            ]
            self.assertEqual(got, wanted)

    def test_fname_matches_pattern(self):
        """ Test fname_matches_pattern with sim.hdf5 pattern """
        basedir = "/some/base/dir"
        fnames = ["sim1.hdf5", "somename.hdf5", "sim25.hdf5"]
        # \d+ is at least one digit
        pattern = r"(sim\d+\.hdf5)"
        paths = [os.path.join(basedir, fname) for fname in fnames]
        wanted = [True, False, True]
        got = [pyutils.fname_matches_pattern(path, pattern) for path in paths]
        self.assertEqual(got, wanted)


if __name__ == "__main__":
    unittest.main()
