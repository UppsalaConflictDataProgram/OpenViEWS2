""" test suite for utils/datautils. """

# pylint: disable=invalid-name


import unittest

import numpy as np
import pandas as pd

from views.utils import datautils
from views.utils.datautils import DfMocker


class TestFilling(unittest.TestCase):
    """Tests for Crosslevel module"""

    def setUp(self):
        """ Setup state for testing pyutils"""

        times = [0, 0, 1, 1]
        groups = [0, 1, 0, 1]
        missing_front = [np.nan, np.nan, 0.0, 0.0]
        missing_end = [0.0, 0.0, np.nan, np.nan]
        no_missing = [0.0, 0.0, 0.0, 0.0]

        df = pd.DataFrame(
            {
                "time": times,
                "group": groups,
                "missing_front": missing_front,
                "missing_end": missing_end,
                "no_missing": no_missing,
            }
        )

        df.set_index(["time", "group"], inplace=True)
        df.sort_index(inplace=True)

        self.df = df

    def test_fill_forwards_backwards(self):
        """ Test fill_forwards_backwards basic functionality """

        # Manually copy the not missing cols to simulate filling
        df_no_missing = self.df.copy()
        df_no_missing["missing_front"] = self.df["no_missing"]
        df_no_missing["missing_end"] = self.df["no_missing"]

        df_filled = datautils.fill_forwards_backwards(self.df)

        # Test that all cols are filled the same
        pd.testing.assert_frame_equal(df_filled, df_no_missing)

    def test_fill_forwards_backwards_varlist(self):
        """ Test fill_forwards_backwards varlist parameter"""

        df_missing_end_only = self.df.copy()
        df_missing_end_only["missing_front"] = self.df["no_missing"]

        varlist = ["missing_front"]
        df_filled = datautils.fill_forwards_backwards(self.df, varlist)

        # Test that all cols are filled the same
        pd.testing.assert_frame_equal(df_filled, df_missing_end_only)

    def test_fill_forwards_backwards_indexasserts(self):
        """ Test fill_forwards_backwards varlist parameter"""

        df = self.df.copy()
        df.reset_index(inplace=True)

        with self.assertRaises(RuntimeError) as _:
            datautils.fill_forwards_backwards(df)


class TestDataGeneration(unittest.TestCase):
    """ Test the dummy data generation functions """

    def setUp(self):
        self.n = 1000

    def test_generate_probs(self):
        """ Test probability generation """

        probs = datautils.generate_probs(self.n)

        # Test probs between 0 and 1
        self.assertGreaterEqual(min(probs), 0.0)
        self.assertLessEqual(max(probs), 1.0)
        # Test the length is correct
        self.assertEqual(len(probs), self.n)

    def test_generate_probs_raises_notimplemented(self):
        """ Test that generate_probs raises NotImplemntedError correctly """

        with self.assertRaises(NotImplementedError) as _:
            datautils.generate_probs(self.n, distribution="unsupported")

    def test_generate_bools(self):
        """ Test that generate_bools() only returns bools """

        bools = datautils.generate_bools(self.n)

        allowed_vals = [0, 1]
        for value in bools:
            self.assertIn(value, allowed_vals)

    def test_generate_counts(self):
        """ Test that generate_counts() returns positive integers or zeros """

        counts = datautils.generate_counts(self.n)

        for value in counts:
            value_int = int(value)
            np.testing.assert_almost_equal(value_int, value)

            self.assertGreater(value, -1)

    def test_generate_reals_limits(self):
        """ Test value limits of generate_reals """

        min_value = -10
        max_value = 10
        uniform = datautils.generate_reals(
            n=self.n,
            min_value=min_value,
            max_value=max_value,
            distribution="uniform",
        )

        for value in uniform:
            self.assertGreaterEqual(value, min_value)
            self.assertLessEqual(value, max_value)

    def test_generate_reals_len(self):
        """ Test that genereate_reals returns vector of correct length """

        len_generated = len(datautils.generate_reals(n=self.n))
        self.assertEqual(len_generated, self.n)

    def test_generate_reals_raises_notimplemented(self):
        """ Test that genereate_reals raises NotimplementedError correctly """

        with self.assertRaises(NotImplementedError) as _:
            datautils.generate_reals(self.n, distribution="unsupported")


class TestDfMaking(unittest.TestCase):
    """ Tests for DfMocker """

    def setUp(self):
        """ Setup """
        self.n_groups = 10
        self.n_t = 100
        self.n_cols = 10
        self.mocker = DfMocker(self.n_t, self.n_groups, self.n_cols)

    def test_returns_df(self):
        """ Test that mocker.get_df returns a dataframe """

        df = self.mocker.df
        self.assertIsInstance(df, pd.DataFrame)

    def test_df_has_multiindex(self):
        """ Assert df has Multiindex on creation """

        df = self.mocker.df
        self.assertIsInstance(df.index, pd.MultiIndex)

    def test_make_idx_from_n(self):
        """ Assert make_idx returns a MultiIndex of the correct length """

        len_wanted = self.n_t * self.n_groups
        idx = self.mocker.make_idx_from_n(self.n_t, self.n_groups)

        self.assertEqual(len(idx), len_wanted)
        self.assertIsInstance(idx, pd.MultiIndex)

    def test_make_idx_from_lists(self):
        """ Assert make_idx_from_lists returns correct length MultiIndex  """

        len_wanted = self.n_t * self.n_groups

        groups = list(range(self.n_groups))
        times = list(range(self.n_t))

        idx = self.mocker.make_idx_from_lists(times, groups)

        self.assertEqual(len(idx), len_wanted)
        self.assertIsInstance(idx, pd.MultiIndex)

    def test_set_index(self):
        """ Test settings index works on the mocker instance """

        self.assertIsInstance(self.mocker.df.index, pd.MultiIndex)

    def test_make_datadict_returns_dict(self):
        """ Test that make_datadict() returns a dict"""
        datadict = self.mocker.make_datadict()
        self.assertIsInstance(datadict, dict)

    def test_make_datadict_n_cols(self):
        """ Test that make_datadict() returns a dict with the n_cols of keys"""
        n_cols = 10
        datadict = self.mocker.make_datadict(n_cols=n_cols)
        self.assertEqual(len(datadict.keys()), n_cols)

    def test_make_datadict_n_rows(self):
        """ Test that make_datadict() returns a dict with the n_cols of keys"""
        n_rows = 100
        datadict = self.mocker.make_datadict(n_rows=n_rows)

        for key in datadict:
            len_this_value = len(datadict[key])
            self.assertEqual(n_rows, len_this_value)

    def test_make_datadict_raises_runtimeerror(self):
        """ Test that make_datadict raises RuntimeError correctly"""

        n_rows = 10
        with self.assertRaises(RuntimeError) as _:
            self.mocker.make_datadict(n_rows=n_rows, datatype="unsupported")

    def test_make_df_shape(self):
        """ Test that a constructed df has the correct shape """

        len_wanted = self.n_t * self.n_groups
        self.assertEqual(len(self.mocker.df), len_wanted)
        self.assertEqual(len(list(self.mocker.df.columns)), self.n_cols)


class TestResampling(unittest.TestCase):
    """ Test the Resampling function """

    def setUp(self):
        """ Setup some mock data """

        self.n_groups = 10
        self.n_t = 100
        self.n_cols = 10
        self.mocker = DfMocker(self.n_t, self.n_groups, self.n_cols)
        self.df = self.mocker.df
        self.col_outcome = "b_a"

    def test_resample_shares_one_returns_unaltered(self):
        """ Test that resample with both shares keep=1 returns original df """

        df_resampled = datautils.resample(
            df=self.df,
            cols=self.col_outcome,
            share_positives=1.0,
            share_negatives=1.0,
        )

        pd.testing.assert_frame_equal(self.df, df_resampled)

    def test_resample_reduces_len_correctly(self):
        """ Test that resample drops correct number of rows """

        df_resampled = datautils.resample(
            df=self.df,
            cols=self.col_outcome,
            share_positives=0.5,
            share_negatives=0.5,
        )

        len_resampled_wanted = len(self.df) / 2
        len_resampled_computed = len(df_resampled)
        ratio = len_resampled_wanted / len_resampled_computed

        self.assertTrue(np.isclose(ratio, 1.0, rtol=0.1))

    def test_resample_raises_runtime_nonsupported_cols(self):
        """ Test that resample acts the same with a list or single column """

        cols_wrong_type = {}

        with self.assertRaises(RuntimeError) as _:
            datautils.resample(
                df=self.df,
                cols=cols_wrong_type,
                share_positives=0.5,
                share_negatives=0.5,
            )

    def test_resample_with_cols_list(self):
        """ Test that resample acts the same with a list or single column """

        cols_list = ["b_a", "b_b"]

        datautils.resample(
            df=self.df, cols=cols_list, share_positives=0.5, share_negatives=0.5
        )


class TestDFMethods(unittest.TestCase):
    """ Test methods that run on a db """

    def setUp(self):
        """ Testing df """
        self.mocker = datautils.DfMocker()
        self.df = self.mocker.df

    def tearDown(self):
        """ CLeanup """
        del self.mocker
        del self.df

    def test_get_var_bounds(self):
        """ Test that get_var_bounds finds correct bounds """

        for c in self.df.columns:
            mi = self.df[c].min()
            ma = self.df[c].max()
            wanted = (mi, ma)
            got = datautils.get_var_bounds(self.df, c)
            self.assertEqual(wanted, got)

    def test_get_df_index_limits(self):
        """ Test that get_df_index_limits returns correct limits for idvars """

        limits_timevar = datautils.get_df_index_limits(
            self.df, self.mocker.timevar
        )

        limits_groupvar = datautils.get_df_index_limits(
            self.df, self.mocker.groupvar
        )

        # If we have 5 groups the group ids should be 0, 1, 2, 3 4
        # 4-0 is 4 so the diff between max and min is n_g - 1
        n_t = self.mocker.n_t
        n_g = self.mocker.n_groups
        diff_limits_timevar = limits_timevar[1] - limits_timevar[0]
        diff_limits_groupvar = limits_groupvar[1] - limits_groupvar[0]
        self.assertEqual(n_t - 1, diff_limits_timevar)
        self.assertEqual(n_g - 1, diff_limits_groupvar)


if __name__ == "__main__":
    unittest.main()
