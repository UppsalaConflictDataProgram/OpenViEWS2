""" Tests of individual questions' functionality on qualtrics """

# pragma: no cover
# pylint: skip-file

import unittest
import os

from views.apps.survey import questions as qs
from views.apps.survey import surveys as ss
import views.apps.survey.qualtrics_api as api
from views.tests import test_survey_utils

# pylint: disable=line-too-long


class TestSurveyQuestionsSurvival(unittest.TestCase):
    """ Test survival of survey questions re API """

    def setUp(self):
        """ Setup the data tests need """
        this_dir = os.path.dirname(os.path.abspath(__file__))
        dir_questions = os.path.join(this_dir, "data/survey/questions/")

        test_survey_utils.setup_db_survey()

        self.posted_surveys = []

        # block 1
        self.q_introduction_text = qs.introduction_text()
        self.q_review_stakeholder_introduction = (
            qs.review_relativepower_introduction()
        )
        self.q_review_stakeholder_drop = qs.review_stakeholder_drop(
            stakeholder_id=1
        )
        self.q_review_stakeholder_add = qs.review_stakeholder_add()
        self.q_review_relativepower = qs.review_relativepower(
            stakeholder_id=1, expert_id=5
        )
        self.q_review_relativepower_introduction = (
            qs.review_relativepower_introduction()
        )
        self.q_review_issues_revision = qs.review_issues_revision(issue_id=1)
        self.q_review_issues_revision_issue = qs.review_issues_revision_issue()
        self.q_review_issues_revision_sq = qs.review_issues_revision_sq()
        # block 2
        self.q_stakeholder_issue_introduction = (
            qs.stakeholder_issue_introduction()
        )
        self.q_stakeholder_issue = qs.stakeholder_issue(
            stakeholder_id=14, issue_id=7
        )
        self.q_stakeholder_salience_introduction = (
            qs.stakeholder_salience_introduction()
        )
        self.q_stakeholder_salience = qs.stakeholder_salience(
            stakeholder_id=1, issue_id=1
        )
        self.q_comment_stakeholder_issue = qs.comment_stakeholder_issue()
        # block 3
        self.q_demanding_stakeholders = qs.demanding_stakeholders(expert_id=1)
        self.q_demands_to_issues = qs.demands_to_issues(
            stakeholder_id=1, expert_id=1
        )
        self.q_demand_label = qs.demand_label(stakeholder_id=1)
        self.q_demand_reaction = qs.demand_reaction()
        self.q_rejection_to_stakeholder = qs.rejection_to_stakeholder(
            expert_id=1
        )
        self.q_reaction_to_rejection = qs.reaction_to_rejection(
            stakeholder_id=1
        )
        self.q_campaign_intensity = qs.campaign_intensity(expert_id=1)
        self.q_reaction_intensity = qs.reaction_intensity(expert_id=1)
        self.q_comment_demands = qs.comment_demands()
        # block 4
        self.q_stakeholder_threats = qs.stakeholder_threats(expert_id=1)
        self.q_describe_threat = qs.describe_threat(stakeholder_id=1)
        self.q_direction_threats = qs.direction_threats(expert_id=1)
        self.q_source_threat = qs.source_threat()
        self.q_comment_threat = qs.comment_threat()
        # block 5
        self.q_scheduled_election = qs.scheduled_election()
        self.q_effect_election = qs.effect_election(issue_id=1)
        self.q_confidence_forecast = qs.confidence_forecast()
        self.q_other_event = qs.other_event()
        self.q_comment_other_event = qs.comment_other_event()
        self.q_effect_other_event = qs.effect_other_event(issue_id=1)
        self.q_demand_reaction_forecast = qs.demand_reaction_forecast()
        self.q_effect_demand_reaction_forecast = (
            qs.effect_demand_reaction_forecast()
        )
        self.q_demand_forecast = qs.demand_forecast()
        self.q_demand_forecast_stakeholder = qs.demand_forecast_stakeholder(
            expert_id=1
        )
        self.q_demand_escalation = qs.demand_escalation()
        self.q_demand_promise = qs.demand_promise()
        self.q_demand_forecast_reaction = qs.demand_forecast_reaction()
        self.q_demand_forecast_stakeholder_resist = qs.demand_forecast_stakeholder_resist(
            expert_id=1
        )
        self.q_comment_predictions = qs.comment_predictions()
        # block 6
        self.q_p3_violence = qs.p3_violence()
        self.q_p12_violence = qs.p12_violence()
        self.q_p12_violence_stakeholder = qs.p12_violence_stakeholder(
            expert_id=1
        )
        self.q_p3_violence_government = qs.p3_violence_government()
        self.q_p3_violence_civilians = qs.p3_violence_civilians()
        self.q_p12_violence_25brd = qs.p12_violence_25brd()
        self.q_p12_violence_1000brd = qs.p12_violence_1000brd()
        self.q_external_actor = qs.external_actor()
        self.q_external_actor_stakeholder = qs.external_actor_stakeholder(
            expert_id=1
        )
        self.q_p3_violence_civilians_pr = qs.p3_violence_civilians_pr()
        self.q_p3_violence_civilians_stakeholder = qs.p3_violence_civilians_stakeholder(
            expert_id=1
        )
        self.q_p3_displacement = qs.p3_displacement()
        self.q_p3_displacement_stakeholder = qs.p3_displacement_stakeholder(
            expert_id=1
        )

    def tearDown(self):
        """ Delete any surveys we have posted """
        for qsi in self.posted_surveys:
            api.delete_survey(qsi)

    def question_survival(self, question_txt):
        """ Wrapper and survival test function """
        header = "[[AdvancedFormat]]\n"
        q = header + question_txt
        print(q)
        qsi = api.post_survey_from_str(name="delete_me", txt=q)
        self.posted_surveys.append(qsi)
        self.assertIsInstance(qsi, str)

    def test_survival_introduction_text(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_introduction_text)

    def test_survival_review_stakeholder_introduction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_stakeholder_introduction)

    def test_survival_review_stakeholder_drop(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_stakeholder_drop)

    def test_survival_review_stakeholder_add(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_stakeholder_add)

    def test_survival_review_relativepower(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_relativepower)

    def test_survival_review_relativepower_introduction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_relativepower_introduction)

    def test_survival_review_issues_revision(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_issues_revision)

    def test_survival_review_issues_revision_issue(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_issues_revision_issue)

    def test_survival_review_issues_revision_sq(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_review_issues_revision_sq)

    def test_survival_stakeholder_issue_introduction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_stakeholder_issue_introduction)

    def test_survival_stakeholder_issue(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_stakeholder_issue)

    def test_survival_stakeholder_salience_introduction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_stakeholder_salience_introduction)

    def test_survival_stakeholder_salience(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_stakeholder_salience)

    def test_survival_comment_stakeholder_issue(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_comment_stakeholder_issue)

    def test_survival_demanding_stakeholders(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demanding_stakeholders)

    def test_survival_demands_to_issues(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demands_to_issues)

    def test_survival_demand_label(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_label)

    def test_survival_demand_reaction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_reaction)

    def test_survival_rejection_to_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_rejection_to_stakeholder)

    def test_survival_reaction_to_rejection(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_reaction_to_rejection)

    def test_survival_campaign_intensity(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_campaign_intensity)

    def test_survival_reaction_intensity(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_reaction_intensity)

    def test_comment_demands(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_comment_demands)

    def test_survival_stakeholder_threats(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_stakeholder_threats)

    def test_survival_describe_threat(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_describe_threat)

    def test_survival_direction_threats(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_direction_threats)

    def test_survival_source_threat(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_source_threat)

    def test_survival_comment_threat(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_comment_threat)

    def test_survival_scheduled_election(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_scheduled_election)

    def test_survival_effect_election(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_effect_election)

    def test_survival_confidence_forecast(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_confidence_forecast)

    def test_survival_other_event(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_other_event)

    def test_survival_comment_other_event(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_comment_other_event)

    def test_survival_effect_other_event(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_effect_other_event)

    def test_survival_demand_reaction_forecast(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_reaction_forecast)

    def test_survival_effect_demand_reaction_forecast(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_effect_demand_reaction_forecast)

    def test_survival_demand_forecast(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_forecast)

    def test_survival_demand_forecast_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_forecast_stakeholder)

    def test_survival_demand_escalation(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_escalation)

    def test_survival_demand_promise(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_promise)

    def test_survival_demand_forecast_reaction(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_forecast_reaction)

    def test_survival_demand_forecast_stakeholder_resist(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_demand_forecast_stakeholder_resist)

    def test_survival_comment_predictions(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_comment_predictions)

    def test_survival_p3_violence(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_violence)

    def test_survival_p12_violence(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p12_violence)

    def test_survival_p12_violence_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p12_violence_stakeholder)

    def test_survival_p3_violence_government(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_violence_government)

    def test_survival_p3_violence_civilians(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_violence_civilians)

    def test_survival_p12_violence_25brd(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p12_violence_25brd)

    def test_survival_p12_violence_1000brd(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p12_violence_1000brd)

    def test_survival_external_actor(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_external_actor)

    def test_survival_p3_violence_civilians_pr(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_violence_civilians_pr)

    def test_survival_external_actor_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_external_actor_stakeholder)

    def test_survival_p3_violence_civilians_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_violence_civilians_stakeholder)

    def test_survival_p3_displacement(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_displacement)

    def test_survival_p3_displacement_stakeholder(self):
        """ Test that the question survives upload to Qualtrics """
        self.question_survival(self.q_p3_displacement_stakeholder)


if __name__ == "__main__":
    # unittest.main()
    pass
