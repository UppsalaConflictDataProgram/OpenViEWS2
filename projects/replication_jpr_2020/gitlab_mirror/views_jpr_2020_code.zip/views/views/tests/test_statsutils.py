""" Tests for utils/statsutils """

# pylint: disable=invalid-name

import unittest

import numpy as np

from views.utils import statsutils


class TestMisc(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        self.p = [0.1, 0.5, 0.9]
        self.p_pct_formatted = ["10%", "50%", "90%"]
        self.p_as_odds = [0.111111, 1, 9]
        self.p_as_logodds = [-2.197225, 0, 2.197225]

    def tearDown(self):
        """ Cleanup after tests """
        del self.p

    def test_prob_to_odds(self):
        """ Test that get_odds computes simple odds right """

        wanted = self.p_as_odds
        got = statsutils.prob_to_odds(self.p)
        np.testing.assert_almost_equal(wanted, got)

    def test_prob_to_odds_warns_on_greq_1(self):
        """ Test that get_odds computes simple odds right """

        p = [1]
        with self.assertWarns(UserWarning) as _:
            statsutils.prob_to_odds(p, clip=False)

    def test_get_logodds(self):
        """ Test that get_logodds computes simple logodds """

        wanted = self.p_as_logodds
        got = statsutils.prob_to_logodds(self.p)
        np.testing.assert_almost_equal(wanted, got, decimal=5)

    def test_format_prob_to_pct(self):
        """ Test that format_prob_as_pct does its thing """

        gots = []
        for p_i in self.p:
            got = statsutils.format_prob_to_pct(p_i)
            gots.append(got)

        self.assertEqual(self.p_pct_formatted, gots)

    def test_format_prob_to_pct_raises_on_prob_greater_than_one(self):
        """ Test that format_prob_as_pct does its thing """

        p = 1.1
        with self.assertWarns(UserWarning) as _:
            statsutils.format_prob_to_pct(p)

    def test_logit_equals_logodds(self):
        """ logit() and logodds() are the same thing """

        logodds = statsutils.prob_to_logodds(self.p)
        logit = statsutils.logit(self.p)
        np.testing.assert_equal(logodds, logit)


if __name__ == "__main__":
    unittest.main()
