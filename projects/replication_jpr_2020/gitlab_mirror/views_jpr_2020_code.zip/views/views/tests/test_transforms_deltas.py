""" Empty unit-test module to copy to new projects """
import unittest

import pandas as pd

from views.utils import datautils

from views.apps.transforms import deltas as trans


class TestTransforms(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        mocker = datautils.DfMocker()
        self.df = mocker.df

    def tearDown(self):
        """ Cleanup after tests """
        del self.df

    def test_df_subtract(self):
        """ Test df_subtract computes correct """
        df_a = self.df.copy()
        df_b = self.df.copy()
        col_a, col_b = df_a.columns[0:2]
        name = "diff"

        df_a[name] = df_a[col_a] - df_a[col_b]
        wanted = df_a

        got = trans.df_subtract(
            df_b, name="diff", minuend=col_a, subtrahend=col_b
        )
        pd.testing.assert_frame_equal(got, wanted)

    def test_worker_subtract(self):
        """ Test worker_subtract computes correct """
        df_a = self.df.copy()
        df_b = self.df.copy()
        col_a, col_b = df_a.columns[0:2]
        name = "diff"

        df_a[name] = df_a[col_a] - df_a[col_b]
        wanted = df_a

        job = {
            "transform": "diff",
            "col_a": col_a,
            "col_b": col_b,
            "name": name,
        }
        got = trans.worker_subtract(df_b, job=job)
        pd.testing.assert_frame_equal(got, wanted)

    def test_df_delta_has_name_in_result(self):
        """ Test df_delta computes correct """

        df = self.df.copy()
        col = df.columns[0]
        df = trans.df_delta_vs_ref_t(df, name="diff", t_ref=0, col=col)

        self.assertTrue(col in df.columns)

    def test_df_delta_has_diff_zero_in_ref_t(self):
        """ Test the difference from the base t is zero at t_ref """

        df = self.df.copy()
        col = df.columns[0]
        df = trans.df_delta_vs_ref_t(df, name="diff", t_ref=0, col=col)

        self.assertEqual(df.loc[0, "diff"].sum(), 0)

    def test_df_delta_has_diff_nonzero_in_ref_tplus(self):
        """ Test the difference from the base t is nonzero at t_ref+1 """

        df = self.df.copy()
        col = df.columns[0]
        df = trans.df_delta_vs_ref_t(df, name="diff", t_ref=0, col=col)

        self.assertNotEqual(df.loc[1, "diff"].sum(), 0)


if __name__ == "__main__":
    unittest.main()
