""" Empty unit-test module to copy to new projects """
import unittest


class TestSkeleton(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        self.data = []

    def tearDown(self):
        """ Cleanup after tests """
        del self.data

    def test_passing(self):
        """ Test that pass passses """
        pass  # pylint: disable=unnecessary-pass


if __name__ == "__main__":
    unittest.main()
