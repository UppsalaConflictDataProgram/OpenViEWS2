""" Common testing setup utils for survey tests """


import os

from views.utils import dbutils


def setup_db_survey():
    """ Run schema.sql and data.sql to init survey tests """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_queries = os.path.join(this_dir, "data/survey/")

    path_schema = os.path.join(dir_queries, "schema.sql")
    # pylint: disable=unused-variable
    path_data = os.path.join(dir_queries, "data.sql")

    # Clear and setup DB Schema
    dbutils.execute_query_from_file(path_schema)
    # Insert some fake data
    print("skipping fake data entry...")
    # dbutils.execute_query_from_file(path_data)


def read_survey_poc():
    """ Read the proof of concept survey for file """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_surveys = os.path.join(this_dir, "data/survey/surveys/")

    fname = "survey_poc.txt"
    path_survey_poc = os.path.join(dir_surveys, fname)
    with open(path_survey_poc, "r") as f:
        survey_poc = f.read()

    return survey_poc


def read_survey_beta():
    """ Read the beta survey to file """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_surveys = os.path.join(this_dir, "data/survey/surveys/")

    fname = "survey_beta.txt"
    path_survey_beta = os.path.join(dir_surveys, fname)
    with open(path_survey_beta, "r") as f:
        survey_beta = f.read()

    return survey_beta
