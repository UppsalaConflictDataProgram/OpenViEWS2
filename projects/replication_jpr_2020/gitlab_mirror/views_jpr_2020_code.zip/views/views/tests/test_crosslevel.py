""" test suite for calibration. """

import os

import unittest
import tempfile
import json

import pandas as pd

from views.apps.crosslevel.crosslevel import Crosslevel

from views.utils import datautils
from views.utils import dbutils

# pylint: disable=too-many-instance-attributes
class TestCrosslevel(unittest.TestCase):
    """Tests for Crosslevel module"""

    def setUp(self):
        """ Setup method for Crosslevel tests.

        Builds three dataframes:

        * self.df_h: high resolution probs
        * self.df_l: low resolution probs
        * self.df_h_links: links between high and low level probs"""

        def make_run_db():
            """ Make a run that reads from DB """

            name = "cl_cm_fcast_test"
            job_1 = make_jobdict(
                name="cl_1", method="colaresi", col_h="h_p_a", col_l="l_p_b"
            )
            job_2 = make_jobdict(
                name="cl_2", method="product", col_h="h_p_b", col_l="l_p_a"
            )
            jobs = [job_1, job_2]

            run = {
                "name": name,
                "jobs": jobs,
                "table_h": self.table_h,
                "table_l": self.table_l,
                "table_links": self.table_links,
                "table_out": self.table_out,
                "groupvar_h": self.groupvar_h,
                "groupvar_l": self.groupvar_l,
                "timevar": self.timevar,
            }

            return run

        def make_jobdict(name, method, col_h, col_l):
            """ make a jobdict """

            job = {
                "name": name,
                "method": method,
                "col_h": col_h,
                "col_l": col_l,
            }

            return job

        def make_jobdict_colaresi():
            """ Make a job dictionary for a colaresian product """

            name = "colaresi_bc"
            method = "colaresi"

            col_h = "h_p_a"
            col_l = "l_p_b"

            job = make_jobdict(name, method, col_h, col_l)

            return job

        def make_jobdict_product():
            """ Make a job dictionary for a simple product """

            name = "product_bc"
            method = "product"

            col_h = "h_p_a"
            col_l = "l_p_b"

            job = make_jobdict(name, method, col_h, col_l)

            return job

        # pylint: disable=too-many-arguments
        def make_df_links(
            times, timevar, groups_h, groups_l, groupvar_h, groupvar_l
        ):
            """ Make df with links between groups_h and groups_l """

            idx = datautils.DfMocker.make_idx_from_lists(
                times=times,
                groups=groups_h,
                timevar=timevar,
                groupvar=groupvar_h,
            )

            datadict_links = {
                groupvar_l: datautils.make_random_links(
                    groups_h, groups_l, times
                )
            }

            df = pd.DataFrame(datadict_links, index=idx)
            return df

        self.timevar = "timevar"
        self.groupvar_h = "pg_id"
        self.groupvar_l = "country_id"

        self.n_t = 2
        self.n_groups_h = 10
        self.n_groups_l = 3

        self.table_links = "staging.links_h_l"
        self.table_h = "landed.h_predictions"
        self.table_l = "landed.l_predictions"
        self.table_out = "landed.cl"

        mocker_h = datautils.DfMocker(
            n_t=self.n_t,
            n_groups=self.n_groups_h,
            groupvar=self.groupvar_h,
            prefix="h_",
        )
        mocker_l = datautils.DfMocker(
            n_t=self.n_t,
            n_groups=self.n_groups_l,
            groupvar=self.groupvar_l,
            prefix="l_",
        )
        self.df_h = mocker_h.df
        self.df_l = mocker_l.df

        dbutils.recreate_schema("staging")
        dbutils.recreate_schema("landed")

        self.run_db = make_run_db()
        self.job_colaresi = make_jobdict_colaresi()
        self.job_product = make_jobdict_product()

        times = list(range(self.n_t))
        groups_h = list(range(self.n_groups_h))
        groups_l = list(range(self.n_groups_l))
        self.df_links = make_df_links(
            times,
            self.timevar,
            groups_h,
            groups_l,
            self.groupvar_h,
            self.groupvar_l,
        )

        dbutils.df_to_db(self.df_h, fqtable=self.table_h)
        dbutils.df_to_db(self.df_l, fqtable=self.table_l)
        dbutils.df_to_db(self.df_links, fqtable=self.table_links)

    def tearDown(self):
        dbutils.drop_table(self.table_h)
        dbutils.drop_table(self.table_l)
        dbutils.drop_table(self.table_links)
        dbutils.drop_table(self.table_out)

    def test_merge_levels_len(self):
        """ Test that merged df has same number of rows as high res df"""
        df = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)
        self.assertEqual(len(df), len(self.df_h))

    def test_merge_levels_cols(self):
        """ Test that  all cols from low res df are included in merged df"""

        df = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)

        cols_merged = sorted(list(df.columns))
        cols_h = sorted(list(self.df_h.columns))
        cols_l = sorted(list(self.df_l.columns))

        cols_wanted = cols_h + cols_l + [self.groupvar_l]
        cols_wanted = sorted(cols_wanted)

        self.assertEqual(cols_merged, cols_wanted)

    def test_merge_asserts_timevar_l(self):
        """ Test that merge_levels checks input df_l timevar """

        df_l_wrong_timevar = self.df_l.copy()
        df_l_wrong_timevar.index.rename(
            ["wrong_timevar", self.groupvar_l], inplace=True
        )

        with self.assertRaises(AssertionError) as _:
            Crosslevel.merge_levels(
                self.df_h, df_l_wrong_timevar, self.df_links
            )

    # pylint: disable=invalid-name
    def test_merge_asserts_timevar_links(self):
        """ Test that merge_levels checks input df_links timevar """

        df_links_wrong_timevar = self.df_links.copy()
        df_links_wrong_timevar.index.rename(
            ["wrong_timevar", self.groupvar_l], inplace=True
        )

        with self.assertRaises(AssertionError) as _:
            Crosslevel.merge_levels(
                self.df_h, self.df_l, df_links_wrong_timevar
            )

    def test_compute_product(self):
        """ Test compute_product() """
        df = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)
        first_col = df.columns[0]
        second_col = df.columns[1]
        product_1 = Crosslevel.compute_product(df, first_col, second_col)

        product_2 = df[first_col] * df[second_col]

        pd.testing.assert_series_equal(product_1, product_2)

    def test_compute_colaresi(self):
        """ Test compute_colaresi() """

        col_h = self.df_h.columns[0]
        col_l = self.df_l.columns[0]

        df = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)
        sum_h_by_l = df.groupby([self.timevar, self.groupvar_l])[
            col_h
        ].transform("sum")

        p_h = df[col_h]
        p_l = df[col_l]

        joint_1 = p_l * (p_h / sum_h_by_l)

        joint_2 = Crosslevel.compute_colaresi(
            df, col_h, col_l, self.timevar, self.groupvar_l
        )

        pd.testing.assert_series_equal(joint_1, joint_2)

    def test_worker_colaresi(self):
        """ Test colaresi worker chain """

        # Compute colaresian product by calling static worker directly
        df_merged = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)
        job = self.job_colaresi

        result_1 = Crosslevel.compute_colaresi(
            df=df_merged,
            col_h=job["col_h"],
            col_l=job["col_l"],
            timevar=self.timevar,
            groupvar_l=self.groupvar_l,
        )
        result_1.name = job["name"]

        # Compute by calling the worker chain

        this_cl = Crosslevel()
        # pylint: disable=protected-access
        this_cl._setup_state(
            self.df_h,
            self.df_l,
            self.df_links,
            self.timevar,
            self.groupvar_h,
            self.groupvar_l,
        )

        result_2 = this_cl.worker(job)

        pd.testing.assert_series_equal(result_1, result_2)

    def test_worker_product(self):
        """ Test simple product worker chain """

        # Compute colaresian product by calling static worker directly
        df_merged = Crosslevel.merge_levels(self.df_h, self.df_l, self.df_links)
        job = self.job_product
        result_1 = Crosslevel.compute_product(
            df=df_merged, col_a=job["col_h"], col_b=job["col_l"]
        )
        result_1.name = job["name"]

        # Compute by calling the worker chain
        # pylint: disable=protected-access
        this_cl = Crosslevel()
        this_cl._setup_state(
            self.df_h,
            self.df_l,
            self.df_links,
            self.timevar,
            self.groupvar_h,
            self.groupvar_l,
        )

        result_2 = this_cl.worker(job)

        pd.testing.assert_series_equal(result_1, result_2)

    # pylint: disable:invalid-name
    def test_load_runfile_sets_cols_and_tables(self):
        """ Test that load runfile sets the instance columns and tables """
        cols_h = ["h_p_a", "h_p_b"]
        cols_l = ["l_p_a", "l_p_b"]

        with tempfile.TemporaryDirectory() as tempdir:
            path = os.path.sep.join([tempdir, "run.json"])
            with open(path, "w") as f:
                json.dump(self.run_db, f)

            cl = Crosslevel()
            cl.load_runfile(path)
            self.assertEqual(cl.cols_h, cols_h)
            self.assertEqual(cl.cols_l, cols_l)
            self.assertEqual(self.run_db["jobs"], cl.jobs)
            self.assertEqual(cl.table_h, self.table_h)
            self.assertEqual(cl.table_l, self.table_l)

    def test_fetch_data_sets_df(self):
        """ Test that fetch_data() sets the self.df attribute """
        with tempfile.TemporaryDirectory() as tempdir:
            path_runfile = os.path.sep.join([tempdir, "runfile.json"])

            with open(path_runfile, "w") as f:
                json.dump(self.run_db, f)

            cl = Crosslevel()
            cl.load_runfile(path_runfile)

        cl.fetch_data()

        self.assertIsInstance(cl.df, pd.DataFrame)

    def test_run_db_jobs(self):
        """ Test run_jobs() populates self.results """

        with tempfile.TemporaryDirectory() as tempdir:
            path_runfile = os.path.sep.join([tempdir, "runfile.json"])

            with open(path_runfile, "w") as f:
                json.dump(self.run_db, f)

            cl = Crosslevel()
            cl.load_runfile(path_runfile)

        cl.fetch_data()
        cl.run_jobs()

        self.assertIsInstance(cl.results, pd.DataFrame)
        self.assertGreater(len(cl.results), 0)

    def test_run_jobs_asserts_has_jobs(self):
        """ Test that run_jobs checks it has any jobs before running """

        cl = Crosslevel()
        with self.assertRaises(AssertionError) as _:
            cl.run_jobs()

    def test_run_jobs_asserts_has_data(self):
        """ Test that run_jobs checks it has any jobs before running """

        cl = Crosslevel()
        cl.load_run(self.run_db)
        message = "No data in self.df, call fetch_data first"
        with self.assertRaisesRegex(AssertionError, message) as _:
            cl.run_jobs()

    def test_publish_results(self):
        """ Test that publish_results populates the run table_out """

        cl = Crosslevel()
        cl.load_run(self.run_db)
        cl.fetch_data()
        cl.run_jobs()
        cl.publish_results()

        table = self.run_db["table_out"]
        ids = [self.timevar, self.groupvar_h]
        results_published = dbutils.db_to_df(table, ids=ids)

        results_internal = cl.results

        pd.testing.assert_frame_equal(results_internal, results_published)

    def test_worker_raises_notimplementederror(self):
        """ Test that cl.worker() raises NotImplemntedError """

        cl = Crosslevel()

        job_wrong_method = self.job_colaresi.copy()
        job_wrong_method["method"] = "unsupported"

        with self.assertRaises(NotImplementedError) as _:
            cl.worker(job_wrong_method)


if __name__ == "__main__":
    # unittest.main()
    pass
