""" Test module for OSA """

# pylint: disable=invalid-name

import unittest

from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

from views.apps.osa import estimators


class TestEstimatorFetcher(unittest.TestCase):
    """ Test estimator_fetcher() """

    def test_estimator_fetcher_returns_rf(self):
        """ A spec with RandomForestClassifier name returns that classifier """

        spec_rf = {"estimator": "RandomForestClassifier", "kwargs": {}}

        rf = estimators.estimator_fetcher(spec_rf)

        self.assertIsInstance(rf, RandomForestClassifier)

    def test_estimator_fetcher_kwargs(self):
        """ Test that kwargs are set """

        spec_rf = {
            "estimator": "RandomForestClassifier",
            "kwargs": {"n_estimators": 100},
        }

        rf = estimators.estimator_fetcher(spec_rf)

        self.assertEqual(rf.n_estimators, 100)

    def test_estimator_fetcher_pipeline(self):
        """ Test that a pipeline is returned when passed """

        spec_rf = {
            "rf": {
                "estimator": "RandomForestClassifier",
                "kwargs": {"n_estimators": 500},
            }
        }

        spec_scaler = {"scaler": {"estimator": "StandardScaler", "kwargs": {}}}

        spec_pipeline = {
            "estimator": "Pipeline",
            "steps": [spec_scaler, spec_rf],
        }

        pipeline = estimators.estimator_fetcher(spec_pipeline)

        self.assertIsInstance(pipeline, Pipeline)

    def test_estimator_fetcher_asserts_two_keys(self):
        """ Test that keys are checked to only be two """

        spec_with_too_many_keys = {
            "name": "somename",
            "kwargs": {},
            "one_too_many": [],
        }

        with self.assertRaises(AssertionError) as _:
            estimators.estimator_fetcher(spec_with_too_many_keys)

    def test_estimator_fetcher_asserts_correct_keys(self):
        """ Test that only allowed keys are allowed """

        spec_with_wrong_keys = {"wrong": "somename", "kwargs": {}}

        with self.assertRaises(AssertionError) as _:
            estimators.estimator_fetcher(spec_with_wrong_keys)

    def test_estimator_fetcher_asserts_estimator_exists(self):
        """ Test that NotImplementedError is raised for unknown estimators """

        spec_with_unknown_name = {
            "estimator": "unknown estimator",
            "kwargs": {},
        }

        with self.assertRaises(NotImplementedError) as _:
            estimators.estimator_fetcher(spec_with_unknown_name)


if __name__ == "__main__":
    unittest.main()
