""" Tests for the survey generator """

# pragma: no cover
# pylint: skip-file

import unittest
import os


from views.apps.survey import questions
from views.tests import test_survey_utils


class TestSurveyQuestions(unittest.TestCase):
    """ Test survey questions """

    def setUp(self):
        """ Setup the data tests need """
        this_dir = os.path.dirname(os.path.abspath(__file__))
        dir_questions = os.path.join(this_dir, "data/survey/questions/")

        test_survey_utils.setup_db_survey()

        fname = "review_stakeholder_drop.txt"
        path_q_review_stakeholder_drop = os.path.join(dir_questions, fname)
        with open(path_q_review_stakeholder_drop, "r") as f:
            self.q_review_stakeholder_drop = f.read()

        fname = "review_relativepower.txt"
        path_q_review_relativepower = os.path.join(dir_questions, fname)
        with open(path_q_review_relativepower, "r") as f:
            self.q_review_relativepower = f.read()

        fname = "review_issues_revision.txt"
        path_q_review_issues_revision = os.path.join(dir_questions, fname)
        with open(path_q_review_issues_revision, "r") as f:
            self.q_review_issues_revision = f.read()

        fname = "stakeholder_issue.txt"
        path_q_stakeholder_issue = os.path.join(dir_questions, fname)
        with open(path_q_stakeholder_issue, "r") as f:
            self.q_stakeholder_issue = f.read()

        fname = "stakeholder_salience.txt"
        path_q_stakeholder_salience = os.path.join(dir_questions, fname)
        with open(path_q_stakeholder_salience, "r") as f:
            self.q_stakeholder_salience = f.read()

        fname = "demanding_stakeholders.txt"
        path_q_demanding_stakeholders = os.path.join(dir_questions, fname)
        with open(path_q_demanding_stakeholders, "r") as f:
            self.q_demanding_stakeholders = f.read()

        fname = "demands_to_issues.txt"
        path_q_demands_to_issues = os.path.join(dir_questions, fname)
        with open(path_q_demands_to_issues, "r") as f:
            self.q_demands_to_issues = f.read()

        fname = "demand_label.txt"
        path_q_demand_label = os.path.join(dir_questions, fname)
        with open(path_q_demand_label, "r") as f:
            self.q_demand_label = f.read()

        fname = "rejection_to_stakeholder.txt"
        path_q_rejection_to_stakeholder = os.path.join(dir_questions, fname)
        with open(path_q_rejection_to_stakeholder, "r") as f:
            self.q_rejection_to_stakeholder = f.read()

        fname = "campaign_intensity.txt"
        path_q_campaign_intensity = os.path.join(dir_questions, fname)
        with open(path_q_campaign_intensity, "r") as f:
            self.q_campaign_intensity = f.read()

        fname = "reaction_intensity.txt"
        path_q_reaction_intensity = os.path.join(dir_questions, fname)
        with open(path_q_reaction_intensity, "r") as f:
            self.q_reaction_intensity = f.read()

        fname = "stakeholder_threats.txt"
        path_q_stakeholder_threats = os.path.join(dir_questions, fname)
        with open(path_q_stakeholder_threats, "r") as f:
            self.q_stakeholder_threats = f.read()

        fname = "direction_threats.txt"
        path_q_direction_threats = os.path.join(dir_questions, fname)
        with open(path_q_direction_threats, "r") as f:
            self.q_direction_threats = f.read()

        fname = "effect_election.txt"
        path_q_effect_election = os.path.join(dir_questions, fname)
        with open(path_q_effect_election, "r") as f:
            self.q_effect_election = f.read()

        fname = "effect_other_event.txt"
        path_q_effect_other_event = os.path.join(dir_questions, fname)
        with open(path_q_effect_other_event, "r") as f:
            self.q_effect_other_event = f.read()

        fname = "demand_forecast_stakeholder.txt"
        path_q_demand_forecast_stakeholder = os.path.join(dir_questions, fname)
        with open(path_q_demand_forecast_stakeholder, "r") as f:
            self.q_demand_forecast_stakeholder = f.read()

        fname = "p3_violence.txt"
        path_q_p3_violence = os.path.join(dir_questions, fname)
        with open(path_q_p3_violence, "r") as f:
            self.q_p3_violence = f.read()

        fname = "p12_violence.txt"
        path_q_p12_violence = os.path.join(dir_questions, fname)
        with open(path_q_p12_violence, "r") as f:
            self.q_p12_violence = f.read()

        fname = "p12_violence_stakeholder.txt"
        path_q_p12_violence_stakeholder = os.path.join(dir_questions, fname)
        with open(path_q_p12_violence_stakeholder, "r") as f:
            self.q_p12_violence_stakeholder = f.read()

        fname = "p3_violence_government.txt"
        path_q_p3_violence_government = os.path.join(dir_questions, fname)
        with open(path_q_p3_violence_government, "r") as f:
            self.q_p3_violence_government = f.read()

        fname = "p3_violence_civilians.txt"
        path_q_p3_violence_civilians = os.path.join(dir_questions, fname)
        with open(path_q_p3_violence_civilians, "r") as f:
            self.q_p3_violence_civilians = f.read()

        fname = "p3_violence_civilians_pr.txt"
        path_q_p3_violence_civilians_pr = os.path.join(dir_questions, fname)
        with open(path_q_p3_violence_civilians_pr, "r") as f:
            self.q_p3_violence_civilians_pr = f.read()

        fname = "external_actor_stakeholder.txt"
        path_q_external_actor_stakeholder = os.path.join(dir_questions, fname)
        with open(path_q_external_actor_stakeholder, "r") as f:
            self.q_external_actor_stakeholder = f.read()

        fname = "p3_violence_civilians_stakeholder.txt"
        path_q_p3_violence_civilians_stakeholder = os.path.join(
            dir_questions, fname
        )
        with open(path_q_p3_violence_civilians_stakeholder, "r") as f:
            self.q_p3_violence_civilians_stakeholder = f.read()

        fname = "p3_displacement.txt"
        path_q_p3_displacement = os.path.join(dir_questions, fname)
        with open(path_q_p3_displacement, "r") as f:
            self.q_p3_displacement = f.read()

        fname = "p3_displacement_stakeholder.txt"
        path_q_p3_displacement_stakeholder = os.path.join(dir_questions, fname)
        with open(path_q_p3_displacement_stakeholder, "r") as f:
            self.q_p3_displacement_stakeholder = f.read()

    def tearDown(self):
        """ No cleanup needed as the schema setup query drops the schema """
        pass

    def test_review_stakeholder_drop(self):
        """ Test that make_q_stakeholder_drop returns a q like the manual """

        wanted = self.q_review_stakeholder_drop
        got = questions.review_stakeholder_drop(stakeholder_id=1)
        self.assertEqual(got, wanted)

    def test_review_relativepower(self):
        """ Test that make_q_review_relativepower returns q like the manual """

        wanted = self.q_review_relativepower
        got = questions.review_relativepower(stakeholder_id=1)
        self.assertEqual(got, wanted)

    def test_review_issues_revision(self):
        """ Test that make_q_review_issues_revision returns like the manual """

        wanted = self.q_review_issues_revision
        got = questions.review_issues_revision(issue_id=1)
        self.assertEqual(got, wanted)

    def test_stakeholder_issue(self):
        """ Test that make_q_stakeholder_issue returns a q like the manual """

        wanted = self.q_stakeholder_issue
        got = questions.stakeholder_issue(stakeholder_id=1, issue_id=1)
        self.assertEqual(got, wanted)

    def test_stakeholder_salience(self):
        """ Test that make_q_stakeholder_salience returns like the manual """

        wanted = self.q_stakeholder_salience
        got = questions.stakeholder_salience(stakeholder_id=1, issue_id=1)
        self.assertEqual(got, wanted)

    def test_demanding_stakeholders(self):
        """ Test that make_q_demanding_stakeholders returns like the manual """

        wanted = self.q_demanding_stakeholders
        got = questions.demanding_stakeholders(expert_id=1)
        self.assertEqual(got, wanted)

    def test_demands_to_issues(self):
        """ Test that make_q_demands_to_issues returns a q like the manual """

        wanted = self.q_demands_to_issues
        got = questions.demands_to_issues(stakeholder_id=1, expert_id=1)
        self.assertEqual(got, wanted)

    def test_demand_label(self):
        """ Test that make_q_demand_label returns a q like the manual """

        wanted = self.q_demand_label
        got = questions.demand_label(stakeholder_id=1)
        self.assertEqual(got, wanted)

    def test_rejection_to_stakeholder(self):
        """Test that make_q_rejection_to_stakeholder returns like the manual """

        wanted = self.q_rejection_to_stakeholder
        got = questions.rejection_to_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)

    def test_campaign_intensity(self):
        """ Test that make_q_campaign_intensity returns a q like the manual """

        wanted = self.q_campaign_intensity
        got = questions.campaign_intensity(expert_id=1)
        self.assertEqual(got, wanted)

    def test_reaction_intensity(self):
        """ Test that make_q_campaign_intensity returns a q like the manual """

        wanted = self.q_reaction_intensity
        got = questions.reaction_intensity(expert_id=1)
        self.assertEqual(got, wanted)

    def test_stakeholder_threats(self):
        """ Test that make_q_stakeholder_threats returns a q like the manual """

        wanted = self.q_stakeholder_threats
        got = questions.stakeholder_threats(expert_id=1)
        self.assertEqual(got, wanted)

    def test_direction_threats(self):
        """ Test that make_q_direction_threats returns a q like the manual """

        wanted = self.q_direction_threats
        got = questions.direction_threats(expert_id=1)
        self.assertEqual(got, wanted)

    def test_effect_election(self):
        """ Test that make_q_effect_election returns a q like the manual """

        wanted = self.q_effect_election
        got = questions.effect_election(issue_id=1)
        self.assertEqual(got, wanted)

    def test_effect_other_event(self):
        """ Test that make_q_effect_other_event returns a q like the manual """

        wanted = self.q_effect_other_event
        got = questions.effect_other_event(issue_id=1)
        self.assertEqual(got, wanted)

    def test_demand_forecast_stakeholder(self):
        """Test that make_q_demand_forecast_stakeholder return like manual """

        wanted = self.q_demand_forecast_stakeholder
        got = questions.demand_forecast_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)

    def test_p3_violence(self):
        """ Test that make_q_p3_violence returns a q like the manual """

        wanted = self.q_p3_violence
        got = questions.p3_violence()
        self.assertEqual(got, wanted)

    def test_p12_violence(self):
        """ Test that make_q_p12_violence returns a q like the manual """

        wanted = self.q_p12_violence
        got = questions.p12_violence()
        self.assertEqual(got, wanted)

    def test_p12_violence_stakeholder(self):
        """ Test that make_q_p12_violence_stakeholder returns like manual """

        wanted = self.q_p12_violence_stakeholder
        got = questions.p12_violence_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)

    def test_p3_violence_government(self):
        """ Test that make_q_p3_violence_government returns like manual """

        wanted = self.q_p3_violence_government
        got = questions.p3_violence_government()
        self.assertEqual(got, wanted)

    def test_p3_violence_civilians(self):
        """ Test that make_q_p3_violence_civilians returns like manual """

        wanted = self.q_p3_violence_civilians
        got = questions.p3_violence_civilians()
        self.assertEqual(got, wanted)

    def test_p3_violence_civilians_pr(self):
        """ Test that make_q_p3_violence_civilians_pr returns like manual """

        wanted = self.q_p3_violence_civilians_pr
        got = questions.p3_violence_civilians_pr()
        self.assertEqual(got, wanted)

    def test_external_actor_stakeholder(self):
        """ Test that make_q_external_actor_stakeholder returns like manual """

        wanted = self.q_external_actor_stakeholder
        got = questions.external_actor_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)

    def test_p3_violence_civilians_stakeholder(self):
        """Test make_q_p3_violence_civilians_stakeholder returns like manual """

        wanted = self.q_p3_violence_civilians_stakeholder
        got = questions.p3_violence_civilians_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)

    def test_p3_displacement(self):
        """ Test that make_q_p3_displacement returns a q like the manual """

        wanted = self.q_p3_displacement
        got = questions.p3_displacement()
        self.assertEqual(got, wanted)

    def test_p3_displacement_stakeholder(self):
        """ Test that make_q_p3_displacement_stakeholder returns like manual """

        wanted = self.q_p3_displacement_stakeholder
        got = questions.p3_displacement_stakeholder(expert_id=1)
        self.assertEqual(got, wanted)


if __name__ == "__main__":
    # unittest.main()
    pass
