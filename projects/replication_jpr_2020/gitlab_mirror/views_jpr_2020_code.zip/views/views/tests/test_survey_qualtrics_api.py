""" Tests for survey qualtrics API

@TODO: test_post_survey_from_db raises a ResourceWarning, why?
"""

# pylint: skip-file

import unittest
import os
import tempfile
import io

import pandas as pd

from views.apps.survey import qualtrics_api as api
from views.apps.survey import survey_generator as sg
from views.tests import test_survey_utils


class TestAPI(unittest.TestCase):
    """Tests for Crosslevel module"""

    def setUp(self):
        """ Setup state for testing pyutils"""

        test_survey_utils.setup_db_survey()

        this_dir = os.path.dirname(os.path.abspath(__file__))
        self.dir_surveys = os.path.join(this_dir, "data/survey/surveys/")

        # Holds Qualitrcs Survey IDs for test-posted surveys
        self.posted_surveys = []

        # This is a survey which should have some responses
        self.qsi = "SV_bE3p25uxDa6OkDz"

    def tearDown(self):
        """ Drop all the test-posted surveys """

        for qsi in self.posted_surveys:
            api.delete_survey(qsi)

    def test_list_surveys(self):
        """ Test that surveys can be listed """

        surveys = api.list_surveys()
        self.assertIsInstance(surveys, dict)

    def test_post_survey_from_db(self):
        """ Test that a survey can be posted from the db """

        # Make sure its in the db to start with
        fname = "survey_poc.txt"
        path_survey_poc = os.path.join(self.dir_surveys, fname)
        with open(path_survey_poc, "r") as f:
            survey_poc = f.read()
        sg.write_survey_txt_to_db(txt=survey_poc, survey_id=1)

        surveys_pre_posting = api.list_surveys()

        qsi = api.post_survey_from_db(survey_id=1)
        self.posted_surveys.append(qsi)

        surveys_post_posting = api.list_surveys()

        # This qsi shouldn't have been in there to start with
        self.assertNotIn(qsi, surveys_pre_posting)

        # It should be there now though
        self.assertIn(qsi, surveys_post_posting)

    def test_get_survey(self):
        """ Test getting a survey """

        surveys = api.list_surveys()
        for qsi in surveys:
            survey = api.get_survey(qualtrics_survey_id=qsi)
            break
        self.assertIsInstance(survey, dict)

    def test_save_survey(self):
        """ Test saving a survey to a file """

        # Get a single qsi
        for qualtrics_survey_id in api.list_surveys():
            qsi = qualtrics_survey_id
            break

        with tempfile.TemporaryDirectory() as tempdir:
            fname = "saved_survey.qsf"
            path = os.path.join(tempdir, fname)

            api.save_survey(qualtrics_survey_id=qsi, path=path)
            file_exists = os.path.exists(path)

        self.assertTrue(file_exists)

    def test_fetch_survey_response_to_str(self):
        """ Test that responses can be parsed as csv"""

        survey_response = api.fetch_survey_response_to_str(self.qsi)

        df = pd.read_csv(io.StringIO(survey_response))

        self.assertIsInstance(df, pd.DataFrame)

    def test_fetch_survey_response_to_str_anonymises(self):
        """ Test that responses don't contain sensitive data """

        wanted = "ResponseId"
        forbidden = "LocationLatitude"

        survey_response = api.fetch_survey_response_to_str(self.qsi)

        df = pd.read_csv(io.StringIO(survey_response))
        columns = list(df.columns)

        self.assertNotIn(forbidden, columns)
        self.assertIn(wanted, columns)

    def test_post_survey_from_str_raises_runtime_on_bad_survey(self):
        """ A incorrectly formatted survey raises RuntimeError """

        # Some broken advanced text format stuff
        bad_survey = "[[AdvancedFormat]][[NotAFeature]]"

        # Make sure we get a runtimeerror when we try to post this
        with self.assertRaises(RuntimeError) as _:
            api.post_survey_from_str(name="test_bad", txt=bad_survey)


if __name__ == "__main__":
    print("Skipping test_survey_qualtrics_api because its slow")
    # unittest.main()
