DROP SCHEMA IF EXISTS survey_info CASCADE;
CREATE SCHEMA survey_info;
DROP SCHEMA IF EXISTS survey_data CASCADE;
CREATE SCHEMA survey_data;
DROP SCHEMA IF EXISTS survey_now CASCADE;
CREATE SCHEMA survey_now;

-- .info
-- replace with staging.country
-- CREATE TABLE survey_info.country(
--     id SERIAL PRIMARY KEY,
--     name TEXT,
--     views_country_id INT -- temporary local fix
-- );

-- CREATE TABLE survey_info.round(
--     id SERIAL PRIMARY KEY,
--     month_id INT
--     CONSTRAINT no_dup_month UNIQUE (month_id)
-- );

CREATE TABLE survey_info.expert(
    id SERIAL PRIMARY KEY,
    --country_id INT REFERENCES survey_info.country(id),
    country_id INT REFERENCES staging.country(id),
    active BOOLEAN DEFAULT TRUE,
    expert_foreign_id INT NOT NULL, -- link to external secret identities table
    CONSTRAINT no_dup_expert UNIQUE (country_id, expert_foreign_id)
);

CREATE TABLE survey_info.survey(
    id SERIAL PRIMARY KEY,
    --country_id INT REFERENCES survey_info.country(id),
    country_id INT REFERENCES staging.country(id),
    expert_id INT REFERENCES survey_info.expert(id),
    round_id INT, -- rather 1,2,3, etc. Month reference in creation_date.
    --round_id INT REFERENCES survey_info.round(id),
    creation_date DATE,
    qualtrics_name TEXT UNIQUE,
    qualtrics_survey_id TEXT UNIQUE,
    txt TEXT,
    response_raw TEXT,
    CONSTRAINT no_dup_survey UNIQUE (country_id, expert_id, round_id)
);


-- .data (retrieved from baseline interviews and survey responses)
CREATE TABLE survey_data.question_response(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    qualtrics_question_id TEXT,
    question_text TEXT,
    response TEXT,
    stakeholder_id TEXT,
    sub_stakeholder_id TEXT,
    stakeholder_number INT,
    issue_id TEXT,
    issue_number INT,
    revision_parse_id text,
    position_parse_id text,
    demand_parse_id text,
    threat_parse_id text,
    prediction_parse_id text,
    stakeholder_prediction_parse_id text,
    prediction_issue_parse_id text,
    comment_parse_id text,
    recode INT,
    baseq INT,
    baseq_link INT,
    CONSTRAINT single_question_number_per_survey UNIQUE (survey_id, qualtrics_question_id)
);

CREATE TABLE survey_data.stakeholder(
    id SERIAL PRIMARY KEY,
    --survey_id INT REFERENCES survey_info.survey(id),
    --country_id INT REFERENCES survey_info.country(id),
    country_id INT REFERENCES staging.country(id),
    active BOOLEAN DEFAULT TRUE,
    name TEXT,
    dominant INT, --boolean instead? + *** how to keep track of changes? ***
    --relative_power INT, --how to keep track of changes?
    CONSTRAINT no_dup_stakeholder UNIQUE (country_id, name)
);

CREATE TABLE survey_data.issue(
    id SERIAL PRIMARY KEY,
    --survey_id INT REFERENCES survey_info.survey(id),
    --country_id INT REFERENCES survey_info.country(id),
    country_id INT REFERENCES staging.country(id),
    active BOOLEAN DEFAULT TRUE,
    name TEXT,
    summary TEXT,
    left_main INT REFERENCES survey_data.stakeholder(id),
    right_main INT REFERENCES survey_data.stakeholder(id),
    left_extreme TEXT,
    left_extreme_sum TEXT,
    right_extreme TEXT,
    right_extreme_sum TEXT,
    status_quo TEXT,
    status_quo_sum TEXT,
    status_quo_location INT,
    CONSTRAINT no_dup_issue UNIQUE (country_id, name)
);

CREATE TABLE survey_data.revision(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    review_stakeholder_drop_comment text,
    review_stakeholder_add_1 text,
    review_stakeholder_add_dominant_1 text,
    review_stakeholder_add_2 text,
    review_stakeholder_add_dominant_2 text,
    review_stakeholder_add_3 text,
    review_stakeholder_add_dominant_3 text,
    review_issue_drop_comment text,
    review_issue_add_1 text,
    review_issue_add_stakeholder_a_1 text,
    review_issue_add_stakeholder_b_1 text,
    review_issue_add_extreme_a_1 text,
    review_issue_add_extreme_b_1 text,
    review_issue_add_status_quo_1 text,
    review_issue_add_status_quo_location_1 text,
    review_issue_add_2 text,
    review_issue_add_stakeholder_a_2 text,
    review_issue_add_stakeholder_b_2 text,
    review_issue_add_extreme_a_2 text,
    review_issue_add_extreme_b_2 text,
    review_issue_add_status_quo_2 text,
    review_issue_add_status_quo_location_2 text,
    review_issue_add_3 text,
    review_issue_add_stakeholder_a_3 text,
    review_issue_add_stakeholder_b_3 text,
    review_issue_add_extreme_a_3 text,
    review_issue_add_extreme_b_3 text,
    review_issue_add_status_quo_3 text,
    review_issue_add_status_quo_location_3 text,
    CONSTRAINT single_survey_revisions UNIQUE(survey_id)
);

-- ! LABEL CHANGE IS NEW INSERT?
CREATE TABLE survey_data.revision_to_stakeholder(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    review_stakeholder_drop INT,
    review_stakeholder_dominant INT,
    review_stakeholder_revise TEXT,
    review_relativepower TEXT, -- *** questionable ***
    CONSTRAINT no_dup_survey_stakeholder UNIQUE (survey_id, stakeholder_id)
);

CREATE TABLE survey_data.revision_to_issue(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    issue_id INT REFERENCES survey_data.issue(id),
    review_issue_drop INT,
    review_issues_revision_issue TEXT,
    review_issues_revision_sq TEXT,
    review_issues_revision_sq_location INT,
    CONSTRAINT no_dup_survey_issue UNIQUE (survey_id, issue_id)
);

CREATE TABLE survey_data.position(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    issue_id INT REFERENCES survey_data.issue(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    -- main INT, -- if in left_main or right_main under .stakeholder
    label TEXT,
    summary TEXT,
    position INT,
    confidence_position INT,
    salience INT,
    confidence_salience INT,
    CONSTRAINT no_dup_position UNIQUE (survey_id, issue_id, stakeholder_id)
);

CREATE TABLE survey_data.demand(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    issue_id INT REFERENCES survey_data.issue(id),
    demand_label TEXT,
    demand_reaction TEXT,
    campaign_intensity TEXT,
    reaction_to_rejection TEXT,
    demand_reaction_forecast TEXT,
    confidence_demand_reaction INT,
    effect_demand_reaction_forecast TEXT,
    confidence_effect_demand_reaction INT,
    CONSTRAINT single_demand_per_stakeholder_issue UNIQUE(survey_id, stakeholder_id, issue_id)
);

CREATE TABLE survey_data.stakeholder_demand_rejection(
    id SERIAL PRIMARY KEY,
    demand_id INT REFERENCES survey_data.demand(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    rejection_to_stakeholder INT,
    reaction_intensity TEXT,
    CONSTRAINT single_rejection UNIQUE(demand_id, stakeholder_id)
);

CREATE TABLE survey_data.threat(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    describe_threat TEXT,
    direction_threats TEXT,
    source_threat TEXT,
    CONSTRAINT single_threat_per_stakeholder UNIQUE(survey_id, stakeholder_id)
);

CREATE TABLE survey_data.predictions(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    scheduled_election text,
    other_event text,
    comment_other_event text,
    demand_forecast TEXT,
    confidence_demand_forecast INT,
    demand_forecast_stakeholder text,
    confidence_demand_forecast_stakeholder INT,
    demand_escalation TEXT,
    confidence_demand_escalation INT,
    demand_promise TEXT,
    confidence_demand_promise INT,
    demand_forecast_reaction TEXT,
    confidence_demand_forecast_reaction INT,
    confidence_demand_forecast_stakeholder_resist INT,
    p3_violence INT,
    confidence_p3_violence INT,
    p12_violence INT,
    confidence_p12_violence INT,
    confidence_p12_violence_stakeholder INT,
    p3_violence_government text,
    confidence_p3_violence_government INT,
    p3_violence_civilians text,
    confidence_p3_violence_civilians INT,
    p12_violence_25brd INT,
    confidence_p12_violence_25brd INT,
    p12_violence_1000brd INT,
    confidence_p12_violence_1000brd INT,
    external_actor INT,
    confidence_external_actor INT,
    external_actor_stakeholder text,
    p3_violence_civilians_pr INT,
    confidence_p3_violence_civilians_pr INT,
    confidence_p3_violence_civilians_stakeholder INT,
    p3_displacement INT,
    confidence_p3_displacement INT,
    confidence_p3_displacement_stakeholder INT,
    p3_negotiations INT,
    confidence_p3_negotiations INT,
    p3_ceasefire INT,
    confidence_p3_ceasefire INT,
    p3_agreement INT,
    confidence_p3_agreement INT,
    CONSTRAINT single_survey_predictions UNIQUE(survey_id)
);

CREATE TABLE survey_data.stakeholder_predictions(
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    stakeholder_id INT REFERENCES survey_data.stakeholder(id),
    p12_violence_stakeholder INT, --boolean?
    p3_violence_civilians_stakeholder INT,
    p3_displacement_stakeholder INT,
    demand_forecast_stakeholder_resist INT,
    CONSTRAINT single_stakeholder_predictions UNIQUE(survey_id, stakeholder_id)
);

CREATE TABLE survey_data.prediction_to_issue (
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    issue_id INT REFERENCES survey_data.issue(id),
    effect_election TEXT,
    effect_election_direction TEXT,
    confidence_effect_election INT,
    effect_other_event TEXT,
    effect_event_direction TEXT,
    confidence_effect_other_event INT,
    CONSTRAINT single_issue_predictions UNIQUE(survey_id, issue_id)
);

CREATE TABLE survey_data.comments (
    id SERIAL PRIMARY KEY,
    survey_id INT REFERENCES survey_info.survey(id),
    comment_stakeholder_issue text,
    comment_demands text,
    comment_threat text,
    comment_predictions text,
    final_comments text,
    CONSTRAINT single_survey_comments UNIQUE(survey_id)
);

-- .now (used for survey generation)
CREATE VIEW survey_now.issue AS
SELECT id, country_id, name, summary, left_extreme, left_extreme_sum,
right_extreme, right_extreme_sum, status_quo, status_quo_sum,
status_quo_location
FROM survey_data.issue
WHERE active IS TRUE;

CREATE VIEW survey_now.stakeholder AS
SELECT id, country_id, name, dominant
FROM survey_data.stakeholder
WHERE active IS TRUE;
