
SELECT * FROM survey.stakeholder LEFT JOIN survey.issue ON stakeholder.survey_id=issue.survey_id WHERE issue.survey_id=4;

SELECT
  *
FROM survey.issue
INNER JOIN survey.position ON position.issue_id=issue.id
INNER JOIN survey.stakeholder ON position.stakeholder_id = stakeholder.id;


SELECT
  country.id AS country_id,
  expert.id AS expert_id,
  expert.name AS expert_name,
  survey.id AS survey_id,
  round.id AS round_id,
  round.month_id as month_id
FROM
  survey.country
  INNER JOIN survey.expert
    ON country.id=expert.country_id
  INNER JOIN survey.survey
      ON expert.id=survey.expert_id
  INNER JOIN survey.round
      ON survey.round_id=round.id;

-- Stakeholders positions on issues
SELECT
  *
FROM survey.issue
INNER JOIN survey.position ON position.issue_id=issue.id
INNER JOIN survey.stakeholder ON position.stakeholder_id = stakeholder.id;
