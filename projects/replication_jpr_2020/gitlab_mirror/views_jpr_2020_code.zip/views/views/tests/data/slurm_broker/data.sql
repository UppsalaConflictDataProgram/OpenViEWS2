INSERT INTO broker.task (task, status)
  VALUES
    ('
       {
           "name": "publish_osa_pgm_acled_wcm_fcast_test",
           "worker": "db",
           "params": {
               "path_hdf": "/storage/test/fakedata.hdf5",
               "fqtable": "landing.osa_pgm_acled_wcm_fcast_test"
           }
       }
     ')
