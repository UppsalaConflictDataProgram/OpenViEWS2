DROP SCHEMA IF EXISTS survey_interview CASCADE;
CREATE SCHEMA survey_interview;

CREATE TABLE survey_interview.interview (
  id  SERIAL PRIMARY KEY,
  expert_foreign_id INT,
  country_id SERIAL REFERENCES staging.country(id),
  round_id INT,
  comment_ucdp text
  CONSTRAINT single_survey_per_round UNIQUE(expert_foreign_id, country_id, round_id)
);

CREATE TABLE survey_interview.issue(
  id SERIAL PRIMARY KEY,
  interview_id INT REFERENCES survey_interview.interview(id),
  name text,
  summary text,
  left_extreme text,
  left_extreme_sum text,
  right_extreme text,
  right_extreme_sum text,
  status_quo text,
  status_quo_sum text,
  status_quo_location INT
);

CREATE TABLE survey_interview.stakeholder (
  id SERIAL PRIMARY KEY,
  interview_id INT REFERENCES survey_interview.interview(id),
  name text,
  dominant INT
);

CREATE TABLE survey_interview.position (
  id SERIAL PRIMARY KEY,
  interview_id INT REFERENCES survey_interview.interview(id),
  stakeholder_id INT REFERENCES survey_interview.stakeholder(id),
  issue_id INT REFERENCES survey_interview.issue(id),
  label text,
  summary text,
  position INT,
  CONSTRAINT single_position_per_issue_stakeholder UNIQUE(interview_id, stakeholder_id, issue_id)
);
