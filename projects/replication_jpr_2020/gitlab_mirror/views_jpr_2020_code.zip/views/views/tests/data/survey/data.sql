
-- Two countries
INSERT INTO survey.country(name)
  VALUES
    ('Sweden'),
    ('Norway'),
    ('Nigeria'),
    ('Angola')
  ;

-- Two experts per country
INSERT INTO survey.expert(country_id, name)
    VALUES
      (1, 'First Swedish Expert'),
      (1, 'Second Swedish Expert'),
      (2, 'First Norwegiean Expert'),
      (2, 'Second Norwegiean Expert'),
      (3, 'Matthias Basedau'),
      (4, 'Cristina Udelsmann Rodrigues')
      ;

-- two rounds of surveys
INSERT INTO survey.round(month_id)
  VALUES
    (420),
    (430);

-- one survey survey per author per round
INSERT INTO survey.survey(round_id, expert_id)
  VALUES
    (1, 1),
    (1, 2),
    (1, 3),
    (1, 4),
    (1, 5),
    (1, 6),
    (2, 1),
    (2, 2),
    (2, 3),
    (2, 4),
    (2, 5),
    (2, 6);

-- Two issues per country
-- All issues recorded for first survey
INSERT INTO survey.issue(survey_id, name, description, left_extreme, status_quo,
                         right_extreme, status_quo_location, actor1_label,
                         actor1_location, actor2_label, actor2_location)
    VALUES
      (1, 'Tax level', 'What is correct level of taxation?', 'No taxation','50% of GDP', 'All the taxes', 10, 'N/A', 0, 'N/A', 0),
      (2, 'Goverment', 'Who should be Prime minister?', 'Stefan','Jimmie','Uffe', 10, 'N/A', 0, 'N/A', 0),
      (3, 'Electric cars', 'Free Teslas for all?', 'Big subsidy', 'Some subsidy', 'Ban batteries in cars', 10, 'N/A', 0, 'N/A', 0),
      (4, 'Oil fund', 'What should the govt do with the oil fund?','Donate to poor','Buy tanks', 'Mixed', 10, 'N/A', 0, 'N/A', 0),
      (8, 'New Norwegian issue', 'Who is number one Norwegian royal?','Haakon', 'Harald', 'Märtha Louise', 10, 'N/A', 0, 'N/A', 0),
      (1, 'Nuclear Power', 'Should Nuclear Power be increased?', 'Ban it', 'Regulate it hard', 'Go full nuclear', 10, 'N/A', 0, 'N/A', 0),
      (5, 'Establishment of a state based on Sharia law', 'Should Nigeria be an Islamic state?','Establishment of an Islamic State in Western Africa', 'De facto control in Northeastern Nigerian areas, no de jure establishment', 'No provisions allowing for Islamic state in Nigeria', 17, 'Establishment of an Islamic State in Nigeria', 1, 'No provisions allowing for the establishment of an Islamic State in Nigeria', 18),
      (5, 'Emancipation of the Niger Delta', 'Should the Niger Delta own the natural resource wealth of Nigeria?','Complete control over natural resources in the Niger Delta', 'Promises but little action on redistribution measures','No provisions allowing for autonomous control over natural resources in the Niger Delta', 15, 'Control of the natural resources in Niger Delta', 0, 'No provisions allowing for the control of the natural resources by MEND', 18),
      (5, 'Religious hegemony over territory', 'Should Nigeria be Christian or Muslim?', 'Killing of all Christians in territories','No party with upper hand', 'Killing of all Muslims in territories', 10, 'Control of the territories of Christians and forcing them to move', 7, 'Control of the territories of Muslims and forcing them to move', 13);

INSERT INTO survey.stakeholder (survey_id, name, power, dominant)
  VALUES
    (1, 'Socialdemokraterna', 50, 1),
    (1, 'Moderaterna', 10, 0),
    (1, 'SD', 40, 0),
    (2, 'Sossarna', 28, 0),
    (2, 'Borgarna', 20, 0),
    (2, 'Nationalisterna', 17, 0),
    (3, 'Röde', 10, 0),
    (3, 'Blåe', 40, 0),
    (3, 'Nasjonalisterna', 50, 1),
    (4, 'Arbeiderpartiet', 27, 0),
    (4, 'Høyre', 25, 0),
    (4, 'Fremskrittspartiet', 15, 0),
    (5, 'Government of Nigeria', 60, 1),
    (5, 'Boko Haram', 20, 0),
    (5, 'Movement for the Emancipation of the Niger Delta (MEND)', 5, 0),
    (5, 'The Fulani people', 5, 0),
    (5, 'The Igbo people', 5, 0),
    (5, 'Christians', 5, 0);

INSERT INTO survey.position(survey_id, stakeholder_id, issue_id, position, salience)
  VALUES
    (1, 1, 1, 70, 90),
    (1, 2, 1, 20, 90),
    (1, 3, 1, 50, 0),
    (2, 4, 2, 100, 100),
    (2, 5, 2, 0, 100),
    (2, 6, 2, 50, 100),
    (3, 7, 3, 0, 75),
    (3, 8, 3, 50, 75),
    (3, 9, 3, 100, 10),
    (4, 10, 4, 0, 90),
    (4, 11, 4, 100, 30),
    (4, 12, 4, 50, 30),
    (1, 1, 6, 50, 75),
    (1, 2, 6, 60, 35),
    (1, 3, 6, 100, 10)
    ;
