""" One off script for map test data setup """
# @TODO: Remove this script
# pylint: disable-all

import pandas as pd

df_pgm_pred = pd.read_hdf(
    "/storage/runs/current/ensemble/results/ensemble_pgm_eval_test.hdf5"
)
df_cm_pred = pd.read_hdf(
    "/storage/runs/current/ensemble/results/ensemble_cm_eval_test.hdf5"
)
df_pgm_act = pd.read_hdf(
    "/storage/runs/current/ds/transforms/pgm_transforms/data/pgm_imp_1.hdf5"
)
df_cm_act = pd.read_hdf(
    "/storage/runs/current/ds/transforms/cm_transforms/data/cm_imp_1.hdf5"
)
df_months = pd.read_csv("/Users/frehoy/Desktop/months.csv")
df_priogrid = pd.read_csv("/Users/frehoy/Desktop/priogrid.csv")

ids_pgm = ["month_id", "pg_id"]
ids_cm = ["month_id", "country_id"]

df_pgm_pred.set_index(ids_pgm, inplace=True)
df_pgm_act.reset_index(inplace=True)
df_pgm_act.set_index(ids_pgm, inplace=True)
df_cm_pred.set_index(ids_cm, inplace=True)
df_cm_act.reset_index(inplace=True)
df_cm_act.set_index(ids_cm, inplace=True)
df_months.set_index(["month_id"], inplace=True)
df_priogrid.set_index(["pg_id"], inplace=True)


df_pgm = df_pgm_pred.merge(df_pgm_act, left_index=True, right_index=True)
df_cm = df_cm_pred.merge(df_cm_act, left_index=True, right_index=True)

cols_pgm = [
    "average_select_sb",
    "average_select_ns",
    "average_select_os",
    "ged_dummy_sb",
    "ged_dummy_ns",
    "ged_dummy_os",
    "decay_12_cw_ged_dummy_sb_0",
    "gcp_li_mer",
]
cols_cm = [
    "average_base_sb",
    "average_base_ns",
    "average_base_os",
    "ged_dummy_sb",
    "ged_dummy_ns",
    "ged_dummy_os",
    "decay_12_cw_ged_dummy_sb_0",
    "ln_fvp_population200",
]

df_pgm = df_pgm[cols_pgm]
df_cm = df_cm[cols_cm]

t_first_pgm = df_pgm.index.get_level_values(0).min()
t_first_cm = df_cm.index.get_level_values(0).min()

df_pgm = df_pgm.loc[t_first_pgm : t_first_pgm + 1]
df_cm = df_cm.loc[t_first_cm : t_first_cm + 1]

df_pgm.to_hdf("/storage/temp/maps/workdata/df_pgm.hdf5", key="data")
df_cm.to_hdf("/storage/temp/maps/workdata/df_cm.hdf5", key="data")
df_months.to_hdf("/storage/temp/maps/workdata/df_months.hdf5", key="data")
df_priogrid.to_hdf("/storage/temp/maps/workdata/df_priogrid.hdf5", key="data")
