""" Empty unit-test module to copy to new projects """

# pylint: disable=invalid-name


import os

import unittest
import tempfile

from views.apps.data.fetch import fetchutils as utils
from views.utils import pyutils


class TestSkeleton(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        self.data = str(list(range(10000)))

    def tearDown(self):
        """ Cleanup after tests """
        del self.data

    def test_utc_now_format(self):
        """ Test that utc_now gives a correctly formatted string """
        now = utils.utc_now()
        # 8 digits, a dash, 6 digits
        time_regex = r"\d{8}\-\d{6}"
        self.assertRegex(now, time_regex)

    def test_compress_file_creates_archive(self):
        """ Test that compress_file creates a archive restorable archive"""

        with tempfile.TemporaryDirectory() as tempdir:
            path_raw = os.path.join(tempdir, "raw.fake")
            path_archive = os.path.join(tempdir, "testarchive.tar.xz")

            with open(path_raw, "w") as f:
                f.write(self.data)

            utils.compress_file(
                path_source=path_raw, path_destination=path_archive
            )
            self.assertTrue(os.path.isfile(path_archive))

    def test_decompress_archive_extracts_identical(self):
        """ Test that decompress_archive writes a file that matches source """

        fname_member = "raw.fake"

        with tempfile.TemporaryDirectory() as tempdir:

            path_raw = os.path.join(tempdir, fname_member)
            path_archive = os.path.join(tempdir, "testarchive.tar.xz")
            dir_extracted = os.path.join(tempdir, "extracted")

            pyutils.create_dir(dir_extracted)

            with open(path_raw, "w") as f:
                f.write(self.data)

            utils.compress_file(
                path_source=path_raw, path_destination=path_archive
            )

            path_extracted = utils.extract_file(
                path_archive=path_archive,
                filename=fname_member,
                dir_destination=dir_extracted,
            )

            with open(path_extracted, "r") as f:
                extracted = f.read()

        self.assertEqual(self.data, extracted)


if __name__ == "__main__":
    unittest.main()
