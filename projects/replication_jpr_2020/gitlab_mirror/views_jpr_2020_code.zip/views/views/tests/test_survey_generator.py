""" Tests for the survey generator """

# pylint: skip-file

import unittest
import os

from views.utils import dbutils

from views.apps.survey import survey_generator as sg
from views.tests import test_survey_utils


class TestSurveyGenerator(unittest.TestCase):
    """ Test survey generator """

    def setUp(self):
        """ Setup the data tests need """
        this_dir = os.path.dirname(os.path.abspath(__file__))
        dir_questions = os.path.join(this_dir, "data/survey/questions/")

        test_survey_utils.setup_db_survey()

        fname = "stakeholder_issue.txt"
        path_q_stakeholder_issue = os.path.join(dir_questions, fname)
        with open(path_q_stakeholder_issue, "r") as f:
            self.q_stakeholder_issue = f.read()

        self.survey_poc = test_survey_utils.read_survey_poc()

    def test_get_stakeholder_name(self):
        """ Test that get_stakeholder name returns a single name as str """

        wants = {
            1: "Socialdemokraterna",
            2: "Moderaterna",
            10: "Arbeiderpartiet",
        }

        for want_id in wants:
            wanted = wants[want_id]
            got = sg.get_stakeholder_name(want_id)
            self.assertEqual(got, wanted)

    def test_get_expert_ids(self):
        """ Test that get_expert_ids returns the 4 expert ids """

        expert_ids = [1, 2, 3, 4]
        self.assertEqual(sg.get_expert_ids(), expert_ids)

    def test_get_expert_issues(self):
        """ Test that get_expert_issues returns rows with the correct fields

        Fields are: issue_id, survey_id, name, description, left_extreme,
        status_quo, right_extreme, """

        wanted = [
            "id",
            "survey_id",
            "name",
            "description",
            "left_extreme",
            "status_quo",
            "right_extreme",
        ]

        expert_id = 1
        got = sg.get_expert_issues(expert_id)
        for got_item in got:
            self.assertCountEqual(got_item.keys(), wanted)

    def test_write_survey_txt_to_db(self):
        """ Test that write_survey_txt_to_db writes a row with content """

        txt = self.survey_poc

        wanted = txt

        sg.write_survey_txt_to_db(txt=txt, survey_id=1)

        query = "SELECT txt FROM survey.survey WHERE id=1"
        survey_txt = dbutils.get_query_rows(query)
        got = survey_txt.pop()["txt"]

        self.assertEqual(got, wanted)


if __name__ == "__main__":
    pass
    # unittest.main()
    # print("Skipping tests for proof of concept db. Setting up db...")
    # test_survey_utils.setup_db_survey()
