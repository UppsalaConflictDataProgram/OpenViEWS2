""" Tests for utils.dbutils

Make sure to add any tables you create to the self.created_tables list!"""


import unittest
import logging
import tempfile
import os

import pandas as pd

from views.utils import datautils
from views.utils import dbutils

logger = logging.getLogger()

# pylint: disable=too-many-instance-attributes


class TestDbutils(unittest.TestCase):
    """ General test for dbutils """

    def setUp(self):
        self.created_tables = []
        self.created_views = []

        self.schema = "testing"
        self.fqtable_mock = "testing.mock"

        self.n_groups = 2
        self.n_t = 2
        self.n_cols = 4
        self.timevar = "time"
        self.groupvar = "group"

        self.mocker = datautils.DfMocker(
            n_t=30,
            n_groups=10,
            n_cols=10,
            timevar=self.timevar,
            groupvar=self.groupvar,
        )
        self.df = self.mocker.df

        dbutils.recreate_schema("testing")
        dbutils.df_to_db(df=self.df, fqtable=self.fqtable_mock)

        self.created_tables.append(self.fqtable_mock)

    def tearDown(self):
        """ Remove any tables and views we've created during testing """

        for fqview in self.created_views:
            dbutils.drop_view(fqview)

        for fqtable in self.created_tables:
            dbutils.drop_table(fqtable=fqtable)

    def test_db_to_df_returns_df_tiny(self):
        """ Test thtat db_to_df returns a DataFrame """

        df = dbutils.db_to_df(self.fqtable_mock)
        self.assertIsInstance(df, pd.DataFrame)

    def test_query_to_df_returns_df(self):
        """ Test that query_to_df returns a df """

        query = "SELECT * FROM {}".format(self.fqtable_mock)
        df = dbutils.query_to_df(query)

        self.assertIsInstance(df, pd.DataFrame)

    def test_query_to_df_respects_limit(self):
        """ Test that query_to_df returns correct nrows when LIMIT  set """

        query = "SELECT * FROM {} LIMIT 5".format(self.fqtable_mock)
        df = dbutils.query_to_df(query)

        nrows = 5

        self.assertEqual(len(df), nrows)

    # pylint: disable=invalid-name
    def test_list_columns_table(self):
        """ Test that list_columns_table returns correct cols"""

        cols_expected = self.df.reset_index().columns
        cols_listed = dbutils.list_columns(fqtable=self.fqtable_mock)
        self.assertCountEqual(cols_listed, cols_expected)

    def test_unpack_fqtable(self):
        """ Test that unpack_fqtable() returns the correct strings """

        name = "some_schema.some_table"
        schema = "some_schema"
        table = "some_table"

        t_schema, t_table = dbutils.unpack_fqtable(name)

        self.assertEqual(t_schema, schema)
        self.assertEqual(table, t_table)

    def test_list_tables(self):
        """ Test that list tables gets a correct list of tables """

        dbutils.df_to_db(self.df, "testing.table_1")
        dbutils.df_to_db(self.df, "testing.table_2")

        self.created_tables.append("testing.table_1")
        self.created_tables.append("testing.table_2")

        tables_listed = dbutils.list_tables_in_schema(self.schema)

        tables_created = [
            self.fqtable_mock,
            "testing.table_1",
            "testing.table_2",
        ]

        self.assertEqual(tables_listed, tables_created)

    def test_create_joined_view(self):
        """ Test that create_joined_view creates a view with correct data """

        df_1 = self.df.add_prefix("a_")
        df_2 = self.df.add_prefix("b_")
        df_3 = self.df.add_prefix("c_")

        dbutils.df_to_db(df_1, "testing.table_v1")
        dbutils.df_to_db(df_2, "testing.table_v2")
        dbutils.df_to_db(df_3, "testing.table_v3")

        self.created_tables.append("testing.table_v1")
        self.created_tables.append("testing.table_v2")
        self.created_tables.append("testing.table_v3")

        df_joined = df_1.merge(df_2, left_index=True, right_index=True)
        df_joined = df_joined.merge(df_3, left_index=True, right_index=True)

        name_joined_view = "testing.joined_view"

        ids = [self.timevar, self.groupvar]
        dbutils.create_joined_view(
            name=name_joined_view,
            ids=ids,
            tables=["testing.table_v1", "testing.table_v2", "testing.table_v3"],
        )
        self.created_views.append(name_joined_view)

        df_view = dbutils.db_to_df(name_joined_view, ids=ids)

        df_joined.sort_index(inplace=True)
        df_view.sort_index(inplace=True)

        pd.testing.assert_frame_equal(df_joined, df_view)

    def test_create_joined_table(self):
        """ Test that create_joined_table creates a table with correct data """

        df_1 = self.df.add_prefix("a_")
        df_2 = self.df.add_prefix("b_")
        df_3 = self.df.add_prefix("c_")

        dbutils.df_to_db(df_1, "testing.table_v1")
        dbutils.df_to_db(df_2, "testing.table_v2")
        dbutils.df_to_db(df_3, "testing.table_v3")

        self.created_tables.append("testing.table_v1")
        self.created_tables.append("testing.table_v2")
        self.created_tables.append("testing.table_v3")

        df_joined = df_1.merge(df_2, left_index=True, right_index=True)
        df_joined = df_joined.merge(df_3, left_index=True, right_index=True)

        name_joined_table = "testing.joined_table"

        ids = [self.timevar, self.groupvar]
        dbutils.create_joined_table(
            name=name_joined_table,
            ids=ids,
            tables=["testing.table_v1", "testing.table_v2", "testing.table_v3"],
        )
        self.created_tables.append(name_joined_table)

        df_joined_table = dbutils.db_to_df(name_joined_table, ids=ids)

        df_joined.sort_index(inplace=True)
        df_joined_table.sort_index(inplace=True)

        pd.testing.assert_frame_equal(df_joined, df_joined_table)

    def test_make_engine_logs(self):
        """ Test that make_engine logs to debug """

        with self.assertLogs(level="DEBUG") as _:
            dbutils.make_engine()

    def test_db_to_df_logs(self):
        """ Test that db_to_df logs to info """

        with self.assertLogs(level="INFO") as _:
            dbutils.db_to_df(self.fqtable_mock)

    def test_list_views_in_schema_returns_list(self):
        """ Test that list_views_in_schema returns a list """

        tables = dbutils.list_views_in_schema(self.schema)

        self.assertIsInstance(tables, list)

    def test_get_query_rows(self):
        """ Test that get_query_rows returns correct num rows """

        n_rows_wanted = len(self.df)

        query = f"SELECT * FROM {self.fqtable_mock};"
        got = dbutils.get_query_rows(query)
        n_rows_got = len(got)

        self.assertEqual(n_rows_wanted, n_rows_got)

    def test_execute_query_parametrisation(self):
        """ Test that execute_query sets passed params in query """

        query_parametrise = f"""
            SELECT
                MAX(p_a)
            FROM
                {self.fqtable_mock}
            WHERE time=:t;"""

        query_filled = f"""
            SELECT
                MAX(p_a)
            FROM
                {self.fqtable_mock}
            WHERE time=1;"""

        query_params = {"t": 1}

        results_param = dbutils.execute_query(query_parametrise, **query_params)
        results_filled = dbutils.execute_query(query_filled)

        for row in results_param:
            got = row["max"]
        for row in results_filled:
            wanted = row["max"]

        self.assertEqual(got, wanted)

    def test_execute_query_from_file(self):
        """ Test that execute_query_from_file works """

        query = f"SELECT MAX(p_a) FROM {self.fqtable_mock};"

        with tempfile.TemporaryDirectory() as tempdir:
            path = os.path.sep.join([tempdir, "query.sql"])
            with open(path, "w") as f:
                f.write(query)

            got = dbutils.get_query_rows_from_file(path)

        wanted = dbutils.get_query_rows(query)

        self.assertCountEqual(got, wanted)

    def test_count_rows(self):
        """ Test that count_rows returns correct number of rows """

        wanted = len(self.df)
        got = dbutils.count_rows(self.fqtable_mock)

        self.assertEqual(got, wanted)


if __name__ == "__main__":
    unittest.main()
