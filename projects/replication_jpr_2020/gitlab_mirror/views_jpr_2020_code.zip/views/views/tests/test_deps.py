""" test suite for dependencies. """

import unittest

import pandas as pd
import numpy as np


class TestDeps(unittest.TestCase):
    """Tests for Crosslevel module"""

    def test_pandas(self):
        """ Try making an empty DataFrame """
        df = pd.DataFrame()
        self.assertIsInstance(df, pd.DataFrame)

    def test_numpy(self):  # pylint: disable=no-self-use
        """ Try making an empty array """
        X = np.array([])  # pylint: disable=unused-variable


if __name__ == "__main__":
    unittest.main()
