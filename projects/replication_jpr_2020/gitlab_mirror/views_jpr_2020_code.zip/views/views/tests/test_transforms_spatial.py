""" Empty unit-test module to copy to new projects """
import unittest

import pysal


class TestSkeleton(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """

        self.n_rows = 3
        self.n_cols = 3
        self.w_grid = pysal.lib.weights.lat2W(self.n_rows, self.n_cols)

    def test_grid_size(self):
        """ Test that we understand grid size correctly"""

        wanted = self.n_rows * self.n_cols
        got = self.w_grid.n
        self.assertEqual(wanted, got)


if __name__ == "__main__":
    unittest.main()
