""" Test eval_lib """
import unittest

from views.apps.evaluate import eval_lib


class TestEvallib(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        self.probs_bad = [0.1, 0.9, 0.5, 0.1, 0.2, 0.3]
        self.probs_good = [0.1, 0.1, 0.2, 0.1, 0.7, 0.9]
        self.actuals = [0.0, 0.0, 0.0, 1.0, 1.0, 1.0]

    def test_average_precision(self):
        """ Test Area Under Precision Recall """

        ap_good = eval_lib.average_precision(self.actuals, self.probs_good)
        ap_bad = eval_lib.average_precision(self.actuals, self.probs_bad)
        self.assertTrue(0 < ap_good < 1)
        self.assertTrue(0 < ap_bad < 1)
        self.assertTrue(ap_bad < ap_good)

    def test_area_under_roc(self):
        """ Test Area Under Receiver Operator Curve """

        auroc_good = eval_lib.area_under_roc(
            actuals=self.actuals, probs=self.probs_good
        )
        auroc_bad = eval_lib.area_under_roc(
            actuals=self.actuals, probs=self.probs_bad
        )
        self.assertTrue(0 < auroc_good < 1)
        self.assertTrue(0 < auroc_bad < 1)
        self.assertTrue(auroc_bad < auroc_good)

    def test_brier(self):
        """ Test Brier score """

        brier_good = eval_lib.brier(actuals=self.actuals, probs=self.probs_good)
        brier_bad = eval_lib.brier(actuals=self.actuals, probs=self.probs_bad)
        self.assertTrue(0 < brier_good < 1)
        self.assertTrue(0 < brier_bad < 1)
        self.assertTrue(brier_bad > brier_good)


if __name__ == "__main__":
    unittest.main()
