""" Empty unit-test module to copy to new projects """
import logging
import unittest

from views.utils import pyutils
from views.apps.model import persist

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)


class TestSkeleton(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        persist._rebuild_metadata_schema()


    def tearDown(self):
        """ Cleanup after tests """
        pass

    def test_register_estimator(self):
        persist.register_estimator_in_db(
            name_model= "test_modelname",
            name_estimator="test_name.1",
            path_pickle="/some/path",
            step=1,
            outcome="sb",
            col_outcome="ged_dummy_sb",
            cols_shift=["feat_1", "feat_2"],
            cols_noshift=[],
            loa="testloa",
            train_end=110,
            )

        persist.register_estimator_in_db(
            name_model= "test_modelname",
            name_estimator="test_name.6",
            path_pickle="/some/path",
            step=6,
            outcome="sb",
            col_outcome="ged_dummy_sb",
            cols_shift=["feat_1", "feat_2"],
            cols_noshift=[],
            loa="testloa",
            train_end=110,
            overwrite=True,
            )

    def test_raises_on_model_inconsistency(self):

        persist.register_estimator_in_db(
            name_model= "test_modelname",
            name_estimator="test_name.1",
            path_pickle="/some/path",
            step=1,
            outcome="sb",
            col_outcome="ged_dummy_sb",
            cols_shift=["feat_1", "feat_2"],
            cols_noshift=[],
            loa="testloa",
            train_end=110,
            )

        with self.assertRaises(RuntimeError):
            persist.register_estimator_in_db(
                name_model= "test_modelname",
                name_estimator="test_name.6",
                path_pickle="/some/path",
                step=6,
                outcome="sb",
                col_outcome="ged_dummy_sb",
                cols_shift=["feat_2", "feat_3"],
                cols_noshift=[],
                loa="testloa",
                train_end=110,
                overwrite=True,
                )



    def test_register_model(self):
        persist.register_model(
            name_model="modelname",
            loa="testloa",
            outcome="sb",
            col_outcome="ged_tx_sb_25",
            cols_shift=["feat_1", "feat_2"],
            cols_noshift=[]
            )


if __name__ == "__main__":
    unittest.main()
