""" Test views.apps.transforms.translib"""
import unittest

import numpy as np
import pandas as pd

from views.utils import datautils
from views.apps.transforms import translib


class TestSkeleton(unittest.TestCase):
    """ Test for transformer library

    self.df is

                      b_a  c_a
    timevar groupvar
    0       0           1    0
            1           1    1
    1       0           0    7
            1           0    6
    2       0           1    9
            1           1    2
    3       0           1    4
            1           1    5
    4       0           1    2
            1           0    4
    """

    def setUp(self):
        """ Setup the data tests need """
        mocker = datautils.DfMocker(
            n_t=5, n_groups=2, n_cols=2, seed=1, datatypes=["bools", "counts"]
        )
        self.df = mocker.df

    def test_tlag(self):
        """ Test tlag() """

        # lag 1 time
        wanted_1 = pd.Series([np.nan, 1, 0, 1, 1])
        got_1 = translib.tlag(s=self.df["b_a"], time=1)
        got_1 = got_1.xs(0, level=1)
        pd.testing.assert_series_equal(
            wanted_1, got_1, check_index_type=False, check_names=False
        )

        # lag 2 times
        wanted_2 = pd.Series([np.nan, np.nan, 1, 0, 1])
        got_2 = translib.tlag(s=self.df["b_a"], time=2)
        got_2 = got_2.xs(0, level=1)
        pd.testing.assert_series_equal(
            wanted_2, got_2, check_index_type=False, check_names=False
        )

        # Raises on lead
        with self.assertRaises(RuntimeError) as _:
            translib.tlag(s=self.df["b_a"], time=-1)

    def test_tlead(self):
        """ Test tlead() """

        # lag 1 time
        wanted_1 = pd.Series([0, 1, 1, 1, np.nan])
        got_1 = translib.tlead(s=self.df["b_a"], time=1)
        got_1 = got_1.xs(0, level=1)
        pd.testing.assert_series_equal(
            wanted_1, got_1, check_index_type=False, check_names=False
        )

        # lag 2 times
        wanted_2 = pd.Series([1, 1, 1, np.nan, np.nan])
        got_2 = translib.tlead(s=self.df["b_a"], time=2)
        got_2 = got_2.xs(0, level=1)
        pd.testing.assert_series_equal(
            wanted_2, got_2, check_index_type=False, check_names=False
        )

        # Raises on "lag"
        with self.assertRaises(RuntimeError) as _:
            translib.tlead(s=self.df["b_a"], time=-1)

    def test_moving_average(self):
        """ Test moving_average() """

        # Time=1 should just give the same values back
        got_1 = translib.moving_average(s=self.df["c_a"], time=1)
        wanted_1 = self.df["c_a"]
        pd.testing.assert_series_equal(got_1, wanted_1, check_dtype=False)

        got_2 = translib.moving_average(s=self.df["c_a"], time=2)
        got_2 = got_2.xs(0, level=1)  # Select groupvar 1
        # Window 2 gives
        # 0, 7, 9, 4, 2 - > 0, 3.5, 8, 13/2, 3
        wanted_2 = pd.Series([0, 3.5, 8, 13 / 2, 3])
        pd.testing.assert_series_equal(
            got_2, wanted_2, check_index_type=False, check_names=False
        )

        with self.assertRaises(RuntimeError) as _:
            translib.moving_average(s=self.df["c_a"], time=0)

    # pylint: disable=no-self-use
    def test_cweq(self):
        """ Test cweq()

        df with swapped levels is:

                          b_a
        groupvar timevar
        0        0          1
                 1          0
                 2          1
                 3          1
                 4          1
                 5          0
                 6          0
                 7          1
                 8          0
                 9          0
        1        0          1
                 1          0
                 2          1
                 3          1
                 4          0
                 5          1
                 6          1
                 7          0
                 8          1
                 9          0

        """

        df = datautils.DfMocker(
            n_groups=2, n_t=10, n_cols=1, datatypes=["bools"]
        ).df

        value = 1
        got = translib.cweq(s=df["b_a"], value=value)
        got_g0 = got.xs(0, level=1)
        got_g1 = got.xs(1, level=1)

        # Check by hand
        wanted_g0 = pd.Series([1, 0, 1, 2, 3, 0, 0, 1, 0, 0])
        pd.testing.assert_series_equal(
            got_g0, wanted_g0, check_index_type=False, check_names=False
        )
        # Check by hand
        wanted_g1 = pd.Series([1, 0, 1, 2, 0, 1, 2, 0, 1, 0])
        pd.testing.assert_series_equal(
            got_g1, wanted_g1, check_index_type=False, check_names=False
        )

    def test_decay(self):
        """ Test decay() """

        # Test with a constant
        halflife = 2
        wanted = 0.5
        got = translib.decay(2, 2)
        self.assertEqual(got, wanted)

        # Test with a Series
        halflife = 4
        s = pd.Series([1, 2, 3, 4])
        got = translib.decay(s, halflife)
        wanted = [0.84, 0.70, 0.59, 0.5]
        self.assertTrue(np.allclose(got, wanted, rtol=0.1))

    def test_mean(self):
        """ Test mean() """

        s = self.df["b_a"]
        # Computed by hand
        wanted_0 = pd.Series(np.repeat(0.8, 5))
        wanted_1 = pd.Series(np.repeat(0.6, 5))
        got = translib.mean(s)
        got_0 = got.xs(0, level=1)
        got_1 = got.xs(1, level=1)
        pd.testing.assert_series_equal(
            got_0, wanted_0, check_index_type=False, check_names=False
        )
        pd.testing.assert_series_equal(
            got_1, wanted_1, check_index_type=False, check_names=False
        )

    def test_demean(self):
        """ test demean() """

        s = self.df["b_a"]

        # Values - mean of values
        wanted_0 = pd.Series([1, 0, 1, 1, 1]) - 0.8
        got = translib.demean(s)
        got_0 = got.xs(0, level=1)

        pd.testing.assert_series_equal(
            got_0, wanted_0, check_index_type=False, check_names=False
        )


if __name__ == "__main__":
    unittest.main()
