""" Tests for the survey surveys """

# pylint: skip-file


import unittest

from views.apps.survey import surveys as ss
import views.apps.survey.qualtrics_api as api

from views.tests import test_survey_utils


class TestSurveyGenerator(unittest.TestCase):
    """ Test survey generator """

    def setUp(self):
        """ Setup the data tests need """

        test_survey_utils.setup_db_survey()
        self.survey_beta = test_survey_utils.read_survey_beta()

        self.posted_surveys = []

    def tearDown(self):
        """ Delete any surveys we have posted """

        for qsi in self.posted_surveys:
            api.delete_survey(qsi)

    # def test_survey_poc(self):
    #     """ Test that survey_poc returns a survey like the manual """

    #     wanted = self.survey_poc
    #     got = ss.survey_poc()

    #     self.assertEqual(got, wanted)

    def test_survey_beta_survives_qualtrics(self):
        """ Test that the POC survey survives upload to Qualtrics """

        qsi = api.post_survey_from_str(name="delete_me", txt=self.survey_beta)
        self.posted_surveys.append(qsi)

        # Check that we got a qualtrics survey id string in response
        self.assertIsInstance(qsi, str)


if __name__ == "__main__":
    print("Skipping test_survey_surveys because it calls the Q API")
    # unittest.main()
