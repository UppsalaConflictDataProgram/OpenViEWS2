""" Test apps/slurm_broker

These tests are testing functionaly which by definition runs on a remote
host. Therefore testing the entire app isn't feasible.
"""

# pylint: disable=invalid-name, protected-access


import unittest
import os

import views.apps.slurm_broker.slurm_broker as broker


class TestSlurmBroker(unittest.TestCase):
    """ Skeleton unit test module """

    def setUp(self):
        """ Setup the data tests need """
        this_dir = os.path.dirname(os.path.abspath(__file__))
        dir_data = os.path.join(this_dir, "data/slurm_broker")

        with open(os.path.join(dir_data, "jobinfo.txt"), "r") as f:
            self.example_jobinfo = f.read()

    def test_parse_jobinfo_running_job_ids(self):
        """ Test that the correct ids for running jobs returned """

        got = broker._parse_jobinfo(self.example_jobinfo)
        ids_running = [6306059, 6306061, 6306064, 6306065]

        for job_id in ids_running:
            self.assertIn(job_id, got["running"].keys())

    def test_parse_jobinfo_waiting_job_ids(self):
        """ Test that the correct ids for waiting jobs are returned """

        got = broker._parse_jobinfo(self.example_jobinfo)
        ids_waiting = [6332276, 6332277, 6332278, 6332279, 6332280]

        for job_id in ids_waiting:
            self.assertIn(job_id, got["waiting"].keys())

    # pylint: disable=no-self-use, unused-variable
    def test_make_runfile_str_vs_template(self):
        """ Test that the template produces expected output """

        project = "some-fake-project"
        jobtype = "core"
        cores = 10
        time = "00:00:01"
        name = "some_fake_jobname"
        command = "python -u worker.py"


if __name__ == "__main__":
    unittest.main()
