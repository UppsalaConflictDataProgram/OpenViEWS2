""" Crosslevel module

This module provides cross level models that combine high and low resolution
models.

_h and _l refer to high and low resolution respectively.

Examples of high resolution might be priogrid and low might be country but
any low resolution should logically contain the higher resolution.

"""
import argparse
import json

import pandas as pd

from views.utils import dbutils
from views.utils import pyutils

# pylint: disable=too-many-instance-attributes
class Crosslevel:
    """ Crosslevel application class """

    def __init__(self):
        """ Init Crosslevel instance with empty state """

        self.name = None
        self.timevar = None
        self.groupvar_l = None
        self.groupvar_h = None
        self.df = None
        self.table_h = None
        self.table_l = None
        self.table_links = None
        self.table_out = None
        self.schema_h = None
        self.schema_l = None
        self.schema_links = None
        self.schema_out = None

        self.results = None
        self.cols_h = []
        self.cols_l = []
        self.jobs = []

    @staticmethod
    def merge_levels(df_h, df_l, df_links):
        """ Merge high resolution and low resolution prediction using links"""

        def assert_same_timevar(df_a, df_b):
            """ Assert that the three input dataframes share a common timevar"""
            timevar_a = df_a.index.names[0]
            timevar_b = df_b.index.names[0]

            msg = (
                "dfs in merge_levels() use different timevar " "{} is not {}"
            ).format(timevar_a, timevar_b)
            assert timevar_a == timevar_b, msg

        def assert_same_timelimits(df_a, df_b):
            """ Make sure df_a and df_b cover the same time frame """

            def get_time_limits(df):
                """ Get a tuple (min, max) of index level 0 values """
                t_start = df.index.get_level_values(0).min()
                t_end = df.index.get_level_values(0).max()
                limits = (t_start, t_end)
                return limits

            limits_a = get_time_limits(df_a)
            limits_b = get_time_limits(df_b)
            msg = "{} is not {}".format(limits_a, limits_b)
            assert limits_a == limits_b, msg

        assert_same_timevar(df_h, df_l)
        assert_same_timevar(df_h, df_links)
        assert_same_timelimits(df_h, df_l)

        timevar = df_h.index.names[0]
        groupvar_h = df_h.index.names[1]
        groupvar_l = df_l.index.names[1]

        # Merge in the links, i.e. the low res groupvar
        df = df_h.merge(df_links, left_index=True, right_index=True)

        # Merge on indexes to keep indexes in merged df
        df.reset_index(inplace=True)
        df.set_index([timevar, groupvar_l], inplace=True)
        df = df.merge(df_l, left_index=True, right_index=True)
        df.reset_index(inplace=True)
        df.set_index([timevar, groupvar_h], inplace=True)
        df.sort_index(inplace=True)

        return df

    @staticmethod
    def compute_product(df, col_a, col_b):
        """ Compute simple product of col_h and col_l in df """

        cols = [col_a, col_b]
        product = df[cols].product(axis=1)

        return product

    @staticmethod
    def compute_colaresi(df, col_h, col_l, timevar, groupvar_l):
        """ Colaresian cross level probability """

        # Sum of high resolution probabilities for each low level area
        sum_h_by_l = df.groupby([timevar, groupvar_l])[col_h].transform(sum)

        # Low resolution prob multiplied by share of high res prob of area in a
        # particular area
        joint_prob = df[col_l] * (df[col_h] / sum_h_by_l)

        return joint_prob

    def worker_colaresi(self, job):
        """ Worker for compute_colaresi """
        col_h = job["col_h"]
        col_l = job["col_l"]
        timevar = self.timevar
        groupvar_l = self.groupvar_l

        result = Crosslevel.compute_colaresi(
            self.df, col_h, col_l, timevar, groupvar_l
        )

        return result

    def worker_product(self, job):
        """ Worker for simple product """
        col_a = job["col_h"]
        col_b = job["col_l"]

        result = Crosslevel.compute_product(self.df, col_a, col_b)

        return result

    def worker(self, job):
        """ General worker """

        def worker_assigner(self, job):
            """ Returns appropriate worker for the jobs method """

            method = job["method"]

            if method == "colaresi":
                worker = self.worker_colaresi
            elif method == "product":
                worker = self.worker_product
            else:
                msg = "Found no worker for method {}".format(method)
                raise NotImplementedError(msg)

            return worker

        this_worker = worker_assigner(self, job)
        result = this_worker(job)

        result.name = job["name"]

        return result

    # pylint: disable=too-many-arguments
    def _setup_state(
        self, df_h, df_l, df_links, timevar, groupvar_h, groupvar_l
    ):
        """ Setup the state of the application """

        self.df = self.merge_levels(df_h, df_l, df_links)
        self.timevar = timevar
        self.groupvar_h = groupvar_h
        self.groupvar_l = groupvar_l

    @staticmethod
    def parse_args():  # pragma: no cover
        """ Parse command line args """
        parser = argparse.ArgumentParser()
        parser.add_argument(
            "--path_runfile",
            type=str,
            required=True,
            help="path to json specifying job",
        )

        args = parser.parse_args()
        argdict = {"path_runfile": args.path_runfile}

        return argdict

    def load_run(self, run):
        """ Initalise run attributes from dictionary """

        self.name = run["name"]
        self.jobs = run["jobs"]
        self.groupvar_l = run["groupvar_l"]
        self.groupvar_h = run["groupvar_h"]
        self.timevar = run["timevar"]

        self.table_h = run["table_h"]
        self.table_l = run["table_l"]
        self.table_links = run["table_links"]
        self.table_out = run["table_out"]

        for job in self.jobs:
            self.cols_h.append(job["col_h"])
            self.cols_l.append(job["col_l"])

        self.cols_h = pyutils.dedup_list(self.cols_h)
        self.cols_l = pyutils.dedup_list(self.cols_l)

    def load_runfile(self, path_runfile):
        """ Initalise run attributes from json file"""

        with open(path_runfile, "r") as runfile:
            run = json.load(runfile)

        self.load_run(run)

    def fetch_data(self):  # @TODO: Loading data from file
        """ Fetch data from db """

        df_h = dbutils.db_to_df(
            fqtable=self.table_h,
            ids=[self.timevar, self.groupvar_h],
            columns=self.cols_h,
        )
        df_l = dbutils.db_to_df(
            fqtable=self.table_l,
            ids=[self.timevar, self.groupvar_l],
            columns=self.cols_l,
        )
        df_links = dbutils.db_to_df(
            fqtable=self.table_links,
            ids=[self.timevar, self.groupvar_h],
            columns=[self.groupvar_l],
        )

        self.df = Crosslevel.merge_levels(df_h, df_l, df_links)

    def run_jobs(self):
        """ Run all the jobs """

        assert self.jobs != [], "No jobs to run. Call load_runfile first."
        message = "No data in self.df, call fetch_data first"
        assert self.df is not None, message

        results_list = []
        for job in self.jobs:
            results_list.append(self.worker(job))

        self.results = pd.concat(results_list, axis=1)
        self.results.sort_index(inplace=True)

    def publish_results(self):
        """ Push results to job['table_out'] """

        dbutils.df_to_db(self.results, self.table_out)

    def main(self):  # pragma: no cover
        """ Crosslevel main """
        args = self.parse_args()
        path_runfile = args["path_runfile"]

        self.load_runfile(path_runfile)
        self.fetch_data()
        self.run_jobs()


def main():  # pragma: no cover
    """ Instantiate and run Crosslevel """
    crosslevel = Crosslevel()
    crosslevel.main()


if __name__ == "__main__":
    main()  # pragma: no cover
