""" Public API for python data transformers

The goal is let other applications such as pipelines, dynasim or
exploratory notebooks access transformations in a common format.
The common interface is funcname(df, cols, **kwargs).
This lets clients call all transforms in the same format.

To create an instance of a Transformer from a spec use the
Transformer class.
"""

import logging

from views.apps.transforms import spatial, translib
from views.utils import pyutils

Logger = logging.getLogger(__name__)


@pyutils.debug_timer
def cweq(df, cols, **kwargs):
    return translib.cweq(df[cols[0]], **kwargs)


@pyutils.debug_timer
def decay(df, cols, **kwargs):
    return translib.decay(df[cols[0]], **kwargs)


@pyutils.debug_timer
def delta(df, cols):
    return translib.delta(df[cols[0]])


@pyutils.debug_timer
def demean(df, cols):
    return translib.demean(df[cols[0]])


@pyutils.debug_timer
def greq(df, cols, **kwargs):
    return translib.greater_or_equal(df[cols[0]], **kwargs)


@pyutils.debug_timer
def ln(df, cols):
    return translib.natural_log(df[cols[0]])


@pyutils.debug_timer
def mean(df, cols):
    return translib.mean(df[cols[0]])


@pyutils.debug_timer
def moving_average(df, cols, **kwargs):
    return translib.moving_average(df[cols[0]], **kwargs)


@pyutils.debug_timer
def rollmax(df, cols, **kwargs):
    return translib.rollmax(df[cols[0]], **kwargs)


@pyutils.debug_timer
def spatial_distance(df, cols, **kwargs):
    return spatial.distance_to_event(df, event_col=cols[0], **kwargs)


@pyutils.debug_timer
def spatial_lag(df, cols, **kwargs):
    return spatial.spatial_lag(gdf=df, col=cols[0], **kwargs)


@pyutils.debug_timer
def spacetime_distance(df, cols, **kwargs):
    return spatial.spacetime_distance_to_event(
        gdf=df, event_col=cols[0], **kwargs,
    )


@pyutils.debug_timer
def summ(df, cols):
    return translib.summ(df[cols[0]])


@pyutils.debug_timer
def time_since_previous_event(df, cols, **kwargs):
    return translib.time_since_previous_event(df[cols[0]], **kwargs)


@pyutils.debug_timer
def tlag(df, cols, **kwargs):
    return translib.tlag(df[cols[0]], **kwargs)


@pyutils.debug_timer
def tlead(df, cols, **kwargs):
    return translib.tlead(df[cols[0]], **kwargs)


TRANSFORM_FUNCS = {
    "cweq": cweq,
    "decay": decay,
    "delta": delta,
    "demean": demean,
    "greq": greq,
    "ln": ln,
    "mean": mean,
    "moving_average": moving_average,
    "rollmax": rollmax,
    "spdist": spatial_distance,
    "splag": spatial_lag,
    "stdist": spacetime_distance,
    "sum": summ,
    "time_since": time_since_previous_event,
    "tlag": tlag,
    "tlead": tlead,
}


class Transformer:
    """ Transformer to be initalised from name spec dictionary"""

    def __init__(self, name, spec):

        self.func = Transformer._get_func_by_name(spec["f"])
        self.name = name
        self.colname = name

        taken_keys = ["f"]

        # If single "col" in args set self.cols to list of that single col
        try:
            self.cols = [spec["col"]]
            taken_keys.append("col")
        # If "cols" in args set self.cols to that list of cols
        except KeyError:
            self.cols = spec["cols"]
            taken_keys.append("cols")

        # Collect all "leftover" kwargs in the spec to pass to funcs
        self.kwargs = {}
        for key, value in spec.items():
            if not key in taken_keys:
                self.kwargs[key] = value

    @staticmethod
    def _get_func_by_name(f_name):
        """ Get transformer by name from TRANSFORM_FUNCS """
        return TRANSFORM_FUNCS[f_name]

    def _subset_data_tick(self, df, t):
        # @TODO Compute start differently by transform type
        # For example, lags/moving average, etc should only get data it needs.
        # spatial distance only needs current time period, etc
        if "time" in self.kwargs:
            start = t - self.kwargs["time"]
        else:
            start = None
        return data.loc[start:t]

    def compute(self, df):
        """ Compute the transformation for the data """

        return self.func(df=df, cols=self.cols, **self.kwargs)

    def tick(self, df, t, **tick_args):
        """ Tick the transformer by computing it for this t

        Args:
            self:
            df: Dataframe with data
            t: Time id to compute transformer for.
            tick_args: Kwargs of this t tick, discarded.
                Included for API compatibility with models that take
                simulation-number specific sim parameter (such as
                logit in dynasim)
        Returns:
            data: Series of data for t

        """

        return self.func(
            df=self._subset_data_tick(df, t), cols=self.cols, **self.kwargs
        )
