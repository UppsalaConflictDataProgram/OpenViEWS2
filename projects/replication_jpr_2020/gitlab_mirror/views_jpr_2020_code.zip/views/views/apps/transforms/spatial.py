""" Spatial transformations """
import logging
import tempfile
import os

import numpy as np
import pysal as ps
from scipy.spatial import cKDTree

from views.utils import spatialutils

Logger = logging.getLogger(__name__)

# Supress superverbose fiona logs
# Source https://github.com/Toblerity/Fiona/issues/780
logging.getLogger("fiona").setLevel(logging.WARNING)


def distance_to_event(gdf, event_col, k=1, fill_value=99):
    """ Get spatial distance to event

    Args:
        gdf: GeoDataFrame with a multiindex like [time, group]  and
            cols for centroid and event_col.
        event_col: Name of col to count as event if == 1
        k: Number of neighbors to consider
        fill_value: When no events are found fill with this value
    Returns:
        dist: pd.Series of distance to event
    """

    # Index-only gdf to hold results
    gdf_results = gdf[[]].copy()
    gdf_results["distance"] = np.nan

    times = sorted(list(set(gdf_results.index.get_level_values(0))))

    # (x,y) coord pairs for all grids
    points_canvas = np.array(
        list(zip(gdf.loc[times[0]].centroid.x, gdf.loc[times[0]].centroid.y))
    )

    for t in times:
        gdf_events_t = gdf.loc[t][gdf.loc[t][event_col] == 1]
        points_events = np.array(
            list(zip(gdf_events_t.centroid.x, gdf_events_t.centroid.y))
        )
        if len(points_events) > 0:
            # Build the KDTree of the points
            btree = cKDTree(data=points_events)  # pylint: disable=not-callable
            # Find distance to closest k points, discard idx
            dist, _ = btree.query(points_canvas, k=k)
            # If more than one neighbor get the mean distance
            if k > 1:
                dist = np.mean(dist, axis=1)
            gdf_results.loc[t, "distance"] = dist
        else:
            gdf_results.loc[t, "distance"] = fill_value

    s = gdf_results["distance"]
    return s


def spacetime_distance_to_event(gdf, event_col, t_scale=1, k=1, fill_value=99):
    """ Get space-time distance to event

    The time dimension of the index (level=0) is used a third
    dimension. Making the distance a space-time interval and
    not just a spatial distance.

    @TODO: Add time scaling to weight distance/time differently

    Args:
        gdf: GeoDataFrame with a multiindex like [time, group]  and
            cols for centroid and event_col.
        event_col: Name of col to count as event if == 1
        k: Number of neighbors to consider, increasing k gives
           more weight to clusters of events than exceptional blips.
        fill_value: When no events are found fill with this value
    Returns:
        dist: pd.Series of distance to event

    """
    gdf_results = gdf[[]].copy()
    gdf_results["distance"] = np.nan
    times = sorted(list(set(gdf_results.index.get_level_values(0))))
    xs = gdf.loc[times[0]].centroid.x
    ys = gdf.loc[times[0]].centroid.y
    len_a_t = len(gdf.loc[times[0]])

    for t in times:
        # Subset to look back in time
        gdf_ts = gdf.loc[min(times) : t]
        gdf_ts_events = gdf_ts[gdf_ts[event_col] > 0]

        # Only compute distances if we have any events
        if len(gdf_ts_events) > k:
            points_all = np.array(
                list(zip(xs, ys, np.repeat(t * t_scale, len_a_t)))
            )
            times_back = gdf_ts_events.index.get_level_values(0) * t_scale
            points_events = np.array(
                list(
                    zip(
                        gdf_ts_events.centroid.x,
                        gdf_ts_events.centroid.y,
                        times_back,
                    )
                )
            )

            btree = cKDTree(data=points_events)  # pylint: disable=not-callable
            # Returns dist and idx, ignore idx
            dist, _ = btree.query(points_all, k=k)

            # if k>1 we get distance to each of k closest points, mean them
            if k > 1:
                dist = np.mean(dist, axis=1)

        # If no events fill dist with fill_value
        else:
            dist = fill_value

        gdf_results.loc[t, "distance"] = dist

    s = gdf_results["distance"]

    return s


def spatial_lag(gdf, col, first=1, last=1):
    """ Compute spatial lag on col in gdf """

    def gdf_to_w_q(gdf_geom, first, last):
        """ Build queen weights from gdf.

        Use a temporary shapefile to get the geometry into pysal as
        their new interface is confusing. There must be a less silly
        way.
        """

        with tempfile.TemporaryDirectory() as tempdir:
            path_shp = os.path.join(tempdir, "shapefile.shp")
            spatialutils.gdf_to_shp(gdf_geom, path_shp)
            graph = ps.lib.weights.W.from_file(path_shp)

        # Compute first order spatial weight
        w = ps.lib.weights.Queen(graph)

        # If we want higher order
        if not first == last == 1:
            w_ho = ps.lib.weights.higher_order(w, first)

            # loop from first to last order
            for order in range(first + 1, last + 1):
                w_this_order = ps.lib.weights.higher_order(w, order)
                w_ho = ps.lib.weights.w_union(w_ho, w_this_order)

            # Replace original w
            w = w_ho

        return w

    def _splag(y, w):
        """ Flip argument order for transform """
        return ps.lib.weights.lag_spatial(w, y)

    # @TODO: Add support for time-variant geometries (countries)
    # If geom's don't change use the one from the last time
    gdf_geom = gdf.loc[gdf.index.get_level_values(0).max()]
    w = gdf_to_w_q(gdf_geom, first, last)
    s = gdf.groupby(level=0)[col].transform(_splag, w=w)
    return s
