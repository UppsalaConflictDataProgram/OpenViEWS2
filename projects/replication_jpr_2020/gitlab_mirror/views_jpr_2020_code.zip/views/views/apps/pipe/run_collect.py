import argparse
import logging

from views.utils import pyutils
from views.apps.pipe import collect


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=str, required=True)
    parser.add_argument("--block", type=str, required=True)
    args = parser.parse_args()

    return args.run, args.block


if __name__ == "__main__":

    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)
    Logger = logging.getLogger(__name__)
    collect.collect_block(*parse_args())
