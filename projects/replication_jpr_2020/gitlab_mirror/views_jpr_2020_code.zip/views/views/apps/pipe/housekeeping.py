import time
import logging
import os
import sys
import shutil

from views.utils import pyutils
from views.apps.pipe import paths

Logger = logging.getLogger(__name__)


def init_rundir(name_run, clear):
    """ Initialise the run directory with subdirs """

    dir_run = paths.dir_run(name_run)
    if clear:
        pyutils.delete_dir(dir_run)

    pyutils.create_dir(dir_run)
    subdirs = [
        "datasets",
        "datacols",
        "trains",
        "predicts",
        "evals",
        "geometry",
        "progress",
    ]

    for subdir in subdirs:
        pyutils.create_dir(os.path.join(dir_run, subdir))


def path_to_run_job_py():
    """ Get absolute path to run_job.py"""
    this_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(this_dir, "run_job.py")


def path_to_run_collect_py():
    """ Get absolute path to run_collect.py """
    this_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(this_dir, "run_collect.py")


def path_to_executable():
    """ Get absolute path to this python interpreter.

    This allows us to launch python scripts in the same virtual env as
    we are currently in without messing with the shell.
    """
    return sys.executable


def register_block_collected(name_run, name_block):
    """ Register that the block is collected """
    with open(paths.block_collect_ready(name_run, name_block), "w") as f:
        f.write("ready")


def register_job_ready(name_run, name_block, name_job):
    """ Register that a job is ready """
    with open(paths.block_job_ready(name_run, name_block, name_job), "w") as f:
        f.write("ready")


def wait_for_block_collect(name_run, name_block):
    """ Wait for the block to be registered as collected """

    def is_block_collected(name_run, name_block):
        block_ready = False

        path = paths.block_collect_ready(name_run, name_block)
        if os.path.isfile(path):
            with open(path, "r") as f:
                if f.read() == "ready":
                    block_ready = True
        return block_ready

    while not is_block_collected(name_run, name_block):
        Logger.info(f"Waiting 60s for {name_block}")
        time.sleep(60)


def wait_for_job(name_run, name_block, name_job):
    """ Wait for the job to be registered as ready """

    def is_job_ready(name_run, name_block, name_job):
        block_ready = False
        path = paths.block_job_ready(name_run, name_block, name_job)
        if os.path.isfile(path):
            with open(path, "r") as f:
                if f.read() == "ready":
                    block_ready = True
        return block_ready

    while not is_job_ready(name_run, name_block, name_job):
        Logger.info(f"Waiting 60s for {name_block}, {name_job}")
        time.sleep(60)
