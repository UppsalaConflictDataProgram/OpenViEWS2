# Pipe

This is the prediction pipeline.

The goal of this pipeline is to take one or more datasets and a specification file and produce a set of predictions.

## Usage

To make a prediction you need

* A specfile that can be parsed by `views.apps.defparser`.
* At least on database table, referenced in the specfile.
* The code in this repository.

To make a prediction with the pipeline you simply

* Make sure you have installed the views module with install.sh in the root of the repository
* Make sure your config file points to the database where your data lives and a valid directory for `dir_runs`.
* Run `conda activate views`
* Run `python manager.py --path_specfile /path/to/specfile.yaml`

These steps start the prediction pipeline on your local machine and if everything works you will have a new run directory in your configured `dir_runs` after some time.

### Usage on cluster

To run the pipeline on a slurm enabled cluster follow the same procedure as before but add the `--slurm` flag to your call. For example

`python manager.py --slurm --path_specfile /path/to/specfile.yaml`

This will make each bit of work to be done (each job) run in a separate slurm job on the cluster.
The main process will only start the jobs in order and monitor progress for you.
This will take a while so I recommend running it in a tmux session.
Support for running the manager itself as a slurm job is coming.

## How it works

First some names:

* A task is a single unit of work, can be a model to be trained, a transform to compute or a dataset to fetch or anything else.
* A job is a collection of tasks that run together, in parallel or in sequence. Used for grouping tasks into practical collections to compute.
* A block is a group of tasks that do not depend on each other and can therefore be run in parallel, it is computed in `views.apps.pipe.dependency`

The pipeline depends on a few other apps:

* `views.apps.defparser`, for reading specfiles and parsing them into tasks
* `views.apps.osa`, for training and predicting using models
* `views.apps.transforms`, for computing transformations on data
* `views.apps.slurm_broker`, for talking to slurm clusters


Here's how it runs:
The main method of the manager.py script is the `run_specfile(path_specfile)` method.
It starts by

* Reading the specfile,
* Using `views.apps.defparser.solver` and `views.apps.pipe.dependency` to create blocks of jobs of tasks.
* It then runs each block by running its tasks using `views.apps.pipe.workers`.
* After a block is finished it must be collected into the datasets as individual tasks cannot write into the same datasets in parallel. Collection happens at the end of each block where all tasks are insterted into their datasets. This happens using `views.apps.pipe.collect`.
* Running and collecting blocks is repeated until all blocks are collected and ready.

The actual work of transforming, training and predicting is done by workers trough the `views.apps.osa` and `views.apps.transforms` modules. This module mainly deals with the plumbing between tasks.


