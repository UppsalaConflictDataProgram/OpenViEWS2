""" Naming convention for pipeline, all based on the dir_run """

# pylint: disable=missing-docstring

import os
from views.utils.config import CONFIG


# Tasks


def dataset(name_run, name_task):
    return os.path.join(dir_run(name_run), "datasets", f"{name_task}.parquet")


def datacol(name_run, name_task):
    return os.path.join(dir_run(name_run), "datacols", f"{name_task}.parquet")


def train(name_run, name_task):
    return os.path.join(dir_run(name_run), "trains", f"{name_task}.pickle.xz")


def predict(name_run, name_task):
    return os.path.join(dir_run(name_run), "predicts", f"{name_task}.parquet")


def evaluate(name_run, name_task):
    return os.path.join(dir_run(name_run), "evals", f"{name_task}.json")


def geometry(name_run, name_task):
    return os.path.join(dir_run(name_run), "geometry", f"{name_task}.shp")


# Dirs


def dir_run(name_run):
    return os.path.join(CONFIG["dirs"]["dir_runs"], name_run)


# Specs/jobs/tasks/etc
def spec(name_run):
    return os.path.join(dir_run(name_run), "spec.yaml")


def jobs(name_run):
    return os.path.join(dir_run(name_run), "jobs.json")


def blocks(name_run):
    return os.path.join(dir_run(name_run), "blocks.json")


def tasks(name_run):
    return os.path.join(dir_run(name_run), "tasks.json")


def block_collect_ready(name_run, name_block):
    return os.path.join(
        dir_run(name_run), "progress", f"{name_block}.collect.ready"
    )


def block_job_ready(name_run, name_block, name_job):
    return os.path.join(
        dir_run(name_run), "progress", f"{name_block}.{name_job}.ready"
    )
