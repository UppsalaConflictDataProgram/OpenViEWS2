import argparse
import logging
import multiprocessing as mp

from views.utils import pyutils
from views.apps.pipe import dependency, paths, workers, housekeeping as hk


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=str, required=True)
    parser.add_argument("--block", type=str, required=True)
    parser.add_argument("--job", type=str, required=True)
    args = parser.parse_args()

    return args.run, args.block, args.job


def _run_tasks_parallel(tasks_list):

    Logger.info(f"Starting {len(tasks_list)} tasks in parallel")
    with mp.Pool(processes=20, maxtasksperchild=1) as pool:
        results = []
        for task in tasks_list:
            results.append(pool.apply_async(workers.worker, (task,)))
        for result in results:
            result.get()
    Logger.info(f"Finished {len(tasks_list)} tasks in parallel")


def _run_tasks_monocore(tasks_list):

    Logger.info(f"Starting {len(tasks_list)} tasks sequential")
    for task in tasks_list:
        workers.worker(task)
    Logger.info(f"Finished {len(tasks_list)} tasks sequential")


def run_job(name_run, name_block, name_job):
    task_names = dependency.get_jobs(name_run)[name_block][name_job][
        "task_names"
    ]
    job_type = dependency.get_jobs(name_run)[name_block][name_job]["job_type"]
    tasks = dependency.get_tasks(name_run)
    Logger.info(f"Running {task_names}")

    tasks_list = [tasks[tn] for tn in task_names]
    if job_type == "sequential":
        _run_tasks_monocore(tasks_list)
    elif job_type == "parallel":
        _run_tasks_parallel(tasks_list)

    hk.register_job_ready(name_run, name_block, name_job)


if __name__ == "__main__":

    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)
    Logger = logging.getLogger(__name__)
    run_job(*parse_args())
else:
    Logger = logging.getLogger(__name__)
