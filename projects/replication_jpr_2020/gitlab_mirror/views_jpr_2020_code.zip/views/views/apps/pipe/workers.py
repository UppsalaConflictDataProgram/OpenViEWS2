""" Workers for pipeline """

# @TODO: Come up with sane naming that does'nt redefine outer names
# pylint: disable=redefined-outer-name

import os
import json
import logging

import pandas as pd
import joblib

from views.utils import dbutils, datautils, spatialutils, pyutils
from views.apps.pipe import paths
from views.apps.transforms import translib, spatial
from views.apps.osa import estimators, osa
from views.apps.evaluate import evaluation

Logger = logging.getLogger(__name__)


def worker(task):

    WORKERS = {
        "dataset": _dataset,
        "datacol": _datacol,
        "train": _train,
        "predict_memt": _predict_memt,
        "predict_semt": _predict_semt,
        "eval": _evaluate,
        "geometry": _geometry,
    }
    task_type = task["task_type"]
    name_task = task["name"]
    Logger.debug(f"worker() starting {name_task} type {task_type}")
    WORKERS[task["task_type"]](task)
    Logger.debug(f"worker() finished {name_task} type: {task_type}")


def _dataset(task):
    """ Get a dataset from db and write to file """

    def forget_future(df, t_end):
        return df.loc[:t_end]

    def get_and_fill(fqtable, ids, cols, path):
        df = dbutils.db_to_df_fast(fqtable, ids=ids, columns=cols)
        df = forget_future(df, t_end=task["times"]["end"])

        # CM hack for balanced data for spatial compat, remove ASAP
        if not datautils.df_is_balanced(df):
            df = datautils.balance_df_panel_index(
                df, timevar=task["timevar"], groupvar=task["groupvar"]
            )
            df = datautils.fill_forwards_backwards(df)
            df = datautils.nan_to_mean(df)

        datautils.write_parquet(df, path)

    fqtable = task["table"]
    ids = [task["timevar"], task["groupvar"]]
    cols = task["cols_source"]
    path = paths.dataset(task["name_run"], task["name"])

    # get_and_fill(fqtable, ids, cols)
    if os.path.isfile(path):
        Logger.info(f"dataset(): {path} already exists, not refetching.")
    else:
        Logger.info(f"{path} not found, refetching.")
        get_and_fill(fqtable, ids, cols, path)


def _datacol(task):
    """ Compute a datacol and write to file """

    def transform(task):
        def _spatial(s_source, task):

            f = task["work"]["f"]
            path_geom = paths.geometry(
                name_run=task["name_run"], name_task="geometry"
            )

            # Get the geom and make a geodataframe
            groupvar = s_source.index.names[1]
            gdf = spatialutils.shp_to_gdf(path=path_geom, groupvar=groupvar)
            gdf = gdf.join(s_source, how="inner")

            if f == "spdist":
                s = spatial.distance_to_event(
                    gdf, event_col=s_source.name, k=task["work"]["params"]["k"]
                )
            elif f == "stdist":
                s = spatial.spacetime_distance_to_event(
                    gdf,
                    event_col=s_source.name,
                    t_scale=task["work"]["params"]["t_scale"],
                    k=task["work"]["params"]["k"],
                )
            elif f == "splag":
                s = spatial.spatial_lag(
                    gdf,
                    col=s_source.name,
                    first=task["work"]["params"]["first"],
                    last=task["work"]["params"]["last"],
                )

            return s

        def _regular(s_source, task):

            f = task["work"]["f"]
            params = task["work"]["params"]

            if f == "tlag":
                s = translib.tlag(s_source, time=params["time"])
            elif f == "cweq":
                s = translib.cweq(s_source, value=params["value"])
            elif f == "ma":
                s = translib.moving_average(s_source, time=params["time"])
            elif f == "decay":
                s = translib.decay(s_source, halflife=params["halflife"])
            elif f == "greq":
                s = translib.greater_or_equal(s_source, value=params["value"])
            elif f == "smeq":
                s = translib.smaller_or_equal(s_source, value=params["value"])
            elif f == "in_range":
                s = translib.in_range(
                    s_source, low=params["low"], high=params["high"]
                )
            elif f == "time_since":
                s = translib.time_since_previous_event(
                    s_source, seed=params["seed"]
                )
            elif f == "rollmax":
                s = translib.rollmax(s=s_source, window=params["window"])
            elif f == "ln":
                s = translib.ln(s=s_source)

            return s

        def _get_s_source(task):

            dataset = task["dataset"]
            col = task["work"]["params"]["col"]
            path = paths.dataset(task["name_run"], dataset)
            df = datautils.load_parquet(path, cols=[col])
            s_source = df[col]

            return s_source

        name = task["name"]
        path = paths.datacol(task["name_run"], name)

        # @TODO: cleanup
        if os.path.isfile(path):
            Logger.info(f"datacol(): {path} already exists, not recomputing.")
        else:
            s_source = _get_s_source(task)

            f = task["work"]["f"]
            if f in [
                "tlag",
                "cweq",
                "ma",
                "decay",
                "greq",
                "smeq",
                "in_range",
                "time_since",
                "rollmax",
                "ln",
            ]:
                s = _regular(s_source, task)
            elif f in ["spdist", "stdist", "splag"]:
                s = _spatial(s_source, task)

            else:
                raise RuntimeError(f"Not matching transformer for {f}")

            s.name = task["colname"]
            datautils.write_parquet(s, path)

    def source(task):
        """ Just check that the source col is present in the df """

        colname = task["colname"]
        dataset = task["dataset"]

        path_df = paths.dataset(task["name_run"], dataset)
        check = False
        if check:
            df = pd.read_parquet(path_df, columns=[colname])

            if not colname in df.columns:
                msg = (
                    f"Missing col {colname} in dataset {dataset}. "
                    f"If it's included in cols_source rerun with --clear"
                )

                raise RuntimeError(msg)

        result = {"task": task.copy(), "result": {}}

        return result

    if task["datasource"] == "transforms":
        transform(task)

    elif task["datasource"] == "source":
        source(task)


def _train(task):
    """ Train an estimator and write to file """

    path = paths.train(task["name_run"], task["name"])
    if os.path.isfile(path):
        Logger.debug(f"{path} exists, not re-training.")
    else:
        name = task["name"]
        Logger.debug(f"Started training estimator {name}")
        estimator = estimators.estimator_fetcher(spec=task["estimator"])
        # df = pd.read_hdf(paths.dataset(task["name_run"], task["dataset"]))
        # df = datautils.load_hdf(paths.dataset(task["name_run"], task["dataset"]))
        cols = task["rhs"].copy()
        cols.append(task["lhs"])
        cols = pyutils.dedup_list(cols)
        df = datautils.load_parquet(
            path=paths.dataset(task["name_run"], task["dataset"]), cols=cols
        )
        t_start = df.index.get_level_values(0).min()
        t_end = df.index.get_level_values(0).max()
        fitted_estimator = osa.fit(
            df,
            estimator,
            outcome=task["lhs"],
            features=task["rhs"],
            stepsize=task["step"],
            t_start=t_start,
            t_end=t_end,
        )
        Logger.info(f"Finished training estimator {name}")

        joblib.dump(fitted_estimator, path, compress=1)
        Logger.info(f"Wrote estimator {name} to {path}")


def _get_estimators(task):
    """ Get the estimators for a predict task """

    estimator_step_names = task["trains"]
    estimators = {}
    step_numbers = estimator_step_names.keys()
    for step_number in step_numbers:
        step_name = estimator_step_names[step_number]
        path_step = paths.train(task["name_run"], step_name)
        estimators[step_number] = joblib.load(path_step)
        Logger.debug(f"predict() read {path_step}")
    return estimators


def _predict_memt(task):
    """ Predict with multiple estimators multiple times """
    path = paths.predict(task["name_run"], task["name"])
    if os.path.isfile(path):
        Logger.info(f"_predict_memt(): {path} already exists, not refetching.")
    else:
        colname_prediction = task["colname"]
        df = datautils.load_parquet(
            paths.dataset(task["name_run"], task["dataset"]), cols=task["rhs"]
        )
        estimators = _get_estimators(task)
        features = task["rhs"]
        times = list(range(task["times"]["start"], task["times"]["end"] + 1))

        df_pred = osa.predict_memt(
            df, estimators, colname_prediction, features, times
        )

        datautils.write_parquet(df_pred, path)


def _predict_semt(task):
    """ Predict with a single estimator multiple times """
    path = paths.predict(task["name_run"], task["name"])
    if os.path.isfile(path):
        Logger.info(f"_predict_semt(): {path} already exists, not refetching.")
    else:
        colname_prediction = task["colname"]

        # df = pd.read_hdf(paths.dataset(task["name_run"], task["dataset"]))
        # df = datautils.load_hdf(paths.dataset(task["name_run"], task["dataset"]))
        df = datautils.load_parquet(
            paths.dataset(task["name_run"], task["dataset"]), cols=task["rhs"]
        )

        # Selet our single estimator
        estimators = _get_estimators(task)
        if len(estimators) != 1:
            raise RuntimeError("predict_semt() got more than one estimator")
        steplen = list(estimators.keys())[0]

        estimator = estimators[steplen]
        features = task["rhs"]

        times = list(range(task["times"]["start"], task["times"]["end"] + 1))

        df_pred = osa.predict_semt(
            df, estimator, int(steplen), colname_prediction, features, times
        )

        df_pred = df_pred.sort_index()
        datautils.write_parquet(df_pred, path)


def _evaluate(task):
    """ Run evaluation task """
    path = paths.evaluate(task["name_run"], task["name"])
    if os.path.isfile(path):
        Logger.info(f"_evaluate(): {path} already exists, not recomputing.")
    else:
        colname_prediction = task["colname_prediction"]
        colname_actual = task["colname_actual"]
        # df = pd.read_hdf(paths.dataset(task["name_run"], task["dataset"]))
        df = datautils.load_parquet(
            paths.dataset(task["name_run"], task["dataset"]),
            cols=[colname_actual, colname_prediction],
        )
        df = df.dropna()

        scores = evaluation.eval_binary(df, colname_actual, colname_prediction)
        pyutils.write_json(scores, path)


def _geometry(task):
    """ Run geometry task """

    path = paths.geometry(task["name_run"], task["name"])
    if os.path.isfile(path):
        Logger.info(f"_geometry(): {path} already exists, not refetching.")
    else:
        gdf = dbutils.db_to_gdf(query=task["query"], groupvar=task["groupvar"])
        spatialutils.gdf_to_shp(gdf=gdf, path=path)
