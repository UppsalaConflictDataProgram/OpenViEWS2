import argparse
import logging

from views.utils import pyutils

from views.apps.slurm_broker import slurm_broker
from views.apps.pipe import (
    paths,
    dependency,
    housekeeping as hk,
    workers,
    run_job,
    collect,
)

DEFAULT_HOURS_PER_JOB = 12

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
Logger = logging.getLogger(__name__)


def parse_args():

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--slurm", action="store_true", help="Send jobs to slurm"
    )
    parser.add_argument(
        "--subproc", action="store_true", help="Do work in subprocs"
    )
    parser.add_argument(
        "--clear",
        action="store_true",
        help="Delete any existing same-name run before start",
    )
    parser.add_argument("--path_specfile", type=str, required=True)
    parser.add_argument(
        "--tasks_per_seq_job",
        type=int,
        help="Number of tasks to do per sequential job.",
    )
    parser.add_argument(
        "--hours_per_job",
        type=int,
        help="Number of hours to request per job if using slurm.",
    )

    args = parser.parse_args()

    mode = "normal"
    if args.slurm and args.subproc:
        raise RuntimeError("Supply either --slurm or --subproc, not both!")
    if args.slurm:
        mode = "slurm"
    elif args.subproc:
        mode = "subproc"

    if args.tasks_per_seq_job:
        tasks_per_seq_job = args.tasks_per_seq_job
    else:
        tasks_per_seq_job = dependency.DEFAULT_TASKS_PER_SEQ_JOB

    if args.hours_per_job:
        hours_per_job = args.hours_per_job
    else:
        hours_per_job = DEFAULT_HOURS_PER_JOB

    clear = args.clear

    return mode, args.path_specfile, tasks_per_seq_job, hours_per_job, clear


def _call_run_job_subproc(run, block, job):
    cmd = [
        hk.path_to_executable(),
        hk.path_to_run_job_py(),
        "--run",
        run,
        "--block",
        block,
        "--job",
        job,
    ]
    pyutils.run_subproc(cmd)


def _call_run_job_slurm(run, block, job, hours):
    cmd = " ".join(
        [
            hk.path_to_executable(),
            hk.path_to_run_job_py(),
            "--run",
            run,
            "--block",
            block,
            "--job",
            job,
        ]
    )
    slurm_broker.run_command(cmd, hours=hours)


def _call_collect_job_subproc(run, block):
    cmd = [
        hk.path_to_executable(),
        hk.path_to_run_collect_py(),
        "--run",
        run,
        "--block",
        block,
    ]
    pyutils.run_subproc(cmd)


def _call_collect_job_slurm(run, block, hours):
    cmd = " ".join(
        [
            hk.path_to_executable(),
            hk.path_to_run_collect_py(),
            "--run",
            run,
            "--block",
            block,
        ]
    )
    slurm_broker.run_command(cmd, hours=hours)


def run_specfile(
    path_spec,
    mode,
    tasks_per_seq_job=dependency.DEFAULT_TASKS_PER_SEQ_JOB,
    hours_per_job=DEFAULT_HOURS_PER_JOB,
    clear=False,
):
    name_run = pyutils.load_yaml(path_spec)["name"]

    hk.init_rundir(name_run, clear)
    dependency.copy_spec_to_rundir(path_spec)

    jobs = dependency.get_jobs(name_run, tasks_per_seq_job)
    for name_block, block in jobs.items():
        for name_job in block:
            if mode == "normal":
                run_job.run_job(name_run, name_block, name_job)
            elif mode == "subproc":
                _call_run_job_subproc(name_run, name_block, name_job)
            elif mode == "slurm":
                _call_run_job_slurm(
                    name_run, name_block, name_job, hours_per_job
                )

        for name_job in block:
            hk.wait_for_job(name_run, name_block, name_job)

        if mode == "normal":
            collect.collect_block(name_run, name_block)
        elif mode == "subproc":
            _call_collect_job_subproc(name_run, name_block)
        elif mode == "slurm":
            _call_collect_job_slurm(name_run, name_block, hours_per_job)

        hk.wait_for_block_collect(name_run, name_block)

    Logger.info(f"Great success!")


if __name__ == "__main__":
    mode, path_specfile, tasks_per_seq_job, hours_per_job, clear = parse_args()
    run_specfile(
        path_specfile,
        mode=mode,
        tasks_per_seq_job=tasks_per_seq_job,
        hours_per_job=hours_per_job,
        clear=clear,
    )
