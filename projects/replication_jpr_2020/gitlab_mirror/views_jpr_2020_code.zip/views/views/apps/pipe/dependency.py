import os
import logging

from views.apps.defparser import solver
from views.utils import pyutils
from views.apps.pipe import paths

Logger = logging.getLogger(__name__)

DEFAULT_TASKS_PER_SEQ_JOB = 50


def copy_spec_to_rundir(path_spec):
    """ Copy specfile to run dir """
    pyutils.copy_file(
        path_spec, paths.spec(pyutils.load_yaml(path_spec)["name"])
    )


def get_jobs(name_run, tasks_per_seq_job=DEFAULT_TASKS_PER_SEQ_JOB):
    """ Get jobs, from file if already created or create if not

    TODO: Split into make and get to avoid tasks_per_seq_job param for get
    """

    if os.path.isfile(paths.jobs(name_run)):
        jobs = pyutils.load_json(paths.jobs(name_run))
    else:
        jobs = _make_jobs(
            blocks=get_blocks(name_run),
            tasks=get_tasks(name_run),
            tasks_per_seq_job=tasks_per_seq_job,
        )
        pyutils.write_json(jobs, paths.jobs(name_run))
    return jobs


def get_spec(name_run):
    return pyutils.load_yaml(paths.spec(name_run))


def get_blocks(name_run):
    if os.path.isfile(paths.blocks(name_run)):
        blocks = pyutils.load_json(paths.blocks(name_run))
    else:
        blocks = _make_blocks(tasks=get_tasks(name_run))
        pyutils.write_json(blocks, paths.blocks(name_run))

    return blocks


def get_tasks(name_run):
    if os.path.isfile(paths.tasks(name_run)):
        tasks = pyutils.load_json(paths.tasks(name_run))
    else:
        tasks = _make_tasks(name_run)
        pyutils.write_json(tasks, paths.tasks(name_run))
    return tasks


def _make_tasks(name_run):
    specs = get_spec(name_run)
    defis = solver.defis(specs)
    tasks = solver.tasks_flat(solver.tasks(defis, specs))

    return tasks


def _make_blocks(tasks):
    """ Create a secuentially dependent list of blocks of tasks

    All the tasks in a block can be run in parallel as they don't depend
    on each other.
    """

    blocks = []
    Logger.info(
        f"Solving sequentially dependent blocks for {len(tasks)} tasks."
    )

    # Max number of blocks is number of tasks
    for i in range(len(tasks)):
        block = []
        Logger.info(f"Solving block {i}")
        blocks_flat = pyutils.flatten_list(blocks, warn_not_nested=False)
        for task_name, task in tasks.items():
            deps = True
            for dep in task["deps"]:
                if dep not in blocks_flat:
                    deps = False
            # If deps is true and task isn't in previous blocks
            if deps and task_name not in blocks_flat:
                block.append(task_name)

        blocks.append(block)
        done = len(pyutils.flatten_list(blocks)) == len(tasks)
        if done:
            break

        # If no tasks in block:
        elif not block:
            for task_name, task in tasks.items():
                deps = True
                for dep in task["deps"]:
                    if dep not in pyutils.flatten_list(blocks, False):
                        deps = False
                        Logger.error(f"{task_name} unresolved {dep}")

            raise RuntimeError("Broke")

    if not done:
        raise RuntimeError("Something wen't wrong while solving deps")

    Logger.info(f"Made {len(blocks)} sequentially dependent task blocks")

    return blocks


def __make_jobs(blocks, tasks):

    types_to_solo = ["train", "predict_semt", "predict_memt"]

    jobs = {}

    for block_num, block in enumerate(blocks):
        block_name = f"block_{block_num}"

        solos = []
        group = []
        jobs[block_name] = {}
        for name in block:
            if tasks[name]["task_type"] in types_to_solo:
                solos.append([name])
            else:
                group.append(name)

        joblist_this_step = []
        for solo in solos:
            joblist_this_step.append(solo)
        if group:
            joblist_this_step.append(group)

        for job_num, job in enumerate(joblist_this_step):
            job_id = f"job_{job_num}"
            jobs[block_name][job_id] = job

    return jobs


def _make_jobs(blocks, tasks, tasks_per_seq_job):
    """ Make jobs of two types, sequential and parallel """

    types_to_run_sequential = [
        "dataset",
        "train",
        "predict_semt",
        "predict_memt",
    ]

    jobs = {}

    for block_num, block in enumerate(blocks):
        block_name = f"block_{block_num}"

        seqs = []
        pars = []
        jobs[block_name] = {}
        for name in block:
            task_type = tasks[name]["task_type"]
            if task_type in types_to_run_sequential:
                seqs.append(name)
            else:
                pars.append(name)

        seq_chunks = pyutils.chunker(seq=seqs, size=tasks_per_seq_job)

        joblist_this_step = []
        for seq_chunk in seq_chunks:
            job = {"job_type": "sequential", "task_names": seq_chunk}
            joblist_this_step.append(job)

        joblist_this_step.append({"job_type": "parallel", "task_names": pars})

        for job_num, job in enumerate(joblist_this_step):
            job_id = f"job_{job_num}"
            jobs[block_name][job_id] = job

    return jobs
