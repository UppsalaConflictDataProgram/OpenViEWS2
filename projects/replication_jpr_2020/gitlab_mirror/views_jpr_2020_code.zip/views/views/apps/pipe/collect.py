import time
import os
import logging
import multiprocessing as mp
import pandas as pd

from views.utils import pyutils, datautils
from views.apps.pipe import paths, dependency, housekeeping as hk

Logger = logging.getLogger(__name__)


def collect_dataset(collection_task):

    # Unpack the collection task
    name_run = collection_task["name_run"]
    dataset = collection_task["dataset"]
    task_names = collection_task["task_names"]

    msg = f"Started collecting for {name_run} {dataset} {len(task_names)} tasks"
    Logger.info(msg)

    # Lookup table for task_type to path function
    path_funcs = {
        "predict_memt": paths.predict,
        "predict_semt": paths.predict,
        "datacol": paths.datacol,
    }

    tasks = dependency.get_tasks(name_run)
    df = datautils.load_parquet(paths.dataset(name_run, dataset))

    for tn in task_names:
        path = path_funcs[tasks[tn]["task_type"]](name_run, tn)
        if not tasks[tn]["colname"] in df.columns:
            s_as_df = datautils.load_parquet(path)
            # Workaround for parquet not being able to store series/df
            # it always gets a df
            if len(s_as_df.columns) == 1:
                s = s_as_df[s_as_df.columns[0]]
            else:
                raise RuntimeError("Expected data to have a single col")
            df[s.name] = s
    datautils.write_parquet(df, paths.dataset(name_run, dataset))


def collect_tasks(name_run, task_names, parallel=False):

    Logger.info(f"Collecting {task_names}")

    # Subset task_names to only collectible types
    tasks = dependency.get_tasks(name_run)
    types = ["datacol", "predict_memt", "predict_semt"]
    task_names = [tn for tn in task_names if tasks[tn]["task_type"] in types]

    Logger.info(f"Collecting only {task_names}")

    # Find datasets
    datasets = pyutils.dedup_list([tasks[tn]["dataset"] for tn in task_names])
    Logger.info(f"Found datasets {datasets}")

    # Order task_names into by-dataset dict
    tasks_names_by_dataset = {}
    for dataset in datasets:
        tasks_dataset = [
            tn for tn in task_names if tasks[tn]["dataset"] == dataset
        ]
        tasks_names_by_dataset[dataset] = tasks_dataset

    # Build list of by-dataset collection tasks
    collection_tasks = []
    for dataset, task_names in tasks_names_by_dataset.items():
        collection_tasks.append(
            {"name_run": name_run, "dataset": dataset, "task_names": task_names}
        )

    # Run collection tasks
    if parallel:
        with mp.Pool(processes=2, maxtasksperchild=1) as pool:
            results = []
            for collection_task in collection_tasks:
                results.append(
                    pool.apply_async(collect_dataset, (collection_task,))
                )
            for res in results:
                res.get()
    else:
        for collection_task in collection_tasks:
            collect_dataset(collection_task)


def collect_block(name_run, name_block):
    jobs = dependency.get_jobs(name_run)[name_block]

    block_task_names = []
    for job_name, job in jobs.items():
        for task_name in job["task_names"]:
            block_task_names.append(task_name)

    collect_tasks(name_run, block_task_names)
    hk.register_block_collected(name_run, name_block)
