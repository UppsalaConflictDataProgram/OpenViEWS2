""" slurm broker client, listens for jobs in the db and submits them """

# TODO: Finish

import subprocess
import string
import os
import json
import uuid
import logging
import datetime
import time

from views.utils import config, pyutils

Logger = logging.getLogger(__name__)

THIS_DIR = os.path.dirname(os.path.abspath(__file__))


def _parse_jobinfo(jobinfo_str):
    """ Get a dict of jobinfos keyed by slurm job ids

    Args:
        jobinfo_str: Output from jobinfo as a string
    Returns:
        jobs: dict of dicts keyed by running/waiting then slurm_job_id

    """

    def get_lines_between_start_and_empty(lines, start, headers):
        """ Get list of lines of running jobs """

        lines_running = []
        started_running = False
        for line in lines:
            # If we find the header go to next line and
            if start in line:
                started_running = True
                continue

            if started_running:
                if line == "":
                    break
                else:
                    lines_running.append(line)

        # Drop the headers line
        for line in lines_running:
            all_headers = True
            for header in headers:
                if not header in line:
                    all_headers = False
            if all_headers:
                lines_running.remove(line)

        return lines_running

    def parse_lines_into_jobs(lines, headers):
        """ Get dict of running jobs from their lines """

        jobs = {}

        for line in lines:
            # Fields are separated by whitespace
            fields = line.split()
            job = {}
            job_id = int(fields[0])
            for index, header in enumerate(headers):
                job[header] = fields[index]
            jobs[job_id] = job.copy()

        return jobs

    headers_running = [
        "JOBID",
        "PARTITION",
        "NAME",
        "USER",
        "ACCOUNT",
        "ST",
        "START_TIME",
        "TIME_LEFT",
        "NODES",
        "CPUS",
        "NODELIST(REASON)",
    ]

    # Actual output contains DEPENDENCY too but it's mostly empty so
    # we drop it
    headers_waiting = [
        "JOBID",
        "POS",
        "PARTITION",
        "NAME",
        "USER",
        "ACCOUNT",
        "ST",
        "START_TIME",
        "TIME_LEFT",
        "PRIORITY",
        "CPUS",
        "NODELIST(REASON)",
        "FEATURES",
    ]

    jobs_running = {}
    jobs_waiting = {}

    lines_running = get_lines_between_start_and_empty(
        jobinfo_str.splitlines(), start="Running jobs:", headers=headers_running
    )
    jobs_running = parse_lines_into_jobs(lines_running, headers_running)

    lines_waiting = get_lines_between_start_and_empty(
        jobinfo_str.splitlines(), start="Waiting jobs:", headers=headers_waiting
    )
    jobs_waiting = parse_lines_into_jobs(lines_waiting, headers_waiting)

    jobs = {}
    jobs["running"] = jobs_running
    jobs["waiting"] = jobs_waiting

    return jobs


def get_jobinfo():
    def get_jobinfo_raw(username):
        """ Get the results from jobinfo -u username """

        command = f"jobinfo -u {username}"
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            encoding="utf-8",
        )
        return result.stdout

    username = config.CONFIG["slurm"]["username"]
    jobinfo_raw = get_jobinfo_raw(username)
    jobs = _parse_jobinfo(jobinfo_raw)
    print(json.dumps(jobs, indent=4))
    return jobs


def _make_runfile(command, jobtype, cores, hours):

    # pylint: disable=too-many-arguments
    def _make_runfile_str(command, project, jobtype, cores, time, name):
        """ Create a slurm runfile string

        Args:
            project: slurm project id
            jobtype: "core" or "node"
            cores: number of cores
            time: time like "8:00:00" for 8 hours
            name: job name, make it unique
            command: the command to run
        Returns:
            runfile: A string of a slurm runfile

        """

        path_template = os.path.join(
            THIS_DIR, f"runfile_template_{jobtype}.txt"
        )
        with open(path_template, "r") as f:
            template_str = f.read()

        template = string.Template(template_str)

        dir_storage = config.CONFIG["dirs"]["dir_storage"]

        dir_logs = os.path.join(dir_storage, "logs")
        pyutils.create_dir(dir_logs)
        log_location = os.path.join(dir_logs, f"{name}.log")

        msg = "jobtype must be core or node!"
        if not jobtype in ["core", "node"]:
            raise RuntimeError(msg)

        if jobtype == "core":
            mapping = {
                "PROJECT_ID": project,
                "JOBTYPE": jobtype,
                "N_CORES": cores,
                "TIME": time,
                "NAME": name,
                "LOGFILE_LOCATION": log_location,
                "COMMAND": command,
            }
        # Don't have N_CORES for node jobs.
        elif jobtype == "node":
            mapping = {
                "PROJECT_ID": project,
                "JOBTYPE": jobtype,
                "TIME": time,
                "NAME": name,
                "LOGFILE_LOCATION": log_location,
                "COMMAND": command,
            }

        runfile = template.substitute(mapping)

        return runfile

    def make_path_runfile(name):
        dir_runfiles = os.path.join(cfg["dirs"]["dir_storage"], "runfiles")
        pyutils.create_dir(dir_runfiles)
        return os.path.join(dir_runfiles, f"{name}.sh")

    def make_job_name():
        name_id = str(uuid.uuid4()).split("-")[0]
        timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        name = f"job_{timestamp}_{name_id}"
        return name

    cfg = config.CONFIG
    name = make_job_name()
    path_runfile = make_path_runfile(name)
    time_str = f"{str(hours)}:00:00"

    runfile_str = _make_runfile_str(
        command=command,
        project=cfg["slurm"]["project"],
        jobtype=jobtype,
        cores=cores,
        time=time_str,
        name=name,
    )

    with open(path_runfile, "w") as f:
        f.write(runfile_str)
    Logger.info(f"Wrote runfile to {path_runfile}")

    return path_runfile


def _submit_runfile(path, clusters):
    """ Submit a runfile to slurm using the sbatch command

    Args:
        path: path to runfile to submit
        clusters: list of clusters to submit the job to. Slurm will send
                  the job to the cluster that will start it first.
    Returns:
        job_id: integer job_id or None if slurm "failed"
    """

    # @TODO: Fix retries somehow.
    # Only try once as sbatch commands may "fail" but submit the job anyway
    n_tries = 1
    timeout = 60
    clusters_str = ",".join(clusters)
    sbatch_command = f"sbatch --clusters={clusters_str} {path}"
    for _ in range(n_tries):
        try:
            result = subprocess.run(
                sbatch_command,
                shell=True,
                check=True,
                stdout=subprocess.PIPE,
                encoding="utf-8",
            )
            response = result.stdout
            break
        except subprocess.CalledProcessError as exc:
            Logger.warning(f"Got {exc}, waiting {timeout}")
            time.sleep(timeout)
            response = "Broken"

    success_str = "Submitted batch job "
    if success_str in response:
        # job_id = int(response.split(success_str)[1])
        job_id = [int(s) for s in response.split() if s.isdigit()][0]
        Logger.info(f"Submitted job to job_id: {job_id}")
    else:
        Logger.warning("Slurm unhappy")
        job_id = None
        # raise RuntimeError(f"Unexpected response from slurm: {response}")

    return job_id


def run_command(
    command, hours=24, cores=20, jobtype="node", clusters=["rackham", "snowy"]
):

    path = _make_runfile(command, cores=cores, jobtype=jobtype, hours=hours)
    job_id = _submit_runfile(path, clusters)

    return job_id


if __name__ == "__main__":
    get_jobinfo()
