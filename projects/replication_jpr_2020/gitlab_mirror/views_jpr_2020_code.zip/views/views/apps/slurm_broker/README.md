# Slurm Broker

This Slurm broker facilitates interaction between a database
and a slurm job queue on a cluster.
The goal is to allow submissions of jobs to the Uppmax job queue without
logging in through ssh every time we want to submit a job.

## Job queue

The job queue in the DB has the following fields

id primary key,
task json,
status text

task is a json describing the work to be done at the cluster.
status is a text column with possible values

* wait, if a job has unmet deps and should not be submitted to slurm
* new, if a job has not yet been submitted but it should be
* in_slurm_queue, if the job is waiting to start in the slurm queue
* in_slurm_running, if the job is running
* failed, if something went wrong
* finished, if the job finished and all is well

## Running

The slurm broker client runs on a login node on the cluster at all times.
This should be done through the following steps

* ssh into our database server
* start a tmux session
* ssh into the cluster
* start the broker

This assures that we can stop the broker if we want.
Simply starting it in a tmux session on a login node of the cluster means
we might not be able to stop it should we be assigned a different login node
next time we login to the cluster.

## Misc
Make a file containing the init hook for conda
Example
eval "$(/home/username/miniconda3/bin/conda shell.bash hook)"
and place it in slurm:conda_hook of your config.json
