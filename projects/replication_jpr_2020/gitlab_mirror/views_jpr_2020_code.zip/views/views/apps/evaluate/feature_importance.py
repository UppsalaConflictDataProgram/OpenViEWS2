import tempfile
import psutil
import os
import joblib
import pandas as pd
import multiprocessing as mp
import logging
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.ensemble import RandomForestClassifier

from views.apps.defparser import solver
from views.apps import pipe
from views.utils import pyutils, sshutils


Logger = logging.getLogger(__name__)


def get_feature_importance_remote(host, dir_run_remote, name, task):
    """ Get feature importance from remote host """
    fname = f"{name}.pickle.xz"
    path_remote = os.path.join(dir_run_remote, "trains", fname)
    features = task["rhs"]

    with tempfile.TemporaryDirectory() as tempdir:
        path_local = os.path.join(tempdir, fname)
        sshutils.scp_file(host, path_remote, path_local)
        fi_dict = get_feature_importance_from_pickle(path_local, features)
        result = {"name": name, "feature_importances": fi_dict}
    return result


def get_feature_importances_remote(host, dir_run_remote):

    # Get spec from remote
    with tempfile.TemporaryDirectory() as tempdir:
        path_spec_local = os.path.join(tempdir, "spec.yaml")
        path_spec_remote = os.path.join(dir_run_remote, "spec.yaml")
        sshutils.scp_file(host, path_remote=path_spec_remote, path_local=path_spec_local)
        spec = pyutils.load_yaml(path_spec_local)

    tasks = solver.tasks_flat(solver.tasks(solver.defis(spec), spec))

    tasks_train = {
        key: value
        for (key, value) in tasks.items()
        if value["task_type"] == "train"
    }

    with mp.Pool(processes=psutil.cpu_count(logical=False)) as pool:
        responses = []
        for name, task in tasks_train.items():
            responses.append(
                pool.apply_async(get_feature_importance_remote, (host, dir_run_remote, name, task))
            )
        fis = []
        for response in responses:
            fis.append(response.get())

    return fis



def get_feature_importance_from_pickle(path_pickle, features):
    """ Get feature importance from pickle at path

    Args:
        path: path to pickled RandomForestClassifier
        features: List of feature names
    Returns:
        fi_dict: A dictionary of feature importance scores
    """
    fi_dict = {}
    if os.path.isfile(path_pickle):
        Logger.debug(f"Started reading {path_pickle}")
        try:
            estimator = joblib.load(path_pickle)
            Logger.debug(f"Finished reading {path_pickle}")
            # Only populate if it's a RandomForestClassifier
            if isinstance(estimator, RandomForestClassifier):
                fi = estimator.feature_importances_
                for value, feature in zip(fi, features):
                    fi_dict[feature] = value

        except EOFError:
            Logger.warning(f"Couldn't read {path_pickle}")

    return fi_dict


def get_feature_importance(dir_run, name, task):
    """ Get feature importance

    Args:
        dir_run: Directory to look for pickles in ./train/ of
        name: Name of the
    """
    path = os.path.join(dir_run, "trains", f"{name}.pickle.xz")
    features = task["rhs"]
    fi_dict = get_feature_importance_from_pickle(path, features)
    result = {"name": name, "feature_importances": fi_dict}
    return result


def get_feature_importances_par(dir_run):
    """ Get feature importances in parallel """
    # Specfile is always called spec.yaml
    dir_run = pyutils.resole_vars_and_home(dir_run)
    path_spec = os.path.join(dir_run, "spec.yaml")

    # Load the spec and get the training tasks from it
    spec = pyutils.load_yaml(path_spec)
    name_run = spec["name"]
    tasks = solver.tasks_flat(solver.tasks(solver.defis(spec), spec))
    tasks_train = {
        key: value
        for (key, value) in tasks.items()
        if value["task_type"] == "train"
    }

    feature_importances = {}
    with mp.Pool(processes=psutil.cpu_count(logical=False)) as pool:
        responses = []

        for name, task in tasks_train.items():
            responses.append(
                pool.apply_async(get_feature_importance, (dir_run, name, task))
            )
        result = [response.get() for response in responses]

    return result


def write_feature_importances_to_file(path, dir_run):
    """ Extract feature importances from rfs in dir_run

    Write a json containing feature importances of all
    trained RandomForestClassifier objects in dir_run to path.

    Args:
        path: Path of json to write
        dir_run: Run directory containing a spec.yaml and a trains/ dir
    Returns: None
    """

    feature_importances = get_feature_importances_par(dir_run)
    pyutils.write_json(content=feature_importances, path=path)


def plot_feature_importances(featimps, modelname, path):
    """ Plots feature importances in vertical bar chart.

    Args:
        featimps: Dict of feature importances.
        modelname: Name of model feature importances pertain to.
        path: Path to write figure to.

    """
    df = pd.DataFrame(featimps, index=[0])
    df = df.transpose()

    # Correct first row after transposing, reset index and give colnames.
    df = df.iloc[1:]
    df.reset_index(inplace=True)
    df.columns = ["variable", "value"]
    df.sort_values("value", ascending=False, inplace=True)

    try:
        # Initialize and plot figure.
        sns.set(style="whitegrid")
        width, height = 14, len(df)/4
        f, ax = plt.subplots(figsize=(width, height))
        fimps = sns.barplot(x="value", y="variable", data=df, palette="RdYlBu")
        sns.despine(left=True, bottom=True)
        ax.set(
            xlim=(0, (max(df.value) + 0.15 * max(df.value))), ylabel="", xlabel=""
        )

        # Add title, labels, get fig.
        title = f"Feature importance\nModelname: {modelname}"
        plt.title(title, loc="left")
        for i, v in enumerate(df.value):
            valuelabels = f" {str(round(v, 3))}"
            plt.text(v, i + 0.1, valuelabels, va="center", size=10)
        fig_featp = fimps.get_figure()



        # Save to file.
        fig_featp.savefig(path, bbox_inches="tight", pad_inches=1)
        plt.close("all")
        Logger.info(f"Wrote {path}")
    except ValueError:
        Logger.warning(f"Couldn't plot {path}")
