"""
Evaluation library.
Contains functions that return metrics and confusion matrices.
"""

# TODO(Remco): Add multi-class and regression evaluation.

import pandas as pd
import numpy as np
from sklearn import metrics
from multiprocessing import Pool


def average_precision(actuals, probs):
    """Computes AUPR given array of actuals and probs."""
    return metrics.average_precision_score(y_true=actuals, y_score=probs)


def area_under_roc(actuals, probs):
    """Computes AUROC given array of actuals and probs."""
    return metrics.roc_auc_score(y_true=actuals, y_score=probs)


def brier(actuals, probs):
    """Computes brier score given array of actuals and probs."""
    return metrics.brier_score_loss(y_true=actuals, y_prob=probs)


def accuracy(actuals, preds):
    """Computes accuracy from series of actuals and predictions with
    single threshold applied."""
    return metrics.accuracy_score(y_true=actuals, y_pred=preds)


def precision(actuals, preds):
    """Computes precision from confusion matrix."""
    return metrics.precision_score(y_true=actuals, y_pred=preds)


def recall(actuals, preds):
    """Computes recall from confusion matrix."""
    return metrics.recall_score(y_true=actuals, y_pred=preds)


def f1_score(actuals, preds):
    """Computes F1-score given precision and recall."""
    return metrics.f1_score(y_true=actuals, y_pred=preds)


def mean_squared_error(actuals, probs):
    """Computes MSE given array of actuals and probs."""
    return metrics.mean_squared_error(y_true=actuals, y_prob=probs)


def mean_absolute_error(actuals, probs):
    """Computes MAE given array of actuals and probs."""
    return metrics.mean_absolute_error(y_true=actuals, y_prob=probs)


def r2_score(actuals, probs):
    """Computes r2 given array of actuals and probs."""
    return metrics.r2_score(y_true=actuals, y_prob=probs)


def confusion_matrix_by_threshold(actuals, probs, threshold):
    """Adds binary 'prediction' column to df: classifications based on
    threshold. Returns the confusion matrix.

    Args:
        actuals: Series (indexed) containing the actuals.
        predictions: Series (indexed) containing the predictions.
        colname_prediction (str): Name of the column containing the predictions.

    Returns:
        confusion_matrix: Numpy array of the confusion matrix.
    """
    prediction = np.where(probs >= threshold, 1, 0)
    confusion_matrix = metrics.confusion_matrix(actuals, prediction)

    return confusion_matrix


def compute_threshold_cost(threshold, actuals, probs, cost_matrix):
    """Computes matrices and costs associated with specified thresholds.

    Args:
        threshold (float): A threshold betwee 0-1.
        actuals: Indexed series of actuals.
        probs: Indexed series of probabilities.
        cost_matrix: A numpy array containing the cost per classification
            category.

    Returns:
        threshold_cost: List containing matrix, threshold, and cost for
            a particular applied threshold.
    """
    cost_tp = cost_matrix[0][0]
    cost_tn = cost_matrix[1][1]
    cost_fp = cost_matrix[0][1]
    cost_fn = cost_matrix[1][0]

    prediction = np.where(probs >= threshold, 1, 0)
    matrix = metrics.confusion_matrix(actuals, prediction)
    tn, fp, fn, tp = matrix.ravel()
    # Punish the scores.
    cost = (tp * cost_tp) + (tn * cost_tn) + (fn * cost_fn) + (fp * cost_fp)
    # Append the information of this threshold to costs.
    threshold_cost = [matrix, threshold, cost]
    return threshold_cost


def compute_optimal_threshold(actuals, probs, cost_matrix, parallel=False, n_steps=1001):
    """Computes the optimal classification threshold for a model given a
    cost matrix. Uses multiprocessing pool (4).

    Args:
        actuals: Series (indexed) containing the actuals.
        probs: Series (indexed) containing the predicted probabilities.
        cost_matrix: A numpy array containing the cost per classification
            category.

    Returns:
        costs: A list containing the confusion matrix, threshold, and cost for
            each threshold looped over. Used for plotting the cost function.
        optimal threshold: The unrounded optimal threshold.
    """
    # Set up an empty dataframe.
    optimal = pd.DataFrame(np.zeros(shape=(1, 6)))
    optimal.columns = ["tp", "tn", "fp", "fn", "cutoff", "cost"]

    # Get costs as defined in cost matrix.
    cost_tp = cost_matrix[0][0]
    cost_tn = cost_matrix[1][1]
    cost_fp = cost_matrix[0][1]
    cost_fn = cost_matrix[1][0]

    # Go over thresholds 1 to 0.
    threshold_list = list((np.linspace(1, 0, n_steps)))

    if parallel:
        with Pool(processes=4) as pool:
            threshold_costs = []
            for threshold in threshold_list:
                threshold_costs.append(pool.apply_async(compute_threshold_cost,
                                                        (threshold, actuals,
                                                         probs, cost_matrix,)))
            costs = [threshold_cost.get() for threshold_cost in threshold_costs]
    else:
        costs = []
        for threshold in threshold_list:
            costs.append(compute_threshold_cost(threshold, actuals, probs, cost_matrix))


    # Find the optimal threshold in costs.
    minimum = min(i[2] for i in costs)
    optimum = [i for i in costs if i[2] == minimum][0]
    optimal_threshold = optimum[1]

    return (costs, optimal_threshold)
