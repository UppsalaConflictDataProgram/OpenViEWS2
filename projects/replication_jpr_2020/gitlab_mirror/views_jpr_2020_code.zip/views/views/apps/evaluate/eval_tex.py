"""Evaluation TeX module

All slightly different tex tables.
@ TODO(Remco): Add visual examples to docstrings.
"""

# pylint: skip-file

from datetime import datetime
import pandas as pd
import numpy as np
import os

from views.apps.data.common import utils
from views.apps.evaluate import eval_lib, eval_data

spec = utils.load_specfile("eval_spec")

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
DIR_TEX = os.path.join(THIS_DIR, "tex_templates")


def return_date():
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")


def write_confusion_matrix(actuals, probs, threshold, filename, to_path):
    """Prints confusion matrix to file (.tex).

    Args:
        actuals: Series (indexed) containing the predictions.
        probs: Series (indexed) containing the predicted probabilities.
        threshold (float): (Optimal) threshold to apply to predicted probabilities.
        filename (str): Filename to write table to.
        to_path (str): Path to write table to.
    """
    # Single-threshold metrics.
    preds = np.where(probs >= threshold, 1, 0)
    accuracy = eval_lib.accuracy(actuals, preds)
    precision = eval_lib.precision(actuals, preds)
    recall = eval_lib.recall(actuals, preds)
    f1_score = eval_lib.f1_score(actuals, preds)

    # Get matrix.
    matrix = eval_lib.confusion_matrix_by_threshold(actuals, probs, threshold)
    tn, fp, fn, tp = matrix.ravel()

    # Open template.
    path_template = os.path.join(DIR_TEX, "confusion_matrix.tex")
    with open(path_template, "r") as f:
        text = f.read()

    filename_tex = filename.replace("_", "\_")
    replaces = {
        "$TITLE": filename_tex,
        "$TP": tp,
        "$FP": fp,
        "$TN": tn,
        "$FN": fn,
        "$SUM_POS_P": tp + fp,
        "$SUM_NEG_P": tn + fn,
        "$SUM_POS_A": tp + fn,
        "$SUM_NEG_A": tn + fp,
        "$TOTAL": tp + fp + tn + fn,
        "$NOTE": f"Evaluation of {filename_tex}",
        "$ACCURACY": accuracy,
        "$PRECISION": precision,
        "$RECALL": recall,
        "$F1": f1_score,
        "$THRESHOLD": threshold,
    }

    for replace in replaces:
        text = text.replace(replace, str(replaces[replace]))

    # Get meta information in.
    meta = f"""
    %Output created by the eval_tex module.
    %Evaluation of {filename_tex}.
    %Produced on {return_date()}, written to {to_path}.
    """
    tex = meta + text

    with open(f"{to_path}{filename}.tex", "w") as f:
        f.write(tex)


def write_eval_table(
    scores, to_path, filename, textsize="footnotesize", confusion=False
):
    """Prints eval table to file (.tex).

    Args:
        scores: A Pandas dataframe containing modelnames, and scores per col:
            ['Model', 'AUROC', 'AUPR', 'Brier score', 'Accuracy', 'F1-score',
            'Cost-based threshold']
        to_path (str): Path to write table to.
        filename (str): File name to write table to.
        textsize (str): Textsize, e.g. "small", "footnotesize", "large".
        confusion (bool): Adds classifications from confusion matrix to table
            if set to True.
    """
    add_confusion = [
        ("Single-threshold metrics", "Accuracy"),
        ("Single-threshold metrics", "F1-score"),
        # ("Single-threshold metrics", "Precision"),
        # ("Single-threshold metrics", "Recall"),
        ("Single-threshold metrics", "Cost-based threshold"),
        ("Single-threshold metrics", "True positive"),
        ("Single-threshold metrics", "False positive"),
        ("Single-threshold metrics", "True negative"),
        ("Single-threshold metrics", "False negative"),
    ]
    if confusion is False:
        scores.drop(columns=[item[1] for item in add_confusion], inplace=True)
        add_confusion = []

    scores_df = scores.copy()  # set up a clean copy
    scores_df.columns = pd.MultiIndex.from_tuples(
        [
            ("", "Model"),
            ("Multi-threshold metrics", "AUPR"),
            ("Multi-threshold metrics", "AUROC"),
            ("Multi-threshold metrics", "Brier score"),
        ]
        + add_confusion
    )

    # Add argument to fix column sizing.
    length = 11 if confusion else 7
    column_format = "lp{.8cm}" + ("p{.8cm}" * length)
    tex = scores_df.to_latex(
        multirow=True, multicolumn=True, column_format=column_format,
        index=False
    )

    # Adding midrules and breaks to column headers.
    if confusion:
        tex = tex.replace(
            "\\\\", "\\\\ \cmidrule(lr){2-4}\cmidrule(lr){5-11}", 1
        )
    else:
        tex = tex.replace(
            "\\\\", "\\\\ \cmidrule(lr){2-4}\cmidrule(lr){5-7}", 1
        )
    tex = tex.replace("Cost-based", "Cost-based \\newline", 1)
    tex = tex.replace("True", "True \\newline")
    tex = tex.replace("False", "False \\newline")

    # get meta information in
    meta = f"""
    %Output created by the eval_tex module.
    %Evaluation of {filename}.
    %Produced on {return_date()}, written to {to_path}.
    \\{textsize}
    """
    tex = meta + tex

    with open(f"{to_path}{filename}.tex", "w") as f:
        f.write(tex)

    print(f"Wrote {filename}.tex to {to_path}.")


def write_confusion_table(df, country_df, outcome, threshold):
    """Turns confusion matrix into table of the underlying cases.
    Returns dataframe.
    """
    df.reset_index(inplace=True)
    df = df.merge(country_df, left_on="country_id", right_on="id")
    df["prediction"] = np.where(df["predicted"] >= threshold, 1, 0)  # !
    ctn = (df.prediction == 0) & (df.actual == 0)
    cfp = (df.prediction == 1) & (df.actual == 0)
    cfn = (df.prediction == 0) & (df.actual == 1)
    ctp = (df.prediction == 1) & (df.actual == 1)
    df["label"] = np.select([ctn, cfp, cfn, ctp], ["TN", "FP", "FN", "TP"])
    df.drop(columns=["month_id"], inplace=True)
    df = df[
        ["name", "country_id", "predicted", "actual", "prediction", "label"]
    ]
    df.columns = [
        "name",
        "country_id",
        f"{outcome}_pr",
        f"{outcome}_observed",
        f"{outcome}_prediction",
        f"{outcome}_label",
    ]
    return df


def write_step_comparison(
    df, to_path, filename, steps=[1, 36], add_metric=None, textsize="footnotesize"
):
    """Prints two-step comparison eval table to file (.tex).

    Args:
        df: A Pandas dataframe containing modelnames, and ordered scores per
            column, e.g.:
            ['Model', 'sb_s1', 'ns_s1', 'os_s1', 'sb_s36', 'ns_s36', 'os_s36']
        to_path (str): Path to write table to.
        filename (str): File name to write table to.
        steps (list): Steps to compare. Needed for column headers.
        textsize (str): Textsize, e.g. "small", "footnotesize", "large".
    """

    column_tuples = []
    for step in steps:
        for outcome in ["sb", "ns", "os"]:
            column_tuples.append((f"AUPR at step={step}", f"{outcome}"))

    if add_metric is not None:
        for step in steps:
            for outcome in ["sb", "ns", "os"]:
                additional_metric = f"{add_metric} at step={step}", f"{outcome}"
                column_tuples.append((additional_metric))

    df.columns = pd.MultiIndex.from_tuples([("", "Model")] + column_tuples)

    column_format = "lp{.8cm}" + ("p{.8cm}" * (len(column_tuples) + 1))
    tex = df.to_latex(
        multirow=True,
        multicolumn=True,
        column_format=column_format,
        index=False
    )

    # Little hack for the midrule.
    if add_metric is not None:
        steps = steps * 2
    mrl = 2
    mrr = 4
    midrule = ""
    for step in steps:
        midrule += f"\cmidrule(lr){{{mrl}-{mrr}}}"
        mrl = mrl + 3
        mrr = mrr + 3

    tex = tex.replace("\\\\", "\\\\ " + midrule, 1)

    # get meta information in
    meta = f"""
    %{filename} at steps {steps}.
    %Output created by eval_tex module.
    %Produced on {return_date()}, written to {to_path}.
    \\{textsize}
    """
    tex = meta + tex

    with open(f"{to_path}{filename}.tex", "w") as f:
        f.write(tex)

    print(f"Wrote {filename}.tex to {to_path}.")


def write_outcome_step_comparison(
    df,
    to_path,
    filename,
    steps=[1, 36],
    textsize="footnotesize",
    add_mal=False,
    add_midrules=False
):
    """Prints two-step comparison eval table BY OUTCOME to file (.tex).

    Args:
        df: A Pandas dataframe containing modelnames, and ordered scores per
            column, e.g.:
            ['Model', 'sb_s1', 'ns_s1', 'os_s1', 'sb_s36', 'ns_s36', 'os_s36']
        to_path (str): Path to write table to.
        filename (str): File name to write table to.
        steps (list): Steps to compare. Needed for column headers.
        textsize (str): Textsize, e.g. "small", "footnotesize", "large".
    """
    df = df.copy()

    mal_score = ["MAL"] if add_mal else []
    metrics = ["AUROC", "AUPR", "Brier"] + mal_score
    column_tuples = []

    for step in steps:
        for metric in metrics:
            column_tuples.append(
                (f"Scores at step={step}", f"{metric}")
            )

    df.columns = pd.MultiIndex.from_tuples([("", "Model")] + column_tuples)

    column_format = "lp{.8cm}" + ("p{.8cm}" * (len(column_tuples) + 1))
    tex = df.to_latex(
        multirow=True,
        multicolumn=True,
        column_format=column_format,
        index=False
    )

    # Get meta information in.
    meta = f"""
    %{filename} at steps {steps}.
    %Output created by the eval_tex module.
    %Produced on {return_date()}, written to {to_path}.
    \\{textsize}
    """
    tex = meta + tex

    with open(f"{to_path}{filename}.tex", "w") as f:
        f.write(tex)

    print(f"Wrote {filename}.tex to {to_path}.")


def write_ebma_comparison(df, to_path, secondary):
    """ Writes EBMA table comparison to file. """
    replace_cols = ["Model", "Step", "EBMA AUPR",
    "Unweighted AUPR", "EBMA AUROC", "Unweighted AUROC",
    "EBMA Brier", "Unweighted Brier"]
    if secondary is not None:
        if secondary=="brier":
            replace_cols = [col for col in replace_cols if "AUROC" not in col]
        if secondary=="auroc":
            replace_cols = [col for col in replace_cols if "Brier" not in col]

    df.columns = replace_cols
    tex = df.to_latex(index=False)

    # get meta information in
    meta = f"""
    %Output created by the eval_tex module.
    %Comparison of evaluation metrics, EBMA and average.
    %Produced on {return_date()}, written to {to_path}.
    \\
    """
    tex = meta + tex

    with open(to_path, "w") as f:
        f.write(tex)

    print(f"Wrote table to {to_path}.")


def write_ensemble_comparison(df, to_path, secondary):
    """ Writes ensemble table comparison to file. """
    replace_cols = ["Model", "New ensemble AUPR",
    "Old ensemble AUPR", "New ensemble AUROC",
    "Old ensemble AUROC", "New ensemble Brier",
    "Old ensemble Brier"]

    if secondary is not None:
        if secondary=="brier":
            replace_cols = [col for col in replace_cols if "AUROC" not in col]
        if secondary=="auroc":
            replace_cols = [col for col in replace_cols if "Brier" not in col]

    df.columns = replace_cols
    tex = df.to_latex(index=False)

    # get meta information in
    meta = f"""
    %Output created by the eval_tex module.
    %Comparison of evaluation metrics, old (2019) and new ensemble.
    %Produced on {return_date()}, written to {to_path}.
    \\
    """
    tex = meta + tex

    with open(to_path, "w") as f:
        f.write(tex)

    print(f"Wrote table to {to_path}.")


def write_onset_comparison(df, to_path, secondary):
    """ Writes onset comparison comparison to file. """
    replace_cols = ["Model", "Outcome", "Step", "Incidence AUPR",
    "Onset AUPR", "Incidence AUROC", "Onset AUROC",
    "Incidence Brier", "Onset Brier"]
    if secondary is not None:
        if secondary=="brier":
            replace_cols = [col for col in replace_cols if "AUROC" not in col]
        if secondary=="auroc":
            replace_cols = [col for col in replace_cols if "Brier" not in col]

    df.columns = replace_cols
    tex = df.to_latex(index=False)

    # get meta information in
    meta = f"""
    %Output created by the eval_tex module.
    %Comparison of evaluation metrics, incidence and onset.
    %Produced on {return_date()}, written to {to_path}.
    \\
    """
    tex = meta + tex

    with open(to_path, "w") as f:
        f.write(tex)

    print(f"Wrote table to {to_path}.")


def write_eval_mal_table(
    scores, to_path, filename, textsize="footnotesize", add_midrules=False
):
    scores_df = scores.copy()  # set up a clean copy
    scores_df.columns = pd.MultiIndex.from_tuples(
        [
            ("", "", "Models"),
            ("sb", "s=1", "AUPR"),
            ("sb", "s=1", "MAL"),
            ("sb", "s=36", "AUPR"),
            ("sb", "s=36", "MAL"),
            ("ns", "s=1", "AUPR"),
            ("ns", "s=1", "MAL"),
            ("ns", "s=36", "AUPR"),
            ("ns", "s=36", "MAL"),
            ("os", "s=1", "AUPR"),
            ("os", "s=1", "MAL"),
            ("os", "s=36", "AUPR"),
            ("os", "s=36", "MAL"),
        ],
    )

    #column_format = "lp{.8cm}" + ("p{.8cm}" * (len(scores_df.columns) + 1))
    tex = scores_df.to_latex(
        multirow=True,
        multicolumn=True,
        index=False,
        #column_format=column_format
    )

    if add_midrules:
        tex = tex.replace(
                "\\\\",
                "\\\\ \cmidrule(lr){2-5}\cmidrule(lr){6-9}\cmidrule(lr){10-13}",
                1
            )
        # Repeat second midrule for six columns.
        mrl = 2
        mrr = 3
        midrule = ""
        for step in range(1, 7):
            midrule += f"\cmidrule(lr){{{mrl}-{mrr}}}"
            mrl = mrl + 2
            mrr = mrr + 2

        tex = tex.replace(
                "\\\\",
                "\\\\" + midrule,
                2
            )

    # get meta information in
    meta = f"""
    %Output created by the eval_tex module.
    %Evaluation of {filename}.
    %Produced on {return_date()}, written to {to_path}.
    \\{textsize}
    """
    tex = meta + tex

    with open(f"{to_path}{filename}.tex", "w") as f:
        f.write(tex)

    print(f"Wrote {filename}.tex to {to_path}.")
