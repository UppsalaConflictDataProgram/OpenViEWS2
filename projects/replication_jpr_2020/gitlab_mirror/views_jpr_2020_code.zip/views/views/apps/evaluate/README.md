# eval_data
Evaluation data utilities.
Contains functions that fetch or otherwise apply transformations to data
for various evaluation tasks.

## compute_proportions
```python
compute_proportions(df, var, groupvar)
```
Computes predicted proportions of gid cells for provided variable.
Grouped on month_id and provided groupvar.

Args:
    df: Indexed (month_id, pg_id) pandas dataframe containing variable to
        get grouped proportions of.
    var (str): Column name of feature to compute proportions for.
    groupvar (str): Column name of the group to compute proportions by.

Returns:
    df_grouped: Grouped df with "prop" column for the result.

## compute_sums
```python
compute_sums(df, var, groupvar)
```
Computes predicted sums of gid cells for provided variable.
Grouped on month_id and provided groupvar.

Args:
    df: Indexed (month_id, pg_id) pandas dataframe containing variable to
        get grouped proportions of.
    var (str): Column name of feature to compute proportions for.
    groupvar (str): Column name of the group to compute proportions by.

Returns:
    df_grouped: Grouped df with "prop" column for the result.

## fetch_month
```python
fetch_month()
```
Fetches month table from db.
## fetch_country
```python
fetch_country()
```
Fetches country table from db. Renames "id" to "country_id.
## get_month_str
```python
get_month_str(month_id)
```
Gets month-string (yyyy-mm) given specified month_id.
## get_country_name
```python
get_country_name(country_id)
```
Gets country name given a specified country_id.
## fetch_actuals
```python
fetch_actuals(fqtable, groupvar, outcome, select_month=None)
```
Fetches actuals from db.

Args:
    fqtable (str): Full schema and table path.
    groupvar (str): "country_id" or "pg_id".
    outcome (str OR list): Outcome abbreviation, e.g. "sb", or ["sb", "ns"].
    select_month (int, optional): Optional month_id to subset on.

Returns:
    actuals: Pandas dataframe of actuals indexed on timevar, groupvar.

## fetch_predictions
```python
fetch_predictions(schema, table, colname_prediction, level)
```
Returns selected model predictions.

Args:
    schema (str): Name of schema.
    table (str): Name of table. No period necessary.
    colname_prediction (str): Name of column containing the predictions.
    level (str): Either "cm" or "pgm".

Returns:
    predictions: Pandas dataframe of predictions indexed on timevar,
        groupvar.

## fetch_previous_predictions
```python
fetch_previous_predictions(level, outcome, aligned=False, eval_test=False)
```
Fetches previous ensemble results from db (aligned/non-aligned).

The aligned table aligns all predictions by "month ahead", with
month_id == 1 as the nowcast. Non-aligned is indexed by month-id.

Args:
    level (str): Either "cm" or "pgm".
    outcome (str): Outcome abbreviation, e.g. "sb".
    aligned (bool): Defaults to false.
    eval_test (bool): Gets eval partition if true. Defaults to false.

Returns:
    df: Pandas dataframe of table from prev_runs schema.

## fetch_ensemble_predictions
```python
fetch_ensemble_predictions(run_id, level, outcome, eval_test=False)
```
Fetches predictions from previous runs, based on selected ensemble
run and model.

Args:
    run_id (str): Identifier for the run as used in the database. Example:
        "r_2019_10_01". Ensemble column names specified in eval_spec.yaml.
    level (str): Either "cm" or "pgm".
    outcome (str): Outcome abbreviation, e.g. "sb".
    eval_test (bool): Gets eval partition if true. Defaults to false.

Returns:
    predictions: Pandas dataframe of selected predictions.

## return_step_predictions
```python
return_step_predictions(previous_predictions, level, outcome, step)
```
Returns step-ahead predictions from aligned previous predictions.

Return is indexed on groupvar only since month_id is not the actual
month_id, but the steps ahead.

Args:
    previous_predictions: Pandas dataframe of *aligned* previous
        predictions.
    level (str): Either "cm" or "pgm".
    outcome (str): Outcome abbreviation, e.g. "sb".
    step (int): Assumes nowcast at -1, current run-month at 0.

Returns:
    step_predictions: Pandas dataframe of predictions at specified step,
        for all selected ensembles since 2018-07, specified in
        eval_spec.yaml.

## return_step_actuals
```python
return_step_actuals(actuals, base, step)
```
Returns the k step ahead actuals, given a run's month (base).

Args:
    actuals: Pandas dataframe of actuals (non-indexed).
    base (int): Month_id of the run looped over.
    step(int): Assumes nowcast at -1, current run-month at 0.

Returns:
    step_actuals: Pandas dataframe of actuals at specified step,
        given a specific month of a run.

# eval_lib

Evaluation library.
Contains functions that return metrics and confusion matrices.

## average_precision
```python
average_precision(actuals, probs)
```
Computes AUPR given array of actuals and probs.
## area_under_roc
```python
area_under_roc(actuals, probs)
```
Computes AUROC given array of actuals and probs.
## brier
```python
brier(actuals, probs)
```
Computes brier score given array of actuals and probs.
## accuracy
```python
accuracy(confusion_matrix)
```
Computes accuracy from confusion matrix.
## precision
```python
precision(confusion_matrix)
```
Computes precision from confusion matrix.
## recall
```python
recall(confusion_matrix)
```
Computes recall from confusion matrix.
## f1_score
```python
f1_score(precision, recall)
```
Computes F1-score given precision and recall.
## mean_squared_error
```python
mean_squared_error(actuals, probs)
```
Computes MSE given array of actuals and probs.
## mean_absolute_error
```python
mean_absolute_error(actuals, probs)
```
Computes MAE given array of actuals and probs.
## r2_score
```python
r2_score(actuals, probs)
```
Computes r2 given array of actuals and probs.
## confusion_matrix_by_threshold
```python
confusion_matrix_by_threshold(actuals, predictions, threshold)
```
Adds binary 'prediction' column to df: classifications based on
threshold. Returns the confusion matrix.

Args:
    actuals: Series (indexed) containing the actuals.
    predictions: Series (indexed) containing the predictions.
    colname_prediction (str): Name of the column containing the predictions.

Returns:
    confusion_matrix: Numpy array of the confusion matrix.

## compute_optimal_threshold
```python
compute_optimal_threshold(actuals, predictions, cost_matrix)
```
Computes the optimal classification threshold for a model given a
cost matrix.

Args:
    actuals: Series (indexed) containing the actuals.
    predictions: Series (indexed) containing the predictions.
    cost_matrix: A numpy array containing the cost per classification
        category.

Returns:
    costs: A list containing the confusion matrix, threshold, and cost for
        each threshold looped over. Used for plotting the cost function.
    optimal threshold: The unrounded optimal threshold.

# eval_plot

Evaluation plotting module.

This module includes all plotting utilities used in various evaluation
procedures.

## SqueezedNorm
```python
SqueezedNorm(self, vmin=None, vmax=None, mid=0, s1=2, s2=2, clip=False)
```
Used to tweak color normalization in non-linear fashion.

## make_ticks
```python
make_ticks(variable_scale)
```
Returns ticks and tick labels depending on variable_scale provided.

Args:
    variable_scale (str): Either "logodds", "prob", or "interval".

Returns:
    ticks: Dictionary holding tick values (ticks["values"]) and
        tick labels (ticks["labels"]).

## shifted_colormap
```python
shifted_colormap(cmap, start=0, midpoint=0.5, stop=1.0, name='shiftedcmap')
```

Credit: `https`://gist.github.com/phobson/7916777

Offsets the "center" of a colormap.
Useful for data with a negative min and positive max and you want the
middle of the colormap's dynamic range to be at zero

Args:
    cmap: The matplotlib colormap to be altered
    start: Offset from lowest point in the colormap's range.
        Defaults to 0.0 (no lower offet). Should be between
        0.0 and 1.0.
    midpoint: The new center of the colormap. Defaults to
        0.5 (no shift). Should be between 0.0 and 1.0. In
        general, this should be  1 - vmax/(vmax + abs(vmin))
        For example if your data range from -15.0 to +5.0 and
        you want the center of the colormap at 0.0, "midpoint"
        should be set to 1 - 5/(5 + 15)) or 0.75
    stop: Offset from highest point in the colormap's range.
        Defaults to 1.0 (no upper ofset). Should be between
        0.0 and 1.0.

Returns:
    newcmap: Shifted colormap object.


## get_cmap
```python
get_cmap(variable_scale=None)
```
Gets matplotlib colormap and shifts according to variable_scale.

Args:
    variable_scale (str): Optional. Either "prob" or "logodds". Won't apply
        shift transformation if not set.

Returns:
    cmap: Shifted colormap object.

## plot_separation
```python
plot_separation(actuals, predictions, to_path=None)
```
Creates a separation plot for logistic and probit classification.
See http://mdwardlab.com/sites/default/files/GreenhillWardSacks.pdf

Args:
    df: Pandas dataframe containing predictions and actuals.
    colname_actual (str): Column name for the actuals.
    colname_probs (str): Column name for the probabilties.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves separation plot to path in .png.

## plot_aupr
```python
plot_aupr(actuals, predictions, to_path=None)
```
Plots AUPR for a given actuals and predictions series.

Args:
    actuals: Series (indexed) of actuals.
    predictions: Series (indexed) of predictions.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves AUPR plot to path in .png.

## plot_auroc
```python
plot_auroc(actuals, predictions, to_path=None)
```
Plots AUROC for a given actuals and predictions series.

Args:
    actuals: Series (indexed) of actuals.
    predictions: Series (indexed) of predictions.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves AUPR plot to path in .png.

## plot_costfunction
```python
plot_costfunction(costs, optimal_threshold, colname_prediction=None, to_path=None)
```
Plots cost function.

Args:
    costs: Costs returned by compute_optimal_threshold (eval_data).
    optimal_threshold (float): Optimal threshold returned by the same function.
    colname_prediction (str): Prediction column name to give to filename.
    to_path (str): Optional. Write to path if set.

## plot_step_average
```python
plot_step_average(scores, metric, ma=None, to_path=None)
```
Plots average AUC of selected runs, over k steps.

Args:
    scores: Pandas dataframe of the scores produced by return_k_auc().
    metric (str): Selected metric as string, either "aupr" or "auroc".
    ma (int): Optional. Plots moving average instead of actual.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

## plot_step_auc
```python
plot_step_auc(scores, metric, ma=None, step=None, to_path=None)
```
Plots AUC of selected runs, at selected k.

Args:
    scores: Pandas dataframe of the scores produced by return_k_auc().
    metric (str): Selected metric as string, either "aupr" or "auroc".
    ma (int): Optional. Plots moving average at provided integer number instead of
        actual.
    step (int): Optional. Used for the title text. Set to zero by default.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

## plot_heatmap
```python
plot_heatmap(df, colname_feature, level, variable_scale, to_path=None)
```
Pivots data and plots heatmap.

Args:
    df: Pandas dataframe with country already merged in.
    colname_feature (str): Column name of feature to use in plot.
    level (str): Currently either "cm" or "pgm".
    variable_scale (str): Scale for colorbar; "logodds" or "prob".
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

## plot_cm_line
```python
plot_cm_line(predictions, actuals, colname_feature, colname_actual, country_id, history=0, step=1, to_path=None)
```
Plots line for specified outcome and country_id.

Actuals are separately plotted to allow for an extended time series
of the history of a particular country.

Args:
    predictions: Pandas dataframe of indexed predictions.
    actuals: Pandas dataframe of indexed actuals.
    colname_feature (str): Column name of feature to plot.
    colname_actual (str): Column name of actual to plot.
    country_id (int): Identifier of the country selected.
    history (int): Optional. Add months backward of actuals you want to add
        to the plot.
    step (int): Step of the predictions. Used in title.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

## plot_pgm_line
```python
plot_pgm_line(predictions, actuals, outcome, country_id, history=0, step=1, to_path=None)
```
Plots line for specified proportion and country_id.

Actuals are separately plotted to allow for an extended time series
of the history of a particular country.

Args:
    predictions: Pandas dataframe of indexed predictions.
    actuals: Pandas dataframe of indexed actuals.
    outcome (str): Full outcome name, e.g. "ged_dummy_sb".
    country_id (int): Identifier of the country selected.
    history (int): Optional. Add months backward of actuals you want to add to
        the plot.
    step (int): Step of the predictions. Used in title.
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

## prepare_pg_country
```python
prepare_pg_country(df, month_id, country_id, colname_feature, variable_scale)
```
Prepares geopandas dataframe for plot_pg_country.

## plot_pg_country
```python
plot_pg_country(df, month_id, country_id, colname_feature, colname_actual=None, variable_scale='logodds', to_path=None)
```
Plots minimap of country's pgm predictions along with actuals.

Note: pandas dataframe should to be indexed on pg_id.

Args:
    df: Pandas dataframe of predictions.
    month_id (int): Identifier for prediction month to plot.
    country_id (int): Identifier for country to plot.
    colname_feature (str): Column name of feature to use in the plot.
    colname_actual (str): Full column name of actual, e.g. "ged_dummy_sb".
    variable_scale (str): Scale to plot values at. Affect colormaps.
        Default at "logodds".
    to_path (str): Optional. Write to path if set.

Returns:
    Saves figure to set path in .png.

# eval_tex
Evaluation TeX module

## write_confusion_matrix
```python
write_confusion_matrix(confusion_matrix, model, vtype, level, start, end, threshold, to_path)
```
LaTeX ugliness: Prints confusion matrix to file (.tex).

Args:
    confusion_matrix: np.array confusion matrix.
    model (str): Name of the model.
    vtype (str): The outcome (e.g. "sb").
    level (str): The level of the outcome (e.g. "cm").
    start (int/str): The start (month_id or month_str) of the eval period.
    end (int/str): The end (month_id or month_str) of the eval period.
    threshold (float): The (optimal) classification threshold used.
    to_path (str): Path to write table to.

## write_eval_table
```python
write_eval_table(scores, run_id, performance_month, to_path)
```
Prints eval table to file (.tex).

Args:
    scores: A Pandas dataframe containing modelnames, and scores per col:
        ['Model', 'AUROC', 'AUPR', 'Brier score', 'Accuracy', 'F1-score',
        'Cost-based threshold']
    run_id (str): run_id to use in filename.
    performance_month (str): Month of performance to use in title and
        meta.
    to_path (str): Path to write table to.

## write_confusion_table
```python
write_confusion_table(df, country_df, outcome, threshold)
```
Turns confusion matrix into table of the underlying cases.
Returns dataframe.

# evaluation
Evaluation Module
## eval_binary
```python
eval_binary(df, colname_actual, colname_prediction)
```
Evaluate binary probability predictions
## eval_step
```python
eval_step(previous, actuals, step, level, outcome, colname_prediction)
```
Fetches k predictions and actuals at cm/pgm for selected run columns,
and computes performance metrics.

Args:
    previous: Pandas df of *aligned* predictions from prev_runs schema.
    actuals: Pandas df of actuals *unindexed*.
    step (int): Step to use. Note: nowcast +1 is currently set to step=0!
    level (str): Level of analysis at "cm" or "pgm".
    outcome (str): Selected outcome (e.g. "sb").
    colname_prediction (str): Column name to be used for the
        step-prediction.

Returns:
    A tuple, containing [0] a pandas dataframe of performance metrics per k,
    and [1] a pandas dataframe with the outcome predicted probabilities at
    k=1 per pg_id-month.

Raises:
    IndexError: Selected outcome is not in the correct string format.

## eval_retrospective
```python
eval_retrospective(previous, actuals, level, outcome, colname_prediction, select_month)
```
Returns AUC of runs for a selected month_id, over all runs up until
that month_id.

Args:
    previous: Pandas df of *non-aligned* predictions from prev_runs schema.
    actuals: Pandas df of actuals.
    level (str): Level of analysis at "cm" or "pgm".
    outcome (str): Selected outcome (e.g. "sb").
    select_month (int): Selected month to get retrospective performance
        scores for.

Returns:
    A pandas dataframe of performance metrics per month of run.

## prepare_metrics
```python
prepare_metrics(actuals, predictions, model, cost_matrix)
```
Returns general and threshold-specific performance metrics in
evaluation table row dict.

Args:
    actuals: Series (indexed) containing the predictions.
    predictions: Series (indexed) containing the predictions.
    model (str): Model name.
    cost_matrix: Numpy array of cost matrix to use.

Returns:
    row_dict: A dictionary containing the scores for entry into a table
        row.

