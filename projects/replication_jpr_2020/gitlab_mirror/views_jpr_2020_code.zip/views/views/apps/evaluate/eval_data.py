"""Evaluation data utilities.
Contains functions that fetch or otherwise apply transformations to data
for various evaluation tasks.
"""

# TODO(Remco): fetch_previous_predictions assumes ensemble.
# TODO(Remco): return_step_actuals might be redundant.

import numpy as np
import pandas as pd

from views.utils import dbutils
from views.apps.data.common import utils
from views.apps.evaluate import evaluation


def compute_proportions(df, var, groupvar):
    """Computes predicted proportions of gid cells for provided variable.
    Grouped on month_id and provided groupvar.

    Args:
        df: Indexed (month_id, pg_id) pandas dataframe containing variable to
            get grouped proportions of.
        var (str): Column name of feature to compute proportions for.
        groupvar (str): Column name of the group to compute proportions by.

    Returns:
        df_grouped: Grouped df with "prop" column for the result.
    """
    df.reset_index(inplace=True)
    df_grouped = df.groupby(["month_id", groupvar])[[var]].mean()
    df_grouped.reset_index(inplace=True)
    df_grouped["prop"] = df_grouped[var]
    df_grouped.drop(columns=[var], inplace=True)

    return df_grouped


def compute_sums(df, var, groupvar):
    """Computes predicted sums of gid cells for provided variable.
    Grouped on month_id and provided groupvar.

    Args:
        df: Indexed (month_id, pg_id) pandas dataframe containing variable to
            get grouped proportions of.
        var (str): Column name of feature to compute proportions for.
        groupvar (str): Column name of the group to compute proportions by.

    Returns:
        df_grouped: Grouped df with "prop" column for the result.
    """
    df.reset_index(inplace=True)
    df_grouped = df.groupby(["month_id", groupvar])[[var]].sum()
    df_grouped.reset_index(inplace=True)
    df_grouped["sums"] = df_grouped[var]
    df_grouped.drop(columns=[var], inplace=True)

    return df_grouped


def fetch_month():
    """Fetches month table from db."""
    month = dbutils.db_to_df(
        fqtable="staging.month", columns=["id", "month", "year_id"]
    )
    month["month"] = month["month"].astype(str)
    month["month"] = month["month"].str.zfill(2)
    month["year_id"] = month["year_id"].astype(str)
    month["month_str"] = month["year_id"] + "-" + month["month"]
    month.rename(columns={"id": "month_id"}, inplace=True)
    return month


def fetch_country():
    """Fetches country table from db. Renames "id" to "country_id."""
    country = dbutils.db_to_df(
        fqtable="staging.country", columns=["id", "name", "gweyear",
        "isoab"]
    )
    country = country[country.gweyear == 2016]
    country = country[["id", "name", "isoab"]]
    country.rename(columns={"id": "country_id"}, inplace=True)
    return country


def fetch_priogrid(bounds=None):
    """Fetches country table from db. Renames "id" to "country_id.
    Args:
        bounds: A list defining the box, e.g. [-5.32,11.47,2.21,17.21]
            which is llong, blat, rlong, tlat.
            See https://boundingbox.klokantech.com/
    """
    query = """
    SELECT cpg.pg_id, pg.latitude, pg.longitude, c.id as country_id
    FROM staging.priogrid AS pg, staging_test.cpgm AS cpg, staging.country AS c
    WHERE cpg.pg_id=pg.gid
    AND cpg.month_id=480
    AND cpg.country_id=c.id
    """
    df = dbutils.query_to_df(query)
    if bounds is not None:
        df = df[(df.latitude>=bounds[1]) &
                 (df.latitude<=bounds[3]) &
                 (df.longitude>=bounds[0]) &
                 (df.longitude<=bounds[2])]
    return df


def get_month_str(month_id):
    """Gets month-string (yyyy-mm) given specified month_id."""
    month = fetch_month()
    month_str = month.loc[month.month_id == month_id, "month_str"].item()
    return month_str


def get_country_name(country_id):
    """Gets country name given a specified country_id."""
    country = fetch_country()
    country_name = country.loc[country.country_id == country_id, "name"].item()
    return country_name


def add_iso_date(df):
    """Adds iso_date column for a cm-level df"""
    country = fetch_country()
    month = fetch_month()
    df.reset_index(inplace=True)
    df = df.merge(month, on="month_id")
    df = df.merge(country, on="country_id")
    df['iso_date'] = df['isoab'] + " " + df['month_str']
    return df


def fetch_actuals(fqtable, groupvar, outcome, select_month=None):
    """Fetches actuals from db.

    Args:
        fqtable (str): Full schema and table path.
        groupvar (str): "country_id" or "pg_id".
        outcome (str OR list): Outcome abbreviation, e.g. "sb", or ["sb", "ns"].
        select_month (int, optional): Optional month_id to subset on.

    Returns:
        actuals: Pandas dataframe of actuals indexed on timevar, groupvar.
    """
    timevar = "month_id"
    ids = [timevar, groupvar]

    if isinstance(outcome, list):
        outcome = [f"ged_dummy_{out}" for out in outcome]
    else:
        outcome = [f"ged_dummy_{outcome}"]

    actuals = dbutils.db_to_df(fqtable=fqtable, columns=ids + outcome)

    if select_month is not None:
        actuals = actuals[actuals.month_id == select_month]

    actuals.set_index([timevar, groupvar], inplace=True)

    return actuals


def fetch_predictions(schema, table, colname_prediction, level):
    """Returns selected model predictions.

    Args:
        schema (str): Name of schema.
        table (str): Name of table. No period necessary.
        colname_prediction (str): Name of column containing the predictions.
        level (str): Either "cm" or "pgm".

    Returns:
        predictions: Pandas dataframe of predictions indexed on timevar,
            groupvar.
    """
    groupvar = "country_id" if level == "cm" else "pg_id"
    ids = ["month_id", groupvar]
    predictions = dbutils.db_to_df(
        fqtable=f"{schema}.{table}", columns=ids + [colname_prediction]
    )

    predictions.set_index(ids, inplace=True)

    return predictions


def fetch_previous_predictions(level, outcome, aligned=False, eval_test=False):
    """Fetches previous ensemble results from db (aligned/non-aligned).

    The aligned table aligns all predictions by "month ahead", with
    month_id == 1 as the nowcast. Non-aligned is indexed by month-id.

    Args:
        level (str): Either "cm" or "pgm".
        outcome (str): Outcome abbreviation, e.g. "sb".
        aligned (bool): Defaults to false.
        eval_test (bool): Gets eval partition if true. Defaults to false.

    Returns:
        df: Pandas dataframe of table from prev_runs schema.
    """
    spec = utils.load_specfile("eval_spec")

    # Set up parameters.
    timevar = "month_id"
    groupvar = "country_id" if level == "cm" else "pg_id"
    ids = [timevar, groupvar]

    align = "aligned" if aligned is True else "all"
    partition = "eval" if eval_test else "fcast"
    fqtable = f"prev_runs.{align}_ensemble_{level}_{partition}_test"

    # Retrieve column names of previous ensemble runs.
    if level == "cm":
        items = spec["cols_cm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]
    else:
        items = spec["cols_pgm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]

    # Getting data.
    df = dbutils.db_to_df(fqtable, columns=ids + cols)

    return df


def fetch_ensemble_predictions(run_id, level, outcome, eval_test=False):
    """Fetches predictions from previous runs, based on selected ensemble
    run and model.

    Args:
        run_id (str): Identifier for the run as used in the database. Example:
            "r_2019_10_01". Ensemble column names specified in eval_spec.yaml.
        level (str): Either "cm" or "pgm".
        outcome (str): Outcome abbreviation, e.g. "sb".
        eval_test (bool): Gets eval partition if true. Defaults to false.

    Returns:
        predictions: Pandas dataframe of selected predictions.
    """
    spec = utils.load_specfile("eval_spec")

    # Set up parameters.
    timevar = "month_id"
    groupvar = "country_id" if level == "cm" else "pg_id"
    ids = [timevar, groupvar]

    partition = "eval" if eval_test else "fcast"
    fqtable = f"prev_runs.{run_id}_ensemble_{level}_{partition}_test"

    # Retrieve column name of previous ensemble runs.
    if level == "cm":
        model = spec["ensemble_cm"].format(run_id=run_id, outcome=outcome)
    else:
        model = spec["ensemble_pgm"].format(run_id=run_id, outcome=outcome)

    predictions = dbutils.db_to_df(fqtable=fqtable, ids=ids, columns=[model])

    # if eval_test:
    #     predictions.reset_index(inplace=True)  # unnecessary reset...
    #     eval_end = spec["eval_window"][run_id]
    #     predictions = predictions[
    #         (predictions.month_id >= (eval_end - 23))
    #         and (predictions.month_id <= eval_end)
    #     ]
    #     predictions.set_index(["month_id", groupvar], inplace=True)

    return predictions


def return_step_predictions(previous_predictions, level, outcome, step):
    """Returns step-ahead predictions from aligned previous predictions.

    Return is indexed on groupvar only since month_id is not the actual
    month_id, but the steps ahead.

    Args:
        previous_predictions: Pandas dataframe of *aligned* previous
            predictions.
        level (str): Either "cm" or "pgm".
        outcome (str): Outcome abbreviation, e.g. "sb".
        step (int): Assumes nowcast at -1, current run-month at 0.

    Returns:
        step_predictions: Pandas dataframe of predictions at specified step,
            for all selected ensembles since 2018-07, specified in
            eval_spec.yaml.
    """
    groupvar = "country_id" if level == "cm" else "pg_id"
    df = previous_predictions

    spec = utils.load_specfile("eval_spec")
    # Retrieve column names of previous ensemble runs.
    if level == "cm":
        items = spec["cols_cm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]
    else:
        items = spec["cols_pgm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]

    # Correcting k first (month_id of 2 in table == base)
    k_adjusted = step + 2
    step_predictions = df.loc[df.month_id == k_adjusted]
    step_predictions = step_predictions[[groupvar] + cols]
    step_predictions.set_index(groupvar, inplace=True)

    return step_predictions


def return_step_actuals(actuals, base, step):
    """Returns the k step ahead actuals, given a run's month (base).

    Args:
        actuals: Pandas dataframe of actuals (non-indexed).
        base (int): Month_id of the run looped over.
        step(int): Assumes nowcast at -1, current run-month at 0.

    Returns:
        step_actuals: Pandas dataframe of actuals at specified step,
            given a specific month of a run.
    """
    month = base + step
    step_actuals = actuals.loc[actuals.month_id == month]

    return step_actuals


def collect_scores(
    models, df_pred, df_actual, prediction_key, confusion=False, step=False
):
    """Collect df of evaluation metrics.
    Will be deprecated when notebook infrastructure changes.

    Args:
        models: List of dictionaries with column name info.
        df_pred: Dataframe containing predictions.
        df_actual: Dataframe containing actuals.
        prediction_key: Key in models list member dicts to
            lookup colnames of predictions in.
        confusion: Boolean for whether to compute confusion scores.
        step: Boolean for whether to select ss or sc.

    Returns: df_scores.
    """
    costs = np.array([[0.0, 1.0], [10.0, 0.0]])
    scorecols = [
        "Model",
        "Step",
        "AUROC",
        "AUPR",
        "Brier score"
    ]
    scores = []
    for model in models:
        if step:
            for step in model["steps"]:
                rd = evaluation.prepare_metrics(
                    actuals=df_actual[model["col_actual"]],
                    probs=df_pred[model[prediction_key][step]],
                    model=f"{model['name']}_{step}",
                    cost_matrix=costs,
                    confusion=confusion,
                )
                rd["Step"] = step
                #rd["Outcome"] = model["col_actual"]
                scores.append(rd)
        else:
            scorecols = [
                "Model",
                "AUROC",
                "AUPR",
                "Brier score"
            ]
            rd = evaluation.prepare_metrics(
                actuals=df_actual[model["col_actual"]],
                probs=df_pred[model[prediction_key]],
                model=f"{model['name']}",
                cost_matrix=costs,
                confusion=confusion,
            )
            #rd["Outcome"] = model["outcome"]
            scores.append(rd)

    df_scores = pd.DataFrame(scores, columns=scorecols)
    return df_scores


def collect_prev_scores(run_id, df_actual, actual_key, level, secondary):
    """Collect df of evaluation metrics for the 'old' (JPR 2019) ensembles.

    Returns: df_scores.
    """

    costs = np.array([[0.0, 1.0], [10.0, 0.0]])
    scorecols = [
            "Model",
            "Outcome",
            "AUPR",
            "AUROC",
            "Brier score"
        ]

    scores = []
    for outcome in ["sb", "ns", "os"]:
        # if level == "pgm":
        #     # If pgm, correct for unequal number of samples...
        #     obs_fqtable = f"launched.transforms_{level}_imp_1"
        #     df_actual = fetch_actuals(fqtable=obs_fqtable,
        #                                         groupvar="pg_id",
        #                                         outcome=outcome)

        col_actual = actual_key.format(outcome=outcome)
        current = fetch_ensemble_predictions(
            run_id=run_id, level=level, outcome=outcome, eval_test=True
        )
        current = current.join(df_actual)
        col_current = current.columns[0]
        rd = evaluation.prepare_metrics(
            actuals=current[col_actual],
            probs=current[col_current],
            model=f"{level}_{outcome}_ensemble",
            cost_matrix=costs,
            confusion=False,
        )
        rd["Outcome"] = outcome
        scores.append(rd)
    df_scores = pd.DataFrame(scores, columns=scorecols)

    # Drop depending on secondary metric selected.
    if secondary is not None:
        if secondary=="brier":
            scorecols = [col for col in scorecols if "AUROC" not in col]
        if secondary=="auroc":
            scorecols = [col for col in scorecols if "Brier" not in col]

    df_scores = df_scores[scorecols]

    return df_scores


def compare_ebma(models, df_pred, df_actual, ebma_key, avg_key, secondary="brier"):
    """ Collects df of scores for EBMA and average, merges,
    and writes .tex. to set eval_scores path. """
    ensembles_ebma_cm_scores = collect_scores(
        models,
        df_pred,
        df_actual,
        ebma_key,
        step=True
    )
    ensembles_ebma_cm_scores.columns = ["model", "step",
                                        "ebma_auroc", "ebma_aupr", "ebma_brier"]
    ensembles_avg_cm_scores = collect_scores(
        models,
        df_pred,
        df_actual,
        avg_key,
        step=True
    )
    ensembles_avg_cm_scores.columns = ["model", "step",
                                       "avg_auroc", "avg_aupr", "avg_brier"]
    out = ensembles_ebma_cm_scores.merge(ensembles_avg_cm_scores,
                                         on=["model", "step"])

    # Reorder the columns.
    out = out[["model", "step", "ebma_aupr",
               "avg_aupr", "ebma_auroc", "avg_auroc",
               "ebma_brier", "avg_brier"]]

    # Fix decimals.
    decimal_cols = [col for col in out.columns if col != "model" and col !="step"]
    for col in decimal_cols:
        out[col] = out[col].round(3)

    # Drop columns depending on selection of secondary metric.
    if secondary=="brier":
        out.drop(columns=["ebma_auroc", "avg_auroc"], inplace=True)
    if secondary=="auroc":
        out.drop(columns=["ebma_brier", "avg_brier"], inplace=True)

    return out
