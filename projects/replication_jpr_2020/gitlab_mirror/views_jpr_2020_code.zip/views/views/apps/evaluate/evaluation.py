""" Evaluation Module """

# TODO(Remco): Counter in eval_step is still cosmetic. Connect base month.
# TODO(Remco): Refactor prepare_metrics. Ravel will break with multiclass.
# TODO(Remco): Fix actuals reset index in prepare_metrics.
# TODO(Remco): Reduce parameter number in prepare_metrics.
# TODO(Remco): Fix for alternative basemonth.

import warnings

import numpy as np
import pandas as pd

from timeit import default_timer as timer

from sklearn import metrics

from views.apps.evaluate import eval_lib
from views.apps.evaluate import eval_data
from views.apps.evaluate import eval_plot
from views.apps.data.common import utils


def eval_binary(df, colname_actual, colname_prediction):
    """ Evaluate binary probability predictions """

    def tryer(actuals, probs, func):
        """ Try to run func on actuals, probs and set fail """

        name_func = func.__name__

        # pylint: disable=bare-except
        try:
            score = func(actuals, probs)
        except:
            msg = f"Couldn't compute {name_func} for {colname_prediction}."
            warnings.warn(msg)
            score = np.NaN
        return score

    if len(df) == 0:
        msg = f"No predictions to evaluate for {colname_prediction}"
        warnings.warn(msg)
        scores = {
            "colname_actual": colname_actual,
            "colname_prediction": colname_prediction,
            "average_precision": np.NaN,
            "area_under_roc": np.NaN,
            "brier": np.NaN,
        }

    else:
        actuals = df[colname_actual]
        probs = df[colname_prediction]

        scores = {
            "colname_actual": colname_actual,
            "colname_prediction": colname_prediction,
            "average_precision": tryer(
                actuals, probs, eval_lib.average_precision
            ),
            "area_under_roc": tryer(actuals, probs, eval_lib.area_under_roc),
            "brier": tryer(actuals, probs, eval_lib.brier),
        }

    return scores


def eval_step(previous, actuals, step, level, outcome, colname_prediction, to_path=None):
    """Fetches k predictions and actuals at cm/pgm for selected run columns,
    and computes performance metrics.

    Args:
        previous: Pandas df of *aligned* predictions from prev_runs schema.
        actuals: Pandas df of actuals *unindexed*.
        step (int): Step to use. Note: nowcast +1 is currently set to step=0!
        level (str): Level of analysis at "cm" or "pgm".
        outcome (str): Selected outcome (e.g. "sb").
        colname_prediction (str): Column name to be used for the
            step-prediction.
        to_path (str): Write figures (AUPR) to specified path.

    Returns:
        A tuple, containing [0] a pandas dataframe of performance metrics per k,
        and [1] a pandas dataframe with the outcome predicted probabilities at
        k=1 per pg_id-month.

    Raises:
        IndexError: Selected outcome is not in the correct string format.
    """

    spec = utils.load_specfile("eval_spec")

    # Setting up an empty dataframes in which to store results later.
    scores = pd.DataFrame(
        columns=["month_id", "step", "model", "auroc", "aupr"]
    )
    groupvar = "country_id" if level == "cm" else "pg_id"  # repeated
    kpredictions = pd.DataFrame(
        columns=["month_id", "step", groupvar, colname_prediction]
    )

    # Little hack to allow for range argument instead of one k integer
    step_list = []
    if isinstance(step, int):
        step_list.append(step)
    else:
        step_list = step

    # Start producing results per step.
    for step in step_list:

        print(f"Returning {level}_{outcome} run metrics for k={step}")
        # setting counter and an upper limit given the most recent data
        # actuals available
        # startmonth + k should refer to this upper limit
        upper_base = spec["endmonth"]  # 480
        base_count = spec["startmonth"]

        predictions = eval_data.return_step_predictions(
            previous, level, outcome, step
        )

        for col in predictions.columns[:-2]:  # no actuals for the last two
            if base_count + step <= upper_base:
                # Get observations/predictions in table for a given run.
                preds = predictions[col]
                step_actuals = eval_data.return_step_actuals(
                    actuals, base_count, step
                )
                step_actuals.set_index(groupvar, inplace=True)  # integrate
                actspreds = step_actuals.merge(
                    preds, left_index=True, right_index=True
                )
                actspreds["step"] = step
                actspreds.reset_index(inplace=True)
                # Write figures if set.
                if to_path is not None:
                    eval_plot.plot_aupr(actspreds[f'ged_dummy_{outcome}'],
                                        actspreds[col],
                                        to_path=to_path)
                # Get scores AUROC/AUPR.
                fpr, tpr, thresholds = metrics.roc_curve(
                    actspreds[f"ged_dummy_{outcome}"], actspreds[col]
                )
                roc_auc = metrics.auc(fpr, tpr)
                apr = metrics.average_precision_score(
                    actspreds[f"ged_dummy_{outcome}"], actspreds[col]
                )
                # Append scores to the empty dataframe.
                scores = scores.append(
                    {
                        "month_id": base_count,
                        "step": step,
                        "model": f"{level}_{outcome}",
                        "auroc": roc_auc,
                        "aupr": apr,
                    },
                    ignore_index=True,
                    sort=False,
                )

                # Add model name for info.
                actspreds["modelname"] = col
                # Append actualspreds to the empty dataframe.
                actspreds.rename(
                    columns={col: colname_prediction}, inplace=True
                )
                kpredictions = kpredictions.append(
                    actspreds, ignore_index=True, sort=False
                )
            # Add to the counter before moving to the next run.
            base_count = base_count + 1

    return scores, kpredictions


def eval_retrospective(
    previous, actuals, level, outcome, colname_prediction, select_month
):
    """Returns AUC of runs for a selected month_id, over all runs up until
    that month_id.

    Args:
        previous: Pandas df of *non-aligned* predictions from prev_runs schema.
        actuals: Pandas df of actuals.
        level (str): Level of analysis at "cm" or "pgm".
        outcome (str): Selected outcome (e.g. "sb").
        select_month (int): Selected month to get retrospective performance
            scores for.

    Returns:
        A pandas dataframe of performance metrics per month of run.
    """
    # setting timevar, groupvar dependent on level
    timevar = "month_id"
    groupvar = "country_id" if level == "cm" else "pg_id"
    fqtable = f"launched.transforms_{level}_imp_1"

    # setting up an empty dataframe in which to store results later
    spec = utils.load_specfile("eval_spec")
    scores = pd.DataFrame(columns=["month_id", "run", "model", "auroc", "aupr"])
    kpredictions = pd.DataFrame(
        columns=[timevar, groupvar, f"ged_dummy_{outcome}", colname_prediction]
    )

    # selected columns
    if level == "cm":
        items = spec["cols_cm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]
    else:
        items = spec["cols_pgm"].items()
        cols = [value.format(outcome=outcome) for key, value in items]

    # fetching predictions in given column names, depending on level provided
    previous = previous.loc[previous[timevar] == select_month]
    previous = previous.drop(columns=timevar)

    # loop over runs
    cols = [col for col in previous.columns if col in cols]
    base_count = spec["startmonth"]
    for col in cols:
        if base_count <= select_month:
            print(
                f"Returning {level}_{outcome} run metrics for month {base_count}"
            )
            preds = previous[[groupvar, col]]
            # get actuals and merge
            actspreds = preds.merge(actuals, on=groupvar)
            # get scores AUROC/AUPR
            fpr, tpr, thresholds = metrics.roc_curve(
                actspreds[f"ged_dummy_{outcome}"], actspreds[col]
            )
            roc_auc = metrics.auc(fpr, tpr)
            apr = metrics.average_precision_score(
                actspreds[f"ged_dummy_{outcome}"], actspreds[col]
            )
            # append scores to the empty dataframe set up at start
            scores = scores.append(
                {
                    "month_id": base_count,
                    "run": col,
                    "model": f"{level}_{outcome}",
                    "auroc": roc_auc,
                    "aupr": apr,
                },
                ignore_index=True,
            )
            # Append actualspreds to the empty dataframe.
            actspreds[timevar] = base_count
            actspreds.rename(columns={col: colname_prediction}, inplace=True)
            kpredictions = kpredictions.append(
                actspreds, ignore_index=True, sort=False
            )
        base_count = base_count + 1

    return scores, kpredictions


def prepare_metrics(actuals, probs, model, cost_matrix, confusion=True):
    """Returns general and threshold-specific performance metrics in
    evaluation table row dict.

    Args:
        actuals: Series (indexed) containing the predictions.
        probs: Series (indexed) containing the predicted probabilities.
        model (str): Model name.
        cost_matrix: Numpy array of cost matrix to use.
        confusion: True by default. Computes optimal threshold and associated
            metrics given cost_matrix.

    Returns:
        row_dict: A dictionary containing the scores for entry into a table
            row.
    """

    aupr = eval_lib.average_precision(actuals, probs)
    auroc = eval_lib.area_under_roc(actuals, probs)
    brier = eval_lib.brier(actuals, probs)

    # Get matrix.
    if confusion:
        # Returns tuple of costs at [0], and optimal threshold at [1].
        costfunction = eval_lib.compute_optimal_threshold(
            actuals, probs, cost_matrix
        )
        optimal_threshold = costfunction[1]

        # Single-threshold metrics.
        preds = np.where(probs >= optimal_threshold, 1, 0)
        accuracy = eval_lib.accuracy(actuals, preds)
        f1_score = eval_lib.f1_score(actuals, preds)

        matrix = eval_lib.confusion_matrix_by_threshold(
            actuals, probs, optimal_threshold
        )
        tn, fp, fn, tp = matrix.ravel()

        row_dict = {
            "Model": model,
            "AUROC": auroc,
            "AUPR": aupr,
            "Brier score": brier,
            "Accuracy": accuracy,
            "F1-score": f1_score,
            "Cost-based threshold": round(optimal_threshold, 3),
            "True positive": tp,
            "False positive": fp,
            "True negative": tn,
            "False negative": fn,
        }

    else:
        row_dict = {
            "Model": model,
            "AUROC": auroc,
            "AUPR": aupr,
            "Brier score": brier
        }

    return row_dict
