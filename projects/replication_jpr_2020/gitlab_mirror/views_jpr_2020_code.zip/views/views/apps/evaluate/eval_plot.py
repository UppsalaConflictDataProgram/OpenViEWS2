"""
Evaluation plotting module.

This module includes all plotting utilities used in various evaluation
procedures.
"""

import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.colors as colors
import logging
import tempfile
import string
import os
Logger = logging.getLogger(__name__)

import seaborn as sns

from sklearn import metrics
from sklearn.calibration import calibration_curve
from views.apps.data.common import utils
from views.apps.evaluate import eval_data
from views.utils import dbutils, pyutils, statsutils, config


spec = utils.load_specfile("eval_spec")

# Global variables for plotting parameters.
LABELPAD = spec["labelpad"]
TITLESIZE = spec["titlesize"]
LABELSIZE = spec["labelsize"]
TICKSIZE = spec["ticksize"]
COL = spec["colours"]
LINE = spec["linetypes"]


class SqueezedNorm(colors.Normalize):
    """Used to tweak color normalization in non-linear fashion.
    """

    def __init__(self, vmin=None, vmax=None, mid=0, s1=2, s2=2, clip=False):
        self.vmin = vmin  # minimum value
        self.mid = mid  # middle value
        self.vmax = vmax  # maximum value
        self.s1 = s1
        self.s2 = s2
        f = (
            lambda x, zero, vmax, s: np.abs((x - zero) / (vmax - zero))
            ** (1.0 / s)
            * 0.5
        )
        self.g = (
            lambda x, zero, vmin, vmax, s1, s2: f(x, zero, vmax, s1)
            * (x >= zero)
            - f(x, zero, vmin, s2) * (x < zero)
            + 0.5
        )
        colors.Normalize.__init__(self, vmin, vmax, clip)

    def __call__(self, value, clip=None):
        r = self.g(value, self.mid, self.vmin, self.vmax, self.s1, self.s2)
        return np.ma.masked_array(r)


def make_ticks(var_scale="interval"):
    """ Make a tick dictionary with 'values' and 'labels' depending on var_scale

    Args:
        var_scale: "logodds", "prob" or "interval"
    Returns:
        ticks: dict with 'values' and 'labels'

    """

    def make_ticks_logit():
        """ Make logistic ticks """
        ticks_logit = []
        ticks_strings = []
        ticks = [
            0.001,
            0.002,
            0.005,
            0.01,
            0.02,
            0.05,
            0.1,
            0.2,
            0.4,
            0.6,
            0.8,
            0.9,
            0.95,
            0.99,
        ]

        for tick in ticks:
            ticks_logit.append(statsutils.logit(tick))
            ticks_strings.append(statsutils.format_prob_to_pct(tick))

        # Make the lower than for 0.001
        ticks_strings[0] = "<= " + ticks_strings[0]

        return ticks_logit, ticks_strings

    def make_ticks_probs():
        ticks_strings = []
        ticks_probs = [0.001, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7,
                 0.8, 0.9, 0.99]

        for tick in ticks_probs:
            ticks_strings.append(str(tick))

        return ticks_probs, ticks_strings

    def make_ticks_delta():
        ticks_strings = []
        #ticks_delta = [-0.4, -0.2, 0, 0.2, 0.4]
        ticks_delta = [-1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1]

        for tick in ticks_delta:
            ticks_strings.append(str(tick))

        return ticks_delta, ticks_strings

    if var_scale == "logodds":
        values, labels = make_ticks_logit()
    elif var_scale == "prob":
        values, labels = make_ticks_probs()
    elif var_scale == "delta":
        values, labels = make_ticks_delta()
    elif var_scale == "interval":
        values, labels = None, None

    ticks = {"values": values, "labels": labels}

    return ticks

# def make_ticks(variable_scale):
#     """Returns ticks and tick labels depending on variable_scale provided.

#     Args:
#         variable_scale (str): Either "logodds", "prob", or "interval".

#     Returns:
#         ticks: Dictionary holding tick values (ticks["values"]) and
#             tick labels (ticks["labels"]).
#     """
#     def logit(p):
#         return np.log(p/(1 - p))

#     def prob_to_pct(p):
#         assert 0 < p < 1
#         pct = p*100
#         if pct == int(pct):
#             pct = int(pct)
#         pct = str(pct)
#         pct += "%"
#         return pct

#     def make_ticks_probs():
#         ticks_strings = []
#         ticks_probs = [0.001, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7,
#                  0.8, 0.9, 0.99]

#         for tick in ticks_probs:
#             ticks_strings.append(str(tick))

#         return ticks_probs, ticks_strings

#     def make_ticks_logit():
#         ticks_logit = []
#         ticks_strings = []
#         ticks = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.4, 0.6, 0.8,
#                  0.9, 0.95, 0.99]

#         for tick in ticks:
#             ticks_logit.append(logit(tick))
#             ticks_strings.append(prob_to_pct(tick))

#         clip_lower_bound = True
#         if clip_lower_bound:
#             ticks_strings[0] = "<= " + ticks_strings[0]

#         return ticks_logit, ticks_strings

#     if variable_scale == "logodds":
#         values, labels = make_ticks_logit()
#     elif variable_scale == "prob":
#         values, labels = make_ticks_probs()
#     elif variable_scale == "interval":
#         values, labels = None, None
#     else:
#         msg = "Did you specify variable_scale?"
#         raise RuntimeError(msg)

#     ticks = {}
#     ticks["values"] = values
#     ticks["labels"] = labels
#     return ticks


def shifted_colormap(cmap, start=0, midpoint=0.5, stop=1.0, name="shiftedcmap"):
    """
    Credit: #https://gist.github.com/phobson/7916777

    Offsets the "center" of a colormap.
    Useful for data with a negative min and positive max and you want the
    middle of the colormap's dynamic range to be at zero

    Args:
        cmap: The matplotlib colormap to be altered
        start: Offset from lowest point in the colormap's range.
            Defaults to 0.0 (no lower offet). Should be between
            0.0 and 1.0.
        midpoint: The new center of the colormap. Defaults to
            0.5 (no shift). Should be between 0.0 and 1.0. In
            general, this should be  1 - vmax/(vmax + abs(vmin))
            For example if your data range from -15.0 to +5.0 and
            you want the center of the colormap at 0.0, "midpoint"
            should be set to 1 - 5/(5 + 15)) or 0.75
        stop: Offset from highest point in the colormap's range.
            Defaults to 1.0 (no upper ofset). Should be between
            0.0 and 1.0.

    Returns:
        newcmap: Shifted colormap object.

    """
    cdict = {"red": [], "green": [], "blue": [], "alpha": []}

    # regular index to compute the colors
    reg_index = np.linspace(start, stop, 257)

    # shifted index to match the data
    shift_index = np.hstack(
        [
            np.linspace(0.0, midpoint, 128, endpoint=False),
            np.linspace(midpoint, 1.0, 129, endpoint=True),
        ]
    )

    for ri, si in zip(reg_index, shift_index):
        r, g, b, a = cmap(ri)

        cdict["red"].append((si, r, r))
        cdict["green"].append((si, g, g))
        cdict["blue"].append((si, b, b))
        cdict["alpha"].append((si, a, a))

    newcmap = colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap


def get_cmap(variable_scale=None):
    """Gets matplotlib colormap and shifts according to variable_scale.

    Args:
        variable_scale (str): Optional. Either "prob" or "logodds". Won't apply
            shift transformation if not set.

    Returns:
        cmap: Shifted colormap object.
    """
    name_cmap = "rainbow"

    # Defaults
    start = 0.0
    mid = 0.5
    stop = 1.0

    # If we're using probs set mid of cmap at 1%
    if variable_scale == "prob":
        cmap = plt.get_cmap(name_cmap)

    if variable_scale == "prob_low":
        cmap = plt.get_cmap(name_cmap)
        mid = 0.01
        cmap = shifted_colormap(cmap, start, mid, stop)

    if variable_scale == "logodds":
        cmap = plt.get_cmap(name_cmap)
        mid = 0.25
        cmap = shifted_colormap(cmap, start, mid, stop)

    return cmap


def plot_separation(actuals, predictions, to_path=None):
    """Creates a separation plot for logistic and probit classification.
    See http://mdwardlab.com/sites/default/files/GreenhillWardSacks.pdf

    Args:
        df: Pandas dataframe containing predictions and actuals.
        colname_actual (str): Column name for the actuals.
        colname_probs (str): Column name for the probabilties.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves separation plot to path in .png.
    """
    p = predictions.values
    y = actuals.values

    assert p.shape[0] == y.shape[0], "p.shape[0] != y.shape[0]"
    n = p.shape[0]

    try:
        M = p.shape[1]
    except Exception:
        p = p.reshape(n, 1)
        M = p.shape[1]

    colors_bmh = np.array(["#FEF0D9", "#E34A33"])

    fig = plt.figure(figsize=(9, 1.2))

    for i in range(M):
        ax = fig.add_subplot(M, 1, i + 1)
        # Sorted index.
        ix = np.argsort(p[:, i])
        # Plot the different bars.
        ax.bar(
            np.arange(n),
            np.ones(n),
            width=1,
            color=colors_bmh[y[ix].astype(int)],
            edgecolor="none",
        )
        # Plot p line, hanging over 1 (.5 bar) extra for cosmetic reason.
        ax.plot(
            np.arange(n + 1),
            np.append(p[ix, i], p[ix, i][-1]),
            "k",
            linewidth=1,
        )
        # Create expected value bar.
        ax.vlines([(1 - p[ix, i]).sum()], [0], [1])
        plt.xlim(0, n)
        # Remove unnecessary spines.
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)

    plt.tight_layout()

    if to_path is not None:
        plt.savefig(f"{to_path}/separation_{colname_prediction}.png", dpi=200)
        plt.close()


def plot_aupr(actuals, predictions, to_path=None):
    """Plots AUPR for a given actuals and predictions series.

    Args:
        actuals: Series (indexed) of actuals.
        predictions: Series (indexed) of predictions.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves AUPR plot to path in .png.
    """
    average_precision = metrics.average_precision_score(actuals, predictions)
    precision, recall, _ = metrics.precision_recall_curve(actuals, predictions)

    plt.step(recall, precision, color="b", alpha=0.2, where="post")
    plt.fill_between(recall, precision, step="post", alpha=0.2, color="b")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.ylim([0.0, 1.05])
    plt.xlim([0.0, 1.0])
    plt.title("Precision-Recall curve: AUPR={0:0.2f}".format(average_precision))

    if to_path is not None:
        plt.savefig(f"{to_path}/aupr_{predictions.name}.png", dpi=200)
        plt.close()


def plot_auroc(actuals, predictions, to_path=None):
    """Plots AUROC for a given actuals and predictions series.

    Args:
        actuals: Series (indexed) of actuals.
        predictions: Series (indexed) of predictions.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves AUPR plot to path in .png.
    """
    fpr, tpr, thresholds = metrics.roc_curve(actuals, predictions)
    roc_auc = metrics.auc(fpr, tpr)

    plt.title("ROC curve: AUC = {0:0.2f}".format(roc_auc))
    plt.plot(fpr, tpr, "b", label="AUC = {0:0.2f}".format(roc_auc))
    plt.legend(loc="lower right")
    plt.plot([0, 1], [0, 1], "r--")
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.ylabel("True Positive Rate")
    plt.xlabel("False Positive Rate")

    if to_path is not None:
        plt.savefig(f"{to_path}/auroc_{predictions.name}.png", dpi=200)
        plt.close()


def plot_costfunction(
    costs, optimal_threshold, colname_prediction=None, to_path=None
):
    """Plots cost function.

    Args:
        costs: Costs returned by compute_optimal_threshold (eval_data).
        optimal_threshold (float): Optimal threshold returned by the same function.
        colname_prediction (str): Prediction column name to give to filename.
        to_path (str): Optional. Write to path if set.
    """

    plt.plot([i[1] for i in costs], [i[2] for i in costs])
    plt.title(f"Optimal threshold at {round(optimal_threshold,3)}")

    if to_path is not None:
        plt.savefig(f"{to_path}/costfunction_{colname_prediction}.png", dpi=200)
        plt.close()


def plot_simple_step_avg(scores, metric, ma=None, to_path=None):
    """Produces simple average AUC plots over k steps per outcome.

    Args:
        scores: Pandas dataframe of the scores produced by return_k_auc().
        metric (str): Selected metric as string, either "aupr" or "auroc".
        ma (int): Optional. Plots moving average instead of actual.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figures to set path in .png.
    """
    avg = scores.groupby(["step", "model"]).mean()
    avg.reset_index(inplace=True)

    # cosmetic correction: replace labels with k+1
    avg["step"] = avg["step"] + 1

    for model in avg.model.unique():
        fig, ax = plt.subplots(1)
        data = avg[["step", metric]].loc[avg.model == model]
        plt.ylim(0, 1)
        if ma is not None:
            data["ma"] = data[metric].rolling(window=ma, min_periods=1).mean()
            plt.plot(data["step"], data["ma"], color="black", lw=2)
        else:
            plt.plot(data["step"], data[metric], color="black", lw=2)
        plt.title(f"{metric.upper()}, {model}", pad=25)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        if to_path is not None:
            plt.savefig(
                f"{to_path}/avg_step_{metric}_{model}.png",
                transparent=False,
                dpi=300,
            )
            plt.close()


def plot_step_average(scores, metric, ma=None, to_path=None):
    """Plots average AUC of selected runs, over k steps.

    Args:
        scores: Pandas dataframe of the scores produced by return_k_auc().
        metric (str): Selected metric as string, either "aupr" or "auroc".
        ma (int): Optional. Plots moving average instead of actual.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    avg_scores = scores.groupby(["step", "model"]).mean()
    avg_scores.reset_index(inplace=True)

    # Setting some custom parameters depending on the metric.
    ylow = 0.8 if metric == "auroc" else 0
    ycorr = 0.01 if metric == "auroc" else 0.05
    iteration = 0.025 if metric == "auroc" else 0.2

    # Cosmetic correction: replace labels with k+1.
    avg_scores["step"] = avg_scores["step"] + 1

    # Set up figure space.
    fig, ax = plt.subplots(figsize=(15, 10))
    plt.ylim(ylow - ycorr, 1 + ycorr)

    # Remove the plot frame lines.
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    # Make sure your axis ticks are large enough to be easily read.
    plt.yticks(fontsize=TICKSIZE)
    plt.xticks(fontsize=TICKSIZE)

    # Add axis labels.
    plt.xlabel("step", fontsize=LABELSIZE, labelpad=LABELPAD)
    plt.ylabel(metric.upper(), fontsize=LABELSIZE, labelpad=LABELPAD)

    # Provide tick lines across the plot to help viewers trace along.
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )
    ax.set_xlim(avg_scores["step"].min(), avg_scores["step"].max())

    # Remove the tick marks
    plt.tick_params(
        axis="both",
        which="both",
        bottom=False,
        top=False,
        labelbottom=True,
        left=False,
        right=False,
        labelleft=True,
    )
    ax.tick_params(axis="y", which="major", pad=20)

    # Loop over the means and plot them.
    for model in avg_scores.model.unique():
        data = avg_scores[["step", metric]].loc[avg_scores.model == model]
        if ma is not None:
            data["ma"] = data[metric].rolling(window=ma, min_periods=1).mean()
            plt.plot(
                data["step"],
                data["ma"],
                label=model,
                color=COL[model],
                linestyle=LINE[model],
                lw=3,
            )
        else:
            plt.plot(
                data["step"],
                data[metric],
                label=model,
                color=COL[model],
                linestyle=LINE[model],
                lw=3,
            )
        ax.legend(
            loc='upper center',
            bbox_to_anchor=(0.5, -0.18),
            fontsize=TICKSIZE-6,
            ncol=6
        )

    # Adjust the margins and set up ticker.
    ax.margins(x=0.03)
    ax.xaxis.set_major_locator(ticker.MultipleLocator(2))

    # Finish up figure with title and save.
    plt.title(
        f"Average performance ({metric.upper()}) over step",
        pad=25,
        fontdict={"fontsize": TITLESIZE},
    )
    plt.tight_layout()

    if to_path is not None:
        plt.savefig(
            f"{to_path}/average_k_{metric}.png", transparent=False, dpi=300
        )
        plt.close()


def plot_step_auc(scores, metric, ma=None, step=None, to_path=None):
    """Plots AUC of selected runs, at selected k.

    Args:
        scores: Pandas dataframe of the scores produced by return_k_auc().
        metric (str): Selected metric as string, either "aupr" or "auroc".
        ma (int): Optional. Plots moving average at provided integer number instead of
            actual.
        step (int): Optional. Used for the title text. Set to zero by default.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    if step is None:
        avg_scores = scores
    else:
        avg_scores = scores.groupby(["step", "model", "month_id"]).mean()
        avg_scores.reset_index(inplace=True)
        avg_scores = avg_scores[avg_scores.step == step]

    # Get month string in.
    month = eval_data.fetch_month()
    avg_scores = avg_scores.merge(month, on="month_id")

    # Setting some custom parameters depending on metric.
    ylow = 0.8 if metric == "auroc" else 0
    ycorr = 0.01 if metric == "auroc" else 0.05
    iteration = 0.025 if metric == "auroc" else 0.2

    # Prepare figure space.
    fig, ax = plt.subplots(figsize=(15, 10))

    # Remove the plot frame lines.
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    # Make sure your axis ticks are large enough to be easily read.
    plt.yticks(fontsize=TICKSIZE)
    plt.xticks(fontsize=TICKSIZE)

    # Add axis labels.
    plt.xlabel(
        "Run (month of forecast publication)",
        fontsize=LABELSIZE,
        labelpad=LABELPAD,
    )
    plt.ylabel(metric.upper(), fontsize=LABELSIZE, labelpad=LABELPAD)

    # Provide tick lines across the plot to help viewers trace along.
    startmonth = avg_scores["month_id"].min()
    endmonth = avg_scores["month_id"].max()
    start_str = month.loc[month.month_id == startmonth, "month_str"].item()
    end_str = month.loc[month.month_id == endmonth, "month_str"].item()
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Remove the tick marks; they are unnecessary.
    plt.tick_params(
        axis="both",
        which="both",
        bottom=False,
        top=False,
        labelbottom=True,
        left=False,
        right=False,
        labelleft=True,
    )
    ax.tick_params(axis="y", which="major", pad=20)

    for model in avg_scores.model.unique():
        data = avg_scores[["month_str", metric]].loc[avg_scores.model == model]
        if ma is not None:
            data["ma"] = data[metric].rolling(window=ma, min_periods=1).mean()
            plt.plot(
                data["month_str"],
                data["ma"],
                label=model,
                color=COL[model],
                linestyle=LINE[model],
                lw=3,
            )
        else:
            plt.plot(
                data["month_str"],
                data[metric],
                label=model,
                color=COL[model],
                linestyle=LINE[model],
                lw=3,
            )
        plt.ylim((ylow - ycorr, 1 + ycorr))
        ax.legend(
            loc='upper center',
            bbox_to_anchor=(0.5, -0.18),
            fontsize=TICKSIZE-6,
            ncol=6
        )

    # Adjust the margins and set up ticker.
    ax.xaxis.set_major_locator(ticker.MultipleLocator(3))

    # Fix limits
    ax.set_xlim(start_str, end_str)

    # Finish up figure with titles and save to file.
    if step is not None:
        plt.title(
            f"{metric.upper()} for step={step + 1}, per month of run",
            pad=25,
            fontdict={"fontsize": TITLESIZE},
        )
        plt.tight_layout()
        if to_path is not None:
            plt.savefig(
                f"{to_path}/{metric}_step_{step + 1}.png",
                transparent=False,
                dpi=300,
            )
            plt.close()

    else:
        endmonth = eval_data.get_month_str(spec["endmonth"])
        plt.title(
            f"{metric.upper()} for predictions of {endmonth}, per month of run",
            pad=25,
            fontdict={"fontsize": TITLESIZE},
        )
        plt.tight_layout()
        if to_path is not None:
            plt.savefig(
                f"{to_path}/retrospective_evaluation.png",
                transparent=False,
                dpi=300,
            )
            plt.close()


def plot_heatmap(df, colname_feature, level, run, variable_scale, to_path=None):
    """Pivots data and plots heatmap.

    Args:
        df: Pandas dataframe with country already merged in.
        colname_feature (str): Column name of feature to use in plot.
        level (str): Currently either "cm" or "pgm".
        run (str): Descriptive for run, e.g. "r.2020_02_01".
        variable_scale (str): Scale for colorbar; "logodds" or "prob".
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    # Get colormap, ticks.
    if variable_scale is not "delta":
        cmap = get_cmap(variable_scale)
    else:
        cmap = "seismic"
    ticks = make_ticks(variable_scale)

    # Min, max values according not to data, but according to set tick range.
    vmin, vmax = np.min(ticks['values']), np.max(ticks['values'])
    #vmid = np.log(.003/(1-.003))

    # Prepare data.
    if level == "pgm":
        df = eval_data.compute_proportions(df, colname_feature, "name")
        df["prop_logit"] = np.log(df["prop"] / (1 - df["prop"]))
        values = "prop_logit" if variable_scale == "logodds" else "prop"
        prefix = "pgm_"
        #norm = SqueezedNorm(vmin=vmin, vmax=vmax, mid=vmid, s1=1.8, s2=1)
        norm = None
    if level == "cm":
        df[f"{colname_feature}_logit"] = np.log(
            df[colname_feature] / (1 - df[colname_feature])
        )
        values = (
            f"{colname_feature}_logit"
            if variable_scale == "logodds"
            else colname_feature
        )
        norm = None
        prefix = "cm_"

    # Get month string in.
    month = eval_data.fetch_month()
    df = df.merge(month, on="month_id")

    # Pivot.
    df_matrix = df.pivot(index="name", columns="month_str", values=values)

    # Set size.
    plt.figure(figsize=(11, 10))
    plt.yticks(fontsize=8)
    plt.xticks(fontsize=10)

    ax = sns.heatmap(df_matrix, cmap=cmap, norm=norm, vmin=vmin, vmax=vmax,
                     linewidths=.003, cbar=False)
    plt.title(f"Heatmap at {level} for {colname_feature}\nRun: {run}",
              loc='left', pad=20)

    # Set axes to empty.
    ax.set_ylabel("")
    ax.set_xlabel("")

    # Colorbar
    fig = ax.collections[0].get_figure()
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(vmin=vmin,
                                                             vmax=vmax))
    sm._A = []
    cbar = fig.colorbar(sm, ax=ax, fraction=0.05, pad=0.03,
                        ticks=ticks["values"])
    cbar.ax.set_yticklabels(ticks['labels'], size=12)
    cbar.outline.set_linewidth(0.1)

    # Finishing up and saving figure.
    if to_path is not None:
        plt.tight_layout()
        plt.savefig(f"{to_path}{prefix}heatmap_{colname_feature}.png", dpi=300)
        plt.close()
        print(f"wrote {to_path}{prefix}heatmap_{colname_feature}.png")


def plot_cm_line(
    predictions,
    actuals,
    colname_feature,
    colname_actual,
    country_id,
    history=0,
    step=1,
    to_path=None,
):
    """Plots line for specified outcome and country_id.

    Actuals are separately plotted to allow for an extended time series
    of the history of a particular country.

    Args:
        predictions: Pandas dataframe of indexed predictions.
        actuals: Pandas dataframe of indexed actuals.
        colname_feature (str): Column name of feature to plot.
        colname_actual (str): Column name of actual to plot.
        country_id (int): Identifier of the country selected.
        history (int): Optional. Add months backward of actuals you want to add
            to the plot.
        step (int): Step of the predictions. Used in title.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    # lazy reset index
    predictions.reset_index(inplace=True)
    actuals.reset_index(inplace=True)

    # get monthstring in
    month = eval_data.fetch_month()
    predictions = predictions.merge(month, on="month_id")
    actuals = actuals.merge(month, on="month_id")

    # return countryname
    country_name = eval_data.get_country_name(country_id)
    predictions = predictions.loc[predictions.country_id == country_id]
    predictions.reset_index(inplace=True)
    actuals = actuals.loc[actuals.country_id == country_id]

    # reset timeline actuals
    startmonth = predictions["month_id"].min()
    endmonth = predictions["month_id"].max()
    actuals = actuals[
        (actuals["month_id"] >= (startmonth - history))
        & (actuals["month_id"] <= endmonth)
    ]

    # Common sizes: (10, 7.5) and (12, 9)
    fig, ax = plt.subplots(figsize=(13, 4))

    # Remove the plot frame lines. They are unnecessary chartjunk.
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    # Limit the range
    plt.ylim((-0.05, 1.1))

    # Make sure your axis ticks are large enough to be easily read.
    plt.yticks(fontsize=13)
    plt.xticks(fontsize=13)

    # axis labels
    plt.xlabel("Run (month of forecast publication)", fontsize=16, labelpad=20)
    plt.ylabel("Probability", fontsize=16, labelpad=20)

    # Remove the tick marks; they are unnecessary with the tick lines we just plotted.
    plt.tick_params(
        axis="both",
        which="both",
        bottom=False,
        top=False,
        labelbottom=True,
        left=False,
        right=False,
        labelleft=True,
    )

    # plot w hacky base
    plt.plot(actuals["month_str"], [0] * len(actuals["month_str"]), alpha=0)
    plt.vlines(
        actuals["month_str"].loc[actuals[colname_actual] == 1],
        0,
        1,
        alpha=0.2,
        color="r",
        linewidth=20,
        label="Observed",
    )
    plt.plot(
        predictions["month_str"],
        predictions[colname_feature],
        linewidth=2,
        label="Predicted",
        color="black",
    )

    # fix margins
    plt.margins(0.014)

    # legend and titlte
    plt.legend(loc="center left", bbox_to_anchor=(1, 0.5), fontsize=13)
    plt.title(
        f"Predicted and observed {colname_actual} at cm-level (step={step + 1}), {country_name}",
        fontdict={"fontsize": 18},
    )

    ax.xaxis.set_major_locator(ticker.MultipleLocator(3))

    # Provide tick lines across the plot to help your viewers trace along
    # ax.set_xlim(startmonth_str, endmonth_str)
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    plt.tight_layout()

    if to_path is not None:
        plt.savefig(
            f"{to_path}/{country_name.lower()}_cm_{colname_actual}.png", dpi=300
        )
        plt.close()


def plot_pgm_line(
    predictions, actuals, outcome, country_id, history=0, step=1, to_path=None
):
    """Plots line for specified proportion and country_id.

    Actuals are separately plotted to allow for an extended time series
    of the history of a particular country.

    Args:
        predictions: Pandas dataframe of indexed predictions.
        actuals: Pandas dataframe of indexed actuals.
        outcome (str): Full outcome name, e.g. "ged_dummy_sb".
        country_id (int): Identifier of the country selected.
        history (int): Optional. Add months backward of actuals you want to add to
            the plot.
        step (int): Step of the predictions. Used in title.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    # lazy reset index
    predictions.reset_index(inplace=True)
    actuals.reset_index(inplace=True)

    # get monthstring in
    month = eval_data.fetch_month()
    predictions = predictions.merge(month, on="month_id")
    actuals = actuals.merge(month, on="month_id")

    # return countryname
    country_name = eval_data.get_country_name(country_id)
    predictions = predictions.loc[predictions.country_id == country_id]
    actuals = actuals.loc[actuals.country_id == country_id]

    # reset timeline actuals
    startmonth = predictions["month_id"].min()
    endmonth = predictions["month_id"].max()
    actuals = actuals[
        (actuals["month_id"] >= (startmonth - history))
        & (actuals["month_id"] <= endmonth)
    ]

    start_str = month.loc[
        month.month_id == (startmonth - history), "month_str"
    ].item()
    end_str = month.loc[month.month_id == endmonth, "month_str"].item()

    # Common sizes: (10, 7.5) and (12, 9)
    fig, ax = plt.subplots(figsize=(13, 4))  # from 7.5

    # Remove the plot frame lines. They are unnecessary chartjunk.
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    # Make sure your axis ticks are large enough to be easily read.
    plt.yticks(fontsize=13)
    plt.xticks(fontsize=13)

    # axis labels
    plt.xlabel("Run (month of forecast publication)", fontsize=16, labelpad=20)
    plt.ylabel("Proportion", fontsize=16, labelpad=20)

    # Provide tick lines across the plot to help your viewers trace along
    ax = plt.gca()
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Remove the tick marks
    plt.tick_params(
        axis="both",
        which="both",
        bottom=False,
        top=False,
        labelbottom=True,
        left=False,
        right=False,
        labelleft=True,
    )

    # plot
    plt.plot(actuals['month_str'], actuals['prop'], linewidth=2, color="red",
             label="Observed")
    plt.plot(predictions['month_str'], predictions['prop'], linewidth=2,
             color="black", label="Predicted")

    # fix limits
    ax.set_xlim(start_str, end_str)

    # title and legend
    handles, labels = ax.get_legend_handles_labels()
    plt.legend(reversed(handles), reversed(labels),
               loc="center left", bbox_to_anchor=(1, 0.5), fontsize=13)
    plt.title(
        f"Predicted and observed proportion of {outcome} (step={step + 1}), {country_name}",
        pad=25,
        fontdict={"fontsize": 18},
    )

    if (endmonth - startmonth) >= 12:
        ax.xaxis.set_major_locator(ticker.MultipleLocator(3))

    ax.tick_params(axis="x", which="major", pad=15)
    plt.tight_layout()
    # plt.subplots_adjust(top=0.90, bottom=0.50)

    if to_path is not None:
        plt.savefig(
            f"{to_path}/{country_name.lower()}_prop_{outcome}.png", dpi=300
        )
        plt.close()


def prepare_pg_country(
    df, month_id, country_id, colname_feature, variable_scale
):
    """Prepares geopandas dataframe for plot_pg_country.
    """

    def logit(p):
        return np.log(p / (1 - p))

    df = df[df.country_id == country_id]

    timevar = "month_id"
    groupvar = "pg_id"

    query_pg = "SELECT gid AS pg_id, geom FROM staging.priogrid;"
    query = query_pg

    groupvar_c = "country_id"
    query_c = f"""
               SELECT id AS country_id, geom FROM staging.country
               WHERE gweyear=2016 AND gwemonth=6 AND id={country_id};
               """
    gdf_geom_c = gpd.GeoDataFrame.from_postgis(
        query_c, dbutils.make_engine(), geom_col="geom"
    )
    gdf_geom_c.set_index([groupvar_c], inplace=True)

    # Gdf holds the geometry or shape.
    gdf = gpd.GeoDataFrame.from_postgis(
        query, dbutils.make_engine(), geom_col="geom"
    )
    gdf = gdf.set_index([groupvar])

    # Join the geometry to the data using a shared index column, hopefully
    # country_id or pg_id.
    gdf = gdf.join(df, how="left")

    # Transform into logodds if selected.
    if variable_scale == "logodds":
        gdf[colname_feature] = logit(gdf[colname_feature])

    # Remove nan.
    gdf_plot = gdf[~gdf[colname_feature].isnull()]

    # Subset on month.
    gdf_plot = gdf_plot.loc[gdf_plot[timevar] == month_id]

    return gdf_geom_c, gdf_plot


def plot_pg_country(
    df,
    month_id,
    country_id,
    colname_feature,
    colname_actual=None,
    variable_scale="logodds",
    to_path=None,
):
    """ Plots minimap of country's pgm predictions along with actuals.

    Note: pandas dataframe should to be indexed on pg_id.

    Args:
        df: Pandas dataframe of predictions.
        month_id (int): Identifier for prediction month to plot.
        country_id (int): Identifier for country to plot.
        colname_feature (str): Column name of feature to use in the plot.
        colname_actual (str): Full column name of actual, e.g. "ged_dummy_sb".
        variable_scale (str): Scale to plot values at. Affect colormaps.
            Default at "logodds".
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    gdf_geom_c, gdf = prepare_pg_country(
        df, month_id, country_id, colname_feature, variable_scale
    )

    # Get colormap, ticks based on variable_scale.
    cmap = get_cmap(variable_scale)
    ticks = make_ticks(variable_scale)

    # Get country name and month string, prepare title
    country_name = eval_data.get_country_name(country_id)
    month_str = eval_data.get_month_str(month_id)
    title = f"{colname_feature} for {country_name}, {month_str}"

    # Min, max values according not to data, but according to set tick range.
    vmin, vmax = np.min(ticks["values"]), np.max(ticks["values"])

    # Initialize figure.
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_title(title)

    # Base plot.
    base = gdf.plot(
        ax=ax,
        column=colname_feature,
        figsize=(10, 10),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
    )

    # Also get the centroid points for the actuals.
    gdf["centroid"] = gdf["geom"].centroid
    for i, geo in gdf.loc[gdf[colname_actual] == 1].centroid.iteritems():
        ax.plot(geo.x, geo.y, marker="o", color="black")

    # Remove axis ticks.
    plt.xticks([])
    plt.yticks([])

    # Add colorbar and custom tick labels.
    fig = ax.get_figure()
    sm = plt.cm.ScalarMappable(
        cmap=cmap, norm=plt.Normalize(vmin=vmin, vmax=vmax)
    )
    sm._A = []
    cbar = fig.colorbar(
        sm, ax=ax, fraction=0.033, pad=0.04, ticks=ticks["values"]
    )
    cbar.ax.set_yticklabels(ticks["labels"], size=13)

    # Add boundaries.
    gdf_geom_c.geom.boundary.plot(
        ax=ax, edgecolor="black", alpha=0.5, linewidth=2
    )

    if to_path is not None:
        plt.tight_layout()
        plt.savefig(f"{to_path}/{colname_feature}_{country_id}_{month_id}.png",
                    dpi=300)
        plt.close()


def mc_plot(df, model, outcome, label, title, filename, path_out):
    """ Wrapper for calling modelcriticism plot in an R subprocess.

    Args:
        df: Pandas dataframe of predictions and actuals.
        model (str): Column name of model.
        outcome (str): Column name of actual.
        label (str): Column name of label to use.
        title (str): Title to add to figure.
        filename (str): Filename to write to.
        path_out (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """

    def read_template():
        this_dir = os.path.dirname(os.path.abspath(__file__))
        path_template = os.path.join(this_dir, "modelcriticism_template.R")
        with open(path_template, "r") as f:
            template_str = f.read()

        template = string.Template(template_str)

        return template

    with tempfile.TemporaryDirectory() as tempdir:

        path_csv_in = os.path.join(tempdir, "input.csv")
        path_rscript = os.path.join(tempdir, "modelcriticism_script.R")

        values = {
            "$PATH_CSV_INPUT": path_csv_in,
            "$PATH_CSV_OUTPUT_STEM": path_out,
            "$MODEL": model,
            "$OUTCOME": outcome,
            "$LABEL": label,
            "$TITLE": title,
            "$FILENAME": filename
        }

        this_dir = os.path.dirname(os.path.abspath(__file__))
        path_template = os.path.join(this_dir, "modelcriticism_template.R")
        with open(path_template, "r") as f:
            rscript = f.read()

        for replace in values:
            rscript = rscript.replace(replace, values[replace])

        df.to_csv(path_csv_in, index=True)
        Logger.info(f"Wrote {path_csv_in}")

        with open(path_rscript, "w") as f:
            f.write(rscript)
        Logger.info(f"Wrote {path_rscript}")
        Logger.debug(rscript)

        cmd = ["Rscript", path_rscript]
        try:
            pyutils.run_subproc(cmd)
        except Exception as e:
            print(e)
            pass

    Logger.info(f"Wrote figure to {path_out}.")


def bisep_plot(df, model_x, model_y, outcome, label, title, filename, path_out):
    """ Wrapper for calling modelcriticism plot in an R subprocess.

    Args:
        df: Pandas dataframe of predictions and actuals.
        model_x (str): Column name of model x.
        model_y (str): Column name of model y.
        outcome (str): Column name of actual.
        label (str): Column name of label to use.
        title (str): Title to add to figure.
        filename (str): Filename to write to.
        path_out (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """

    def read_template():
        this_dir = os.path.dirname(os.path.abspath(__file__))
        path_template = os.path.join(this_dir, "biseparation_template.R")
        with open(path_template, "r") as f:
            template_str = f.read()

        template = string.Template(template_str)

        return template

    with tempfile.TemporaryDirectory() as tempdir:

        path_csv_in = os.path.join(tempdir, "input.csv")
        path_rscript = os.path.join(tempdir, "biseparation_script.R")

        values = {
            "$PATH_CSV_INPUT": path_csv_in,
            "$PATH_CSV_OUTPUT_STEM": path_out,
            "$MODEL_X": model_x,
            "$MODEL_Y": model_y,
            "$OUTCOME": outcome,
            "$LABEL": label,
            "$TITLE": title,
            "$FILENAME": filename
        }

        this_dir = os.path.dirname(os.path.abspath(__file__))
        path_template = os.path.join(this_dir, "biseparation_template.R")
        with open(path_template, "r") as f:
            rscript = f.read()

        for replace in values:
            rscript = rscript.replace(replace, values[replace])

        df.to_csv(path_csv_in, index=True)
        Logger.info(f"Wrote {path_csv_in}")

        with open(path_rscript, "w") as f:
            f.write(rscript)
        Logger.info(f"Wrote {path_rscript}")
        Logger.debug(rscript)

        cmd = ["Rscript", path_rscript]
        try:
            pyutils.run_subproc(cmd)
        except Exception as e:
            print(e)
            pass

    Logger.info(f"Wrote figure to {path_out}.")


def plot_calibration_curve(y_true, y_prob, title, n_bins=5, hist=True,
                           normalize=False, to_path=None):
    """Credit to Andreas Müller at Columbia University
    https://github.com/amueller/COMS4995-s18/.

    Args:
        y_true: Series of actuals.
        y_prob: Series of probabilities.
        title (str): Title to put on plot.
        n_bins (int): Number of bins for the histogram. Defaults to 5.
        ax (bool): Gets current axes.
        hist (bool): Adds histogram to figure.
        normalize (bool): Normalized calibration curve or not.
        to_path (str): Optional. Write to path if set.

    Returns:
        Saves figure to set path in .png.
    """
    prob_true, prob_pred = calibration_curve(y_true, y_prob,
                                             n_bins=n_bins,
                                             normalize=normalize)

    fig, ax = plt.subplots(figsize=(5, 5))

    if hist:
        ax.hist(y_prob, weights=np.ones_like(y_prob) / len(y_prob), alpha=.4,
               bins=np.maximum(10, n_bins))
    ax.plot([0, 1], [0, 1], ':', c='k')
    curve = ax.plot(prob_pred, prob_true, marker="o")

    ax.set_xlabel("predicted probability")
    ax.set_ylabel("fraction of positive samples")

    ax.set(aspect='equal')
    ax.set_title(title)

    if to_path:
        plt.savefig(to_path, dpi=300)
        plt.close()

    Logger.info(f"Wrote figure to {to_path}.")
    return curve
