""" This module provides estimators from scikit-learn for OSA """

import json

from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, RidgeCV, Lasso

ESTIMATORS = {
    "Lasso": Lasso,
    "RidgeCV": RidgeCV,
    "LinearRegression": LinearRegression,
    "RandomForestClassifier": RandomForestClassifier,
    "Pipeline": Pipeline,
    "StandardScaler": StandardScaler,
}


def estimator_fetcher(spec):
    """ Returns corresponding scikit estimator from a dict

    A spec dictionary contains a text only dict despcription of an estimator,
    suitable for storing in .json. When passed such a dict this function
    returns a scikit-learn estimator object.
    Two

    Args:
        spec: Dict with a name key-value and either steps or kwargs key values

    Returns:
        A scikit learn estimator
    """

    def assert_sane_spec(spec):
        """ Make sure a spec is a dict of two keys,
        name+kwargs or name+steps
        """

        msg = f"spec contains more than two keys: {json.dumps(spec)}"
        assert len(spec) == 2, msg

        msg = "only estimator+kwargs or estimator+steps are allowed keys"
        keys_pipe = ["estimator", "steps"]
        keys_est = ["estimator", "kwargs"]

        sorted_keys = sorted(spec.keys())
        has_keys_pipe = sorted_keys == keys_pipe
        has_keys_est = sorted_keys == keys_est
        assert has_keys_pipe or has_keys_est, msg

        if spec["estimator"] not in ESTIMATORS:
            msg = "{} wasn't found in ESTIMATORS".format(spec["estimator"])
            raise NotImplementedError(msg)

    def pipeline_builder(spec):
        """ Build a scikit pipeline from the values of 'steps' in spec """

        steps = []
        for step_dict in spec["steps"]:
            # each step_dict is a estimator_name: definition pair
            assert len(step_dict.keys()) == 1, "each step should be one dict"
            step_name = list(step_dict.keys())[0]

            step_spec = step_dict[step_name]
            step_tuple = (step_name, estimator_fetcher(step_spec))
            steps.append(step_tuple)

        pipeline = Pipeline(steps)

        return pipeline

    assert_sane_spec(spec)

    name = spec["estimator"]

    if name == "Pipeline":
        estimator = pipeline_builder(spec)
    else:
        kwargs = spec["kwargs"]
        estimator = ESTIMATORS[name](**kwargs)

    return estimator
