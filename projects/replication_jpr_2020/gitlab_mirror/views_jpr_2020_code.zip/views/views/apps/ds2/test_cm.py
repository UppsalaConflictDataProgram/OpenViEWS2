import itertools
import string
import functools
import math
import time
import pyarrow
import pyarrow.parquet as pq

import pandas as pd
import numpy as np

import logging
from sklearn.ensemble import RandomForestClassifier

from views.apps.ds2 import ds, wrappers
from views.utils import datautils, pyutils, dbutils
from views.apps.ds2.balance import balance_df_panel_index, fill_all_missing

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
# logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)


def main():

    df = dbutils.db_to_df(
        fqtable="preflight.flight_cm",
        columns=["ged_dummy_sb"],
        ids=["month_id", "country_id"],
    )

    df = df.dropna()
    df = df.loc[121:337]

    # Balance data if required
    timevar = df.index.names[0]
    groupvar = df.index.names[1]

    if len(df) != len(df.index.get_level_values(0).drop_duplicates()) * len(
        df.index.get_level_values(1).drop_duplicates()
    ):
        df = balance_df_panel_index(df, timevar, groupvar)
        df = fill_all_missing(df)

    print("df imported")

    # Pre-compute training vars
    df["time_since_ged_dummy_sb"] = wrappers.time_since_previous_event(
        df, cols=["ged_dummy_sb"]
    )
    df["tlag_1_ged_dummy_sb"] = wrappers.time_since_previous_event(
        df, cols=["ged_dummy_sb"]
    )

    spec = pyutils.load_yaml("spec_cm.yaml")

    # Clone the outcome cols for
    df["pt_rf_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["inst_rf_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["logit_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["ols_ged_dummy_sb"] = df["ged_dummy_sb"]

    print("training")
    # A pre-trained estimator
    pt_rf = RandomForestClassifier(n_estimators=2)
    cols_pt_rf = ["tlag_1_ged_dummy_sb", "time_since_ged_dummy_sb"]
    data_train = df.loc[121:432, cols_pt_rf + ["ged_dummy_sb"]].dropna()
    pt_rf.fit(X=data_train[cols_pt_rf], y=data_train["ged_dummy_sb"])

    # An instantiated but untrained estimator
    inst_rf = RandomForestClassifier(n_estimators=2)

    estimators = wrappers.ESTIMATORS
    estimators["pt_rf"] = pt_rf
    estimators["inst_rf"] = inst_rf
    print(datautils.get_share_missing_str(df))
    print(df)
    for col in df:
        print(df[col])
    df_aggregates = ds.dynasim(df, **spec, estimators=estimators)
    for col in df_aggregates:
        print(df_aggregates[col])

    df_aggregates.to_csv("maxinetest.csv")


if __name__ == "__main__":
    main()
