from typing import Dict, Optional
import logging
import multiprocessing as mp

import os
import psutil
import tempfile

import joblib
import numpy as np
import pandas as pd

from views.apps.ds2 import wrappers, agg
from views.apps.ds2.transformer import Transformer
from views.apps.ds2.model import Model
from views.utils import datautils, pyutils

Logger = logging.getLogger(__name__)


def simulate(df, times, tasks, sim, tempdir):
    """ Simulate df for times using tasks for sim number sim

    Args:
        df: Simulation df
        times: Time limit iterable
        tasks: Ordered list of task objects with .tick(data, t) methods
        sim: Integer sim number
        tempdir: Scratch directory to write simulation to
    Returns:
        path: path to .parquet dataframe with simulated values from tasks
     """

    Logger.info(f"Started simulation {sim}")
    for t in times:
        Logger.debug(f"Sim {sim}, t {t}")
        for task in tasks:
            Logger.debug(f"Ticking {task.name}")
            df.loc[t, task.colname] = task.tick(df, t, sim)

    colnames = [task.colname for task in tasks]
    path = os.path.join(tempdir, f"sim_{sim}.parquet")
    datautils.write_parquet(df.loc[times, colnames], path)
    Logger.info(f"Finished simulation {sim}")
    return path


def dynasim(
    df: pd.DataFrame,
    spec_transforms: Dict,
    spec_models: Dict,
    spec_stats: Dict,
    sim_order: list,
    times: Dict,
    n_sim: int,
    estimators: Optional[Dict] = wrappers.ESTIMATORS,
    dir_sims: Optional[list] = None,
    dir_task_pickles: Optional[list] = None,
):
    """ Dynasim

    Args:
        df: Dataframe of input data
        spec_transforms: Spec of transformations to compute
        spec_models: Spec of models to compute
        spec_stats: Specify which statistics to compute for aggregates
        sim_order: List of transform and model names to order simulation by
        times: dict of train/sim times with start and end
        n_sim: Number of simulations to perform
        estimators: Dictionary of estimator objects used to lookup
            using spec_models[model]['estimator'].
            defaults to wrappers.ESTIMATORS
        debug: If True run single core, else run on all cores.
    Returns:
        df_aggregates: Dataframe of aggregates


     """

    def order_tasks_by_sim_order(sim_order, transformers, models):

        tasks_by_name = {}
        for task in transformers + models:
            tasks_by_name[task.name] = task

        tasks_ordered = []
        for task_name in sim_order:
            tasks_ordered.append(tasks_by_name[task_name])
        return tasks_ordered

    def start_tasks(df, tasks, times_train):
        Logger.info(f"Began starting tasks")
        for task in tasks:
            if isinstance(task, Transformer):
                Logger.info(f"Starting transform {task.name}")
                df.loc[:, task.colname] = task.start(df)
            elif isinstance(task, Model):
                Logger.info(f"starting model {task.name}")
                task.start(df, times_train)
        Logger.info(f"All tasks started")
        return df

    def run_sims_parallel(df, times, tasks, n_sim, tempdir):
        raise NotImplementedError(f"run_sims_parallel() not ready")
        with mp.Pool(processes=psutil.cpu_count(logical=False)) as pool:
            results = []
            for i_sim in range(n_sim):
                results.append(
                    pool.apply_async(
                        simulate, (df, times, tasks, i_sim, tempdir)
                    )
                )
            for result in results:
                result.get()
            paths_sims = [result.get() for result in results]

        return paths_sims

    def run_sims_sequential(df, times, tasks, n_sim, tempdir):

        paths_sims = [
            simulate(df.copy(), times, tasks, i_sim, tempdir)
            for i_sim in range(n_sim)
        ]
        return paths_sims

    # Instantiate our transformers
    transformers = [
        Transformer(name, spec) for name, spec in spec_transforms.items()
    ]
    # Instantiate our models
    models = [
        Model(name, spec, estimators) for name, spec in spec_models.items()
    ]

    times_train = range(times["train"]["start"], times["train"]["end"] + 1)
    times_sim = range(times["sim"]["start"], times["sim"]["end"] + 1)
    tasks = order_tasks_by_sim_order(sim_order, transformers, models)
    df = start_tasks(df, tasks, times_train)
    print(datautils.get_share_missing_str(df))
    # Create a temporary directory to write our simulations into
    with tempfile.TemporaryDirectory() as tempdir:
        paths_sims = run_sims_parallel(df, times_sim, tasks, n_sim, tempdir)
        df_aggregates = agg.aggregate(paths_sims, stats=spec_stats)

        if dir_sims:
            for path_sim in paths_sims:
                pyutils.copy_file_to_dir(path_sim, dir_sims)

    if dir_task_pickles:
        for task in tasks:
            fname = f"{task.name}.pickle"
            path_pickle = os.path.join(dir_task_pickles, fname)
            joblib.dump(task, path_pickle)
            Logger.info(f"Stored {path_pickle}")

    return df_aggregates
