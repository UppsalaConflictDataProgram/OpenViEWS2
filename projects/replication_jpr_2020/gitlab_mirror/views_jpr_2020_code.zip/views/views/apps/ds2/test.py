import logging
import numpy as np

from sklearn.ensemble import RandomForestClassifier

from views.apps.ds2 import ds, wrappers
from views.utils import datautils, pyutils, dbutils

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)


def main():

    n_t = 36
    n_groups = 1000
    df = datautils.DfMocker(n_groups=n_groups, n_t=n_t, n_cols=10).df
    df.loc[1, "b_a"] = np.nan

    df["time_since_b_a"] = wrappers.time_since_previous_event(df, cols=["b_a"])
    df["b_a_1"] = df["b_a"]
    df["b_a_2"] = df["b_a"]
    df["b_a_3"] = df["b_a"]

    df["intercept"] = 1

    spec = pyutils.load_yaml("spec_test.yaml")

    # A pre-trained estimator
    pt_rf = RandomForestClassifier(n_estimators=5)
    data = df[["p_a", "time_since_b_a", "b_a"]].dropna()
    pt_rf.fit(X=data[["p_a", "time_since_b_a"]], y=data["b_a"])

    # An instantiated but untrained estimator
    inst_rf = RandomForestClassifier(n_estimators=11)

    estimators = wrappers.ESTIMATORS
    estimators["pt_rf"] = pt_rf
    estimators["inst_rf"] = inst_rf

    df_aggregates = ds.dynasim(df, **spec, estimators=estimators)
    for col in df_aggregates:
        print(df_aggregates[col])
    # datautils.write_parquet(df_aggregates, path="df_agg.parquet")


if __name__ == "__main__":
    main()
