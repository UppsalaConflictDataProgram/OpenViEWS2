import warnings
import logging

import numpy as np
from views.utils import datautils

Logger = logging.getLogger(__name__)


class Model:
    """ Model wrapper for dynasim """

    def __init__(self, name, spec, estimators):
        self.name = name
        self.cols_features = spec["cols_features"]
        self.col_outcome = spec["col_outcome"]
        self.colname = self.col_outcome

        self._set_estimator(
            spec_estimator=spec["estimator"], estimators=estimators
        )

    def _set_estimator(self, spec_estimator, estimators):
        """ sets self.estimator and self.fitted """

        spec = spec_estimator

        # Assert we have name and type
        required = ["name", "type"]
        for key in required:
            if not key in spec_estimator.keys():
                msg = f"{key} is required but missing in {spec_estimator}"
                raise KeyError(msg)

        # Assert type is either class or instance
        if spec["type"] not in ["class", "instance"]:
            msg = f"estimator type must be class or instance {spec['type']}"
            raise RuntimeError(msg)

        # Make sure the name exists in estimators
        if not spec["name"] in estimators.keys():
            msg = f"{spec['name']} doesn't exist in {estimators.keys()}"
            raise KeyError(msg)

        # If type is class, instantiate with kwargs
        if spec["type"] == "class":
            kwargs = dict()
            if "kwargs" in spec.keys():
                kwargs = spec["kwargs"]
            self.estimator = estimators[spec["name"]](**kwargs)

        # If type is instance we don't instantiate and ignore kwargs
        elif spec["type"] == "instance":
            self.estimator = estimators[spec["name"]]

            msg = f"kwargs passed but ignored because type=instance"
            if "kwargs" in spec.keys():
                warnings.warn(msg)

        # Default to self.fitted=False if fitted not in spec
        if "fitted" in spec.keys():
            self.fitted = spec["fitted"]
        else:
            self.fitted = False

    def _train(self, data, times):
        all_cols = self.cols_features + [self.col_outcome]
        data = data.loc[times, all_cols].dropna()
        X = data[self.cols_features]
        y = data[self.col_outcome]
        self.estimator.fit(X, y)

    def _predict_proba(self, X, sim):
        try:
            p_y_1 = self.estimator.predict_proba(X, sim)[:, 1]
        except TypeError:
            p_y_1 = self.estimator.predict_proba(X)[:, 1]
        return p_y_1

    def _predict_rand_threshold(self, X, sim):
        """ Predict boolean with random treshold """
        p_y_1 = self._predict_proba(X, sim)
        n = len(p_y_1)
        thresholds = datautils.generate_probs(n=n, seed=sim, distribution="uniform")
        mask = p_y_1 > thresholds
        y = np.zeros(n)
        y[mask] = 1
        return y

    def _predict_real(self, X, sim):
        y = self.estimator.predict(X, sim)
        return y

    def _predict(self, data, sim):

        # Subset data to our features and drop rows w missing
        X = data[self.cols_features].dropna()
        if len(X) == 0:
            msg = (
                f"No data left to predict with after dropna(). "
                f"df shares missing: "
                f"{datautils.get_share_missing_str(data[self.cols_features])}"
            )
            raise RuntimeError(msg)

        # If estimator.predit_proba() available use that,
        if hasattr(self.estimator, "predict_proba"):
            y = self._predict_rand_threshold(X, sim)
        # else use estimator.predict()
        elif hasattr(self.estimator, "predict"):
            y = self._predict_real(X, sim)

        return y

    def tick(self, data, t, sim):
        """ Predict for this t

        Args:
            self:
            data: Dataframe of state
            t: integer time id
            sim: simulation number
        Returns:
            y: Array of predicted values

        """
        y = self._predict(data.loc[t], sim)
        # @TODO: Find out why this is necessary for SMOLS to work
        y = np.array(y)
        return y

    def start(self, data, times):
        """ Start the model by fitting to data if not fitted """
        if self.fitted:
            Logger.debug(f"{self.name} already fitted")
        else:
            Logger.debug(f"{self.name} not fitted, fitting now")
            self._train(data, times)
