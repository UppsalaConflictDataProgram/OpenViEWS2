""" Aggregation of simulations """

import logging
import tempfile
import os
import multiprocessing as mp
import psutil

import pandas as pd
import numpy as np
import scipy.stats as spstats
import h5py

from views.utils import datautils, pyutils

Logger = logging.getLogger(__name__)


class Statistic:
    """ Computes statistics across simulations in a 3d array """

    @staticmethod
    def _get_func(name_func):
        """ Get aggregation function by name """
        funcs = {
            "mean": np.mean,
            "variance": np.var,
            "skew": spstats.skew,
            "kurtosis": spstats.kurtosis,
            "percentile": np.percentile,
        }

        return funcs[name_func]

    def __init__(self, name, params):
        """ Init """
        self.name = name
        self.suffix = params["suffix"]
        self.func = Statistic._get_func(params["f"])

        # Put leftover args in self.kwargs to send to the func
        self.kwargs = {}
        taken = ["name", "suffix", "f"]
        for key, value in params.items():
            if key not in taken:
                self.kwargs[key] = value

    def compute(self, data, rows):
        return self.func(data[:, rows, :], axis=0, **self.kwargs)


def _get_aggregate(statistic, path_merged, index, columns):
    """ Compute a statistic over a 3d hdf5 array on disk
    Args:
        statistic: An instance of Statistic
        path_merged: Path to 3d hdf5 array
        index: A pandas dataframe index to apply to the output
        columns: A list of column names to apply to the output
    Returns:
        df: A dataframe
    """
    chunksize = 5000

    with h5py.File(path_merged, "r") as f:
        results = f["simulation_results"]

        n_rows, n_cols = results.shape[1], results.shape[2]
        output = np.empty((n_rows, n_cols))
        for rows in pyutils.chunker(range(n_rows), chunksize):
            output[rows, :] = statistic.compute(results, rows)

    df = pd.DataFrame(output, columns=columns, index=index)
    if statistic.suffix:
        df = df.add_suffix(statistic.suffix)

    return df


def aggregate(paths, stats, parallel=True):
    def make_placeholder_file(path_merged, shape):
        chunks = (1, shape[1], shape[2])
        with h5py.File(path_merged, "w") as f:
            result = f.create_dataset(
                "simulation_results",
                tuple(shape),
                dtype="float64",
                compression="lzf",
                chunks=chunks,
            )
        Logger.info(f"Wrote {path_merged}")

    def insert_results(path_merged, paths):
        with h5py.File(path_merged, "a") as f:
            result = f["simulation_results"]
            for i, path in enumerate(paths):
                df = datautils.load_parquet(path)
                result[i, :, :] = np.array(df.values, dtype=np.float64)
                Logger.info(f"Inserted {path}")

    def get_index_shape_columns(paths):
        df = datautils.load_parquet(paths[0])
        index = df.index
        columns = df.columns
        shape = list(df.values.shape)
        shape.insert(0, len(paths))
        return index, shape, columns

    index, shape, columns = get_index_shape_columns(paths)
    for name, value in stats.items():
        Logger.info(name, value)
    stats = [Statistic(name, value) for name, value in stats.items()]

    with tempfile.TemporaryDirectory() as tempdir:
        path_merged = os.path.join(tempdir, "merged.hdf5")
        make_placeholder_file(path_merged, shape)
        insert_results(path_merged, paths)

        if parallel:
            # Multi-core version
            with mp.Pool(processes=psutil.cpu_count(logical=False)) as pool:
                results = [
                    pool.apply_async(
                        _get_aggregate, (stat, path_merged, index, columns)
                    )
                    for stat in stats
                ]
                dfs_aggregates = [result.get() for result in results]
        else:
            # Single core version
            dfs_aggregates = [
                _get_aggregate(stat, path_merged, index, columns)
                for stat in stats
            ]

        df = datautils.merge_dfs(dfs_aggregates)

    return df
