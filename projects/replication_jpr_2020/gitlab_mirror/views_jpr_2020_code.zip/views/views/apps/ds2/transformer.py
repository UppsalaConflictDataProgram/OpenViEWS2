from views.apps.ds2 import wrappers


class Transformer:
    """ Transformers wrapper for dynasim """

    def __init__(self, name, spec):
        self.func = Transformer._get_func_by_name(spec["f"])
        self.name = name
        self.colname = name

        taken_keys = ["f"]
        try:
            self.cols = [spec["col"]]
            taken_keys.append("col")
        except KeyError:
            self.cols = spec["cols"]
            taken_keys.append("cols")

        # Collect all "leftover" kwargs in the spec to pass to funcs
        self.kwargs = {}
        for key in spec.keys():
            if not key in taken_keys:
                self.kwargs[key] = spec[key]

    @staticmethod
    def _get_func_by_name(f_name):
        """ Get transformer by name from wrappers module """
        return wrappers.FUNCS[f_name]

    def _select_cols(self):
        # If cols is single column, pass it to pandas as a single string
        # That way we get a Series for single-col transforms
        if len(self.cols) == 1:
            cols = self.cols[0]
        else:
            cols = self.cols
        return cols

    def _subset_data_start(self, data):
        # Return all data to start off
        return data

    def _subset_data_tick(self, data, t):
        # @TODO Compute start differently by transform type
        # For example, lags/moving average, etc should only get data it needs.
        # spatial distance only needs current time period, etc
        if "time" in self.kwargs:
            start = t - self.kwargs["time"]
        else:
            start = None
        return data.loc[start:t]

    def start(self, data):
        """ Start the transformer by computing it once """
        return self.func(
            df=self._subset_data_start(data), cols=self.cols, **self.kwargs
        )

    def tick(self, data, t, sim):
        """ Tick the transformer by computing it for this t """
        return self.func(
            df=self._subset_data_tick(data, t), cols=self.cols, **self.kwargs
        )
