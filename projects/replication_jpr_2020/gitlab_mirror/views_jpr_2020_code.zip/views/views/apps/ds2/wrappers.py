""" Wrappers for external modules to ds2.


# Transformations
In order to call all transformations with the same format of function
call this module wraps around the various transformations
available from the views.apps.transforms module and exposes them with
a common func(df, cols, **kwargs) interface.
This allows us to call all transformers with the same signature.

The need for this arises because geopandas-based transformations
also need the geometry column, which we don't want to pass around
explicitly. So it's easier to send the entire df.
cols as a list is chosen because some transformations work on a list
of columns, such as sums and products.

# Estimators
The ESTIMATORS dict provides sklearn compatible estimator objects
with the familiar .fit(), .predict() and .predict_proba() interfaces.
This includes wrappers for statsmodels Logit and OLS.

"""
import numpy as np
import statsmodels.api as sm
from views.apps.transforms import spatial, translib
from views.apps.estimators import estimators
from views.utils import statsutils


def summ(df, cols):
    return translib.sum(df[cols[0]])


def spdist(df, cols):
    return spatial.distance_to_event(df, event_col=cols[0])


def splag(df, cols, first, last):
    return spatial.spatial_lag(gdf=df, col=cols[0], first=first, last=last)


def ln(df, cols):
    return translib.ln(df[cols[0]])


def rollmax(df, cols, window):
    return translib.rollmax(df[cols[0]], window)


def demean(df, cols):
    return translib.demean(df[cols[0]])


def mean(df, cols):
    return translib.mean(df[cols[0]])


def decay(df, cols, halflife):
    return translib.decay(df[cols[0]], halflife)


def time_since_previous_event(df, cols, value=0, seed=None):
    return translib.time_since_previous_event(df[cols[0]], value, seed)


def cweq(df, cols, value, seed=None):
    return translib.cweq(df[cols[0]], value, seed)


def moving_average(df, cols, time):
    return translib.moving_average(df[cols[0]], time)


def tlead(df, cols, time):
    return translib.tlead(df[cols[0]], time)


def tlag(df, cols, time):
    return translib.tlag(df[cols[0]], time)


def delta(df, cols):
    return translib.delta(df[cols[0]])


def greq(df, cols, value):
    return translib.greater_or_equal(df[cols[0]], value)


class Logit:
    """ Statsmodels Logistic regression wrapper """

    def __init__(self, n_sim):
        self.model = None
        self.betas = None
        self.n_sim = n_sim
        self.fitted = False

    def _draw_betas(self):
        """ Create simulated coefficients """
        self.betas = np.random.multivariate_normal(
            mean=self.model.params, cov=self.model.cov_params(), size=self.n_sim
        )

    def fit(self, X, y):
        self.model = sm.Logit(y, X).fit()
        self._draw_betas()
        self.model.remove_data()  # Remove training data stored in self.model
        self.fitted = True

    def predict_proba(self, X, i_sim):
        """ Return array of probs for each case (y=0, y=1)

        This is for compat with multilevel classifiers and the
        sklearn interfaces predict_proba()

        """
        probs_1 = statsutils.logodds_to_prob(X.dot(self.betas[i_sim].T))
        probs_0 = 1 - probs_1
        probs = np.array([probs_0, probs_1]).T
        return probs


class OLS:
    """ Statsmodels Ordinary least squares wrapper """

    def __init__(self, n_sim):
        self.model = None
        self.betas = None
        self.n_sim = n_sim
        self.fitted = False

        self.summary_txt = None
        self.summary_tex = None

    def _draw_betas(self):
        self.betas = np.random.multivariate_normal(
            mean=self.model.params, cov=self.model.cov_params(), size=self.n_sim
        )

    def _set_var_residuals(self):
        self.var_residuals = np.var(
            a=self.model.resid, ddof=self.model.df_model
        )

    def fit(self, X, y):
        self.model = sm.OLS(y, X).fit()

        self.summary_txt = self.model.summary()
        self.summary_tex = self.model.summary().as_latex()

        self._draw_betas()
        self._set_var_residuals()
        self.model.remove_data()
        self.fitted = True

    def predict(self, X, i_sim):

        # Draw some residuals to include more uncertainty
        predicted_residuals = np.random.normal(
            loc=0, scale=np.sqrt(self.var_residuals), size=len(X)
        )
        # Draw a simulated coefficient
        beta = self.betas[i_sim].T

        y_hat = X.dot(beta) + predicted_residuals

        return y_hat


FUNCS = {
    "spdist": spdist,
    "ln": ln,
    "rollmax": rollmax,
    "demean": demean,
    "mean": mean,
    "decay": decay,
    "time_since_previous_event": time_since_previous_event,
    "cweq": cweq,
    "moving_average": moving_average,
    "tlead": tlead,
    "tlag": tlag,
    "delta": delta,
    "sum": summ,
    "greq": greq,
}

ESTIMATORS = {"SMLogit": Logit, "SMOLS": OLS}
# Load in the estimators exposed by views.apps.osa.estimators.ESTIMATORS
for key in estimators.ESTIMATORS.keys():
    ESTIMATORS[key] = estimators.ESTIMATORS[key]
