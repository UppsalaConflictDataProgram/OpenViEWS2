import logging
from sklearn.ensemble import RandomForestClassifier

from views.apps.ds2 import ds, wrappers
from views.utils import datautils, pyutils, dbutils

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)


def main():

    # df = datautils.load_parquet(
    #     path=pyutils.resole_vars_and_home(
    #         "~/views/test/runs/models_pgm_v01/datasets/pgm_africa_0_A_predict.parquet"
    #     ),
    #     cols=["ged_dummy_sb"],
    # )
    df = dbutils.db_to_df(
        fqtable="preflight.flight_pgm",
        columns=["ged_dummy_sb"],
        ids=["month_id", "pg_id"],
    )
    gdf = dbutils.db_to_gdf(
        query="SELECT gid AS pg_id, geom FROM staging.priogrid",
        groupvar="pg_id",
    )
    df = gdf.join(df)
    df = df.dropna()
    df = df.loc[121:337]
    print("data joined")

    # Pre-compute training vars
    df["time_since_ged_dummy_sb"] = wrappers.time_since_previous_event(
        df, cols=["ged_dummy_sb"]
    )
    df["tlag_1_ged_dummy_sb"] = wrappers.time_since_previous_event(
        df, cols=["ged_dummy_sb"]
    )
    df["spdist_tlag_1_ged_dummy_sb"] = wrappers.time_since_previous_event(
        df, cols=["tlag_1_ged_dummy_sb"]
    )

    spec = pyutils.load_yaml("spec_db.yaml")

    # Clone the outcome cols for
    df["pt_rf_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["inst_rf_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["logit_ged_dummy_sb"] = df["ged_dummy_sb"]
    df["ols_ged_dummy_sb"] = df["ged_dummy_sb"]

    print("training")
    # A pre-trained estimator
    pt_rf = RandomForestClassifier(n_estimators=2)
    cols_pt_rf = [
        "tlag_1_ged_dummy_sb",
        "time_since_ged_dummy_sb",
        "spdist_tlag_1_ged_dummy_sb",
    ]
    data_train = df.loc[121:432, cols_pt_rf + ["ged_dummy_sb"]].dropna()
    pt_rf.fit(X=data_train[cols_pt_rf], y=data_train["ged_dummy_sb"])

    # An instantiated but untrained estimator
    inst_rf = RandomForestClassifier(n_estimators=2)

    estimators = wrappers.ESTIMATORS
    estimators["pt_rf"] = pt_rf
    estimators["inst_rf"] = inst_rf
    print(datautils.get_share_missing_str(df))
    print(df)
    for col in df:
        print(df[col])
    df_aggregates = ds.dynasim(df, **spec, estimators=estimators)
    for col in df_aggregates:
        print(df_aggregates[col])
    # datautils.write_parquet(df_aggregates, path="df_agg.parquet")


if __name__ == "__main__":
    main()
