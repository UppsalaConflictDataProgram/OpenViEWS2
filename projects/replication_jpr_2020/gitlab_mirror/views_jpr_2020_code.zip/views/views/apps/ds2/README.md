# Dynasim 2

This is a rewrite of dynasim, the dynamic simulation forecating program.

## New features

This rewrite brings in some new features:

* Flexible simulation order: transformers and models can be ordered arbitrarily in the simulation through the sim_order argument, allowing for chained models or transforms.
* More transformations: spatial distance to event, spatial lag, spacetime distance to event, demean, rollmax, deltas.
* Simplified interface for adding new transformers through wrappers.FUNCS
* Ability to use arbitrary prediction models, the user can pass in a class or instance with a .predict(data) or predict_proba(data) method and dynasim can use it in the simulations. Pre-fitted models can also be used to save on training time.
* Fewer dependencies, no longer includes MPI. By removing MPI the codebase has shrunk in size and made it easier to maintain, debug and reason about.

## Usage

All access happens through the views.apps.ds2.ds.dynasim() function.
See ds2/test.py for example usage.

## Todo:

* Improve this document.
* Test coverage
* Example usage notebook
* Multiprocessing simulations: Something about the statsmodels logistic regression causes simulations to stall when run in a multiprocessing pool.
