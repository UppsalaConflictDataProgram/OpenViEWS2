""" Imputation of missing data

Currently two methods of imputation are supported, Amelia and MICE.

"""
import logging
import os
import string
import tempfile

import numpy as np
import pandas as pd

from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer

from views.utils import pyutils, datautils, config

Logger = logging.getLogger(__name__)


def _get_skeleton_copy(df):
    """ Get a skeleton df with only index and colnames but all values NaN """

    df_skeleton = df.copy()
    df_skeleton[df.columns] = np.nan

    return df_skeleton


def _fill_iterative(df, seed=1, max_iter=10):
    """ Gets a single imputation using IterativeImputer from sklearn.

    Uses BayesianRidge() from sklearn.

    Changed default of sample_posterior to True as we're doing
    multiple imputation.

    Clips imputed values to min-max of observed values to avoid
    brokenly large values. When imputation model doesn't converge
    nicely we otherwise end up with extreme values that are out of
    range of the float32 type used by model training, causing crashes.
    Consider this clipping a workaround until a more robust imputation
    strategy is in place.

    """
    Logger.info("Started _fill_iterative()")
    Logger.info(f"seed: {seed}")
    Logger.info(f"n_rows: {len(df)}")
    Logger.info(f"n_cols: {len(df.columns)}")
    Logger.info(f"Share missing: {datautils.share_obs_missing(df)}")

    # Only impute numberic cols
    cols_numeric = list(df.select_dtypes(include=[np.number]).columns.values)
    cols_not_numeric = [col for col in df.columns if not col in cols_numeric]

    # Get bounds so we can clip imputed values to not be outside
    # observed values
    observed_min = df[cols_numeric].min()
    observed_max = df[cols_numeric].max()

    df_imputed = _get_skeleton_copy(df)
    df_imputed[cols_numeric] = IterativeImputer(
        random_state=seed, max_iter=max_iter, sample_posterior=True
    ).fit_transform(df[cols_numeric])
    df_imputed[cols_not_numeric] = df[cols_not_numeric]

    # Clip imputed values to observed min-max range
    df_imputed[cols_numeric] = df_imputed[cols_numeric].clip(
        observed_min, observed_max, axis=1
    )

    Logger.info("Finished _fill_iterative()")

    return df_imputed


# pylint: disable=too-many-locals
def impute_amelia(df, n_imp):
    """ Wrapper for calling Amelia in an R subprocess

    Args:
        df: Dataframe with MultiIndex set
        n_imp: Number of imputations to perform
    Return:
        dfs: List of imputed dataframes
    """

    def read_template():
        this_dir = os.path.dirname(os.path.abspath(__file__))
        path_template = os.path.join(this_dir, "amelia_template.R")
        with open(path_template, "r") as f:
            template_str = f.read()

        template = string.Template(template_str)

        return template

    Logger.info("Started impute_amelia()")

    datautils.assert_df_has_multiindex(df)
    timevar, groupvar = df.index.names

    Logger.info(f"n_imp: {n_imp}")
    Logger.info(f"timevar: {timevar}")
    Logger.info(f"groupvar: {groupvar}")
    Logger.info(f"n_rows: {len(df)}")
    Logger.info(f"n_cols: {len(df.columns)}")
    Logger.info(f"Share missing: {datautils.share_obs_missing(df)}")

    with tempfile.TemporaryDirectory() as tempdir:

        path_csv_in = os.path.join(tempdir, "input.csv")
        path_rscript = os.path.join(tempdir, "impute_script.R")
        path_out_stem = os.path.join(tempdir, "imputed_")

        values = {
            "CRAN_REPO": config.CONFIG["R"]["cran_repo"],
            "PATH_CSV_INPUT": path_csv_in,
            "PATH_CSV_OUTPUT_STEM": path_out_stem,
            "TIMEVAR": timevar,
            "GROUPVAR": groupvar,
            "N_IMP": n_imp,
            "N_CPUS": n_imp,
        }

        template = read_template()
        rscript = template.substitute(values)

        df.to_csv(path_csv_in, index=True)
        Logger.info(f"Wrote {path_csv_in}")

        with open(path_rscript, "w") as f:
            f.write(rscript)
        Logger.info(f"Wrote {path_rscript}")
        Logger.debug(rscript)

        cmd = ["Rscript", path_rscript]
        pyutils.run_subproc(cmd)

        dfs = []
        for i in range(n_imp):
            path_imputed = f"{path_out_stem}{i+1}.csv"
            df_imp = pd.read_csv(path_imputed)
            df_imp = df_imp.drop(columns=["Unnamed: 0"])
            df_imp = df_imp.set_index([timevar, groupvar])
            dfs.append(df_imp)
            Logger.info(f"Read {path_imputed}")

    Logger.info("Finished impute_amelia()")
    return dfs


def impute_mice(df, n_imp):
    """ Impute df with MICE """

    Logger.info(f"Starting impute_mice()")
    Logger.info(f"n_imp: {n_imp}")
    dfs = []
    for imp in range(n_imp):
        Logger.info(f"Starting imp {imp}")
        dfs.append(_fill_iterative(df, seed=imp))

    return dfs


def impute_mice_generator(df, n_imp):
    """ Impute df with MICE """

    Logger.info(f"Starting impute_mice_generator()")
    Logger.info(f"n_imp: {n_imp}")
    for imp in range(n_imp):
        Logger.info(f"Starting imp {imp}")
        yield _fill_iterative(df, seed=imp)
