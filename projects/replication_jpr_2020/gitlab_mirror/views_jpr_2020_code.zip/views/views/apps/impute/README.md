# Impute

This module contains code for imputation of missing data.
There are a few libraries available for missing data imputation.

## Python - Fancyimpute - IterativeImputer, formerly MICE

Fancyimpute offers several methods for imputation of missing data.
I have only focused on IterativeImputer, AKA MICE, as it allows multiple imputation
by passing a random state seed.

Other methods available are:

* KNN, sometimes fail to fill values, leaving them NaN
* NuclearNormMinimization, very very slow
* Softimpute, rescales data I think?
* BiScaler, rescales data I think?
* IterativeSVD, rescales data I think?
* SimpleFill, too naive.

I haven't properly explored the other options but at first glance they seem not
appropriate due to reasons noted above.

## R - Amelia

