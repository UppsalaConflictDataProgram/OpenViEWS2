""" Specification to task solver module

The module takes human-writable specification files and produces
task definitions that are explicit in the work to be done.

Using the solver starts by reading humna-written specifications from a
file.
The solver then creates definitions, defis for short, that contain
solved mappings such as:

* Defining each column for each dataset.
* Defining each model training for each dataset
* Solving nested column sets
* Etc

These defis are then used to create tasks that are explicit and
machine-executable.

TODO:
* Move all specs needed by tasks into defis so tasks don't
  have to read specs, only defis.
* Add assert for steplength and prediction window length
* Fix crash on mixed colsets and columns in colsets (mixed nested crash)

"""

# pylint: disable=redefined-outer-name

from views.apps.defparser import names
from views.utils import pyutils


def defis_cols(specs):
    """ Create column definitions """

    def cols_sources(specs):

        spec_sources = specs["cols_source"]

        cols_sources = {}
        for col in spec_sources:
            cols_sources[col] = "source"

        return cols_sources

    def cols_transforms(specs):

        spec_transforms = specs["transforms"]

        cols_transforms = {}
        for transform in spec_transforms:
            cols_transforms[transform] = "transforms"

        return cols_transforms

    cols_defis = {}
    cols_defis.update(cols_sources(specs))
    cols_defis.update(cols_transforms(specs))

    return cols_defis


def defis_colsets(defis, specs):
    """ Create column-set definitions """

    def get_cols_from_colset(colset, specs_colsets, defis_cols):
        """ Get all cols for a colset, including references

        Recursively looks up each reference in a colset in both the dict
        of other colsets and in dict of columns.

        Returns:
            cols_this_colset: list of cols referenced by this colset
        """

        def check_not_duplicate_ref(member, specs_colsets, defis_cols):
            if member in specs_colsets and member in defis_cols:
                msg = (
                    f"Duplicate reference found. "
                    f'"{member}" is defined as both a colset and a col'
                )
                raise RuntimeError(msg)

        cols_this_colset = []
        for member in specs_colsets[colset]:
            check_not_duplicate_ref(member, specs_colsets, defis_cols)

            if member in specs_colsets:
                cols_this_colset.append(
                    get_cols_from_colset(member, specs_colsets, defis_cols)
                )
            elif member in defis_cols:
                cols_this_colset.append(member)
            else:
                raise RuntimeError(f"Unresolved ref {member}")

        return sorted(
            pyutils.dedup_list(
                pyutils.flatten_list(cols_this_colset, warn_not_nested=False)
            )
        )

    defis_cols = defis["cols"]
    specs_colsets = specs["colsets"]

    defis_colsets = {}
    for colset in specs_colsets:
        defis_colsets[colset] = get_cols_from_colset(
            colset, specs_colsets, defis_cols
        )

    return defis_colsets


# pylint: disable=too-many-locals
def defis_datasets(specs):
    """ Create dataset definitions """

    def times(specs, period, slot):
        periods_specs = specs["periods"]
        times = periods_specs[period][slot]
        return times

    def match_table(loa, imp, geo, tables):

        matches = []
        for table_name, table_spec in tables.items():
            match = (
                table_spec["loa"] == loa
                and table_spec["imp"] == imp
                and table_spec["geo"] == geo
            )
            if match:
                matches.append(table_name)

        if len(matches) == 1:
            return matches[0]
        else:
            msg = (
                f"Didn't find ONE table matching"
                f"loa: {loa}, imp: {imp}, geo: {geo}"
            )
            raise RuntimeError(msg)

    loa = specs["loa"]
    geos = specs["geos"]
    imps = specs["imps"]
    periods = specs["periods"]
    tables = specs["tables"]

    cols_source = specs["cols_source"]

    defis_datasets = {}
    for geo in geos:
        for imp in imps:
            for period in periods:
                for slot in periods[period]:
                    defi = {
                        "loa": loa,
                        "geo": geo,
                        "imp": imp,
                        "period": period,
                        "slot": slot,
                        "cols_source": cols_source,
                        "table": match_table(loa, imp, geo, tables),
                        "times": times(specs, period, slot),
                    }
                    name = names.dataset(loa, geo, imp, period, slot)
                    defis_datasets[name] = defi

    return defis_datasets


def defis_datacols(defis):
    """ Create datacol definitions """

    datasets = defis["datasets"]
    cols = defis["cols"]

    datacols = {}
    for dataset in datasets:
        for col in cols:
            name = names.defi_datacol(dataset, col)
            datacol = {
                "colname": col,
                "datasource": cols[col],
                "dataset": dataset,
            }
            datacols[name] = datacol

    return datacols


def defis_models(specs):
    """ Create model definitions """

    formulas = specs["formulas"]
    estimators = specs["estimators"]
    shiftmaps = specs["shiftmaps"]
    stepsets = specs["stepsets"]

    defis_models = {}
    for formula in formulas:
        for estimator in estimators:
            for shiftmap in shiftmaps:
                for stepset in stepsets:
                    defi = {
                        "formula": formula,
                        "estimator": estimator,
                        "shiftmap": shiftmap,
                        "stepset": stepset,
                    }
                    name = names.model(**defi)
                    defis_models[name] = defi
    return defis_models


def defis_trains(defis, specs):
    """ Create trains definitions

    Trains are the actual training of a model for a certain OSA-step
    """

    def get_stepset_spec(model, defis, specs):
        defi_model = defis["models"][model]
        stepset = defi_model["stepset"]
        stepset_spec = specs["stepsets"][stepset]

        return stepset_spec

    datasets = defis["datasets"]
    models = defis["models"]

    # Only produce trains for datasets with slot == "train"
    datasets = {
        k: datasets[k]
        for k in datasets.keys()
        if datasets[k]["slot"] == "train"
    }

    defis_trains = {}
    for dataset in datasets:
        for model in models:
            stepset_spec = get_stepset_spec(model, defis, specs)
            for step in stepset_spec:
                train = {"dataset": dataset, "model": model, "step": step}
                name = names.defi_train(**train)
                defis_trains[name] = train
    return defis_trains


# pylint: disable=too-many-boolean-expressions, too-many-locals


def defis_dataset_predict_train_siblings(defis):
    """ Get a mapping between predict:train dataset siblings

    The mapping is achievied by comparing all dataset properties.
    Slot does not match and slot of the key dataset is "predict"
    """

    predict_train_maps = {}
    for name, dataset_defi in defis["datasets"].items():

        loa = dataset_defi["loa"]
        geo = dataset_defi["geo"]
        imp = dataset_defi["imp"]
        period = dataset_defi["period"]
        slot = dataset_defi["slot"]

        items = defis["datasets"].items()
        for name_sibling, dataset_defi_sibling in items:

            loa_sibling = dataset_defi_sibling["loa"]
            geo_sibling = dataset_defi_sibling["geo"]
            imp_sibling = dataset_defi_sibling["imp"]
            period_sibling = dataset_defi_sibling["period"]
            slot_sibling = dataset_defi_sibling["slot"]

            if (
                loa == loa_sibling
                and geo == geo_sibling
                and imp == imp_sibling
                and period == period_sibling
                and not slot == slot_sibling
                and slot == "predict"
            ):

                predict_train_maps[name] = name_sibling

    return predict_train_maps


def defis_predicts_memt(defis):
    """ Multiple Estimators Many Times """

    models = defis["models"]
    datasets = defis["datasets"]
    trains = defis["trains"]
    dataset_predict_train_siblings = defis["predict_train_siblings"]

    datasets_predict = {
        k: datasets[k]
        for k in datasets.keys()
        if datasets[k]["slot"] == "predict"
    }

    defis_predicts = {}
    for dataset in datasets_predict:
        for model in models:
            name = names.defi_predict_memt(dataset, model)
            dataset_train = dataset_predict_train_siblings[dataset]

            # Select the trains for this model and dataset_train
            these_trains = [
                k
                for k in trains.keys()
                if trains[k]["dataset"] == dataset_train
                and trains[k]["model"] == model
            ]

            # Create a step: train map
            step_train_map = {}
            for train in these_trains:
                step_train_map[trains[train]["step"]] = train

            defi = {
                "trains": step_train_map,
                "dataset": dataset,
                "model": model,
            }
            defis_predicts[name] = defi

    return defis_predicts


def defis_predicts_semt(defis):
    """ Single Estimator Many Times """

    models = defis["models"]
    datasets = defis["datasets"]
    trains = defis["trains"]
    dataset_predict_train_siblings = defis["predict_train_siblings"]

    datasets_predict = {
        k: datasets[k]
        for k in datasets.keys()
        if datasets[k]["slot"] == "predict"
    }

    defis_predicts = {}
    for dataset in datasets_predict:

        for model in models:
            dataset_train = dataset_predict_train_siblings[dataset]

            # Select the trains for this model and dataset_train
            these_trains = [
                k
                for k in trains.keys()
                if trains[k]["dataset"] == dataset_train
                and trains[k]["model"] == model
            ]
            for train in these_trains:
                step = trains[train]["step"]
                name = names.defi_predict_semt(dataset, model, step)

                # Create a step: train map
                step_train_map = {}
                step_train_map[step] = train

                defi = {
                    "trains": step_train_map,
                    "dataset": dataset,
                    "model": model,
                }
                defis_predicts[name] = defi

    return defis_predicts


def defis_estimators(specs):
    """ Definitions of estimators """

    def solve_pipeline(estimator, specs_estimators):
        """ Build pipeline defi as a dict with steps as list of dicts"""
        pipeline_steps = []
        # Steps in spec are given as name references to other estimators
        step_name_referenes = estimator["steps"]
        for step_name in step_name_referenes:
            this_step = {}
            this_step[step_name] = specs_estimators[step_name]
            pipeline_steps.append(this_step)
        pipeline_defi = {"estimator": "Pipeline", "steps": pipeline_steps}
        return pipeline_defi

    specs_estimators = specs["estimators"]

    defis_estimators = {}
    for estimator_name, estimator in specs_estimators.items():

        if estimator["estimator"] == "Pipeline":
            pipeline_defi = solve_pipeline(estimator, specs_estimators)
            defis_estimators[estimator_name] = pipeline_defi

        else:
            defis_estimators[estimator_name] = estimator

    return defis_estimators


def defis(specs):
    """ Create all definitions """
    defis = {}
    defis["datasets"] = defis_datasets(specs)
    defis["models"] = defis_models(specs)
    defis["cols"] = defis_cols(specs)
    defis["trains"] = defis_trains(defis, specs)
    defis["colsets"] = defis_colsets(defis, specs)
    defis["predict_train_siblings"] = defis_dataset_predict_train_siblings(
        defis
    )
    defis["predicts_memt"] = defis_predicts_memt(defis)
    defis["predicts_semt"] = defis_predicts_semt(defis)
    defis["datacols"] = defis_datacols(defis)
    defis["estimators"] = defis_estimators(specs)
    return defis


def tasks_trains(defis, specs):
    """ Create trains tasks """

    def task(train, defis, specs):
        def get_formula_spec(train, defis, specs):
            train_defi = defis["trains"][train]
            model = train_defi["model"]
            model_def = defis["models"][model]
            formula = model_def["formula"]
            formula_spec = specs["formulas"][formula]
            return formula_spec

        def lhs(train, defis, specs):
            formula_spec = get_formula_spec(train, defis, specs)
            lhs = formula_spec["lhs"]
            return lhs

        def rhs(train, defis, specs):
            formula = get_formula_spec(train, defis, specs)
            rhs_colset = formula["rhs"]
            rhs_cols = defis["colsets"][rhs_colset]
            return rhs_cols

        def estimator(train, defis):
            train_defi = defis["trains"][train]
            model = train_defi["model"]
            model_defi = defis["models"][model]
            estimator = model_defi["estimator"]
            estimator_defi = defis["estimators"][estimator]
            return estimator_defi

        def step(train, defis):
            train_defi = defis["trains"][train]
            step = train_defi["step"]
            return step

        def dataset(train, defis):
            train_defi = defis["trains"][train]
            dataset = train_defi["dataset"]
            return dataset

        def shiftmap(train, defis, specs, rhs):
            train_defi = defis["trains"][train]
            model = train_defi["model"]
            model_defi = defis["models"][model]
            shiftmap_name = model_defi["shiftmap"]
            shiftmap_spec = specs["shiftmaps"][shiftmap_name]

            colset_shift = shiftmap_spec[True]
            colset_noshift = shiftmap_spec[False]

            cols_shift = defis["colsets"][colset_shift]
            cols_noshift = defis["colsets"][colset_noshift]

            cols_shift = [col for col in cols_shift if col in rhs]
            cols_noshift = [col for col in cols_noshift if col in rhs]

            shiftmap = {"shift": cols_shift, "noshift": cols_noshift}
            return shiftmap

        def deps(dataset, lhs, rhs):
            deps = []

            cols = [lhs, *rhs]
            cols = sorted(cols)
            cols = pyutils.dedup_list(cols)
            for col in cols:
                deps.append(names.defi_datacol(dataset, col))

            return deps

        lhs = lhs(train, defis, specs)
        rhs = rhs(train, defis, specs)
        estimator = estimator(train, defis)
        step = step(train, defis)
        dataset = dataset(train, defis)
        shiftmap = shiftmap(train, defis, specs, rhs)
        deps = deps(dataset, lhs, rhs)

        source = train

        task = {
            "name_run": specs["name"],
            "task_type": "train",
            "defi": source,
            "dataset": dataset,
            "lhs": lhs,
            "rhs": rhs,
            "estimator": estimator,
            "step": step,
            "shiftmap": shiftmap,
            "deps": deps,
        }

        return task

    tasks = {}
    for train in defis["trains"]:
        name = train
        tasks[name] = task(train, defis, specs)

    return tasks


def tasks_predicts(defis, specs):
    """ Create prediction tasks """

    def task(predict, defis, specs, defis_predict_key):
        def dataset(predict, defis):
            return defis[defis_predict_key][predict]["dataset"]

        def model(predict, defis):
            return defis[defis_predict_key][predict]["model"]

        def get_formula_spec(predict, defis, specs):
            predict_defi = defis[defis_predict_key][predict]
            model = predict_defi["model"]
            model_def = defis["models"][model]
            formula = model_def["formula"]
            formula_spec = specs["formulas"][formula]
            return formula_spec

        def rhs(predict, defis, specs):
            formula = get_formula_spec(predict, defis, specs)
            rhs_colset = formula["rhs"]
            rhs_cols = defis["colsets"][rhs_colset]
            return rhs_cols

        def shiftmap(predict, defis, specs, rhs):
            predict_defi = defis[defis_predict_key][predict]
            model = predict_defi["model"]
            model_defi = defis["models"][model]
            shiftmap_name = model_defi["shiftmap"]
            shiftmap_spec = specs["shiftmaps"][shiftmap_name]

            colset_shift = shiftmap_spec[True]
            colset_noshift = shiftmap_spec[False]

            cols_shift = defis["colsets"][colset_shift]
            cols_noshift = defis["colsets"][colset_noshift]

            cols_shift = [col for col in cols_shift if col in rhs]
            cols_noshift = [col for col in cols_noshift if col in rhs]

            shiftmap = {"shift": cols_shift, "noshift": cols_noshift}
            return shiftmap

        def trains(predict, defis):
            predict_defi = defis[defis_predict_key][predict]
            trains = predict_defi["trains"]
            return trains

        def deps(dataset, rhs, trains):
            """ Predicts depend on the dataset, trains and rhs vars """

            deps = []

            # rhs cols
            for col in rhs:
                deps.append(names.defi_datacol(dataset, col))

            # trains
            for train in trains.values():
                deps.append(train)

            # dataset
            deps.append(dataset)

            return deps

        def times(dataset, defis):
            times = defis["datasets"][dataset]["times"]
            return times

        dataset = dataset(predict, defis)
        times = times(dataset, defis)
        model = model(predict, defis)
        rhs = rhs(predict, defis, specs)
        shiftmap = shiftmap(predict, defis, specs, rhs)
        source = predict
        trains = trains(predict, defis)
        deps = deps(dataset, rhs, trains)

        task = {
            "name_run": specs["name"],
            "dataset": dataset,
            "model": model,
            "rhs": rhs,
            "shiftmap": shiftmap,
            "defi": source,
            "trains": trains,
            "deps": deps,
            "times": times,
        }

        return task

    predicts_memt = defis["predicts_memt"]
    predicts_semt = defis["predicts_semt"]
    tasks_predicts = {}
    for predict in predicts_memt:
        this_task = task(predict, defis, specs, "predicts_memt")
        this_task["task_type"] = "predict_memt"
        this_task["colname"] = names.colname_predict_memt(this_task["model"])
        tasks_predicts[predict] = this_task.copy()

    for predict in predicts_semt:
        this_task = task(predict, defis, specs, "predicts_semt")
        this_task["task_type"] = "predict_semt"
        this_task["colname"] = names.colname_predict_semt(
            this_task["model"], step=list(this_task["trains"].keys())[0]
        )
        tasks_predicts[predict] = this_task.copy()

    return tasks_predicts


def tasks_datasets(defis, specs):
    """ Create dataset creation tasks """

    def task(dataset, defis, specs):
        def loa(dataset, defis):
            return defis["datasets"][dataset]["loa"]

        def geo(dataset, defis):
            return defis["datasets"][dataset]["geo"]

        def imp(dataset, defis):
            return defis["datasets"][dataset]["imp"]

        def period(dataset, defis):
            return defis["datasets"][dataset]["period"]

        def slot(dataset, defis):
            return defis["datasets"][dataset]["slot"]

        def times(dataset, defis):
            times = defis["datasets"][dataset]["times"]
            return times

        def timevar(specs):
            timevar = specs["timevar"]
            return timevar

        def groupvar(specs):
            groupvar = specs["groupvar"]
            return groupvar

        def deps():
            deps = []
            return deps

        def cols_source(dataset, defis):
            cols_source = defis["datasets"][dataset]["cols_source"]
            return cols_source

        def table(dataset, defis):
            table = defis["datasets"][dataset]["table"]
            return table

        period = period(dataset, defis)
        slot = slot(dataset, defis)
        times = times(dataset, defis)

        task = {
            "name_run": specs["name"],
            "task_type": "dataset",
            "defi": dataset,
            "loa": loa(dataset, defis),
            "geo": geo(dataset, defis),
            "imp": imp(dataset, defis),
            "period": period,
            "slot": slot,
            "times": times,
            "groupvar": groupvar(specs),
            "timevar": timevar(specs),
            "deps": deps(),
            "cols_source": cols_source(dataset, defis),
            "table": table(dataset, defis),
        }

        return task

    datasets = defis["datasets"]
    tasks_datasets = {}
    for dataset in datasets:
        tasks_datasets[dataset] = task(dataset, defis, specs)

    return tasks_datasets


def tasks_datacols(defis, specs):
    """ Create datacol tasks """

    def task(datacol, defis, specs):
        def col(datacol, defis):
            return defis["datacols"][datacol]["colname"]

        def datasource(datacol, defis):
            return defis["datacols"][datacol]["datasource"]

        def dataset(datacol, defis):
            return defis["datacols"][datacol]["dataset"]

        def work(specs, datasource, col):
            if datasource == "transforms":
                specs_transforms = specs["transforms"]
                work = specs_transforms[col]
            elif datasource == "source":
                work = {"f": "load_source"}
            else:
                raise RuntimeError(f"Unrecognised datasource {datasource}")
            return work

        def deps(datacol, datasource, dataset, work):
            def deps_transforms(work):
                deps = []

                if "col" in work["params"].keys():
                    col = work["params"]["col"]
                    deps.append(names.defi_datacol(dataset, col))
                elif "cols" in work["params"].keys():
                    cols = work["params"]["cols"]
                    for col in cols:
                        deps.append(names.defi_datacol(dataset, col))

                return deps

            if datasource == "transforms":
                deps = deps_transforms(work)
            elif datasource == "source":
                deps = [dataset]
            else:
                msg = f"Unrecognised datasource: {datasource} for {datacol}"
                raise RuntimeError(msg)
            return deps

        datasource = datasource(datacol, defis)
        col = col(datacol, defis)
        work = work(specs, datasource, col)
        dataset = dataset(datacol, defis)
        deps = deps(datacol, datasource, dataset, work)

        task = {
            "name_run": specs["name"],
            "task_type": "datacol",
            "defi": datacol,
            "colname": col,
            "datasource": datasource,
            "dataset": dataset,
            "work": work,
            "deps": deps,
        }

        return task

    datacols = defis["datacols"]
    tasks_datacols = {}
    for datacol in datacols:
        tasks_datacols[datacol] = task(datacol, defis, specs)

    return tasks_datacols


def tasks_geometry(specs):
    """ Create geometry tasks """

    def groupvar(specs):
        return specs["groupvar"]

    task_geom = {
        "name_run": specs["name"],
        "query": specs["geometry"]["query"],
        "task_type": "geometry",
        "groupvar": groupvar(specs),
        "deps": [],  # No deps, always run first
    }

    tasks_geom = {"geometry": task_geom}

    return tasks_geom


def tasks_evals(defis, specs, tasks):
    """ Create evaluation tasks for each predict """

    # @TODO: Look for predict tasks
    # pylint: disable=unused-argument
    def task(name_predict, task_predict, defis, specs, tasks):
        def colname_actual(task_predict, defis, specs):
            name_model = task_predict["model"]
            name_formula = defis["models"][name_model]["formula"]
            formula_lhs = specs["formulas"][name_formula]["lhs"]
            col_actual = formula_lhs
            return col_actual

        def colname_prediction(task_predict):
            return task_predict["colname"]

        def deps(name_predict):
            return [name_predict]

        task = {
            "name_run": specs["name"],
            "predict": name_predict,
            "task_type": "eval",
            "dataset": task_predict["dataset"],
            "colname_actual": colname_actual(task_predict, defis, specs),
            "colname_prediction": colname_prediction(task_predict),
            "deps": deps(name_predict),
        }

        return task

    predict_tasks = tasks["predicts"]

    tasks = {}
    for name_predict, task_predict in predict_tasks.items():
        name = names.task_eval(name_predict)
        tasks[name] = task(name_predict, task_predict, defis, specs, tasks)

    return tasks


def tasks(defis, specs):
    """ Create all tasks from definitions and specifications """

    tasks = {}
    tasks["trains"] = tasks_trains(defis, specs)
    tasks["predicts"] = tasks_predicts(defis, specs)
    tasks["datasets"] = tasks_datasets(defis, specs)
    tasks["datacols"] = tasks_datacols(defis, specs)
    tasks["evals"] = tasks_evals(defis, specs, tasks)
    tasks["geometry"] = tasks_geometry(specs)
    return tasks


def tasks_flat(tasks_nested, name_run=None):
    """ Tasks are nested by type, flatten and set task_type and name attr """
    tasks_flat = {}
    for type_tasks in tasks_nested.values():
        for task_name, task in type_tasks.items():
            task["name"] = task_name
            if name_run:
                task["name_run"] = name_run
            tasks_flat[task_name] = task
    return tasks_flat
