""" Names module, the naming standard used internally by defparser """
# pylint: disable=redefined-outer-name


def dataset(loa, geo, imp, period, slot):
    """ Name a dataset """
    return f"{loa}_{geo}_{imp}_{period}_{slot}"


def model(formula, estimator, shiftmap, stepset):
    """ Name a model """
    return f"{formula}_{estimator}_{shiftmap}_{stepset}"


def defi_train(dataset, model, step):
    """ Name a train definition """
    return f"{dataset}.{model}.{step}"


def defi_predict_memt(dataset, model):
    """ Name a predict definition """
    return f"{dataset}.memt.{model}"


def defi_predict_semt(dataset, model, step):
    """ Name a predict definition """
    return f"{dataset}.semt.{model}.{step}"


def defi_datacol(dataset, col):
    """ Name a datacol definition """
    return f"{dataset}.{col}"


def colname_predict_memt(model):
    """ Name a column in a memt predict """
    return f"memt.{model}"


def colname_predict_semt(model, step):
    """ Name a column in a semt predict, note the addition of step """
    return f"semt.{model}.{step}"


def task_eval(predict):
    """ Name an evaluation task """
    return f"eval.{predict}"
