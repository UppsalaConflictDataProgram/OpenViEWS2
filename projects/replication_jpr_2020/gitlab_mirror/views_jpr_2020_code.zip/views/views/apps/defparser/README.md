# defparser

This is the definition parser application for ViEWS.

The program reads human-friendly definitions of forecasting runs and
translates them into explicit tasks for the various components to execute.

The purpose of the application is to provide a user-friendly interface for
defining large sets of diverse models, transformations and metadata which can
be efficiently interpreted by the larger ViEWS system to produce our forecasts.

For a minimal example see tests/data/defparser/pgm.yaml in this repo