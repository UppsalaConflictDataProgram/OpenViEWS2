CREATE TABLE staging.country_year AS
SELECT
c.country_id,
c.country_name,
c.isoab,
c.gwno,
c.cowcode,
y.year
FROM staging.country AS c
CROSS JOIN staging.year AS y
WHERE date_part('year', c.gw_date_start) <= y.year
AND
date_part('year', c.gw_date_end) >= y.year;

ALTER TABLE staging.country_year ADD COLUMN country_year_id SERIAL PRIMARY KEY;

CREATE INDEX ON staging.country_year (country_year_id);
CREATE INDEX ON staging.country_year (country_id);
CREATE INDEX ON staging.country_year (year);
CREATE INDEX ON staging.country_year (country_id, year);
CREATE INDEX ON staging.country_year (year, country_id);
CREATE INDEX ON staging.country_year (gwno, year);
CREATE INDEX ON staging.country_year (year, gwno);


ALTER TABLE staging.country_year ADD CONSTRAINT
cy_year_fkey FOREIGN KEY (year) REFERENCES staging.year (year);
ALTER TABLE staging.country_year ADD CONSTRAINT
cy_country_id_fkey FOREIGN KEY (country_id) REFERENCES staging.country (country_id);
