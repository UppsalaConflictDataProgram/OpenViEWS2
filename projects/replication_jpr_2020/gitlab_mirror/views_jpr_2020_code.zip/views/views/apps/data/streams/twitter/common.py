""" Common utils for twitter scrapers """

import tweepy
from views.utils.config import SECRETS


def authenticate(secrets=SECRETS):
    """ Get the twitter keys from secrets """

    keys = secrets["twitter"]
    auth = tweepy.OAuthHandler(
        consumer_key=keys["api_key"], consumer_secret=keys["api_secret_key"]
    )
    auth.set_access_token(keys["access_token"], keys["access_token_secret"])

    return auth
