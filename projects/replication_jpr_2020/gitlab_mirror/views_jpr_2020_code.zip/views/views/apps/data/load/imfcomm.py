""" IMF commodities data loader

Reads IMF commmodites data from dir_data_raw and pushes to db.

"""
import logging
import pandas as pd

from views.apps.data.load import utils
from views.utils import dbutils

Logger = logging.getLogger(__name__)


def load_imf_commodities():
    """ Turns xls into clean dataframe. Available: 1980 up until t-1 """

    Logger.info("Starting IMF commodities import")
    dbutils.recreate_schema("imfcomm")
    spec = utils.load_specfile(name_dataset="imfcomm")
    path_data_tar = utils.path_to_latest_archive(name_dataset="imfcomm")
    df = utils.load_df_from_only_xls_in_tar(path_tar=path_data_tar)

    # some cleanup of excel sheet
    df = df.iloc[3:]
    df = df.rename(columns=lambda x: x.lower()).rename_axis(None)
    df.rename(columns={"commodity": "date"}, inplace=True)
    df["date"] = pd.to_datetime(df["date"], format="%YM%m")
    df["year"] = df["date"].map(lambda x: x.year)
    df["month"] = df["date"].map(lambda x: x.month)
    df = df.drop(columns=["date"])

    # rename duplicate column name
    df = df.rename(columns={"poilapsp.1": "poilapsp_alt"})

    # remove p from df.columns
    p_cols = [col for col in df.columns if col.startswith("p")]
    renames = {p_col: p_col.replace("p", "", 1) for p_col in p_cols}
    df = df.rename(columns=renames)

    # reset indices
    df.reset_index(inplace=True, drop=True)
    df = df.set_index(spec["ids_raw"])

    # correct dtypes
    df = df.apply(pd.to_numeric)

    # load and stage
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])
    Logger.info("Finished IMF commodities raw import")
    utils.stage_data(spec)

    # interpolate (bfill/ffill)
    ids = [spec["timevar"]]
    df = dbutils.db_to_df(
        fqtable=spec["fqtable_staged"], ids=ids, columns=spec["cols_data"]
    )
    df = df.interpolate(method="linear", limit_direction="both")
    dbutils.df_to_db(df=df, fqtable=spec["fqtable_interpolated"])

    # end
    Logger.info("IMF commodities data ready.")


if __name__ == "__main__":
    load_imf_commodities()
