import json
import requests

from views.utils import config


def query_api(search_string, token):
    """ Query the newsriver.io API with a text search string """

    url_base = "https://api.newsriver.io/v2/search"
    params = {"query": f"text:{search_string}", "limit": 100, "page": 5}
    headers = {"Authorization": token}

    response = requests.get(url=url_base, params=params, headers=headers)

    print(response)
    return response.json()


def main():

    token = config.SECRETS["newsriver"]["token"]

    queries = ["killed"]

    responses = []
    for search_string in queries:
        responses.append(query_api(search_string, token))

    with open("derp.json", "w") as f:
        f.write(json.dumps(responses, indent=2))

    print("wrote derp.json")


if __name__ == "__main__":
    main()
