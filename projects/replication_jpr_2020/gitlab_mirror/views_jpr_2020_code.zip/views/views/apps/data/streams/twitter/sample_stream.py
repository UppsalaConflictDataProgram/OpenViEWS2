""" Three-piece twitter fetcher

This module uses three threads to produce an hourly .tar.xz of all
tweets made available through twitters sample stream.

"""
import json
import os
import sys
import time
import logging
import threading
import tempfile
import queue

import tweepy

from views.utils import pyutils
from views.apps.data.fetch import fetchutils
from views.apps.data.streams.twitter import common

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
)
Logger = logging.getLogger(__name__)


class QueueListener(tweepy.StreamListener):
    """ Tweepy listener that puts tweets in a Queue

    Both queue.Queue and multiprocessing.Queue are supported.

    """

    def __init__(self, tweet_queue):
        tweepy.StreamListener.__init__(self)
        self.queue = tweet_queue

    def on_data(self, raw_data):
        self.queue.put(raw_data)

    def on_error(self, status_code):
        msg = f"Listener got error {status_code}"
        Logger.error(msg)


def get_tweets_to_queue(tweet_queue):
    """ Get sample stream of tweets and put them in queue """

    retry_time = 60
    while True:
        try:
            auth = common.authenticate()
            listener = QueueListener(tweet_queue)
            stream = tweepy.Stream(auth=auth, listener=listener)
            stream.sample()
        # pylint: disable=broad-except
        except Exception as exc:
            msg = f"Error in getting tweets: {exc}. Retrying in {retry_time} s"
            Logger.error(msg)
            time.sleep(retry_time)


def flush_tweets_to_json_every_minute(tweet_queue, json_paths_queue):
    """ Flush tweet_queue into .json files every minute

    Every minute all tweets from tweet_queue are dumped to a .json
    file which is written to a temporary directory.
    Once a .json is written the path to that .json is put in
    json_paths_queue.

    Args:
        tweet_queue: A queue of raw string tweets
        json_paths_queue: A queue in which to put paths to .jsons
    Returns: None

    """

    tweet_buffer = []
    time_last_flush = fetchutils.utc_now_minute()

    with tempfile.TemporaryDirectory() as tempdir:
        while True:

            # Put all tweets from queue into buffer
            while not tweet_queue.empty():
                tweet_buffer.append(json.loads(tweet_queue.get()))

            # If we're in a new minute
            if not time_last_flush == fetchutils.utc_now_minute():
                time_last_flush = fetchutils.utc_now_minute()
                fname = f"{time_last_flush}.json"
                path = os.path.join(tempdir, fname)
                with open(path, "w") as f:
                    json.dump(tweet_buffer, f)
                json_paths_queue.put(path)
                msg = f"Flusher wrote {path} with {len(tweet_buffer)} tweets"
                Logger.debug(msg)
                tweet_buffer.clear()

            time.sleep(10)


def archive_jsons_hourly(json_paths_queue):
    """ Archive all files in json_paths_queue once an hour """

    time_last_archive = fetchutils.utc_now_hour()

    while True:

        # If an hour since last archive
        if not time_last_archive == fetchutils.utc_now_hour():
            time_last_archive = fetchutils.utc_now_hour()
            paths = []
            while not json_paths_queue.empty():
                paths.append(json_paths_queue.get())
            path = fetchutils.create_path_stream_archive("twitter")
            fetchutils.compress_files(
                paths_sources=paths, path_destination=path
            )
            Logger.info(f"Archiver wrote {path}")

            # Cleanup
            for path in paths:
                os.remove(path)
                Logger.debug(f"Archiver removed {path}")

        time.sleep(30)


def main():
    """ Sample the twitter stream and dump hourly .tar.xz archives """
    tweetqueue = queue.Queue()
    json_paths_queue = queue.Queue()

    p_listen = threading.Thread(target=get_tweets_to_queue, args=(tweetqueue,))
    p_flush = threading.Thread(
        target=flush_tweets_to_json_every_minute,
        args=(tweetqueue, json_paths_queue),
    )
    p_archive = threading.Thread(
        target=archive_jsons_hourly, args=(json_paths_queue,)
    )

    p_listen.start()
    p_flush.start()
    p_archive.start()


if __name__ == "__main__":
    main()
