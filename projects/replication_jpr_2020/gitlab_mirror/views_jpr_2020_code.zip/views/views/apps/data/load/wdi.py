""" World development indicators loader """

import logging

from views.utils import dbutils, pyutils
from views.apps.data.load import utils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)
Logger = logging.getLogger(__name__)


def _cleanup(spec):
    keys = [
        "fqtable_data",
        "fqtable_staged",
        "fqtable_data_raw",
        "fqtable_meta_raw",
    ]
    for key in keys:
        dbutils.drop_table(spec[key])

    Logger.info("Cleaned up WDI")


def flip_wdi(df, drops_preflip, ix_preflip, timevar, groupvar):
    """ Flip WDI data from wide to long """

    Logger.info("Flipping WDI")

    df = df.rename(columns=lambda x: x.replace(" ", ""))
    df = df.rename(columns=lambda x: x.lower())

    # Headache-magic, tbh I don't remember how it works.
    df = df.drop(drops_preflip, axis=1)
    df = df.set_index(ix_preflip)
    df.columns.name = "year"
    df = df.stack().unstack("indicatorcode")
    df = df.reset_index()
    df["year"] = df["year"].astype("int32")
    df = df.set_index([timevar, groupvar]).sort_index()

    df = df.rename(columns=lambda x: x.replace(".", "_"))
    df = df.rename(columns=lambda x: x.lower())

    Logger.info("Done flipping WDI")

    return df


def load_wdi():
    """ Load WDI """

    Logger.info("Starting WDI import")
    dbutils.recreate_schema("wdi")
    spec = utils.load_specfile(name_dataset="wdi")
    path_data_tar = utils.path_to_latest_archive(name_dataset="wdi")
    loader = utils.load_df_from_csv_in_zip_in_tar
    df = loader(
        path_tar=path_data_tar,
        name_zip=spec["name_zip"],
        name_csv=spec["name_csv_data"],
    )
    df_info = loader(
        path_tar=path_data_tar,
        name_zip=spec["name_zip"],
        name_csv=spec["name_csv_info"],
    )

    df = flip_wdi(
        df=df,
        drops_preflip=spec["misc"]["flip"]["drops_preflip"],
        ix_preflip=spec["misc"]["flip"]["ix_preflip"],
        timevar=spec["timevar_raw"],
        groupvar=spec["groupvar_raw"],
    )
    df = df[spec["cols_data"]]

    df_info = df_info.rename(columns=lambda col: col.lower())
    df_info = df_info.rename(columns=lambda col: col.replace(" ", "_"))

    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])
    dbutils.df_to_db(df_info, fqtable=spec["fqtable_meta_raw"])
    Logger.info("Finished WDI raw import")
    utils.stage_data(spec)
    utils.interpolate_data(spec)
    utils.impute_data(spec)
    _cleanup(spec)
    Logger.info("WDI data ready.")


if __name__ == "__main__":
    load_wdi()
