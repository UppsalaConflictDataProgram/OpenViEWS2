# Twitter fetcher

The twitter fetcher is made up of several scipts.
The decision to run several scripts was done to keep things simple.
A multi-threaded application could do this all in one script but at the cost of
complexity.

## run.py

Runs `fetch_raw.py` and `archive.py` in two separate processes.

## fetch_raw.py

This script listens to the twitter sample endpoint and fetches all the tweets.
Every minute it writes all tweets, one per line, to a timestamped file

`$dir_data/raw/$timestamp-minute.raw`

where timestamp-minute is of the for YearMonthDay-HourMinute such as
`20190222-1224.raw`

It runs indefinitely.

## archive.py

This script looks in

`$dir_data/raw/`

for raw tweet files from hours before the current hour.
Raw tweets are compressed into a per-hour .tar.xz archive and sent to S3.
