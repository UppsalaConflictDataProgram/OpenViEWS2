""" GADM load module """
import tempfile
import os
import logging
import subprocess

from views.utils import dbutils, config
from views.apps.data.load import utils
from views.apps.data.fetch import fetchutils

Logger = logging.getLogger(__name__)


def invoke_ogr2ogr(schema, path_gpkg, tables_expected):
    """ Push gpkg to db schema

    @TODO: Rewrite using shell=False and subprocess pipes
    """

    db_opts = config.CONFIG["db"]

    dbname = db_opts["database"]
    host = db_opts["host"]
    port = db_opts["port"]
    user = db_opts["user"]

    cmd = (
        f"ogr2ogr -f PostgreSQL "
        f'PG:"'
        f"dbname='{dbname}' "
        f"host='{host}' "
        f"port='{port}' "
        f"user='{user}'\" "
        f"-lco SCHEMA={schema} -overwrite {path_gpkg}"
    )

    Logger.info(f"Calling in subprocess: {cmd}")
    result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    Logger.info(f"ogr2ogr output: {result}")

    # Raise if we didn't push successfully
    for table in tables_expected:
        fqtable = f"{schema}.{table}"
        if not fqtable in dbutils.list_tables_in_schema(schema):
            msg = (
                "Something wen't wrong with GADM. "
                "Is ogr2ogr installed? "
                "Is your ogr2ogr_pg_opts set correctly in your config?"
            )
            raise RuntimeError(msg)


def load_gadm():
    """ Load GADM data """
    spec = utils.load_specfile("gadm")
    path_tar = utils.path_to_latest_archive("gadm")
    name_zip = spec["name_zip"]
    name_gpkg = spec["name_gpkg"]
    schema = spec["schema"]
    tables_expected = spec["tables_raw_expected"]

    dbutils.recreate_schema(spec["schema"])

    with tempfile.TemporaryDirectory() as tempdir:

        # Extract the zip from the .tar.xz
        path_zip = fetchutils.extract_file(
            path_archive=path_tar, filename=name_zip, dir_destination=tempdir
        )
        # Unpack the zip
        fetchutils.unpack_zipfile(path_zip=path_zip, destination=tempdir)

        # Get the path to the .gpkg that we unpacked from the zip
        path_gpkg = False
        for root, _, files in os.walk(tempdir):
            for fname in files:
                if fname == name_gpkg:
                    path_gpkg = os.path.join(root, fname)
                    break

        if path_gpkg:
            invoke_ogr2ogr(schema, path_gpkg, tables_expected)
        else:
            msg = f"{name_gpkg} wasn't found in the zip contents. "
            raise RuntimeError(msg)

    Logger.info("GADM data ready.")


if __name__ == "__main__":
    load_gadm()
