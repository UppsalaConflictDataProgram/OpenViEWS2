CREATE TABLE staging.priogrid_month AS SELECT
pg.pg_id,
m.month_id,
m.year,
m.month,
pgy.priogrid_year_id,
pgy.country_id,
pgy.country_year_id,
cm.country_month_id
FROM staging.priogrid AS pg
CROSS JOIN staging.month AS m
INNER JOIN staging.priogrid_year AS pgy
ON pgy.pg_id=pg.pg_id
AND pgy.year=m.year
LEFT JOIN staging.country_month AS cm
ON m.month_id=cm.month_id AND pgy.country_id=cm.country_id;

ALTER TABLE staging.priogrid_month ADD COLUMN priogrid_month_id SERIAL PRIMARY KEY;

CREATE INDEX ON staging.priogrid_month(priogrid_month_id);
CREATE INDEX ON staging.priogrid_month(pg_id);
CREATE INDEX ON staging.priogrid_month(month_id);
CREATE INDEX ON staging.priogrid_month(pg_id, month_id);
CREATE INDEX ON staging.priogrid_month(month_id, pg_id);
CREATE INDEX ON staging.priogrid_month(country_year_id);
CREATE INDEX ON staging.priogrid_month(priogrid_year_id);
CREATE INDEX ON staging.priogrid_month(country_id);

ALTER TABLE staging.priogrid_month ADD CONSTRAINT pgm_month_id_fkey FOREIGN KEY (month_id) REFERENCES staging.month (month_id);
ALTER TABLE staging.priogrid_month ADD CONSTRAINT pgm_pg_id_fkey FOREIGN KEY (pg_id) REFERENCES staging.priogrid (pg_id);
ALTER TABLE staging.priogrid_month ADD CONSTRAINT pgm_priogrid_year_id_fkey FOREIGN KEY (priogrid_year_id) REFERENCES staging.priogrid_year (priogrid_year_id);
ALTER TABLE staging.priogrid_month ADD CONSTRAINT pgm_country_year_id_fkey FOREIGN KEY (country_year_id) REFERENCES staging.country_year (country_year_id);
ALTER TABLE staging.priogrid_month ADD CONSTRAINT pgm_country_id_fkey FOREIGN KEY (country_id) REFERENCES staging.country (country_id);
