CREATE TABLE staging.year AS SELECT
generate_series(:year_start, :year_end) AS year;
CREATE INDEX ON staging.year(year);
ALTER TABLE staging.year ADD PRIMARY KEY (year);