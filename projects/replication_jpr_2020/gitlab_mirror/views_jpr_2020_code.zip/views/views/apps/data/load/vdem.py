""" V-Dem loader

Reads V-Dem from dir_data_raw, subsets cols and pushes to db.

"""
import os
import logging

from views.apps.data.load import utils
from views.utils import dbutils, pyutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):

    keys = [
        "fqtable_data",
        "fqtable_staged",
        "fqtable_data_raw",
        "fqtable_meta_raw",
    ]
    for key in keys:
        dbutils.drop_table(spec[key])
    Logger.info("Cleaned up VDEM")


def make_continents():
    """ Make continents schema with .c and .pg tables, see query """

    Logger.info("Starting VDEM continents")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", "continents", "stage.sql")
    dbutils.execute_query_from_file(path_query)
    Logger.info("Finished VDEM continents")


def load_vdem():
    """ Take vdem from data.tar.xz to database """

    Logger.info("Starting loading VDEM")
    spec = utils.load_specfile("vdem")
    path_data_tar = utils.path_to_latest_archive(name_dataset="vdem")
    df = utils.load_df_from_csv_in_zip_in_tar(
        path_tar=path_data_tar,
        name_zip=spec["name_zip"],
        name_csv=spec["name_csv_data"],
    )

    df = df.set_index([spec["timevar"], spec["groupvar"]]).sort_index()
    df = df.rename(columns=lambda col: col.lower())

    df_data = df[spec["cols_data"]]
    df_meta = df[spec["cols_meta"]]

    df_data = utils.do_recodes(df_data, spec["recodes"])

    dbutils.recreate_schema("vdem")
    dbutils.df_to_db(df=df_data, fqtable=spec["fqtable_data_raw"])
    dbutils.df_to_db(df=df_meta, fqtable=spec["fqtable_meta_raw"])
    Logger.info("Finished VDEM raw import")
    utils.stage_data(spec)
    utils.interpolate_data(spec)
    utils.impute_data(spec)
    make_continents()
    _cleanup(spec)

    Logger.info("Finished loading VDEM")


if __name__ == "__main__":
    load_vdem()
