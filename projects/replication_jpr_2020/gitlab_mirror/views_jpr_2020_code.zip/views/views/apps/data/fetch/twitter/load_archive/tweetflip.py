""" Read tweets from stdin and write them to csv on stdout """
import sys
import csv
import json


def json_to_tuple(tweet):
    """ Get a id, content tuple from a tweet dict """
    return (tweet["id"], json.dumps(tweet))


def parse_in_loop(limit=100):
    """ Parse tweets in a loop with an iterator limit """
    i = 0
    csvwriter = csv.writer(sys.stdout)
    for line in sys.stdin:
        tweet = json.loads(line)
        if "id" in tweet:
            if not tweet["geo"] is None:
                tup = json_to_tuple(tweet)
                csvwriter.writerow(tup)
                i += 1
        if i == limit:
            break


def parse_funcstyle():
    """ Parse tweets using a generator, so no limit """

    tweets = (
        tweet
        for tweet in map(json.loads, sys.stdin)
        if "id" in tweet and not tweet["geo"] is None
    )
    csvwriter = csv.writer(sys.stdout)
    csvwriter.writerows(map(json_to_tuple, tweets))


if __name__ == "__main__":
    # parse_in_loop()
    parse_funcstyle()
