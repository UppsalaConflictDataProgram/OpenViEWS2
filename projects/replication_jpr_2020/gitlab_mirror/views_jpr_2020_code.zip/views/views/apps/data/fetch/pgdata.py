""" Fetch priogrid data from their API """
import sys
import os
import tempfile
import json
import logging
import time
import random

import requests

from views.utils import pyutils
from views.utils.config import CONFIG

from views.apps.data.common import utils
from views.apps.data.fetch import fetchutils

DIR_RAW = CONFIG["dirs"]["dir_data_raw"]

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
)
Logger = logging.getLogger(__name__)


def _get_data(url, params, try_number=1):
    msg = f"PRIO getting {url} with params {params} try_number {try_number}"
    Logger.debug(msg)
    try:
        data = requests.get(url=url, params=params).json()
    except json.decoder.JSONDecodeError:
        time.sleep(2 ** try_number + random.random() * 0.01)
        return _get_data(url, params, try_number=try_number + 1)
    else:
        return data


def fetch_pgdata():
    """ Fetch priogrid data from API """

    def get_grid(url):
        """ Fetch the basegrid """
        grid = requests.get(url).json()
        Logger.info(f"Got grid with {len(grid)} cells")
        return grid

    def fetch_varinfos(url):
        """ Fetch varinfo """
        varinfos = requests.get(url).json()
        Logger.info(f"Got varinfos with info for {len(varinfos)} vars")
        return varinfos

    def add_urls_to_varinfos(varinfos, url_data):
        """ Update varinfo dictionaries with API endpoint URLs """
        varinfos = varinfos.copy()
        for varinfo in varinfos:
            url = f"{url_data}{varinfo['id']}"
            if varinfo["type"] == "yearly":
                payload = {k: varinfo[k] for k in ("startYear", "endYear")}
            elif varinfo["type"] == "static":
                payload = {}

            varinfo.update({"url": url, "payload": payload})

        return varinfos

    def fetch_data(varinfos, dir_destination):
        """ Fetch all the data to dir_destination"""

        paths = []
        for i, varinfo in enumerate(varinfos):

            msg = f"Getting pgdata {i+1}/{len(varinfos)}: {varinfo['name']}"
            Logger.debug(msg)

            # data = requests.get(
            #     url=varinfo["url"], params=varinfo["payload"]
            # ).json()
            data = _get_data(url=varinfo["url"], params=varinfo["payload"])

            fname = f"{varinfo['name']}.json"
            path = os.path.join(dir_destination, fname)
            with open(path, "w") as f:
                json.dump(data, f, indent=2)

            Logger.info(f"Wrote {path}")
            paths.append(path)

        return paths

    name = "pgdata"
    spec = utils.load_specfile(name)
    path_fetch = fetchutils.create_path_fetch(name)

    Logger.info(f"Fetching {name} from {spec['url_base']}")

    url_base = spec["url_base"]
    url_grid = url_base + "data/basegrid"
    url_varinfo = url_base + "variables"
    url_data = url_base + "data/"

    grid = get_grid(url=url_grid)
    varinfos = fetch_varinfos(url=url_varinfo)
    varinfos = add_urls_to_varinfos(varinfos, url_data)

    with tempfile.TemporaryDirectory() as tempdir:

        path_varinfos = os.path.join(tempdir, "varinfos.json")
        path_grid = os.path.join(tempdir, "basegrid.json")

        with open(path_grid, "w") as f:
            json.dump(grid, f, indent=2)
        Logger.debug(f"Wrote {path_grid}")
        with open(path_varinfos, "w") as f:
            json.dump(varinfos, f, indent=2)
        Logger.debug(f"Wrote {path_varinfos}")

        paths_data = fetch_data(varinfos, dir_destination=tempdir)

        paths_all = paths_data + [path_varinfos] + [path_grid]

        fetchutils.compress_files(
            paths_sources=paths_all, path_destination=path_fetch
        )


if __name__ == "__main__":
    fetch_pgdata()
