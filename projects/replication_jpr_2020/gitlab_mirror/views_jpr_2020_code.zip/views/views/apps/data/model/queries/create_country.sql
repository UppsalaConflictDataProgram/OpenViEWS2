CREATE TABLE staging.country AS
SELECT
    cshapes.gid        AS country_id,
    cshapes.cntry_name AS country_name,
    cshapes.area       AS area,
    cshapes.capname,
    cshapes.caplong,
    cshapes.caplat,
    cshapes.gwcode     AS gwno,
    cshapes.gw_date_start,
    cshapes.gw_date_end,
    cshapes.cowcode,
    cshapes.isoname,
    cshapes.iso1num    AS isonum,
    cshapes.iso1al3    AS isoab,
    cshapes.geom

FROM cshapes.data AS cshapes;

ALTER TABLE staging.country ADD PRIMARY KEY (country_id);
CREATE INDEX ON staging.country(country_id);
CREATE INDEX ON staging.country(gwno);
CREATE INDEX ON staging.country(isoab);
