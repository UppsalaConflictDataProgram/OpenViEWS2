import json

import requests
import newspaper

from views.utils.config import SECRETS
from views.apps.data.common import utils
from views.apps.data.fetch import fetchutils


def get_sources():

    url = "https://newsapi.org/v2/sources"
    params = {"apiKey": SECRETS["newsapi"]["api_key"]}

    response = requests.get(url, params=params)
    print(json.dumps(response.json(), indent=2))


def query_everything(query, sources, page=1):

    url = "https://newsapi.org/v2/everything"
    sources_param = ",".join(sources)  # sources comma separated

    params = {
        "q": query,
        "sources": sources_param,
        "apiKey": SECRETS["newsapi"]["api_key"],
        "pageSize": 100,
        "page": page,
    }

    response = requests.get(url, params=params).json()

    return response


def get_articles(query, sources):

    response = query_everything(query, sources)

    status = response["status"]
    n_results = response["totalResults"]
    articles = response["articles"]

    pages = int(n_results / 100)


def fetch_newsapi():
    spec = utils.load_specfile("newsapi")
    keywords = spec["keywords"]

    for kw in keywords:
        query_everything(query=kw, sources=spec["sources"])


if __name__ == "__main__":
    fetch_newsapi()
    # get_sources()
