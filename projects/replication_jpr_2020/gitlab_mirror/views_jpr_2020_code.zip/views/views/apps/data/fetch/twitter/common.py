""" Common components for twitter fetcher """

import os
import tweepy

from views.utils import pyutils
from views.utils.config import CONFIG, SECRETS


def _authenticate(secrets):
    """ Get the twitter keys from secrets """

    keys = secrets["twitter"]
    auth = tweepy.OAuthHandler(
        consumer_key=keys["api_key"], consumer_secret=keys["api_secret_key"]
    )
    auth.set_access_token(keys["access_token"], keys["access_token_secret"])

    return auth


def _dir_scratch(config):
    """ Define the location of the tweets scratch dir """

    basedir = config["dirs"]["dir_scratch"]
    dir_scratch_tweets = os.path.join(basedir, "tweets")
    pyutils.create_dir(dir_scratch_tweets)

    return dir_scratch_tweets


def _dir_scratch_raw(dir_scratch):
    """ Read which dir to use as scratch for raw tweets """

    dir_scratch_raw = os.path.join(dir_scratch, "raw")
    pyutils.create_dir(dir_scratch_raw)
    return dir_scratch_raw


def _dir_scratch_tars(dir_scratch):
    """ Read which dir to use as scratch for TARed tweets from config """
    dir_scratch_tars = os.path.join(dir_scratch, "tars")
    pyutils.create_dir(dir_scratch_tars)
    return dir_scratch_tars


def _s3_bucket(config):
    """ Read which S3 bucket to use from config """

    bucket = config["buckets"]["tweets"]
    if list(bucket.keys()) != ["name", "region"]:
        raise RuntimeError("Config file looks off")

    return bucket


AUTH = _authenticate(SECRETS)
DIR_SCRATCH = _dir_scratch(CONFIG)
DIR_SCRATCH_RAW = _dir_scratch_raw(_dir_scratch(CONFIG))
DIR_SCRATCH_TARS = _dir_scratch_tars(_dir_scratch(CONFIG))
BUCKET = _s3_bucket(CONFIG)
