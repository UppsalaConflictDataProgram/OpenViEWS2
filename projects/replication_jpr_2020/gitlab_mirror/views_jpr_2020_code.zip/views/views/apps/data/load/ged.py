""" GED loader

Reads GED from dir_data_raw and pushes to DB

"""
import os
import logging
import string

import pandas as pd

from views.apps.data.load import utils, eventutils
from views.utils import dbutils

Logger = logging.getLogger(__name__)


def cleanup_df_events(df, spec):
    """ cleanup events in df

    Does multiple things based on the specfile:

    * Renames cols as per spec['renames']
    * Extracts year and month for start and end.
    * Sets index col
    * Recodes some values
    * Drops some events

     """

    def drop_values(df, colname, values):
        len_predrop = len(df)
        mask = df[colname].isin(values)
        ix_drop = df[mask].index
        df = df.drop(ix_drop)
        diff = len_predrop - len(df)
        Logger.info(f"Dropped {diff} rows for {colname} in {values}")
        return df

    def set_dates(df):

        Logger.debug("Setting dates")
        df["date_start"] = pd.to_datetime(df["date_start"])
        df["date_end"] = pd.to_datetime(df["date_end"])
        df["year_start"] = df["date_start"].map(lambda x: x.year)
        df["year_end"] = df["date_end"].map(lambda x: x.year)
        df["month_start"] = df["date_start"].map(lambda x: x.month)
        df["month_end"] = df["date_end"].map(lambda x: x.month)

        return df

    df = df.rename(columns=spec["renames"])

    # Keep the instance of each ged event from the latest available
    # api version
    df = df.set_index(spec["index"])
    df = df.sort_values(by=["api_version"])
    df = df[~df.index.duplicated(keep="first")]

    # Recode values as per spec-file
    df = utils.do_recodes(df, recodes=spec["recodes"])

    for colname, values in spec["drop_values"].items():
        df = drop_values(df, colname, values)

    df = set_dates(df)

    return df


def attach_ged(spec):
    """ Attach ids and write to spec['fqtable_attached'] """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", "ged", "attach.sql")
    with open(path_query, "r") as f:
        query_template = string.Template(f.read())

    query = query_template.substitute(
        {
            "fqtable_data_raw": spec["fqtable_data_raw"],
            "fqtable_attached": spec["fqtable_attached"],
            "fqtable_country_problems": spec["fqtable_country_problems"],
            "date_id_mode": spec["attach_options"]["date_id_mode"],
        }
    )

    dbutils.execute_query(query)
    Logger.info("ged data attached.")


def stage_ged(spec):
    """ Create staged.loa as staging.loa Left join ged.agg_loa

    coalesce(colname, 0) in each row fills rows unobserved in GED
    with zeros.
    """

    Logger.info(f"Started staging GED")

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", "ged", "stage.sql")
    with open(path_query, "r") as f:
        query_template = string.Template(f.read())

    query_cm = query_template.substitute(
        {
            "fqtable": spec["fqtable_staged_cm"],
            "groupvar": "country_id",
            "loa": "cm",
            "fqtable_stage": "staging.country_month",
        }
    )
    query_pgm = query_template.substitute(
        {
            "fqtable": spec["fqtable_staged_pgm"],
            "groupvar": "pg_id",
            "loa": "pgm",
            "fqtable_stage": "staging.priogrid_month",
        }
    )

    dbutils.execute_query(query_cm)
    dbutils.execute_query(query_pgm)
    Logger.info(f"Finished staging GED")


def load_df_events(spec):
    """ Load each stored version as per spec file """

    dfs = []
    for version in spec["versions"].keys():
        df = eventutils.make_df_events(
            utils.path_to_latest_archive(name_dataset="ged", version=version)
        )
        df["api_version"] = version
        dfs.append(df.copy())

    df = pd.concat(dfs)

    return df


def load_ged():
    """ Take ged from data.tar.xz to database """

    Logger.info("Starting ged import")
    spec = utils.load_specfile("ged")

    df = load_df_events(spec)
    df = cleanup_df_events(df, spec)
    dbutils.recreate_schema("ged")
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])
    attach_ged(spec)  # Attach identifiers
    eventutils.run_aggregate(spec)
    eventutils.run_stage(spec)
    eventutils.cleanup(spec)
    Logger.info("Finished ged import")


if __name__ == "__main__":
    load_ged()
