# Archiveteam loader

This directory contains scripts for loading the tweets collected by archiveteam
available at https://archive.org/details/twitterstream

I downloaded all the available archives as torrents.
To load them into postgres I run the pipe.py script.

## How it works
It looks for all .tar files in the directory specified for archive dumps
and uses unix pipes and postgres COPY to load the tweets into postgres.

The steps with pipes between are:

* gtar: Unpacks the .tar files for each month
* bzcat: prints the contents of the single-minute .bz2 files
* tweetflip: Turns the jsons into a CSV
* psql: loads the data using COPY

This has some nice benefits:

* No tempfiles created during extraction (ain't nobody got space for that)
* Very low memory usage
* Highest possible throughput AFAIK
* Each monthly table can be copied in parallel. I use joblib to launch multiple pipes at once.


## To get it running
* Get the archives (1.5 TB+) to a single dir and update dir_fetched in pipe.py
* Have psql and make it default to the database you want to write to
* On MacOS: install gnutar using brew `brew install gnu-tar`.
* On linux: Change gtar to tar in the call in pipe.py

To load just a subset of tweets make sure:
* tweetflip is set to parse_in_loop
* set the break for the number of rows per
If you want all set it to parse_funcstyle()

## Issues:

* Some archives can't be extracted, haven't checked why as there's plenty of data anyway.
* Errors aren't reported correctly at the end
* Limiting tweets with breakpoint in tweetflip isn't consistent across months due to
  how the months are packed. Some months have a tar per day, meaning they get 30* more tweets
  than other months.