import datetime
import sys
import time
import textwrap

from views.apps.data.fetch import fetchutils

import requests
from bs4 import BeautifulSoup, NavigableString, Tag

FETCH_DELAY = 60

URL_BASE = "http://www.reuters.com"
URL_WIRE = f"{URL_BASE}/assets/jsonWireNews"


def get_article(headline):
    def get_keywords(soup):
        kws = soup.find("meta", {"name": "keywords"})["content"].split(",")
        kws_separated = ", ".join(kws)
        keywords = f"Keywords: {kws_separated}"
        return keywords

    def get_paragraphs(soup):
        try:
            article_body = soup.find(
                "div", {"class": "StandardArticleBody_body"}
            )
            paragraphs = article_body.find_all("p")
            paragraph_texts = [p.get_text() for p in paragraphs]
        except:
            paragraph_texts = ""

        return paragraph_texts

    def get_datetime(headline):
        ms = int(headline["dateMillis"])
        dt = str(datetime.datetime.utcfromtimestamp(ms / 1000.0))
        return dt

    url = URL_BASE + headline["url"]

    article_raw = requests.get(url)
    soup = BeautifulSoup(article_raw.content, "lxml")

    article = {
        "id": headline["id"],
        "paragraphs": get_paragraphs(soup),
        "headline": headline["headline"],
        "keywords": get_keywords(soup),
        "datetime": get_datetime(headline),
        "url": url,
    }

    return article


def get_headlines():
    wire_raw = requests.get(URL_WIRE)
    headlines = wire_raw.json()["headlines"]
    return headlines


def main():

    finished_ids = []
    while True:
        headlines = get_headlines()
        articles = []
        for headline in headlines:
            if not headline["id"] in finished_ids:
                article = get_article(headline)
                finished_ids.append(headline["id"])
                articles.append(article)

        print_articles(articles)

        time.sleep(FETCH_DELAY)

        # prune finished_ids
        while len(finished_ids) > 1000:
            finished_ids.pop(0)


if __name__ == "__main__":
    main()
