""" Pipe for loading of tweets into postgresql from archives """

import subprocess
import re
import os
import joblib

N_CPUS = 6


def find_tars(path_dir):
    """ Find all the .tar files in path_dir """
    paths = []
    for root, _, files in os.walk(path_dir):
        for file in files:
            if file.endswith(".tar"):
                paths.append(os.path.join(root, file))
    paths = sorted(paths)

    print(f"Found {len(paths)} archives")

    return paths


def get_year_month_from_path(path):
    """ Get year, month ints  from path

    Example /dir/some-name-2018-01.tar returns 2018, 01 """

    fname = os.path.basename(path)

    exp = r"(20\d{2}-\d{2})"
    pattern = re.compile(exp)
    match = pattern.search(fname)

    if match:
        year_month = match.group(0)
        year, month = year_month.split("-")

    return year, month


def make_copy_pipe_call(path_archive, year, month):
    """ Make the bash call for the pipe """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_flipper = os.path.join(this_dir, "tweetflip.py")

    tar_opts = "--extract --verbose --to-stdout --wildcards '*.bz2'"
    tar_infile = os.path.join(path_archive)

    psql_opts = "--echo-all"
    psql_table = f"tweets_raw.t_{year}_{month} (tweet_id, body)"
    psql_cmd_opts = "(FORMAT CSV, HEADER FALSE)"
    psql_cmd = f'"COPY {psql_table} FROM STDIN WITH {psql_cmd_opts};"'

    call = (
        f"gtar {tar_opts} --file={tar_infile} "
        f"| bzcat "
        f"| python {path_flipper} "
        f"| psql {psql_opts} --command={psql_cmd} "
    )

    return call


def make_init_sql(paths):
    """ Make the SQL for creating the tables """

    def create_table_query(year, month):
        return (
            f"CREATE TABLE tweets_raw.t_{year}_{month} (\n"
            "     tweet_id bigint NOT NULL,\n"
            "     body JSON NOT NULL\n"
            ");\n"
        )

    def schema_query():
        query = (
            "DROP SCHEMA IF EXISTS tweets_raw CASCADE;\n"
            "CREATE SCHEMA tweets_raw;\n"
        )
        return query

    year_months = []
    for path in paths:
        year_months.append(get_year_month_from_path(path))

    year_months = sorted(list(set(year_months)))
    table_queries = []
    for year, month in year_months:
        table_queries.append(create_table_query(year, month))

    queries = [schema_query()] + table_queries
    init_sql = "\n".join(queries)
    return init_sql


def call_init_sql(path_init_sql):
    """ Make the psql call for initalising the tables """
    opts = " --echo-all"
    return f"psql {opts} --file={path_init_sql}"


def worker(path):
    """ Run one pipe that copies into postgres """
    year, month = get_year_month_from_path(path)
    call = make_copy_pipe_call(path, year, month)
    print(call)
    error = ""
    return_code = subprocess.call(call, shell=True)
    if return_code != 0:
        error = path

    return error


def run_jobs_parallel(paths):
    """ Run worker in parallel for each path """
    errors = joblib.Parallel(n_jobs=N_CPUS)(
        joblib.delayed(worker)(path) for path in paths
    )
    return errors


# @TODO: Fix error handling
def main():
    """ Do it """
    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_fetched = "/Volumes/share/dockervols/transmission/downloads/complete"
    path_init_sql = os.path.join(this_dir, "init.sql")
    paths_arhives = find_tars(dir_fetched)
    paths_arhives = paths_arhives[0:6]

    init_sql = make_init_sql(paths_arhives)
    with open(path_init_sql, "w") as f:
        f.write(init_sql)
    print(f"wrote {path_init_sql}")

    subprocess.call(call_init_sql(path_init_sql), shell=True)

    errors = run_jobs_parallel(paths_arhives)

    print("errors:")
    for error in errors:
        if not error == "":
            print(error)


if __name__ == "__main__":
    main()
