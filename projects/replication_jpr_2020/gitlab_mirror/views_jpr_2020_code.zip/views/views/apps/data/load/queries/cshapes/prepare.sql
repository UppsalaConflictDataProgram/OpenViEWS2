-- add dates to cshapes
CREATE TABLE cshapes.data AS
SELECT
gid,
cntry_name,
area,
capname,
caplong,
caplat,
cowcode
gwcode,
MAKE_DATE(gwsyear, gwsmonth, gwsday) AS gw_date_start,
MAKE_DATE(gweyear, gwemonth, gweday) AS gw_date_end,
cowcode,
isoname,
iso1num,
iso1al2,
iso1al3,
geom
FROM
cshapes.raw
WHERE
gweyear > 0 -- countries missing gw date ranges have year=-1, drop them
;

-- Set the end date further into future
UPDATE cshapes.data SET
gw_date_end = :date_end
WHERE gw_date_end='2016-06-30';
