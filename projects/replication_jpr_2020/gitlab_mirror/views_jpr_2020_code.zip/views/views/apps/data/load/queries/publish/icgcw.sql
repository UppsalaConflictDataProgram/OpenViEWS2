CREATE TABLE ${fqtable_staged} AS
SELECT
  cm.country_month_id,
  cm.month_id,
  cm.country_id,
  ${cols_data}
FROM
  staging.country_month AS cm
  LEFT JOIN
  ${fqtable_data_raw} AS raw
  ON raw.name=cm.country_name
  AND raw.month=cm.month
  AND raw.year=cm.year;