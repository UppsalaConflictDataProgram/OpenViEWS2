CREATE TABLE ${fqtable} AS
SELECT
${loa}.${loa_id},
${loa}.${timevar},
${loa}.${groupvar},
COALESCE(low_ns, 0)         AS low_ns,
COALESCE(low_os, 0)         AS low_os,
COALESCE(low_sb, 0)         AS low_sb,
COALESCE(best_ns, 0)        AS best_ns,
COALESCE(best_os, 0)        AS best_os,
COALESCE(best_sb, 0)        AS best_sb,
COALESCE(high_ns, 0)        AS high_ns,
COALESCE(high_os, 0)        AS high_os,
COALESCE(high_sb, 0)        AS high_sb,
COALESCE(count_ns, 0)       AS count_ns,
COALESCE(count_os, 0)       AS count_os,
COALESCE(count_sb, 0)       AS count_sb
FROM ${fqtable_stage} AS ${loa}
LEFT JOIN ged.agg_${loa} AS agg
ON  ${loa}.${timevar}=agg.${timevar}
AND ${loa}.${groupvar}=agg.${groupvar};

CREATE INDEX ${loa}_${groupvar}_${timevar}x ON ${fqtable}(${groupvar}, ${timevar});
CREATE INDEX ${loa}_${timevar}_${groupvar}_idx ON ${fqtable}(${timevar}, ${groupvar});