""" DROPS THE CONFIGURED DATABSE! Rebuild the database from sources.
"""

import json
import time
import sys
import multiprocessing as mp
import argparse
import logging

from views.utils import dbutils, config, pyutils

from views.apps.data.flat import flat
from views.apps.data.model import build
from views.apps.data.load import (
    gadm,
    ged,
    icgcw,
    reign,
    vdem,
    wdi,
    pgdata,
    acled,
    fvp,
    polity,
    spei,
)


logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
)

Logger = logging.getLogger(__name__)


def force_from_args():
    """ Parse command line arg --force as boolean """

    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="Don't prompt")

    args = parser.parse_args()
    force = args.force

    return force


def check_user_sure():
    """ Prompt the user to type yes to confirm rebuild database """

    go_ahead = False

    print("The current database is:")
    print(json.dumps(config.CONFIG["db"], indent=2))
    print("This will DROP THE DATABASE. Are you super sure?")
    msg = "Type Yes to continue: "
    answer = input(msg)

    if not answer.lower() == "yes":
        print("OK Exiting")
        sys.exit()
    else:
        print("Press Control + C to abort.")
        print("Nuking in ")

        for i in range(10, -1, -1):
            print(i)
            time.sleep(1)
        go_ahead = True

    return go_ahead


def load_sources():
    """ Load each source in its own process """

    Logger.info("Started loading all sources")

    p_fvp = mp.Process(target=fvp.load_fvp)
    p_ged = mp.Process(target=ged.load_ged)
    p_icgcw = mp.Process(target=icgcw.load_icgcw)
    p_reign = mp.Process(target=reign.load_reign)
    p_vdem = mp.Process(target=vdem.load_vdem)
    p_wdi = mp.Process(target=wdi.load_wdi)
    p_pgdata = mp.Process(target=pgdata.load_pgdata)
    p_acled = mp.Process(target=acled.load_acled)
    p_polity = mp.Process(target=polity.load_polity)
    p_spei = mp.Process(target=spei.load_spei)

    # p_gadm = mp.Process(target=gadm.load_gadm)

    p_fvp.start()
    p_ged.start()
    p_icgcw.start()
    p_reign.start()
    p_vdem.start()
    p_wdi.start()
    p_pgdata.start()
    p_acled.start()
    p_polity.start()
    p_spei.start()

    # p_gadm.start()

    p_fvp.join()
    p_ged.join()
    p_icgcw.join()
    p_reign.join()
    p_vdem.join()
    p_wdi.join()
    p_pgdata.join()
    p_acled.join()
    p_polity.join()
    p_spei.join()
    # p_gadm.join()

    Logger.info("Finished loading all sources")


def rebuild_from_sources():
    """ Rebuild the database from stored sources """

    db = config.CONFIG["db"]["database"]
    dbutils.drop_db(db)
    dbutils.create_db(db)
    dbutils.init_postgis()
    build.build_model()
    load_sources()
    flat.flatten()


def main():
    """ Run rebuild_from_sources() if --force or user consents """

    # Check if --force was passed
    go_ahead = force_from_args()
    # If not prompt user
    if not go_ahead:
        go_ahead = check_user_sure()

    # If they don't say yes: exit
    if not go_ahead:
        sys.exit()
    else:
        rebuild_from_sources()


if __name__ == "__main__":
    main()
