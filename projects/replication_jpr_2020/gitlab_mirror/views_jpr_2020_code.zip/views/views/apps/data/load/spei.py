""" Loader for SPEI """
import os
import sys
import tempfile
import math
import logging
import joblib

import xarray as xr
import numba

from views.utils import dbutils, pyutils
from views.apps.data.fetch import fetchutils
from views.apps.data.load import utils

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    for spei_num in spec["speis_to_load"]:
        fqtable = f"spei.spei_{str(spei_num)}"
        dbutils.drop_table(fqtable)

    dbutils.drop_table("spei.pg_ug")
    Logger.info("Cleaned up SPEI")


@numba.vectorize
def priogrid_vec(lat, lon):
    """ Get pg_id from latitide and longitude vectorised """

    lat_part = ((int((90 + (math.floor(lat * 2) / 2)) * 2) + 1) - 1) * 720
    lon_part = (180 + (math.floor(lon * 2) / 2)) * 2
    pg_id = lat_part + lon_part + 1
    pg_id = int(pg_id)

    return pg_id


def spei_num_from_path(path):
    fname = os.path.basename(path)
    spei_num = "".join([s for s in fname if s.isdigit()])
    spei_num = int(str(int(spei_num)))  # Get rid of leading zeros
    return spei_num


def _spei_cdf4_to_db(spec, path, df_pgm):
    """ Read a spei .nc file and push ti to spei schema in db """

    Logger.info(f"Started loading {path}")

    spei_num = spei_num_from_path(path)
    colname = f"spei_{spei_num_from_path(path)}"

    # Use xarray to load the .nc, it deals with indexing, time etc
    df = xr.open_dataset(path).to_dataframe().reset_index()
    print(len(df))

    # Vectorised pg_id assignment on lat/lon
    df["pg_id"] = priogrid_vec(df.lat.to_numpy(), df.lon.to_numpy())

    print(df.isnull().sum() / len(df))

    # Get year/month from date for joining
    df["year"] = df["time"].dt.year
    df["month"] = df["time"].dt.month

    # Cleanup
    df.drop(columns=["time", "lat", "lon"], inplace=True)

    # Get the number of this spei (1-48) and append it to colname

    # Put the SPEI number in the colname
    df.rename(columns={"spei": colname}, inplace=True)
    df.dropna(inplace=True)

    print(len(df))

    # Reindex to join with df_pgm faster
    df.set_index(["pg_id", "year", "month"], inplace=True)
    df.sort_index(inplace=True)

    Logger.info(f"Finished prepping started attaching {path}")

    # Attach priogrid_month_id
    df = df_pgm.join(df, how="inner")
    df.reset_index(inplace=True)
    df.set_index(["priogrid_month_id"], inplace=True)
    df = df[[colname]]

    Logger.info(f"Started pushing {path}")

    # Push it up and create index
    fqtable = f"spei.spei_{spei_num}"
    dbutils.df_to_db(fqtable=fqtable, df=df)
    dbutils.create_table_index(fqtable, cols=["priogrid_month_id"])
    Logger.info(f"{fqtable} ready")


def spei_cdf4_to_db(path, df_pg_ug, df_m, df_ug_pgm):
    """ Read a spei .nc file and push to spei schema in db """

    Logger.info(f"Started loading {path}")

    spei_num = spei_num_from_path(path)
    colname = f"spei_{spei_num_from_path(path)}"

    # Use xarray to load the .nc, it deals with indexing, time etc
    df = xr.open_dataset(path).to_dataframe().reset_index()
    Logger.debug(f"Read {len(df)} rows of data from {path}")

    # Vectorised pg_id assignment on lat/lon
    df["pg_id"] = priogrid_vec(df.lat.to_numpy(), df.lon.to_numpy())
    Logger.debug("Assigned pg_ids")

    # Get year/month from date for joining
    df["year"] = df["time"].dt.year
    df["month"] = df["time"].dt.month
    df.drop(columns=["time", "lat", "lon"], inplace=True)

    # Put the SPEI number in the colname
    df.rename(columns={"spei": colname}, inplace=True)
    # Drop rows with no data
    df.dropna(inplace=True)

    # Join in month_id and drop those with missing
    df = df.set_index(["year", "month"]).join(df_m)
    df = df.dropna()  # Don't carry pre-month_id data around
    df.month_id = df.month_id.astype(int)
    Logger.debug("Assigned month_id")

    # Keep only data
    df = df.reset_index().set_index(["pg_id", "month_id"])[[colname]]

    # Join in the ug_id
    df = df.join(df_pg_ug)
    df = df.dropna()
    df.ug_id = df.ug_id.astype(int)
    Logger.debug("Assigned ug_id")

    # Now reindex to ug_id-month_id so we can join bigly
    df = df.reset_index().set_index(["ug_id", "month_id"]).sort_index()
    df = df[[colname]]
    df.head()

    # Now join in pg_id and priogrid_month_id by ug_id
    df = df_ug_pgm.join(df)

    df = df.set_index(["priogrid_month_id"])[[colname]]
    df = df.dropna()

    Logger.info(f"Started pushing {path}")

    # Push it up and create index
    fqtable = f"spei.spei_{spei_num}"
    dbutils.df_to_db(fqtable=fqtable, df=df)
    dbutils.create_table_index(fqtable, cols=["priogrid_month_id"])
    Logger.info(f"{fqtable} ready")


def load_spei_from_path(spec, path, df_pg_ug, df_m, df_ug_pgm):

    spei_num = spei_num_from_path(path)
    if spei_num in spec["speis_to_load"]:
        spei_cdf4_to_db(path, df_pg_ug, df_m, df_ug_pgm)
    else:
        Logger.info(f"Spei num {spei_num} not in speis_to_load of spec, skip")


def stage_spei(spec):
    """ Join all the 48 spei.spei_{num} tables to spei.pgm """

    Logger.info(f"Started staging SPEI")

    speis_to_load = spec["speis_to_load"]

    head = (
        f"CREATE TABLE spei.pgm AS SELECT \n"
        f"pgm.priogrid_month_id, pgm.pg_id, pgm.month_id, \n"
    )
    selects = ",\n".join([f"sp{i}.spei_{i}" for i in speis_to_load])
    joins = "\n".join(
        [
            (
                f"LEFT JOIN spei.spei_{i} AS sp{i}"
                f" ON sp{i}.priogrid_month_id=pgm.priogrid_month_id"
            )
            for i in speis_to_load
        ]
    )
    base = "\nFROM staging.priogrid_month AS pgm\n"

    query = head + selects + base + joins + ";"
    dbutils.execute_query(query)
    dbutils.create_table_index(
        fqtable="spei.pgm", cols=["priogrid_month_id"], unique=True
    )

    Logger.info(f"Finished staging SPEI")


def build_pg_ug():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_queries = os.path.join(this_dir, "queries", "spei")
    path_query = os.path.join(dir_queries, "create_pg_ug.sql")
    dbutils.execute_query_from_file(path_query)


def load_spei():
    """ Load SPEI Global drought monitor"""

    Logger.info("Started loading SPEI")

    spec = utils.load_specfile("spei")
    schema = spec["schema"]

    dbutils.recreate_schema(schema)
    build_pg_ug()

    path_data_tar = utils.path_to_latest_archive(name_dataset="spei")

    # Get the ids we need
    Logger.info("Started getting IDs from DB")
    df_pg_ug = dbutils.db_to_df_fast(fqtable="spei.pg_ug", ids=["pg_id"])
    df_m = dbutils.db_to_df_fast(
        fqtable="staging.month", columns=["month_id"], ids=["year", "month"]
    )
    df_ug_pgm = (
        dbutils.db_to_df_fast(
            fqtable="staging.priogrid_month",
            columns=["priogrid_month_id"],
            ids=["pg_id", "month_id"],
        )
        .join(df_pg_ug)
        .reset_index()
        .set_index(["ug_id", "month_id"])[["pg_id", "priogrid_month_id"]]
    )
    Logger.info("Finished getting IDs from DB")

    with tempfile.TemporaryDirectory() as tempdir:
        fetchutils.extract_all_files(
            path_archive=path_data_tar, dir_destination=tempdir
        )
        paths = pyutils.get_paths_from_dir(tempdir)
        for path in paths:
            load_spei_from_path(spec, path, df_pg_ug, df_m, df_ug_pgm)

    stage_spei(spec)
    _cleanup(spec)
    Logger.info("Finished loading SPEI")


if __name__ == "__main__":
    load_spei()
