# data - legacy
This module contains code needed to interface with the existing ViEWS database.
The contents are meant to produce output for copy-pasting queries to the existing DB,
not fully automated.