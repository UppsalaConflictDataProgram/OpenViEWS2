-- Query to create public table of VDEM data to be read into main datasets.
-- Since no identifier overlaps perfectly we choose either
-- gwcode==cowcode or isoab==country_text_id. Both have drawbacks.
-- Propose to write a consistent cow to gwno converter

DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS
WITH
data AS (
    SELECT
    data.*,
    meta.cowcode,
    meta.country_text_id
    FROM
    vdem.meta_raw AS meta
    INNER JOIN
    ${fqtable_data_raw} AS data
    ON meta.country_id=data.country_id
    AND
    meta.year=data.year
)
SELECT
cy.country_year_id,
cy.country_id,
cy.year,
${cols_data}
FROM staging.country_year AS cy
LEFT JOIN data
-- ON cy.gwcode=data.cowcode
ON cy.isoab=data.country_text_id
AND
cy.year = data.year;

