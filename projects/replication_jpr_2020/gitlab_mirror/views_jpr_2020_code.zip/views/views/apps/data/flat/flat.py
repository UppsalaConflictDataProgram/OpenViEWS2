""" Create flat tables for loading by clients

See data/specs/flat.yaml for controls
"""
import sys
import logging

from views.utils import dbutils, pyutils
from views.apps.data.load import utils


def build_query_view(fqview, base_loa, sources, loas, regions, region):
    """ Build a query for joining multiple tables """

    head = "\n".join(
        [
            f"DROP VIEW IF EXISTS {fqview};",
            f"CREATE VIEW {fqview} AS SELECT",
            f"base.{loas[base_loa]['groupvar']},",
            f"base.{loas[base_loa]['timevar']},",
        ]
    )

    from_base = f"FROM {loas[base_loa]['fqtable_base']} AS base"

    selects = []
    froms = []
    for source_name, source_entry in sources.items():

        loa = source_entry["loa"]
        source_fqtable = source_entry["fqtable"]

        source_spec = utils.load_specfile(source_name)
        prefix = source_spec["prefix"]
        source_cols = source_spec["cols_data"]
        source_loa_id = loas[loa]["loa_id"]

        source_selects = ",\n".join(
            [f"{prefix}.{col} AS {prefix}_{col}" for col in source_cols]
        )
        selects.append(source_selects)

        source_from = "\n".join(
            [
                f"LEFT JOIN {source_fqtable} AS {prefix} ",
                f"ON base.{source_loa_id}={prefix}.{source_loa_id}",
            ]
        )
        froms.append(source_from)

    selects_string = ",\n".join(selects)
    froms_string = "\n".join(froms)

    conditions_string = build_query_conditions(filter_spec=regions[region])

    query = "\n".join(
        [head, selects_string, from_base, froms_string, conditions_string, ";"]
    )

    return query


def build_query_conditions(filter_spec):

    head = ""
    print(filter_spec)
    conditions = []
    for col_filter, values in filter_spec.items():
        head = "WHERE"
        quoted_values = [f"'{value}'" for value in values]
        comma_sep_values = ", ".join(quoted_values)
        condition = f"{col_filter} in ({comma_sep_values})"
        conditions.append(condition)

    conditions_str = "\n AND \n".join(conditions)
    conditions_query = "\n".join([head, conditions_str])

    return conditions_query


def make_flat_views(spec):
    """ Make flat views as specified by specs/flat.yaml """

    Logger.info("Started making flat views")
    loas = spec["loas"]
    regions = spec["regions"]
    for fqview, entry in spec["views"].items():
        Logger.info(f"Making flat view {fqview}")
        query = build_query_view(
            fqview,
            base_loa=entry["base_loa"],
            sources=entry["sources"],
            region=entry["region"],
            regions=regions,
            loas=loas,
        )
        dbutils.execute_query(query)

    Logger.info("Finished making flat views")


def flatten():
    """ Create flattened tables as defined by specs/flat.yaml """

    spec = utils.load_specfile("flat")
    dbutils.recreate_schema("flat")
    make_flat_views(spec)
    Logger.info("Finished flattening.")


if __name__ == "__main__":

    logging.basicConfig(
        stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
    )
    Logger = logging.getLogger(__name__)

    flatten()

else:
    Logger = logging.getLogger(__name__)
