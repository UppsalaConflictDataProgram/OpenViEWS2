-- Attaching GED means joining it into our existing structure of
-- country_id and month_id.
-- GED has start and end dates for its events, this query
-- assigns both month_id_start and month_id_end.
-- The merging of country codes is done on

CREATE TABLE ${fqtable_attached} AS
WITH
ged_months_start AS
    (
        SELECT ged.ged_id,
               ged.gwno,
               ged.year_start,
               ged.month_start,
               m.month_id AS month_id_start
        FROM ${fqtable_data_raw} AS ged
        INNER JOIN staging.month AS m
        ON ged.year_start=m.year AND m.month=ged.month_start
    ),
ged_months_end AS
    (
        SELECT ged.ged_id,
               ged.gwno,
               ged.year_end,
               ged.month_end,
               m.month_id AS month_id_end
        FROM ${fqtable_data_raw} AS ged
        INNER JOIN staging.month AS m
        ON ged.year_end=m.year AND m.month=ged.month_end
    ),

ged_country_ids AS
    (
        SELECT ged.ged_id,
               cm.country_id,
               cm.country_month_id,
               cm.country_year_id
        FROM ged_months_${date_id_mode} AS ged
        INNER JOIN staging.country_month AS cm
        -- param to control whether to join on month_id_start or month_id_end
        ON  ged.month_id_${date_id_mode}=cm.month_id
        AND ged.gwno=cm.gwno
    )
SELECT ged.*,
       cm.country_id,
       cm.country_month_id,
       cm.country_year_id,
       m_start.month_id_start AS month_id,
       m_start.month_id_start,
       m_end.month_id_end,
       pgm.priogrid_month_id,
       pgy.priogrid_year_id
FROM
${fqtable_data_raw} AS ged
INNER JOIN ged_months_start         AS m_start  ON ged.ged_id=m_start.ged_id
INNER JOIN ged_months_end           AS m_end    ON m_start.ged_id=m_end.ged_id
INNER JOIN staging.priogrid_month   AS pgm      ON ged.pg_id=pgm.pg_id AND m_start.month_id_start=pgm.month_id
INNER JOIN staging.priogrid_year    AS pgy      ON ged.pg_id=pgy.pg_id AND m_start.year_start=pgy.year
LEFT JOIN ged_country_ids           AS cm       ON cm.ged_id=m_start.ged_id;

-- Some countries don't get country codes merged in.
-- Keep them in a table as a problem reminder to fix.
CREATE TABLE ${fqtable_country_problems} AS
SELECT * FROM ${fqtable_attached} WHERE country_id IS NULL;