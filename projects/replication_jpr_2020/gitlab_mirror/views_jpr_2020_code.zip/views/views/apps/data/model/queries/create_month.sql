CREATE TABLE staging.month_extent (
month_id serial8 PRIMARY KEY,
month int4 NOT NULL,
year int4 REFERENCES staging.year (year)
);

INSERT INTO staging.month_extent
(
  year,
  month
)
(
SELECT
  y.year,
  generate_series(1, 12)
FROM staging.year AS y
);

CREATE TABLE staging.month AS
SELECT
ms.month_id,
ms.year,
ms.month,
make_date(ms.year, ms.month, 1) AS date_start,
(make_date(ms.year, ms.month , 1) + INTERVAL '1 MONTH' - INTERVAL '1 DAY') :: date AS date_end
FROM staging.month_extent AS ms;

DROP TABLE staging.month_extent;

CREATE INDEX ON staging.month(month_id);
CREATE INDEX ON staging.month(year, month);

ALTER TABLE staging.month ADD PRIMARY KEY (month_id);
ALTER TABLE staging.month ADD CONSTRAINT
m_year_fkey FOREIGN KEY (year) REFERENCES staging.year (year);
