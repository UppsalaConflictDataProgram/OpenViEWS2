CREATE TABLE staging.country_month AS SELECT
c.country_id,
c.country_name,
c.isoab,
c.gwno,
c.cowcode,
m.month_id,
cy.country_year_id,
m.year,
m.month
FROM
staging.country as c
CROSS JOIN
staging.month AS m
INNER JOIN
staging.country_year AS cy
ON
c.country_id=cy.country_id
AND
m.year=cy.year
WHERE c.gw_date_start <= m.date_end -- start of country is before end of month
AND   c.gw_date_end   >= m.date_end -- end of country is after end of month
;

ALTER TABLE staging.country_month ADD COLUMN country_month_id SERIAL PRIMARY KEY;

CREATE INDEX ON staging.country_month(country_month_id);
CREATE INDEX ON staging.country_month(country_id);
CREATE INDEX ON staging.country_month(month_id);
CREATE INDEX ON staging.country_month(country_id, month_id);
CREATE INDEX ON staging.country_month(month_id, country_id);

ALTER TABLE staging.country_month ADD CONSTRAINT
cm_year_fkey FOREIGN KEY (year) REFERENCES staging.year (year);
ALTER TABLE staging.country_month ADD CONSTRAINT
cm_country_id_fkey FOREIGN KEY (country_id) REFERENCES staging.country (country_id);
ALTER TABLE staging.country_month ADD CONSTRAINT
cm_country_year_id_fkey FOREIGN KEY (country_year_id) REFERENCES staging.country_year (country_year_id);
