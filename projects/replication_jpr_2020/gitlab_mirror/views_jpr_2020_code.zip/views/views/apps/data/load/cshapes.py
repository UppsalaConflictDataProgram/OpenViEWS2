""" Loader for cshapes """

import tempfile
import os
import logging

from views.utils import dbutils, spatialutils
from views.apps.data.load import utils
from views.apps.data.fetch import fetchutils

Logger = logging.getLogger(__name__)


def prepare_cshapes(spec_model):
    """ Run queries/cshapes/prepare.sql with date_end from spec """

    Logger.info(f"Preparing cshapes with dates")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", "cshapes", "prepare.sql")
    params = {"date_end": spec_model["cshapes"]["date_end"]}
    dbutils.execute_query_from_file(path_query, params=params)


def load_cshapes():
    """ Load cshapes """

    spec = utils.load_specfile("cshapes")
    spec_model = utils.load_specfile("model")

    path_tar = utils.path_to_latest_archive("cshapes")
    name_zip = spec["name_zip"]
    name_shp = spec["name_shp"]
    fqtable_raw = spec["fqtable_data_raw"]

    dbutils.recreate_schema("cshapes")

    with tempfile.TemporaryDirectory() as tempdir:

        # Extract the zip from the .tar.xz
        path_zip = fetchutils.extract_file(
            path_archive=path_tar, filename=name_zip, dir_destination=tempdir
        )
        # Unpack the zip
        fetchutils.unpack_zipfile(path_zip=path_zip, destination=tempdir)

        # Get the path to the .csv that we unpacked
        path_shp = False
        for root, _, files in os.walk(tempdir):
            for fname in files:
                if fname == name_shp:
                    path_shp = os.path.join(root, fname)
                    break

        if path_shp:
            spatialutils.invoke_shp2pgsql(fqtable_raw, path_shp)
        else:
            msg = f"{spec['name_shp']} wasn't found in the zip contents. "
            raise RuntimeError(msg)

    prepare_cshapes(spec_model)

    Logger.info("cshapes data ready.")


if __name__ == "__main__":
    load_cshapes()
