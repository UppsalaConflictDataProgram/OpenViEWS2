""" Fetch ACLED data """
import json

import requests
from requests.adapters import HTTPAdapter


class AcledAPI:
    """ Acled API iterator

    Args:
        date_start: str of date to get events following, ex: "1996-12-31
    Yields:
        data: a list of ACLED events in json
    """

    def __init__(self, date_start):
        self.date_start = date_start
        self.page = None
        self.session = requests.Session()
        self.session.mount(
            "http://api.acleddata.com", HTTPAdapter(max_retries=2 ** 10)
        )
        self.url = "http://api.acleddata.com/acled/read"

    def __iter__(self):
        self.page = 1
        return self

    def __next__(self):

        count, data = self.get_slice()

        if count == 0:
            raise StopIteration()
        else:
            self.page += 1
            return data

    def get_slice(self):
        """ Get a page of ACLED data """

        payload = {
            "event_date": self.date_start,
            "event_date_where": ">",
            "page": self.page,
            "terms": "accept",
        }

        response = self.session.get(url=self.url, params=payload)

        try:
            output = response.json()
            data = output["data"]
            count = output["count"]

        except json.decoder.JSONDecodeError:
            print(response)
            raise

        return count, data
