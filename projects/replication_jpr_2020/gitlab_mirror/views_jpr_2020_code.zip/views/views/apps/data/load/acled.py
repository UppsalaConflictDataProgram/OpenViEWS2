""" Load ACLED """

import os
import logging
import string

import pandas as pd

from views.apps.data.load import eventutils
from views.apps.data.load import utils
from views.utils import datautils, dbutils

Logger = logging.getLogger(__name__)


def _cleanup_df_events(df, spec):
    """ Cleanup events dataframe """

    def set_month(df):
        df["date"] = pd.to_datetime(df["event_date"])
        df["month"] = df["date"].map(lambda date: date.month)
        return df

    def set_pg_id(df):
        df["latitude"] = pd.to_numeric(df["latitude"])
        df["longitude"] = pd.to_numeric(df["longitude"])
        df["pg_id"] = df[["latitude", "longitude"]].apply(
            lambda coords: datautils.priogrid(*coords), axis=1
        )
        return df

    df = df.rename(columns=spec["renames"])
    df = df.set_index(spec["index"])
    df = utils.do_recodes(df, recodes=spec["recodes"])
    df = set_month(df)
    df = set_pg_id(df)

    df["fatalities"] = pd.to_numeric(df["fatalities"])
    df["year"] = pd.to_numeric(df["year"])

    return df


def _attach_acled(spec):
    """ Attach acled """

    Logger.info("Started attach acled")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", "acled", "attach.sql")
    with open(path_query, "r") as f:
        query_template = string.Template(f.read())

    query = query_template.substitute(
        {
            "fqtable_data_raw": spec["fqtable_data_raw"],
            "fqtable_attached": spec["fqtable_attached"],
            "fqtable_country_problems": spec["fqtable_country_problems"],
        }
    )

    dbutils.execute_query(query)
    Logger.info("ACLED data attached.")


def load_acled():
    """ Load acled to db """
    Logger.info("Started ACLED import")

    spec = utils.load_specfile("acled")
    path_tar = utils.path_to_latest_archive("acled")
    df_events = eventutils.make_df_events(path_tar)
    df_events = _cleanup_df_events(df_events, spec)

    dbutils.recreate_schema("acled")
    dbutils.df_to_db(df_events, fqtable=spec["fqtable_data_raw"])
    _attach_acled(spec)
    eventutils.run_aggregate(spec)
    eventutils.run_stage(spec)
    eventutils.cleanup(spec)
    Logger.info("Finished ACLED import")


if __name__ == "__main__":
    load_acled()
