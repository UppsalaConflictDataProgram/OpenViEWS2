""" Fetch module for fetching raw sources """
import sys
import logging

import joblib

from views.utils import pyutils
from views.apps.data.fetch import sources
from views.utils.config import CONFIG

DIR_RAW = CONFIG["dirs"]["dir_data_raw"]

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.INFO
)
Logger = logging.getLogger(__name__)


def worker(task_name):
    """ Run a single fetch task """

    task_funcs = {
        "pggeom": sources.fetch_pggeom,
        "pgdata": sources.fetch_pgdata,
        "cshapes": sources.fetch_cshapes,
        "wdi": sources.fetch_wdi,
        "acled": sources.fetch_acled,
        "ged": sources.fetch_ged,
        "geoepr": sources.fetch_geoepr,
        "gadm": sources.fetch_gadm,
        "reign": sources.fetch_reign,
        "icgcw": sources.fetch_icgcw,
        "epr": sources.fetch_epr,
        "polity": sources.fetch_polity,
        "spei": sources.fetch_spei,
        "imfcomm": sources.fetch_imfcomm,
    }

    task_func = task_funcs[task_name]
    task_func()
    Logger.info(f"Finished task {task_name}")


def main_parallel():
    """ Fetch all sources in parallel """

    Logger.info("Started fetching all")
    pyutils.create_dir(DIR_RAW)
    task_names = [
        "pggeom",
        "pgdata",
        "cshapes",
        "wdi",
        "acled",
        "ged",
        "geoepr",
        "gadm",
        "reign",
        "icgcw",
        "epr",
        "polity",
        "spei",
        "imfcomm",
    ]

    joblib.Parallel(n_jobs=len(task_names), verbose=10, prefer="threads")(
        joblib.delayed(worker)(task_name) for task_name in task_names
    )

    Logger.info("Finished fetching all")


def main():
    """ Fetches all the latest sources to disk """

    pyutils.create_dir(DIR_RAW)
    sources.fetch_pggeom()
    sources.fetch_pgdata()
    sources.fetch_cshapes()
    sources.fetch_wdi()
    sources.fetch_acled()
    sources.fetch_ged()
    sources.fetch_geoepr()
    sources.fetch_gadm()
    sources.fetch_reign()
    sources.fetch_icgcw()
    sources.fetch_epr()
    sources.fetch_polity()
    sources.fetch_spei()
    sources.fetch_imfcomm()


if __name__ == "__main__":

    # main_parallel() and main() do the same thing
    # _parallel just does them all at once.
    main_parallel()
    # main()
