DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS

SELECT
cy.country_year_id,
cy.country_id,
cy.year,
${cols_data}
FROM
staging.country_year AS cy
LEFT JOIN
${fqtable_data_raw} AS fvp
ON cy.gwno=fvp.gwno
AND
cy.year=fvp.year;
