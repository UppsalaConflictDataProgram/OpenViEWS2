-- Attach identifiers to acled.events
-- Done in two steps with indexing in between

-- Attach country_id and month_id
CREATE TABLE ${fqtable_attached}_first AS
WITH
w_mid AS
(
    SELECT
    acled.acled_id,
    m.month_id
    FROM ${fqtable_data_raw} AS acled
    INNER JOIN staging.month AS m
    ON acled.month=m.month AND acled.year::int=m.year
),
w_cid AS
(
   SELECT
   acled.acled_id,
   c.country_id
   FROM ${fqtable_data_raw} AS acled
   LEFT JOIN staging.country AS c
   ON acled.iso3=c.isoab
)
SELECT
acled.acled_id,
acled.pg_id,
acled.year,
acled.month,
acled.fatalities,
acled.event_type,
w_mid.month_id,
w_cid.country_id
FROM ${fqtable_data_raw} AS acled
INNER JOIN w_mid ON acled.acled_id=w_mid.acled_id
INNER JOIN w_cid ON acled.acled_id=w_cid.acled_id
;

-- Index up
CREATE INDEX ON ${fqtable_attached}_first (pg_id, month_id);
CREATE INDEX ON ${fqtable_attached}_first (pg_id, year);

-- Join in the rest of the identifiers
CREATE TABLE ${fqtable_attached} AS
SELECT
acled.acled_id,
acled.pg_id,
acled.year,
acled.month,
acled.month_id,
acled.country_id,
pgm.priogrid_month_id,
pgy.priogrid_year_id,
cm.country_month_id,
cm.country_year_id,
acled.fatalities,
acled.event_type
FROM ${fqtable_attached}_first AS acled
INNER JOIN staging.priogrid_month AS pgm ON pgm.pg_id=acled.pg_id AND acled.month_id=pgm.month_id
INNER JOIN staging.priogrid_year AS pgy ON pgy.pg_id=acled.pg_id AND pgy.year=acled.year
LEFT JOIN staging.country_month AS cm ON cm.country_id=acled.country_id AND cm.month_id=acled.month_id;

DROP TABLE ${fqtable_attached}_first;
