-- Query to create public table of WDI data to be read into main datasets.
-- Join using isoab to WDI countrycodes.

DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS

SELECT
cy.country_year_id,
cy.country_id,
cy.year,
${cols_data}
FROM
staging.country_year AS cy
LEFT JOIN
${fqtable_data_raw} AS wdi
ON cy.isoab=wdi.countrycode
AND
cy.year=wdi.year;
