CREATE TABLE staging.priogrid_year_extent AS SELECT
pg.pg_id,
y.year
FROM
staging.priogrid AS pg
CROSS JOIN
staging.year AS y;

CREATE TABLE staging.priogrid_year_w_gwno_sparse AS
SELECT pgy.pg_id,
       pgy.year,
       pgdy.gwno
FROM staging.priogrid_year_extent AS pgy
     LEFT JOIN pgdata.yearly      AS pgdy
     ON pgdy.gid = pgy.pg_id
     AND pgdy.year = pgy.year;


-- Extrapolate gwno back and forward to fill extent
-- Notice this breaks exact mapping between country years and priogrid years
-- Manual checks find those grids that need back-filled gwnos are tiny islands.
-- Fill them anyway as a balanced panel of grid years makes life easier.
CREATE TABLE staging.priogrid_year_w_gwno AS
WITH
filled AS (
    SELECT pg_id,
           year,
           locf(gwno) OVER( PARTITION BY pg_id ORDER BY year ASC) AS gwno_forward,
           locf(gwno) OVER( PARTITION BY pg_id ORDER BY year DESC) AS gwno_backward
    FROM staging.priogrid_year_w_gwno_sparse
)
SELECT

filled.pg_id,
filled.year,
COALESCE(filled.gwno_forward, filled.gwno_backward) AS gwno
FROM filled;


-- Chose the greatest country_year_id for all the matching country_years by gwno and year
-- Because some gwnos appear in multiple countries for the same year
CREATE TABLE staging.priogrid_year_w_cyid AS
WITH chosen_cy AS (
    SELECT MAX(cy.country_year_id) AS country_year_id,
           cy.year,
           cy.gwno
    FROM staging.country_year AS cy
    GROUP BY cy.gwno, cy.year
)
SELECT pgy.pg_id,
       pgy.year,
       cy.country_year_id
FROM staging.priogrid_year_w_gwno AS pgy
LEFT JOIN chosen_cy AS cy
ON pgy.gwno = cy.gwno AND pgy.year = cy.year;

CREATE TABLE staging.priogrid_year AS
    SELECT pgy.pg_id,
           pgy.year,
           pgy.country_year_id,
           cy.country_id
FROM staging.priogrid_year_w_cyid AS pgy
LEFT JOIN staging.country_year AS cy
ON pgy.country_year_id=cy.country_year_id;

ALTER TABLE staging.priogrid_year ADD COLUMN priogrid_year_id SERIAL PRIMARY KEY;

CREATE INDEX ON staging.priogrid_year(priogrid_year_id);
CREATE INDEX ON staging.priogrid_year(pg_id);
CREATE INDEX ON staging.priogrid_year(year);
CREATE INDEX ON staging.priogrid_year(pg_id, year);
CREATE INDEX ON staging.priogrid_year(year, pg_id);
CREATE INDEX ON staging.priogrid_year(country_year_id);
CREATE INDEX ON staging.priogrid_year(country_id);
CREATE INDEX ON staging.priogrid_year(country_id, year);
CREATE INDEX ON staging.priogrid_year(year, country_id);

ALTER TABLE staging.priogrid_year ADD CONSTRAINT pgy_year_fkey FOREIGN KEY (year) REFERENCES staging.year (year);
ALTER TABLE staging.priogrid_year ADD CONSTRAINT pgy_pg_id_fkey FOREIGN KEY (pg_id) REFERENCES staging.priogrid (pg_id);
ALTER TABLE staging.priogrid_year ADD CONSTRAINT pgy_country_year_id_fkey FOREIGN KEY (country_year_id) REFERENCES staging.country_year (country_year_id);
ALTER TABLE staging.priogrid_year ADD CONSTRAINT pgy_country_id_fkey FOREIGN KEY (country_id) REFERENCES staging.country (country_id);

DROP TABLE staging.priogrid_year_extent;
DROP TABLE staging.priogrid_year_w_gwno;
DROP TABLE staging.priogrid_year_w_cyid;
DROP TABLE staging.priogrid_year_w_gwno_sparse;