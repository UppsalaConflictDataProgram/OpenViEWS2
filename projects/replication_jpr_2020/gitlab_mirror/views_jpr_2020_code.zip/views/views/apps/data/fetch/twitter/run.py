""" Run module, runs fetch_raw and archive in parallel """

import joblib

from views.apps.data.fetch.twitter import archive, fetch_raw

TASK_FUNCS = {"fetch_raw": fetch_raw.main, "archive": archive.main}


def worker(task_name):
    """ Run one of the tasks """
    print(f"Starting task {task_name}")
    task_func = TASK_FUNCS[task_name]
    task_func()


def main():
    """ Run fetch_raw and archive in parallel """
    task_names = ["fetch_raw", "archive"]
    joblib.Parallel(n_jobs=len(task_names), verbose=10)(
        joblib.delayed(worker)(task_name) for task_name in task_names
    )


if __name__ == "__main__":
    main()
