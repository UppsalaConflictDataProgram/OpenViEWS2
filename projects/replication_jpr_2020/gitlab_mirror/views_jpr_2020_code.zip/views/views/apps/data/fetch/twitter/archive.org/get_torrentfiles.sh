#cat urls.txt | xargs -n 1 -P 10 wget -N --directory /Volumes/Seagate/twitter/torrentfiles/
wget --input-file=urls.txt -N --directory /Volumes/Seagate/twitter/torrentfiles/