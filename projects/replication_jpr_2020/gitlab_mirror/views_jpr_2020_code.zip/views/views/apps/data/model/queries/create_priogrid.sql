CREATE TABLE staging.priogrid AS
SELECT
    core.gid AS pg_id,
    geom.row,
    geom.col,
    geom.xcoord :: NUMERIC(6,2) AS longitude,
    geom.ycoord :: NUMERIC(6,2) AS latitude,
    public.ST_GeometryN(public.st_geomfromewkt(geom.geom), 1) AS geom
FROM pgdata.core AS core
INNER JOIN
pggeom.geom_raw AS geom
ON core.gid=geom.__gid;

ALTER TABLE staging.priogrid ADD PRIMARY KEY (pg_id);
CREATE INDEX ON staging.priogrid (pg_id);
CREATE INDEX ON staging.priogrid USING GIST (geom);