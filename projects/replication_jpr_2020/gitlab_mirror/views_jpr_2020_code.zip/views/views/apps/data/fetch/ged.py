""" Fetch module for GED """

import requests

URL = "http://ucdpapi.pcr.uu.se/api/gedevents/"


class GedAPI:
    """ Get API iterator """

    def __init__(self, version):
        self.url = f"{URL}{version}"
        self.page = None
        self.pages = None

    def __iter__(self):
        self.page = 1
        self.pages = 1
        return self

    def __next__(self):

        params = {"page": self.page, "pagesize": 1000}

        response = requests.get(url=self.url, params=params)
        response = response.json()
        self.pages = response["TotalPages"]
        data = response["Result"]

        if data == []:
            raise StopIteration()
        else:
            self.page += +1
            return data
