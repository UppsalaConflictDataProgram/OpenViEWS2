CREATE TABLE ${fqtable} AS
SELECT
${loa}.${loa_id},
${loa}.${timevar},
${loa}.${groupvar},
COALESCE(count_bt, 0)       AS count_bt,
COALESCE(count_cv, 0)       AS count_cv,
COALESCE(count_pr, 0)       AS count_pr,
COALESCE(count_rt, 0)       AS count_rt,
COALESCE(count_rv, 0)       AS count_rv,
COALESCE(count_sd, 0)       AS count_sd,
COALESCE(fatalities_bt, 0)  AS fatalities_bt,
COALESCE(fatalities_cv, 0)  AS fatalities_cv,
COALESCE(fatalities_pr, 0)  AS fatalities_pr,
COALESCE(fatalities_rt, 0)  AS fatalities_rt,
COALESCE(fatalities_rv, 0)  AS fatalities_rv,
COALESCE(fatalities_sd, 0)  AS fatalities_sd
FROM ${fqtable_stage} AS ${loa}
LEFT JOIN acled.agg_${loa} AS agg
ON  ${loa}.${timevar}=agg.${timevar}
AND ${loa}.${groupvar}=agg.${groupvar};

CREATE INDEX ${loa}_${groupvar}_${timevar}x ON ${fqtable}(${groupvar}, ${timevar});
CREATE INDEX ${loa}_${timevar}_${groupvar}_idx ON ${fqtable}(${timevar}, ${groupvar});