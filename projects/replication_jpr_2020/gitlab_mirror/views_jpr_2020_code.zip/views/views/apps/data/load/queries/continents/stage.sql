-- Continent info is derived from vdems e_regiongeo variable
-- It comes in country year form and we want it static so

DROP SCHEMA IF EXISTS continents CASCADE;
CREATE SCHEMA continents;

-- Get country_id and regiongeo matches in timeless form
CREATE TABLE continents.c_matches AS
WITH pairs AS (
    SELECT DISTINCT c.country_id,
                    vdem.e_regiongeo
    FROM staging.country AS c
             LEFT JOIN vdem.cy AS vdem
                       ON c.country_id = vdem.country_id
)
SELECT pairs.country_id,
       pairs.e_regiongeo AS region
FROM pairs
WHERE e_regiongeo IS NOT NULL;

CREATE TABLE continents.c AS
SELECT
c.country_id,
matches.region
FROM staging.country AS c
LEFT JOIN continents.c_matches AS matches
ON c.country_id=matches.country_id;



-- First create a table with pg_id - region matches.
-- Some duplicate pg_ids in here as some grids change
-- region as borders shift
CREATE TABLE continents.pg_matches AS
WITH pairs AS (
    SELECT DISTINCT pg.pg_id,
                    vdem.e_regiongeo AS region
    FROM staging.priogrid AS pg
             INNER JOIN staging.priogrid_year AS pgy
                        ON pg.pg_id = pgy.pg_id
             LEFT JOIN vdem.cy AS vdem
                 ON vdem.country_year_id = pgy.country_year_id)
SELECT pg.pg_id,
       pairs.region AS region
FROM staging.priogrid AS pg
    LEFT JOIN pairs ON pg.pg_id=pairs.pg_id
WHERE pairs.region IS NOT NULL;

-- Use distinct on to get the single regions per pg_id
-- Use left join to get all pg_id's in there
CREATE TABLE continents.pg AS
    SELECT DISTINCT ON (pg.pg_id)
                                  pg.pg_id,
                                  matches.region
FROM staging.priogrid AS pg
LEFT JOIN continents.pg_matches AS matches
ON pg.pg_id=matches.pg_id
ORDER BY pg_id, region DESC NULLS LAST;

CREATE INDEX ON continents.pg(pg_id);
CREATE INDEX ON continents.pg(region);
CREATE INDEX ON continents.c(country_id);
CREATE INDEX ON continents.c(region);

DROP TABLE continents.c_matches;
DROP TABLE continents.pg_matches;