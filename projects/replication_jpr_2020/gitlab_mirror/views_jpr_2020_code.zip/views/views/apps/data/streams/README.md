# data/streams

Some data sources are streaming, such as online news and twitter.
This directory contains modules for fetching these streams.