"""Persons of interest"""
import collections
import sys
import os
import logging
import queue
import json
import time

import tweepy as tp

from views.utils import pyutils, config
from views.apps.data.common import utils
from views.apps.data.fetch import fetchutils
from views.apps.data.streams.twitter import common

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.INFO
)
Logger = logging.getLogger(__name__)


class Worker:
    def __init__(self, dir_storage, lists, handles):

        self.api = tp.API(
            common.authenticate(config.SECRETS),
            wait_on_rate_limit=True,
            wait_on_rate_limit_notify=True,
            retry_delay=60,  # Retry once a minute,
            retry_count=24 * 60,  #  for 24 hours
            retry_errors=[401, 404, 443, 500, 503],
        )
        self.lists = lists  # Dict with slug and owner of lists
        self.handles = handles
        self.handle_scrape_queue = queue.Queue()
        self.dir_storage = dir_storage
        self.last_seen_tweets = collections.defaultdict(lambda: 1)
        self.path_lst = os.path.join(self.dir_storage, "lst.json")

    def load_lst_from_file(self):

        if os.path.isfile(self.path_lst):
            with open(self.path_lst, "r") as f:
                lst_file = json.load(self.path_lst)
            for key in lst_file:
                self.last_seen_tweets[key] = lst_file[key]
                logging.debug(f"Read lst for {key} from {self.path_lst}")

    def update_state(self):

        with open(self.path_lst, "w") as f:
            json.dump(self.last_seen_tweets, f)

    def load_state(self):

        if os.path.isfile(self.path_lst):
            with open(self.path_lst, "r") as f:
                file_data = json.load(f)
            for key in file_data:
                self.last_seen_tweets[key] = file_data[key]
                msg = f"Read last seen tweet for {key} from {self.path_lst}"
                logger.debug(msg)

    def get_handles_from_list(self, owner, slug):

        Logger.info(f"Getting users from list {slug} by user {owner}")
        list_users = tp.Cursor(
            self.api.list_members, slug=slug, owner_screen_name=owner
        ).items()

        handles = []
        for user in list_users:
            handle = user.screen_name
            msg = f"Got handle {handle} from list {owner}/{slug}"
            Logger.info(msg)
            handles.append(handle)

        msg = f"Got {len(handles)} handles from list {slug} by user {owner}"
        Logger.info(msg)

        return handles

    def populate_handles_from_lists(self):

        for l_ids in self.lists.values():
            handles = self.get_handles_from_list(
                owner=l_ids["owner"], slug=l_ids["slug"]
            )
            self.handles += handles

        self.handles = pyutils.dedup_list(self.handles)

    def get_tweets(self, handle):

        latest_tweet_id = self.last_seen_tweets[handle]

        msg = f"Getting tweets for {handle} since tweet id {latest_tweet_id}"
        Logger.info(msg)

        tweets = []
        ids = []
        curs = tp.Cursor(
            self.api.user_timeline, id=handle, since_id=latest_tweet_id
        ).items()

        for tweet in curs:
            tweets.append(tweet._json)
            ids.append(tweet.id)

        Logger.info(f"Got {len(tweets)} tweets for user {handle}")

        # If we got any tweets update the last seen tweet id
        if tweets:
            latest_tweet_id = max(ids)
            self.last_seen_tweets[handle] = latest_tweet_id
            Logger.info(f"Last seen tweet for {handle} is {latest_tweet_id}")

        return tweets

    def print_handles(self):
        for handle in self.handles:
            print(handle)

    def scrape_timelines(self):

        for handle in self.handles:
            tweets = self.get_tweets(handle)

            fname = f"{handle}.json"
            path = os.path.join(self.dir_storage, fname)
            try:
                with open(path, "r") as f:
                    tweets += json.load(f)
            except FileNotFoundError:
                pass
            with open(path, "w") as f:
                json.dump(tweets, f)
            Logger.info(f"Wrote {len(tweets)} tweets to {path}")


def main():

    dir_storage = "/Users/frehoy/temp/tweets"
    spec = utils.load_specfile("twitter")
    worker = Worker(
        lists=spec["lists"], handles=spec["handles"], dir_storage=dir_storage
    )
    worker.init_db()
    worker.populate_handles_from_lists()
    while True:
        try:
            worker.scrape_timelines()
        except:
            Logger.info("Something went wrong, sleeping a minute")
            time.sleep(60)


if __name__ == "__main__":
    main()
