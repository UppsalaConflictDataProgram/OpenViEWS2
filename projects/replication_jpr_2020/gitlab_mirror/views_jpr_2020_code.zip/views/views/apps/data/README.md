# __ON HOLD__ this app is on hold, see views/apps/jdata instead


# Data pipeline

This module is intended to streamline the process of repeatably creating datasets ready for analysis and forecasting in ViEWS.

It is built on the idea of applying code to raw source data to get a set of usable datasets in a repeatable manner.
The same code on the same data should always produce near-identical results within reason.
(I say near identical because getting identical results is practically impossible considering processes like imputation of missing data and differences between platforms and software versions.
The ambition is that data should be "practically" the same.)

code_t + sources_t => data_t

Thus, the code and the source data at a point in time t is the "Single source of truth"  for the data at time t.
Using timestamps for the source data and tagged commits in version control for code (git) we can establish exactly how we arrived at each state of the data.

Separating raw data in files from the database itself and rebuilding the database from these sources for each run has some important pros versus maintaining the state of a database and incrementally updating the data for each run:

* Development becomes faster when we can drop or modify anything in the database without fear of corrupting it for anyone else while we develop.
* Development becomes easier to distribute across more people when each person can have their own copy to develop against, no fear of stepping on each others work.
* Merging of work from developers happens not by "could you push that data to the database" but "could you commit that code to the repository so it ends up in the next rebuild".
* If the production database is always rebuilt from the latest tagged release of the master branch of the code we all know exactly how the data ended up in the state it's in, no chance of diverging source trees and unknown scripts being involved.
* Maintaining versions becomes much easier, there is no need for large versioned database backups.
* Storing the raw sources is the most storage-efficient way of maintaining history. Current size of all active sources is \~5GB, dumping the entire database takes hundreds of gigabytes and would have to be done monthly.
* It ensures data integrity, `sources_t + code_t => data_t` can be run, tested and rerun. On the contrary `data_(t-1) + sources_t + code_t => data_t` means we always depend recursively on the initally loaded data.

It is important to note that there are more pros than simply replicability to this approach, the increase in speed of development from allowing each developer to build their own copy of the database are significant when it comes to adding new source data.

How to implement this in practice?

## Short version

* Fetching script fetches each data sources raw data into timestamped files.
* Files are stored in Amazon S3 or similar.
* `views.apps.data.rebuild_from_sources` creates a new database from the sources.
* Monthly updates fetch the sources that are updated monthly to the shared storage and rebuilds.
* Need for database persistence can be accomodated through having multiple databases.
* Total rebuild runtime is 2h, reloading a problematic source while developing can be as quick as 10 minutes.

## Spec

A lot of different sources are used to construct the ViEWS data (priogrid, cshapes, GED, ACLED, WDI, SSP, VDem, REIGN, etc, with more to come).
In order to make this addition of sources as smooth and pain-free as possible as much of the data specification as possible is contained in spec files in the `views/apps/data/specs/` dir.
Each source dataset gets a specfile where things like identifier names, lists of columns to include, destination tables, URLs for fetching, API versions, etc are organised.

These are in the YAML format and are versioned along with the rest of the code.
A user that checks out code from a certain date will get the same specs that were in use at that time.
A user that wants to change which columns are loaded from each source, how many imputations to do,  or some other high level parameter of the loading of the data source can do so here without touching any SQL or Python code.
Abstracting away these high level parameters from "actual" code means control is easier and mistakes less likely.

This centralised point of information for columns lists is another major feature of this implementation, there is no need for copy-pasting large lists of columns around queries to get a particular piece of data through the process: every column in the specfiles `cols_data` section is carried through the entire pipeline.

The specfiles also contain recodings of data (such as country names that don't match our system), certain values for which to drop rows, etc.

## Fetch - Download and store

The first part of the data loading process is fetching it from sources.

fetch/fetch.py downloads data from sources direct download URLs and APIs and stores them in the directory specified by the `dirs/dir_data_raw` field in the views config file at `\~/.views/config.json` by default.

The structure there is sourcename/version/timestamp/data.tar.xz, everything we fetch ends up in a data.tar.xz file.
For APIs this is commonly .json pages, for WDI it's a .zip file containing .csv files and more, for cshapes its a .zip with a shapefile, etc.

Each data source has it's own function in the fetch module.
As little transformation and parsing of the data as possible happens in the fetch.
Some APIs require us to a be a bit interactive (do we need more pages?) but as little logic as possible should go in here.

Some sources aren't fetchable automatically, notably VDEM requires manual clicking.
These odd sources that aren't frequently updated can be downloaded, compressed and timestamped manually.

This current implementation simply stores these raw files in a directory on the local machine.
To share these and establish a single source of truth for these files I suggest we write a program that can push these to a central Amazon S3 Bucket or self-hosted alternative (MinIO) that we make available to the public.
The fetched data in this bucket is the common source of truth that will build production data.

The data in this bucket will

* Never be deleted
* Be regularly backed up
* Only added to in the form of new timestamped archives.
* Be readable by the public
* Be writable by the project

It is not up to the individual user to download from the sources, this is done by one or more members of the ViEWS team and stored centrally.
The point is to provide a single consistent snapshot of each source at each point in time.

## Staging - model - schema

Before we can use the data we need to stage it to our structure.
Our analysis happens geographically at the priogrid and country level and temporally at monthly and yearly resolutions.
The relationships between these levels form our levels of analysis:

* year, month, country, grid.

The code for building staging is in `views.apps.data.model.build` and is primarily a wrapper around SQL queries in `views/apps/data/model/queries`.
Building the model depends on cshapes, priogrid geometry and the priogrid data to be loaded.


### Country

Our country definitions come from cshapes which provides the start and end date of country's existence and their gwno (Gleditsch and Ward country codes).
These start and end dates are used to create the temporal extent of each country's existence.

### PRIO-GRID

Priogrid definitions come from the priogrid API and shapefile downloaded from the priogrid website.
The yearly priogrid data contains a gwno which is used to relate grids to countries.

### Implementation differences to original DB

The current implementation in place for the ViEWS project relies heavily on updating and inserting data in-place in tables, which is slow.
This new implementation achieves much higher speed by almost always creating new tables, which is faster.a
This makes rebuilding the database feasible from a runtime perspective.

Another change from the original database was to attach all identifiers directly to each staging table, saving developers who wish to add data joining that in themselves.
This breaks some of the normalisation, as the same data (identifiers) not resides in multiple places.
It does however make attaching identifiers to sources easier as the developer doesn't have to write as many joins to get the ids they need, thus reducing the chance for an error in that step.
Apart from this the rest of the implementation is fully normalised.

As opposed to the original ViEWS database no actual data is attached to the staging tables, only identifiers.
They serve as the base for the final flat tables as as linking tables for the different source identifiers (gwno, isoab, etc).
The actual data is kept in tables in the per-source schemas and absence of duplicates / normalisation is guaranteed by unique constraints on these tables.

## Load sources

Loading is the process where each source is ingested into the database and our structure of analysis.

This is what happens:

* First the timestamped data.tar.xz fetched from either the local raw data dir (while writing updates) or the S3 bucket (for production) and is extracted to a local temp directory.
* Any necessary transformations are done in python before loading. This includes transforming from wide to long format for WDI or whatever else is best done before data hits the database.
* A schema for the source is created. Each source gets its own schema.
* Data is loaded into a raw table in its schema.
* Our identifiers (such as pg_id, country_id and month_id) are attached and joined with the data into a new table using a query for each source.
* Optinoally, interpolation and imputation of missingness is performed.
* Intermediate tables are deleted.
* At the end of each loader there is a set of tables in the sources schema called $source.$loa for unimputed data and $source.$loa_imp_$method_$number for imputed datasets.

Examples:
* wdi.cy: unimputed WDI data at country_year level. has columns country_year_id, country_id, year and data columns.
* pgdata.pgy: has the priogrid data at yearly level. It has columns priogrid_year_id, pg_id, year and data columns.
* fvp.cy_imp_mice_1 has imputed FVP data at country_year level. Has columns country_year_id, country_id and data columns with no missingness.

Each loader is responsible for ensuring that the public tables it produces have no duplicate rows.
This is achieved by a CREATE UNIQUE INDEX call on the loa identifier (such as country_year_id) of each table.
If there are duplicates this fails and the process stops.
This ensures normalisation.

For versioned sources, such as UCDP GED API, each version of the API is stored as a separate file in the raw data directory / raw data S3 bucket.
We can apply any rule of incremental updating, manual edits or filters we want in the GED loading script.
The current version is overly simple. It simply loads all the events from all the versions listed in the spec.yaml and drops duplicates of events that appear in multiple versions, keeping the latest version of that event.
It then counts deaths and event counts by category and writes that to ged.pgm, ged.cm, ged.pgy and ged.cy.
I'm sure there's more filtering, processing, aggregation and other things to do and this system lets us apply any rules we want to any specific version.

If we detect a problem with a specific version of any data source we can simply write a fix for it and re-run the load of it.

## Flat

The final product of this data pipeline is a number of views in the flat schema.
These form the final data that is read by the prediction pipeline to produce our forecasts.

These views are defined by the specfile in specs/flat.yaml and produced by running `views.apps.data.flat.flatten()`
See that specfile for examples.

Each view is defined by an entry that specifies

* The base level of analysis (pgm/pgy/cy/cm/etc)
* which geographic region to include
* which source data tables to join in

Because every source table has their LOA-specific identifier attached and the staging tables are also fully linked we can automatically build the SQL joins for attaching any source to any lower level of analysis (country sources can be included in a priogrid table flat table but not the other way around.).

The choice of views instead of tables was made because:
* The physical space of 10 priogrid monthly tables is very large, views take no space.
* The performance impact when fetching was small (20% longer fetch times compared to tables).
* They are created instantly, reducing total runtime from start->data ready because we skip the intermediate step of writing the flat table to disk in the database server.

This replaces the preflight schema in the old database.
The advantage is that:

* We can combine as many imputations as we want, imputation at the source level keeps the data managable in size.
* We can create separate views for africa, global, or whatever other geographic restriction we want.
* Users don't have to write SQL to get data out, they just update the specfile and run flatten().

# Monthly updates and consistency

ViEWS operates on a monthly schedule with updates of sources each month.
Some sources are annual (WDI, FVP, etc) and some are monthly.
I propose the following routine for this, DM is the "data manager", someone from our team.

* DM updates the specfiles for sources with version-dependent fetching info. Currently only GED needs this with a new API version part for each month.
* DM runs fetcher scripts for the monthly updated sources to get the latest raw data to their local raw data dir. Currently GED, ACLED, SPEI, ICGCW and Reign are update monthly. Sources can also be fetched manually.
* The DM writes a timestamp file in the repository with the timestamp of the latest fetched source data at the current time.
* DM rebuilds their own local copy of the database from these newly fetched sources and the data already available in the S3 bucket.
* DM writes any patches or code updates necessary for the newly fetched raw data to build a correct database.
* Once the newly fetched raw data and updated code is verified to create a working database the sources DM just fetched to their local machine are uploaded to the common S3 bucket.
* The DM commits+pushes the code that was verified to create a working database with the most recent data and puts a git tag on it like "d.2020.01.01" where d is for data and the date.
* The DM rebuilds the production database from the data now in S3 and the code tagged r.2020.01.01.data. This ensures the same code runs on the same input data, which we already verified locally to produce a working database.

This process is repeated each month.

The DM can of course replace their local machine in this routine with any development machine.
This process gives the DM complete control to manage any manual fixes needed for each month. Even manual edits to the source data are possible as the source data are uploaded from the DM's machine after being verified to create a working db.
Of course fixes in code are better as they clearly document what was done to the raw data.
It also lets the DM download problematic sources manually should they need to.
There is no need for the fetching part to be redoable as we can never trust external sources to return the same data at a later point in time anyway.
External sources are out of our control and this procedure fixes that.

# Replicating

To replicate a previous version of the database is then a simple process.

* User checks out the code with the appropriate historical git tag.
* User rebuilds their database from the code, which includes the timestamp file that tells the rebuilding script to only include data older than that timestamp. This ensures only the source data available at the time the build happened originally are included.
* The rebuilding script gets all the needed data, based on the timestamp, from the public S3 bucket and rebuilds the database.
* Same code + same source data => same resulting db. The only differing things should be imputation noise.


# Database availability, persistence and building from scratch

The probability of a dropped and not successfully recreated database are of course not zero, there is a human in the loop.
This could be mitigated by the data pipeline building the new database to a database named views_next, if it runs fine and data looks good it proceeds to dropping the exists database `views` and renames `views_next` to `views`. If it detects some failure it simply aborts the rebuild and the existing data is unchanged.

Recreating the database completely from sources has the advantage of code_t + sourcedata_t => data_t being idempotent.
It is guaranteed to always produce the practically the same data.
If we leave data in the database and update it in place we end up in
data_(t-1) + sources_t + code_t => data_t, which means anyone wishing to replicate always needs data_(t-1) to get data_t, which isn't possible unless we distribute database dumps every month.

A solution to the problem of storing persistent things in a database, such as intermediate results for development, model metadata, surveys, tweets, manually coded actor information, etc, is to use multiple databases.
One rebuildable database for the actual datasets we produce and persistent databases for things that need persistence.
We could drop and rebuild the dataset database and keep all the others indefinitely.
Connecting to multiple databases can be easily accomodated with a small update of the `views.utils.dbutils` module.

This would give us:
* A rebuildable from sources "data-database" for data going in to the pipeline.
* Any number of persistent databases for everything else.

Currently I think an appropriate set of databases could be
* data: Rebuilt monthly, contains the latest data
* results: Persistent results from runs, organised in schemas by run_id. For ensembling, evaluation and model development work, holds metadata for models.
* surveys: Persistent storage for export surveys
* actors: Persistent storage for actor layer

Data that we produce and needs persistence can be included in the data-database through monthly exports from them that we treat as any other input data source, i.e. put it on S3 and load like any other.

Example: actor information is continually updated in an actor database.
Whatever data we need to include in the runs from the actor database can be exported monthly from the actor database, published to S3 and then loaded like any external source.

# S3 storage

S3, or Simple Storage Service, is Amazons solution to object (file) storage in the cloud.
An on-premise alternative that follows the same API is MinIO (see www.min.io).
The implementation isn't important as long as it is

* readable by the project
* readable by the public
* writable by the project
* backed up
* not retroactively modified
*




