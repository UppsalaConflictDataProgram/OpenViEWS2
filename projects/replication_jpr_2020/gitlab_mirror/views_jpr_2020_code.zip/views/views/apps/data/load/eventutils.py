""" Common functions for event datasets (GED and ACLED) """
import logging
import tempfile
import multiprocessing as mp
import json
import os
import string

import pandas as pd

from views.apps.data.fetch import fetchutils
from views.utils import pyutils, dbutils

Logger = logging.getLogger(__name__)


def _page_to_df(path_json):
    """ Load a json page into a dataframe """

    with open(path_json, "r") as f:
        data = json.load(f)
    df = pd.DataFrame(data)
    Logger.debug(f"Parsed {path_json}")

    return df


def cleanup(spec):

    to_drop = [
        "fqtable_aggregated_cm",
        "fqtable_aggregated_cy",
        "fqtable_aggregated_pgm",
        "fqtable_aggregated_pgy",
        "fqtable_attached",
        "fqtable_data_raw",
    ]

    for key in to_drop:
        dbutils.drop_table(spec[key])
    name = spec["name"]
    Logger.info(f"Cleaned up {name}")


def make_df_events(path_tar):
    """ Make dataframe of events from .jsons in .tar at.xz path_tar """

    with tempfile.TemporaryDirectory() as tempdir:
        # Extract pages.jsons from data.tar.xz
        fetchutils.extract_all_files(
            path_archive=path_tar, dir_destination=tempdir
        )
        paths = pyutils.get_paths_from_dir(tempdir)
        Logger.debug(f"Found {len(paths)} pages of data.")

        with mp.Pool() as pool:
            results = [
                pool.apply_async(_page_to_df, args=(path,)) for path in paths
            ]
            df = pd.concat([res.get() for res in results])

        return df


def _aggregate_events(fqtable_attached, fqtable_agg, ids, col_tov, cols_fat):
    """ Compute counts of events and sums of fatalities

    Args:
        fqtable_attached: table where attached (with ids) events are
        fqtable_agg: table to write to
        ids: timevar and groupvar to group by
        col_tov: Column indicating Type Of Violence (tov)
        cols_fat: Which columns to count fatalities by (low/best/etc.)

    """

    def sum_fatalities(df_events, ids, cols_fat, col_tov):

        # Group by ids and type of violence
        vars_grouping = ids + [col_tov]

        # Subset to grouping and fatalities cols
        df_sums = df_events[vars_grouping + cols_fat]

        Logger.debug(f"Summing fatalities by {vars_grouping}")
        # Sum fatalities by (groupvar-timevar-type_of_violence)
        df_sums = df_sums.groupby(vars_grouping).sum().reset_index()

        # Fix the indexing
        df_sums = df_sums.set_index(ids + [col_tov]).unstack()
        # Flatten the column names
        df_sums.columns = df_sums.columns.map("_".join).str.strip("_")

        return df_sums

    def count_events(df_events, ids, col_tov):

        # Group by ids and type of violence
        vars_grouping = ids + [col_tov]
        # size() counts rows per group

        Logger.debug(f"Counting events by {vars_grouping}")
        df_counts = df_events.groupby(vars_grouping).size()

        # Fix the indexing
        df_counts = df_counts.unstack()
        df_counts.reset_index().set_index(ids)
        # Get rid of hierarchical name thingy
        df_counts.columns.name = None
        df_counts = df_counts.add_prefix("count_")

        return df_counts

    Logger.info(f"Started aggregating by {ids + [col_tov]}.")

    Logger.debug(f"Aggregate fetching attached events")
    df_events = dbutils.db_to_df(fqtable=fqtable_attached)

    df_fatalities = sum_fatalities(
        df_events=df_events, ids=ids, cols_fat=cols_fat, col_tov=col_tov
    )

    df_counts = count_events(df_events=df_events, ids=ids, col_tov=col_tov)

    df = df_counts.join(df_fatalities)

    Logger.info(f"Pusing to {fqtable_agg}")
    dbutils.df_to_db(df=df, fqtable=fqtable_agg)
    Logger.info(f"Finished aggregating by {ids + [col_tov]}.")


def run_aggregate(spec):
    """ Compute aggregates at each level of analysis """

    # CM
    _aggregate_events(
        fqtable_attached=spec["fqtable_attached"],
        fqtable_agg=spec["fqtable_aggregated_cm"],
        ids=spec["aggregation"]["ids_cm"],
        col_tov=spec["aggregation"]["col_tov"],
        cols_fat=spec["aggregation"]["cols_fat"],
    )
    # CY
    _aggregate_events(
        fqtable_attached=spec["fqtable_attached"],
        fqtable_agg=spec["fqtable_aggregated_cy"],
        ids=spec["aggregation"]["ids_cy"],
        col_tov=spec["aggregation"]["col_tov"],
        cols_fat=spec["aggregation"]["cols_fat"],
    )

    # PGM
    _aggregate_events(
        fqtable_attached=spec["fqtable_attached"],
        fqtable_agg=spec["fqtable_aggregated_pgm"],
        ids=spec["aggregation"]["ids_pgm"],
        col_tov=spec["aggregation"]["col_tov"],
        cols_fat=spec["aggregation"]["cols_fat"],
    )
    # PGY
    _aggregate_events(
        fqtable_attached=spec["fqtable_attached"],
        fqtable_agg=spec["fqtable_aggregated_pgy"],
        ids=spec["aggregation"]["ids_pgy"],
        col_tov=spec["aggregation"]["col_tov"],
        cols_fat=spec["aggregation"]["cols_fat"],
    )


def build_indices(fqtable, timevar, groupvar, loa_id, **kwargs):
    """ Build indices on timevar, groupvar, loa_id and their combos """

    dbutils.create_table_index(fqtable=fqtable, cols=[timevar])
    dbutils.create_table_index(fqtable=fqtable, cols=[groupvar])
    dbutils.create_table_index(
        fqtable=fqtable, cols=[timevar, groupvar], unique=True
    )
    dbutils.create_table_index(
        fqtable=fqtable, cols=[groupvar, timevar], unique=True
    )
    dbutils.create_table_index(fqtable=fqtable, cols=[loa_id], unique=True)


def run_stage(spec):
    """ Create staged.loa as staging.loa Left join ged.agg_loa

    coalesce(colname, 0) in each row fills rows unobserved in GED
    with zeros.
    """

    Logger.info(f"Started staging {spec['name']}")

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "queries", spec["name"], "stage.sql")
    with open(path_query, "r") as f:
        query_template = string.Template(f.read())

    query_cm_args = {
        "fqtable": spec["fqtable_staged_cm"],
        "groupvar": "country_id",
        "timevar": "month_id",
        "loa": "cm",
        "loa_id": "country_month_id",
        "fqtable_stage": "staging.country_month",
    }

    query_cy_args = {
        "fqtable": spec["fqtable_staged_cy"],
        "groupvar": "country_id",
        "timevar": "year",
        "loa": "cy",
        "loa_id": "country_year_id",
        "fqtable_stage": "staging.country_year",
    }

    query_pgm_args = {
        "fqtable": spec["fqtable_staged_pgm"],
        "groupvar": "pg_id",
        "timevar": "month_id",
        "loa": "pgm",
        "loa_id": "priogrid_month_id",
        "fqtable_stage": "staging.priogrid_month",
    }

    query_pgy_args = {
        "fqtable": spec["fqtable_staged_pgy"],
        "groupvar": "pg_id",
        "timevar": "year",
        "loa": "pgy",
        "loa_id": "priogrid_year_id",
        "fqtable_stage": "staging.priogrid_year",
    }

    dbutils.execute_query(query_template.substitute(query_cm_args))
    build_indices(**query_cm_args)
    dbutils.execute_query(query_template.substitute(query_cy_args))
    build_indices(**query_cy_args)
    dbutils.execute_query(query_template.substitute(query_pgm_args))
    build_indices(**query_pgm_args)
    dbutils.execute_query(query_template.substitute(query_pgy_args))
    build_indices(**query_pgy_args)

    Logger.info(f"Finished staging {spec['name']}")
