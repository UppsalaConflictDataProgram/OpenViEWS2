""" Fetch raw tweets """

import os
import time

import tweepy

from views.apps.data.fetch import fetchutils
from views.apps.data.fetch.twitter import common


class FileListener(tweepy.StreamListener):
    """ Listener that appends to file for each tweet, very high IO """

    def __init__(self, dir_data):
        tweepy.StreamListener.__init__(self)
        self.dir_scratch = dir_data

    def on_data(self, raw_data):
        fname = f"{fetchutils.utc_now_minute()}.raw"
        path = os.path.join(self.dir_scratch, fname)
        with open(path, "a") as f:
            f.write(raw_data)

    def on_error(self, status_code):
        print(status_code)


class BufferedFileListener(tweepy.StreamListener):
    """ Buffered tweet listener that writes a file per minute """

    def __init__(self, dir_scratch):
        tweepy.StreamListener.__init__(self)
        self.dir_scratch = dir_scratch
        self.tweetbuffer = []
        self.time_last_flush = fetchutils.utc_now_minute()

    def write_data(self):
        """ Write tweets to disk"""

        # Update times
        timestamp = fetchutils.utc_now_minute()
        self.time_last_flush = timestamp

        # Flush the buffer to a string for writing
        data_to_write = "".join(self.tweetbuffer)
        n_tweets_in_buffer = len(self.tweetbuffer)
        self.tweetbuffer.clear()

        # Write the the data to file
        fname = f"{timestamp}.raw"
        path = os.path.join(self.dir_scratch, fname)
        with open(path, "w") as f:
            f.write(data_to_write)
        print(f"Fetcher wrote {n_tweets_in_buffer} tweets to {path}")

    def on_data(self, raw_data):

        # Store the data in the buffer
        self.tweetbuffer.append(raw_data)

        # If we're in a new minute from last flush we write to file.
        if not self.time_last_flush == fetchutils.utc_now_minute():
            self.write_data()

    def on_error(self, status_code):
        print(status_code)


class PrintListener(tweepy.StreamListener):
    """ Print each tweet text to screen """

    def on_status(self, status):
        print(status.text)

    # def on_data(self, raw_data):
    #     print(raw_data)

    def on_error(self, status_code):
        print(status_code)


def main():
    """ Run the fetcher """

    dir_scratch = common.DIR_SCRATCH_RAW
    auth = common.AUTH
    while True:
        try:
            listener = BufferedFileListener(dir_scratch=dir_scratch)
            stream = tweepy.Stream(auth=auth, listener=listener)
            stream.sample()
        # Connection issues can generate a range of exceptions,
        # most of which are solved when simply retrying.
        # pylint: disable=broad-except
        except Exception as exc:
            print(exc)
            print("Something went wrong")
            print("Sleeping 60s and retrying...")
            time.sleep(60)


if __name__ == "__main__":
    main()
