""" SQL model module. Rebuilds staging from sources """

import os
import logging


from views.utils import dbutils
from views.apps.data.common import utils
from views.apps.data.load import pgdata, pggeom, cshapes

Logger = logging.getLogger(__name__)


def path_query(name):
    """ Get the path to staging query named name """
    fname = f"{name}.sql"
    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_queries = os.path.join(this_dir, "queries")
    path = os.path.join(dir_queries, fname)

    return path


def build_staging(spec):
    """ Build staging schema """
    dbutils.recreate_schema("staging")
    dbutils.register_funcs()
    dbutils.execute_query_from_file(
        path=path_query("create_year"), params=spec["times"]
    )
    dbutils.execute_query_from_file(path=path_query("create_month"))
    dbutils.execute_query_from_file(path=path_query("create_country"))
    dbutils.execute_query_from_file(path=path_query("create_country_year"))
    dbutils.execute_query_from_file(path=path_query("create_country_month"))
    dbutils.execute_query_from_file(path=path_query("create_priogrid"))
    dbutils.execute_query_from_file(path=path_query("create_priogrid_year"))
    dbutils.execute_query_from_file(path=path_query("create_priogrid_month"))


def build_model():
    """ Build the SQL model from cshapes, pgdata and pggeom """

    Logger.info("Started building SQL model")

    cshapes.load_cshapes()
    pgdata.load_initial_pgdata()
    pggeom.load_pggeom()

    spec = utils.load_specfile("model")
    build_staging(spec)

    Logger.info("Finished building SQL model")


if __name__ == "__main__":
    build_model()
