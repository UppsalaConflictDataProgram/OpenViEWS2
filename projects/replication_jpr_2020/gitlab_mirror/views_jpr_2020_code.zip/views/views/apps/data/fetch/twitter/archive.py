""" Archive .raw files with tweets from the previous hour every hour """
import os
import time
import collections


from views.apps.data.fetch.twitter import common
from views.apps.data.fetch import fetchutils

from views.utils import awsutils


def get_hour_from_path(path):
    """ Get the YmdH component from a filename at path """
    fname = os.path.basename(path)
    # Get 20180101-13 from 20180101-133701 which is first 11 chars
    utc_hour = fname[0:11]
    return utc_hour


def get_paths_raw():
    """ Get list of paths to raw tweet files from previous hours """

    def not_this_hour(path):
        """ True for hourly timestamped files at path for previous hours
        """
        if get_hour_from_path(path) == fetchutils.utc_now_hour():
            not_this_hour = False
        else:
            not_this_hour = True

        return not_this_hour

    workdir = common.DIR_SCRATCH_RAW
    paths = [
        os.path.join(workdir, f)
        for f in os.listdir(workdir)
        if os.path.isfile(os.path.join(workdir, f))
    ]
    paths = [path for path in paths if path.endswith(".raw")]
    paths = list(filter(not_this_hour, paths))

    print(f"Archiver found {len(paths)} raw files")

    return sorted(paths)


def assign_raw_into_archives(paths_raw):
    """ Create a dict mapping paths to raw tweet files to hourly archives """

    paths_by_hour = collections.defaultdict(list)
    for path in paths_raw:

        # Name the target archive after the hour of the raw file
        hour = get_hour_from_path(path)
        fname_archive = f"{hour}.tar.xz"
        path_archive = os.path.join(common.DIR_SCRATCH_TARS, fname_archive)

        paths_by_hour[path_archive].append(path)

    return paths_by_hour


def compress_by_groups(groups):
    """ Compress raw tweets as defined by groups dict """

    paths_archives = []

    for path_archive, paths_members in groups.items():
        fetchutils.compress_files(
            paths_sources=paths_members, path_destination=path_archive
        )
        print(f"Done compressing to {path_archive}.")
        paths_archives.append(path_archive)
        # Cleanup
        for path in paths_members:
            os.remove(path)
            print(f"Deleted {path}")

    return paths_archives


def send_compressed_to_s3(paths, name_bucket):
    """ Send the compressed tarballs to S3 and delete from disk """
    for path in paths:
        awsutils.upload_file(path, name_bucket)
        os.remove(path)
        print(f"Deleted {path}")


def archive_to_s3():
    """ Send all raw tweets to S3 once an hour """

    # Make sure the bucket exists
    awsutils.create_s3_bucket(
        name=common.BUCKET["name"],
        region=common.BUCKET["region"],
        if_exists="pass",
    )

    while True:
        paths_raw = get_paths_raw()
        pathdicts = assign_raw_into_archives(paths_raw)
        paths_archives = compress_by_groups(pathdicts)
        send_compressed_to_s3(paths_archives, common.BUCKET["name"])
        time.sleep(60 * 10)


def archive_to_disk():

    while True:
        paths_raw = get_paths_raw()
        pathdicts = assign_raw_into_archives(paths_raw)
        paths_archives = compress_by_groups(pathdicts)
        time.sleep(60 * 10)


def main():
    """ Main loop """
    archive_to_disk()


if __name__ == "__main__":
    main()
