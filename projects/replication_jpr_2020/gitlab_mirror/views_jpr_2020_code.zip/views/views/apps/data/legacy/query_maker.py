""" Hack! Make queries for attaching vdem and WDI  """
# pylint: skip-file

import os
from views.apps.data.common import utils


def _get_cols_prefixed(spec):
    return [f"{spec['prefix']}{col}" for col in spec["cols_data"]]


def _get_drops(cols_data_prefixed):
    drop = "ALTER TABLE staging.country_year DROP COLUMN IF EXISTS {col};"
    return [drop.format(col=col) for col in cols_data_prefixed]


def _get_updates(source_alias, cols_data_prefixed, cols_data):

    update = "{col_pfx} = {source_alias}.{col}"

    return [
        update.format(col_pfx=col_pfx, col=col, source_alias=source_alias)
        for col_pfx, col in zip(cols_data_prefixed, cols_data)
    ]


def _get_adds(cols_data_prefixed):
    add = "ALTER TABLE staging.country_year ADD COLUMN {col} float;"
    return [add.format(col=col) for col in cols_data_prefixed]


def make_attach_wdi():
    spec = utils.load_specfile("wdi")

    cols_data_prefixed = _get_cols_prefixed(spec)
    cols_data = spec["cols_data"]

    # Headers
    update_header = "\n".join(("UPDATE staging.country_year", "SET"))
    update_tail = "\n".join(
        (
            "FROM wdi.data as wdi",
            "WHERE",
            "staging.country_year.country_id = wdi.country_id",
            "AND ",
            "staging.country_year.year_id = wdi.year;",
        )
    )

    print("\n".join(_get_drops(cols_data_prefixed)))
    print("\n".join(_get_adds(cols_data_prefixed)))
    print(update_header)
    print(
        ",\n".join(
            _get_updates(
                source_alias="wdi",
                cols_data_prefixed=cols_data_prefixed,
                cols_data=cols_data,
            )
        )
    )
    print(update_tail)


def make_attach_vdem():
    spec = utils.load_specfile("vdem")

    cols_data_prefixed = _get_cols_prefixed(spec)
    cols_data = spec["cols_data"]

    # Headers
    update_header = "\n".join(("UPDATE staging.country_year", "SET"))

    update_tail = "\n".join(
        (
            "FROM vdem.data as vdem",
            "WHERE",
            "staging.country_year.country_id = vdem.country_id",
            "AND ",
            "staging.country_year.year_id = vdem.year;",
        )
    )

    print("\n".join(_get_drops(cols_data_prefixed)))
    print("\n".join(_get_adds(cols_data_prefixed)))
    print(update_header)
    print(
        ",\n".join(
            _get_updates(
                source_alias="vdem",
                cols_data_prefixed=cols_data_prefixed,
                cols_data=cols_data,
            )
        )
    )
    print(update_tail)


if __name__ == "__main__":
    # make_attach_wdi()
    make_attach_vdem()
