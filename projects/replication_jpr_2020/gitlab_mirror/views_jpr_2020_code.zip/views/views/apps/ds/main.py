import os
import argparse
from subprocess import call
from utils import make_call, make_dirstructure, create_dirs
import sys
import shutil
import multiprocessing as mp

from views.utils import pyutils


def get_run_id_from_paramfile(path_paramfile):
    params = pyutils.load_json(path_paramfile)
    return params["run_id"]


# Parse parameters
parser = argparse.ArgumentParser()

parser.add_argument(
    "--dir_scratch", type=str, help="directory to work in", required=True
)
parser.add_argument("--dir_input", type=str, help="directory to read data from")
parser.add_argument(
    "--path_paramfile",
    type=str,
    help="directory where the paramfile lives",
    required=True,
)

args_main = parser.parse_args()

dir_scratch = args_main.dir_scratch
dir_input = args_main.dir_input
path_paramfile = args_main.path_paramfile
run_id = get_run_id_from_paramfile(path_paramfile)
dir_scratch = os.path.join(dir_scratch, run_id)

print(f"dir_input: {dir_input}")
print(f"path_paramfile: {path_paramfile}")
print(f"run_id: {run_id}")
print(f"dir_scratch: {dir_scratch}")


make_dirstructure(dir_scratch)
shutil.copy(path_paramfile, os.path.join(dir_scratch, "params.json"))

# Prepare argument dictionaries for component scripts
argdict_dir_scratch = {"dir_scratch": dir_scratch}
argdict_dir_input = {"dir_input": dir_input}
args = [argdict_dir_scratch]

#########################################################################################
################################## RUNNING STARTS HERE ##################################
#########################################################################################


pyfile = "prep.py"
args = [argdict_dir_scratch, argdict_dir_input]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "ts.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "spatial.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "transforms.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "train.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "sim.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "merger.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)

pyfile = "aggregate.py"
args = [argdict_dir_scratch]
c = make_call(pyfile, args)
print(c)
ret = call(c, shell=True)
if ret != 0:
    sys.exit(1)
