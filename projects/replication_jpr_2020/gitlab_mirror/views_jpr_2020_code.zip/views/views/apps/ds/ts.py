import os
import multiprocessing as mp
import pandas as pd

import argparse

from utils import (
    split,
    load_params,
    make_work_data,
    add_paths_to_jobs,
    make_jobs_merge,
    worker_merge,
)


def worker_ts(job):
    def count_while(var, criteria, seed=0):
        """
        Count time as long as variable meets criteria, then resets
        """

        def rolling_count(var, criteria):
            if eval("var" + criteria):
                rolling_count.count += 1
                return rolling_count.count
            else:
                previous = rolling_count.count + 1
                rolling_count.count = 0
                return previous

        rolling_count.count = seed
        return var.apply(rolling_count, criteria=criteria)

    print("starting", job["name"])

    df = pd.read_hdf(job["path_input"])
    print("read", job["path_input"])

    d = job

    varname = d["name"]

    if "lag" in d.keys():
        df[d["name"]] = df.groupby(level=1)[d["var"]].shift(d["lag"])

    if "value" in d.keys():
        df[d["name"]] = df[d["name"]] == d["value"]

    if "cw" in d.keys():
        if "seed" in d.keys():
            df[d["name"]] = df.groupby(level=1)[d["var"]].apply(
                count_while, criteria=d["cw"], seed=d["seed"]
            )
        else:
            df[d["name"]] = df.groupby(level=1)[d["var"]].apply(
                count_while, criteria=d["cw"]
            )

    if "ma" in d.keys():
        df[d["name"]] = df.groupby(level=1)[d["var"]].apply(
            lambda x: x.rolling(window=d["ma"]).mean()
        )

    df.sort_index(inplace=True)
    df[[varname]].to_hdf(job["path_output"], key="data", mode="w")
    print("wrote", job["path_output"])


def main_ts():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dir_scratch", type=str, help="temp directory in which to save data"
    )

    args = parser.parse_args()

    dir_scratch = args.dir_scratch

    path_params = os.path.join(dir_scratch, "params.json")
    dir_data = os.path.join(dir_scratch, "data")
    dir_ts = os.path.join(dir_scratch, "ts")

    params = load_params(path_params)
    jobs = params["ts"]
    jobs_ts = add_paths_to_jobs(jobs, dir_data, dir_ts)
    make_work_data(jobs_ts, dir_data, dir_ts)

    with mp.Pool(maxtasksperchild=1) as pool:
        rs = []
        for job in jobs_ts:
            rs.append(pool.apply_async(worker_ts, (job,)))
        for r in rs:
            r.get()

    jobs_merge = add_paths_to_jobs(jobs, dir_data, dir_ts)
    jobs_merge = make_jobs_merge(jobs_merge, dir_data, dir_ts)

    for j in jobs_merge:
        worker_merge(j)


if __name__ == "__main__":
    main_ts()
