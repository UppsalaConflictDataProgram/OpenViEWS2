import os
import multiprocessing as mp
import pandas as pd

import argparse

from utils import (
    add_nsim_to_jobs,
    add_paths_to_jobs,
    load_params,
    make_data_subset,
    split,
    add_varsets_to_modeljobs,
    get_model_vars,
)

from models_sm import load_model


def worker_train(job):

    message = " started job for " + job["name"]
    print(message)

    # Don't load from file, we haven't trained it yet!
    model = load_model(job, from_file=False)
    model.from_description()

    df = pd.read_hdf(job["path_input"], key="data")
    model.train(df)
    model.populate(job["nsim"])
    model.save()


def main_train():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dir_scratch", type=str, help="temp directory in which to save data"
    )

    args = parser.parse_args()

    dir_scratch = args.dir_scratch

    path_params = os.path.join(dir_scratch, "params.json")
    dir_data = os.path.join(dir_scratch, "data")
    dir_train = os.path.join(dir_scratch, "train")

    # Use half the cores for mergin to keep mem within bounds
    # load jobs from json in the root process
    params = load_params(path_params)
    jobs = params["models"]

    jobs = add_paths_to_jobs(jobs, dir_data, dir_train)
    print(jobs)
    jobs = add_varsets_to_modeljobs(jobs)
    jobs = add_nsim_to_jobs(jobs, params["nsim"])

    train_start = params["times"]["train_start"]
    train_end = params["times"]["train_end"]
    allvars = get_model_vars(jobs)

    make_data_subset(allvars, train_start, train_end, dir_data, dir_train)

    with mp.Pool(maxtasksperchild=1) as pool:
        rs = []
        for job in jobs:
            rs.append(pool.apply_async(worker_train, (job,)))
        for r in rs:
            r.get()

    # for job in jobs:
    #     worker_train(job)


if __name__ == "__main__":
    main_train()
