""" Wrapper for EBMA """
import logging
import os
import string
import tempfile

import pandas as pd

from views.utils import pyutils, datautils, config

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)

Logger = logging.getLogger(__name__)


def _read_template():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(this_dir, "ebma_template.R"), "r") as f:
        template_str = f.read()

    template = string.Template(template_str)

    return template


def ebma(
    df_calib,
    df_test,
    s_calib_actual,
    tolerance=0.001,
    shrinkage=3,
    const=0.01,
    maxiter=10_000,
):
    """ Compute EBMA predictions and weights using wrapped R EBMAforecast

    Args:
        df_calib: Dataframe with constituent models predictions for calibration
        df_test: Dataframe with constituent model
        predictions for test period
        s_calib_actual: Series with actuals for the calibration partition
        tolerance: See R docs
        shrinkage: See R docs
        const: See R docs
        maxiter: See R docs
    Returns:
        s_ebma: Series with ebma predictions
        weights: Dictionary of model weights

    R docs at:
    https://cran.r-project.org/web/packages/EBMAforecast/EBMAforecast.pdf

    Ensure df_calib, df_test and s_calib_actual have multiindex set.

    """

    # Copy data so we don't mess with callers data
    df_calib = df_calib.copy()
    df_test = df_test.copy()
    s_calib_actual = s_calib_actual.copy()

    # Make sure we're all indexed as expected
    datautils.assert_df_has_multiindex(df_calib)
    datautils.assert_df_has_multiindex(df_test)
    datautils.assert_df_has_multiindex(s_calib_actual)

    if not len(s_calib_actual) == len(df_calib):
        msg = "Number of rows in df_calib and s_calib_actual don't match"
        raise RuntimeError(msg)

    # EBMA assumes
    s_calib_actual = s_calib_actual.copy()
    s_calib_actual.name = "actual"

    offset = 1e-10
    upper = 1 - offset
    lower = 0 + offset

    # Sort indexes so they're aligned
    # Clip predictions
    df_calib = df_calib.sort_index().clip(lower, upper)
    df_test = df_test.sort_index().clip(lower, upper)
    df_calib_actual = pd.DataFrame(s_calib_actual.sort_index())

    with tempfile.TemporaryDirectory() as tempdir:

        path_csv_calib = os.path.join(tempdir, "calib.csv")
        path_csv_test = os.path.join(tempdir, "test.csv")
        path_csv_actuals = os.path.join(tempdir, "actuals.csv")
        path_csv_ebma = os.path.join(tempdir, "ebma.csv")
        path_csv_weights = os.path.join(tempdir, "weights.csv")
        path_rscript = os.path.join(tempdir, "ebma_script.R")

        values = {
            "PATH_CSV_ACTUALS": path_csv_actuals,
            "PATH_CSV_CALIB": path_csv_calib,
            "PATH_CSV_TEST": path_csv_test,
            "PATH_CSV_EBMA": path_csv_ebma,
            "PATH_CSV_WEIGHTS": path_csv_weights,
            "PARAM_TOLERANCE": tolerance,
            "PARAM_SHRINKAGE": shrinkage,
            "PARAM_CONST": const,
            "PARAM_MAXITER": maxiter,
        }

        template = _read_template()
        rscript = template.substitute(values)

        df_calib.to_csv(path_csv_calib, index=False)
        df_test.to_csv(path_csv_test, index=False)
        df_calib_actual.to_csv(path_csv_actuals, index=False)

        with open(path_rscript, "w") as f:
            f.write(rscript)
        cmd = ["Rscript", path_rscript]
        pyutils.run_subproc(cmd)

        df_ebma = pd.read_csv(path_csv_ebma)
        df_weights = pd.read_csv(path_csv_weights)

    df_ebma.index = df_test.index
    s_ebma = df_ebma["x"]
    s_ebma.name = "ebma"

    s_weights = df_weights["x"]
    s_weights.index = df_calib.columns
    weights_dict = s_weights.to_dict()

    return s_ebma, weights_dict


def main():

    df_calib = datautils.DfMocker(n_t=1000, n_cols=10, datatypes=["probs"]).df
    df_test = datautils.DfMocker(n_t=100, n_cols=10, datatypes=["probs"]).df
    df_actuals = datautils.DfMocker(n_t=1000, n_cols=1, datatypes=["bools"]).df
    s_calib_actual = df_actuals["b_a"]

    s_ebma, weights = ebma(df_calib, df_test, s_calib_actual)


if __name__ == "__main__":
    main()
