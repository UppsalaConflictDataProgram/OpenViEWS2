import logging
import warnings
import pandas as pd
import statsmodels.api as sm
from views.utils import statsutils
import numpy as np

Logger = logging.getLogger(__name__)

def calibrate_models(
    df_calib, df_test, s_calib_actual, check_names=True, by_logodds=True
):
    """ Calibrate df_test predictions to s_calib_actual ~ df_calib

    Args:
        df_calib: Dataframe with constituent models predictions for calibration
        df_test: Dataframe with constituent model predictions for test period
        s_calib_actual: Series with actuals for the calibration partition
        check_names: if True check that columns in df_calib and df_test match,
                     if False just assume df_calib and df_test have matching
                     columns
    Returns:
        df_test_calibrated: Dataframe with calibrated predictions for test period


    First predictions are transformed into logodds.
    Then a logit model is fit on
    "actual_outcomes ~ alpha + beta*logodds(p_calib)".
    Then alpha and beta are applied to test predictions like
    A =  e^(alpha+(beta*p_test))
    p_test_calibrated = A/(A+1)

    See: https://en.wikipedia.org/wiki/Logistic_regression

    @TODO: Explain WHY we transform to logodds first.

    """

    def check_names_match(df_calib, df_test):
        if not list(df_calib.columns) == list(df_test.columns):
            msg = "Columns in df_calib and df_test don't match exactly"
            raise RuntimeError(msg)

    def check_df_is_probs_only(df):
        if df.min().min() < 0:
            msg = "Probabilities smaller than 0 in df"
            raise RuntimeError(msg)
        if df.max().max() > 1:
            msg = "Probabilities bigger than 1 in df"
            raise RuntimeError(msg)

    def check_no_missing(df_calib, df_test, s_calib_actual):
        if df_calib.isnull().sum().sum() > 0:
            Logger.info(f"Missing in df_calib: {df_calib.isnull().sum()}")
        if df_test.isnull().sum().sum() > 0:
            Logger.info(f"Missing in df_test: {df_test.isnull().sum()}")
        if s_calib_actual.isnull().sum().sum() > 0:
            Logger.info(f"Missing in s_calib_actual: {s_calib_actual.isnull().sum()}")

    def apply_scaling_params_probs(s_test, intercept, beta):
        """ Scale logodds in s_test using intercept and beta"""
        intercept = np.ones(len(s_calib))
        X = np.array([intercept, s_test]).T
        numerator = np.exp(intercept + (beta * s_test))
        denominator = numerator + 1
        scaled_probs = numerator / denominator

        return scaled_probs

    def calibrate_by_logodds(s_calib_actual, df_calib, df_test):
        def get_scaling_params(s_calib_actual, s_calib):
            """ Gets scaling params """

            y = np.array(s_calib_actual)
            intercept = np.ones(len(s_calib))
            X = np.array([intercept, s_calib]).T

            model = sm.Logit(y, X).fit(disp=0)
            beta_0 = model.params[0]
            beta_1 = model.params[1]

            return beta_0, beta_1

        def apply_scaling_params(s_test, beta_0, beta_1):
            """ Scale logodds in s_test using intercept and beta"""
            numerator = np.exp(beta_0 + (beta_1 * s_test))
            denominator = numerator + 1
            scaled_probs = numerator / denominator

            return scaled_probs

        # Convert predictions to logodds
        df_calib_logodds = statsutils.prob_to_logodds(df_calib.copy())
        df_test_logodds = statsutils.prob_to_logodds(df_test.copy())

        df_test_calibrated = df_test[[]].copy()

        for col_calib, col_test in zip(
            df_calib_logodds.columns, df_test_logodds.columns
        ):

            beta_0, beta_1 = get_scaling_params(
                s_calib_actual=s_calib_actual,
                s_calib=df_calib_logodds[col_calib],
            )
            scaled_probs = apply_scaling_params(
                s_test=df_test_logodds[col_test], beta_0=beta_0, beta_1=beta_1
            )
            Logger.debug(
                f"Calibrated {col_calib} to {col_test} \tb0: {beta_0}, \tb1:{beta_1}"
                )
            if beta_1 < 0:
                Logger.warn(f"{col_calib} beta_1 {beta_1} is smaller than 0.")
            # Store calibrated probabilities
            df_test_calibrated[col_test] = scaled_probs

        return df_test_calibrated

    def calibrate_by_probs(s_calib_actual, df_calib, df_test):

        df_test_calibrated = pd.DataFrame(index=df_test.index)
        intercept_train = np.ones(len(df_calib))
        intercept_test = np.ones(len(df_test))

        for col_calib, col_test in zip(df_calib.columns, df_test.columns):
            y_train = np.array(s_calib_actual)
            X_train = np.array([intercept_train, df_calib[col_calib]]).T
            X_test = np.array([intercept_test, df_test[col_test]]).T
            model = sm.Logit(y_train, X_train).fit(disp=0)
            df_test_calibrated[col_test] = model.predict(X_test)
        return df_test_calibrated

    if check_names:
        check_names_match(df_calib, df_test)
    else:
        msg = (
            "Not checking column names match, make sure they're sorted properly"
        )
        warnings.warn(msg)

    check_df_is_probs_only(df_calib)
    check_df_is_probs_only(df_test)
    check_no_missing(df_calib, df_test, s_calib_actual)

    # Skeleton df for storing calibrated probs

    if by_logodds:
        df_test_calibrated = calibrate_by_logodds(
            s_calib_actual, df_calib, df_test
        )
    else:
        df_test_calibrated = calibrate_by_probs(
            s_calib_actual, df_calib, df_test
        )

    return df_test_calibrated
