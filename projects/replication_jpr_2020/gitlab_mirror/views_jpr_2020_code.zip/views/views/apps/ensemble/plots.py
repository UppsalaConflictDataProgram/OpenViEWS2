import os
import calendar

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.image as mpimg
import numpy as np

from views.apps.ensemble import ensemble as ens
from views.utils.config import CONFIG
from views.utils import pyutils, dbutils


def add_logos(fig, fig_scale):
    """ Add ViEWS logo """

    current_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(current_dir, '..', "plot", "logos", "views.png")

    logo_views = mpimg.imread(path_logo_views)

    views_axis = fig.add_axes([0.87, 0.08, 0.12, 0.06])
    url_axis = fig.add_axes([0.87, 0.06, 0.12, 0.06])

    views_axis.imshow(logo_views, interpolation="none")
    url_axis.text(
        x=0.2, y=0, s="http://views.pcr.uu.se", fontsize=60 * fig_scale
    )
    views_axis.axis("off")
    url_axis.axis("off")

def add_logos_stacks(fig, fig_scale):
    """ Add ViEWS logo """

    current_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(current_dir, '..', "plot", "logos", "views.png")

    logo_views = mpimg.imread(path_logo_views)

    views_axis = fig.add_axes([0.79, 0.09, 0.56, 0.06])
    url_axis = fig.add_axes([1.032, 0.07,0,0])

    views_axis.imshow(logo_views, interpolation="none")
    url_axis.text(
        x=0.2, y=0, s="http://views.pcr.uu.se", fontsize=60 * fig_scale
    )
    views_axis.axis("off")
    url_axis.axis("off")

def add_logos_stacks_grid(fig, fig_scale):
    """ Add ViEWS logo """

    current_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(current_dir, '..', "plot", "logos", "views.png")

    logo_views = mpimg.imread(path_logo_views)

    views_axis = fig.add_axes([0.87, 0.08, 0.12, 0.06])
    url_axis = fig.add_axes([0.87, 0.06, 0.12, 0.06])

    views_axis.imshow(logo_views, interpolation="none")
    url_axis.text(
        x=0.2, y=0, s="http://views.pcr.uu.se", fontsize=60 * fig_scale
    )
    views_axis.axis("off")
    url_axis.axis("off")


def add_logos_spaghetti(fig, fig_scale):
    """ Add ViEWS logo """

    current_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(current_dir, '..', "plot", "logos", "views.png")

    logo_views = mpimg.imread(path_logo_views)

    views_axis = fig.add_axes([0.79, 0.08, 0.12, 0.06])
    url_axis = fig.add_axes([0.79, 0.06, 0.12, 0.06])

    views_axis.imshow(logo_views, interpolation="none")
    url_axis.text(
        x=0.2, y=0, s="http://views.pcr.uu.se", fontsize=60 * fig_scale
    )
    views_axis.axis("off")
    url_axis.axis("off")

def add_logos_pie(fig, fig_scale):
    """ Add ViEWS logo """

    current_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(current_dir, '..', "plot", "logos", "views.png")

    logo_views = mpimg.imread(path_logo_views)

    views_axis = fig.add_axes([0.80, 0.2, 0.10, 0.06])
    url_axis = fig.add_axes([0.80, 0.18, 0.10, 0.06])

    views_axis.imshow(logo_views, interpolation="none")
    url_axis.text(
        x=0, y=0, s="http://views.pcr.uu.se", fontsize=60 * fig_scale
    )
    views_axis.axis("off")
    url_axis.axis("off")


def ss_proportion(ensemble, step, df):
    """Computes proportion of individual model ensembles for all countries and months based on ss prediction.
    Args:
        ensemble: cm level enembles (cm_all_sb, cm_all_ns, cm_all_os)
        step: specific step from list of steps defined in ensemble
        df: indexed (month_id, pg_id) pandas dataframe containing calibrated predictions
    Returns:
        df_prop_complete: model proportions; "ensemble_propability" column includes sum
    """
    if step not in ensemble["steps"]: # Print error message if step is not defined in ensemble
        raise KeyError("Only steps 1,6,12,24,36 are available for ss ebma predictions")

    weights = ensemble["weights_ebma_bc"][step]

    cols_ss = ensemble["cols_constituent_ss"][step]
    cols_ss_renames = {
            col: ens.modelname_from_step_prediction_name(col)
            for col in cols_ss
        }
    df_weighted = df[cols_ss].rename(columns=cols_ss_renames)*weights
    ensemble_probability = df_weighted.sum(axis=1)
    df_prop = df_weighted.div(ensemble_probability, axis=0)

    df_prop_complete = df_prop
    df_prop_complete["ensemble_probability"] = ensemble_probability

    return df_prop_complete

def sc_proportion(ensemble, df):
    """Computes proportion of individual model ensembles for all countries and months based on ss prediction.
    Args:
        ensemble: cm level enembles (cm_all_sb, cm_all_ns, cm_all_os)
        df: indexed (month_id, pg_id) pandas dataframe containing calibrated predictions
    Returns:
        df_prop_complete: model proportions; "ensemble_propability" column includes sum
    """
    weights_all = ens.interpolate_weights(ensemble["weights_ebma_bc"])
    df_weights = pd.DataFrame.from_dict(weights_all, orient='columns')

    first_t = df.index.levels[0].min()
    df_weights = df_weights.rename(columns = lambda col: first_t-1+ int(col))

    df_weights = df_weights.transpose()
    df_weights.index.name="month_id"

    cols_sc = ensemble["cols_constituent_sc"]
    cols_sc_rename = [ens.modelname_from_step_prediction_name_sc(col) for col in df[cols_sc]]

    df_sc = df[cols_sc]
    df_sc.columns = cols_sc_rename


    df_weighted = df_weights*df_sc
    ensemble_probability = df_weighted.sum(axis=1)
    df_prop = df_weighted.div(ensemble_probability, axis=0)

    df_prop_complete = df_prop
    df_prop_complete["ensemble_probability"] = ensemble_probability

    return df_prop_complete

def sc_weighted(ensemble, df):
    """Computes proportion of individual model ensembles for all countries and months based on ss prediction.
    Args:
        ensemble: cm level enembles (cm_all_sb, cm_all_ns, cm_all_os)
        df: indexed (month_id, pg_id) pandas dataframe containing calibrated predictions
    Returns:
        df_weighted
    """
    weights_all = ens.interpolate_weights(ensemble["weights_ebma_bc"])
    df_weights = pd.DataFrame.from_dict(weights_all, orient='columns')

    first_t = df.index.levels[0].min()
    df_weights = df_weights.rename(columns = lambda col: first_t -1+ int(col))

    df_weights = df_weights.transpose()
    df_weights.index.name="month_id"

    cols_sc = ensemble["cols_constituent_sc"]
    cols_sc_rename = [ens.modelname_from_step_prediction_name_sc(col) for col in df[cols_sc]]

    df_sc = df[cols_sc]
    df_sc.columns = cols_sc_rename

    df_weighted = df_weights*df_sc

    return df_weighted

def join_country_names(df):
    """Gets country table from db. Renames "id" to "country_id" and "name" to "country_name".
    Args:
        df: has same index as df_country - "country_id"
    Returns:
        df_joined: country names added to df
    """
    df_country =  dbutils.db_to_df("staging.country", columns=["id", "name"]) #Import country table from db

    df_country.rename(columns={"id": "country_id"}, inplace=True) #Rename
    df_country.rename(columns={"name": "country_name"}, inplace=True) #Rename
    df_country = df_country.set_index("country_id") #Set index

    df_joined = df.join(df_country) #Join with df

    return df_joined

def join_month_ids(df):
    """Fetches month table from db. Renames "id" to "month_id". Adds names of months as "month_name" and string with year and month as "month_str".
    Args:
        df: has same index as df_country - "month_id"
    Returns:
        df_joined: month_name, month_str added to df
    """
    df_month = dbutils.db_to_df("staging.month", columns=["id", "month", "year_id"]) #Import month table from db

    df_month["month"] = df_month["month"].map("{:02}".format)
    df_month.rename(columns={"id": "month_id"}, inplace=True) #Rename
    df_month = df_month.set_index("month_id") #Set index
    #df_month["month_name"] = df_month["month"].apply(lambda x: calendar.month_abbr[x]) #Add column with month names
    #df_month.year_id = df_month.year_id.astype(str)
    #df_month["month_str"] = df_month["year_id"] + "-" + df_month["month_name"]
    df_month["month_str"] = df_month["year_id"].astype(str) + "-" + df_month["month"].astype(str)

    df_joined = df.join(df_month, how="inner") #Join with df

    return df_joined

def plot_pie(df1, df2, models, step, country_id, run_id, path):
    """Plot importance of individual model ensembels for specific step and selected country
    Args:
        df: df with proportions
        models: list of models (as defined in ensembles)
        step: specific step (all steps from 1 to 36)
        country_id: country id
    Returns:
        plot
    """

    def my_autopct(pct):
        """Define percentage that should be displayed in pie-chart"""
        return ("%.1f%%" % pct) if pct > 5 else ''

    first_t = df1.index.levels[0].min()
    month_id = first_t+step-1 #Assign step to month id

    df1 = df1.loc[month_id] #Filter month

    #Names for sub/titles
    countryname = df1.loc[country_id, "country_name"] #Return country name
    month = df1.loc[country_id, "month_str"] #Return month name

    ensemble_probability = df2.loc[(month_id, country_id)] #Return ensemble probability
    ensemble_probability = ensemble_probability.round(3)

    outcome = str(df1.columns[1])[0:2] #Return outcome

    #Filter models
    data = df1[models]

    #Shorten names
    data = data.rename(columns = lambda col: col.lstrip(outcome+'_'))
    data.columns = [x.replace('_', ' ') for x in data.columns]

    #Sort alphabetically
    #data = data.sort_index(axis=1)

    #Transpose data and filter country
    data_t = data.transpose()
    data_t = data_t[country_id]

    #Size and Color
    fig = plt.figure(figsize=[10,10]) #Set size
    ax = fig.add_subplot(1,1,1)

    #Plot
    plot = data_t.plot(kind='pie', ax=ax, autopct=my_autopct, labels=None,
                      fontsize = 13, shadow = False, cmap="tab20", counterclock=False)

    #Hide y-label
    plt.ylabel("")

    #Title
    plt.suptitle(f'Probability proportions for {countryname} for {month} ({outcome})\n', fontsize=18, fontweight='bold')
    plt.title(f"{run_id}\n Ensemble probability = {ensemble_probability}", fontsize=13)

    #Define labels
    labels = data_t.index
    labels = ['%s (%.1f %%)' % (l, s*100) for l, s in zip(labels, data_t)]

    plt.legend(data_t, labels=labels, loc='center left', bbox_to_anchor= (1, 0.5), title="Models", fontsize=18)

    #plt.tight_layout()
    #add_logos_pie(fig=fig, fig_scale=0.15)

    #Save fig.
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Wrote {path}")

def plot_pie_addsteps(df1, models, step, country_id, path):
    """Plot importance of individual model ensembels for specific step and selected country
    Args:
        df: df with proportions
        models: list of models (as defined in ensembles)
        step: specific step (all steps from 1 to 36)
        country_id: country id
    Returns:
        plot
    """

    def my_autopct(pct):
        """Define percentage that should be displayed in pie-chart"""
        return ("%.1f%%" % pct) if pct > 5 else ''

    first_t = df1.index.levels[0].min()
    month_id = first_t+step-1 #Assign step to month id

    df1 = df1.loc[month_id] #Filter month

    #Names for sub/titles
    countryname = df1.loc[country_id, "country_name"] #Return country name
    month = df1.loc[country_id, "month_str"] #Return month name

    #ensemble_probability = df2.loc[(month_id, country_id)] #Return ensemble probability
    #ensemble_probability = ensemble_probability.round(3)

    outcome = str(df1.columns[1])[0:2] #Return outcome

    #Filter models
    data = df1[models]

    #Shorten names
    data = data.rename(columns = lambda col: col.lstrip(outcome+'_'))
    data.columns = [x.replace('_', ' ') for x in data.columns]

    #Sort alphabetically
    #data = data.sort_index(axis=1)

    #Transpose data and filter country
    data_t = data.transpose()
    data_t = data_t[country_id]

    #Size and Color
    fig = plt.figure(figsize=[10,10]) #Set size
    ax = fig.add_subplot(1,1,1)

    #Plot
    plot = data_t.plot(kind='pie', ax=ax, autopct=my_autopct, labels=None,
                      fontsize = 13, shadow = False, cmap="tab20", counterclock=False)

    #Hide y-label
    plt.ylabel("")

    #Title
    plt.suptitle(f'Probability proportions for {countryname} for {month} ({outcome})\n', fontsize=18, fontweight='bold')
    #plt.title(f"r2020.02.02\n Ensemble probability = {ensemble_probability}", fontsize=13)

    #Define labels
    labels = data_t.index
    labels = ['%s (%.1f %%)' % (l, s*100) for l, s in zip(labels, data_t)]

    ax.legend(data_t, labels=labels, loc="center right", bbox_to_anchor=(1, 0, 0.2, 1), title="Models")

    add_logos_pie(fig=fig, fig_scale=0.15)

    plt.tight_layout()

    #Save fig.
    plt.savefig(path, dpi=300)
    plt.close()
    print(f"Wrote {path}")


def plot_spaghetti_countries(df, model, countries, step_start, step_end, run_id, path):
    """Plot probability over time for all countries and specified outcome
    Args:
        df: dataframe with probabilities and country names, month_ids
        model: model as defined in ensembles
        countries: list of countries
        s_start: first step
        s_end: last step
        """

    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subset
    df_sub = df.loc[t_start:t_end] #Time period
    df_sub = df_sub.filter(items=[model,'month_str','country_name']) #Model
    df_sub = df_sub.reset_index()

    # Names
    start = df.loc[t_start, 'month_str'].iloc[0]
    end = df.loc[t_end, 'month_str'].iloc[0]
    period = 'Period: ' + start + ' to ' + end

    model_name = model[3:10].replace('.',' ') # Return model name and outcome
    outcome = model_name[-2:] # Return outcome (sb,ns,os)

    # Set figure space
    plt.rcParams['font.size'] = 17
    fig, ax = plt.subplots(figsize=(18.5, 9))
    fig.subplots_adjust(
        right=1,
        top=0.8)
    plt.ylim([0, 1])

    # Remove plot framelines
    for spine in plt.gca().spines.values():
        spine.set_visible(False)

    # Format grid lines
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Format ticks
    #plt.tick_params(colors='black', labelsize=14, bottom=False, left=False)
    plt.tick_params(colors='black', bottom=False, left=False)

    # Add axis label
    def unique(list): # Function to delete duplicates from list
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]

    ticks = unique(list(df_sub['month_id']))[::3] # Format tick frequency
    labels = unique(list(df_sub['month_str']))[::3] # Format tick labels

    # Adjust the margins
    ax.margins(x=0)

    plt.xticks(ticks,labels)
    plt.yticks(np.arange(0, 1.1, step=0.1))

    # Plot
    df_plot = df_sub.pivot(index='month_id', columns='country_name', values=model)
    
    # Filter countries and sort regarding probability in last month
    hpc_pivot = df_plot[countries]
    new_columns = hpc_pivot.columns[hpc_pivot.ix[hpc_pivot.last_valid_index()].argsort()]
    new_columns = new_columns[::-1]
    hpc_pivot = hpc_pivot[new_columns]

    for i in hpc_pivot:
        plt.plot(hpc_pivot[i],label=i,linewidth=3)

    # Plot legend
    plt.legend(
        loc=7, #center right
        bbox_to_anchor=(0.88, 0, 0.4, 1),
        borderaxespad=0.2,
        #fontsize="large",
        #title_fontsize="large",
        title=f'Level of Analysis: cm\nModel: {model_name}\nRun: {run_id} \n \nCountries')

    # Title
    #plt.title(f'Predicted probability trend for all countries: \n{start} to {end}\n',
        #fontsize=15, fontweight='bold')
    plt.title(f'Predicted probability trend for all countries: \n{start} to {end}\n',
     fontweight='bold')

    # Layout
    plt.style.context('ggplot')
    ax.tick_params(axis="x", which="major", pad=20)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95]) # Make sure that legend is not cut in half when saving as .png

    add_logos_spaghetti(fig=fig, fig_scale=0.15)


    # Save fig.
    plt.savefig(path, dpi=300)
    plt.close()
    print(f"Wrote {path}")


def plot_stacked(df,models, step_start,step_end,country_id, run_id, path):

    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subset
    df_sub = df.loc[t_start:t_end] # Time period
    df_sub = df_sub.swaplevel().loc[country_id] # Country

    df_sub = df_sub.reset_index()
    df_models = df_sub[models]

    # Names for sub/titles
    countryname = list(df.swaplevel().loc[country_id, 'country_name'].drop_duplicates())
    countrynames_t = ', '.join(countryname) # Return list of country names separated by commas and without brackets
    start = df.loc[t_start, 'month_str'].iloc[0]
    end = df.loc[t_end, 'month_str'].iloc[0]
    period = 'Period: ' + start + ' to ' + end
    outcome = str(df_models.columns[1])[0:2] # Return outcome (sb,ns,os)

    # Shorten names
    df_models.columns = df_models.columns.str[3:]
    df_models.columns = [x.replace('_', ' ') for x in df_models.columns]
    
    # Reorder
    df_models = df_models[
    ["cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "acled violence",
    "neibhist",
    "cdummies",
    "acled protest",
    "reign coups",
    "onset24 25 all"]]

    df_models2 = df_models
    df_models2["others"] = df_models2["acled violence"] + df_models2["neibhist"] + df_models2["cdummies"] + df_models2["acled protest"] + df_models2["reign coups"] + df_models2["onset24 25 all"]
    df_models2 = df_models2[[
    "cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "others"]]

# Set figure space
    fig, ax = plt.subplots(figsize=(30, 12))
    fig.subplots_adjust(
        right=0.95,
        top=0.92)
    plt.rcParams['font.size'] = 28

    ymax = df_models.sum(axis=1).max(axis=0)
    plt.ylim([0,ymax])

    # Remove plot framelines
    for spine in plt.gca().spines.values():
        spine.set_visible(False)

    # Format grid lines
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Format ticks
    plt.tick_params(colors='black', bottom=False, left=False)

    # Add axis label
    def unique(list): # Function to delete duplicates from list
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]

    ticks = unique(list(df_sub['month_id']))[::3] # Format tick frequency
    labels = unique(list(df_sub['month_str']))[::3] # Format tick labels

    # Adjust the margins
    ax.margins(x=0.03)

    plt.xticks(ticks,labels)

    # Set Colors
    n = len(models) #number of models
    norm = matplotlib.colors.Normalize(vmin=0, vmax=20)
    pal = plt.cm.tab20([0,12,13,14,16,17,18,19])
    
    # Plot
    x = df_sub["month_id"]
    plot = plt.stackplot(x, *[ts for col, ts in df_models2.iteritems()], labels=df_models2, colors=pal)
    

    handles, labels = ax.get_legend_handles_labels()
    #print(handles,labels)

    # Plot legend
    plt.legend(handles=reversed(handles),labels=(reversed(labels)),
        loc=7, #center right
        bbox_to_anchor=(0.98, 0, 0.22, 1),
        borderaxespad=0.4,
        #fontsize="large",
        #title_fontsize="large",
        title=f'Level of Analysis: cm\nRun: {run_id}\n \nModels')

    # Plot title
    plt.title(f'Probability proportions for {countrynames_t} ({outcome}): \n{start} to {end}\n',
              fontsize=28, fontweight='bold')

    # Layout
    plt.style.context('ggplot')
    #plt.tight_layout(rect=[0, 0.03, 1, 0.90])

    add_logos_stacks(fig=fig, fig_scale=0.15)

    #Save fig.
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Wrote {path}") 


def plot_stacked_grid(df, 
    models, 
    step_start, 
    step_end, 
    country_id,
    country_id1,
    country_id2,
    country_id3,
    run_id, path):

    #List of countries
    countries =[
    country_id,
    country_id1,
    country_id2,
    country_id3]

    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subsets
    df_sub = df.loc[t_start:t_end] # Time period
    df_sub = df_sub.swaplevel().loc[country_id] # Country

    df_sub = df_sub.reset_index()
    df_models = df_sub[models]

    df_sub1 = df.loc[t_start:t_end] # Time period
    df_sub1 = df_sub1.swaplevel().loc[country_id1] # Country

    df_sub1 = df_sub1.reset_index()
    df_models1 = df_sub1[models]

    df_sub2 = df.loc[t_start:t_end] # Time period
    df_sub2 = df_sub2.swaplevel().loc[country_id2] # Country

    df_sub2 = df_sub2.reset_index()
    df_models2 = df_sub2[models]

    df_sub3 = df.loc[t_start:t_end] # Time period
    df_sub3 = df_sub3.swaplevel().loc[country_id3] # Country

    df_sub3 = df_sub3.reset_index()
    df_models3 = df_sub3[models]

    # Names for sub/titles
    countryname = list(df.swaplevel().loc[country_id, 'country_name'].drop_duplicates())
    countryname_t = ' '.join(countryname) # Returns countryname without brackets
    countryname1 = list(df.swaplevel().loc[country_id1, 'country_name'].drop_duplicates())
    countryname_t1 = ' '.join(countryname1) # Returns countryname without brackets
    countryname2 = list(df.swaplevel().loc[country_id2, 'country_name'].drop_duplicates())
    countryname_t2 = ' '.join(countryname2) # Returns countryname without brackets
    countryname3 = list(df.swaplevel().loc[country_id3, 'country_name'].drop_duplicates())
    countryname_t3 = ' '.join(countryname3) # Returns countryname without brackets
    #start = df.loc[t_start, 'month_str'].iloc[0]
    #end = df.loc[t_end, 'month_str'].iloc[0]
    #period = 'Period: ' + start + ' to ' + end
    outcome = str(df_models.columns[1])[0:2] # Return outcome (sb,ns,os)
    outcome1 = str(df_models1.columns[1])[0:2] # Return outcome (sb,ns,os)
    outcome2 = str(df_models2.columns[1])[0:2] # Return outcome (sb,ns,os)
    outcome3 = str(df_models3.columns[1])[0:2] # Return outcome (sb,ns,os)

    # Shorten names
    df_models.columns = df_models.columns.str[3:]
    df_models.columns = [x.replace('_', ' ') for x in df_models.columns]
    df_models1.columns = df_models1.columns.str[3:]
    df_models1.columns = [x.replace('_', ' ') for x in df_models1.columns]
    df_models2.columns = df_models2.columns.str[3:]
    df_models2.columns = [x.replace('_', ' ') for x in df_models2.columns]
    df_models3.columns = df_models3.columns.str[3:]
    df_models3.columns = [x.replace('_', ' ') for x in df_models3.columns]
    
    # Reorder
    df_models = df_models[
    ["cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "acled violence",
    "neibhist",
    "cdummies",
    "acled protest",
    "reign coups",
    "onset24 25 all"]]

    df_models1 = df_models1[
    ["cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "acled violence",
    "neibhist",
    "cdummies",
    "acled protest",
    "reign coups",
    "onset24 25 all"]]

    df_models2 = df_models2[
    ["cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "acled violence",
    "neibhist",
    "cdummies",
    "acled protest",
    "reign coups",
    "onset24 25 all"]]

    df_models3 = df_models3[
    ["cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "acled violence",
    "neibhist",
    "cdummies",
    "acled protest",
    "reign coups",
    "onset24 25 all"]]

    df_models_2 = df_models
    df_models_2["others"] = df_models_2["acled violence"] + df_models_2["neibhist"] + df_models_2["cdummies"] + df_models_2["acled protest"] + df_models_2["reign coups"] + df_models_2["onset24 25 all"]
    df_models_2 = df_models_2[[
    "cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "others"]]

    df_models1_2 = df_models1
    df_models1_2["others"] = df_models1_2["acled violence"] + df_models1_2["neibhist"] + df_models1_2["cdummies"] + df_models1_2["acled protest"] + df_models1_2["reign coups"] + df_models1_2["onset24 25 all"]
    df_models1_2 = df_models1_2[[
     "cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "others"]]

    df_models2_2 = df_models2
    df_models2_2["others"] = df_models2_2["acled violence"] + df_models2_2["neibhist"] + df_models2_2["cdummies"] + df_models2_2["acled protest"] + df_models2_2["reign coups"] + df_models2_2["onset24 25 all"]
    df_models2_2 = df_models2_2[[
    "cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "others"]]

    df_models3_2 = df_models3
    df_models3_2["others"] = df_models3_2["acled violence"] + df_models3_2["neibhist"] + df_models3_2["cdummies"] + df_models3_2["acled protest"] + df_models3_2["reign coups"] + df_models3_2["onset24 25 all"]
    df_models3_2 = df_models3_2[[
    "cflong",
    "vdem glob",
    "demog",
    "wdi all glob",
    "ds 25",
    "ds dummy",
    "all glob",
    "others"]]

# Set figure space
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2,2, figsize=(28, 12))
    plt.subplots_adjust(
        left=1/28.0, 
        right=0.82, 
        bottom=0.09, 
        top=0.92,
        wspace=0.13)

    #plt.rcParams['font.size'] = 28

    #ymax = df_models2.sum(axis=1).max(axis=0)
    ax1.set_ylim([0,0.8])
    ax2.set_ylim([0,0.8])
    ax3.set_ylim([0,0.8])
    ax4.set_ylim([0,0.8])

    # Remove plot framelines
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    ax1.spines['bottom'].set_visible(False)
    ax1.spines['left'].set_visible(False)

    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    ax2.spines['bottom'].set_visible(False)
    ax2.spines['left'].set_visible(False)

    ax3.spines['top'].set_visible(False)
    ax3.spines['right'].set_visible(False)
    ax3.spines['bottom'].set_visible(False)
    ax3.spines['left'].set_visible(False)

    ax4.spines['top'].set_visible(False)
    ax4.spines['right'].set_visible(False)
    ax4.spines['bottom'].set_visible(False)
    ax4.spines['left'].set_visible(False)


    # Format grid lines
    ax1.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    ax2.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    ax3.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    ax4.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Format ticks
    ax1.tick_params(colors='black', labelsize=25, bottom=False, left=False)
    ax2.tick_params(colors='black', labelsize=25, bottom=False, left=False)
    ax3.tick_params(colors='black', labelsize=25, bottom=False, left=False)
    ax4.tick_params(colors='black', labelsize=25, bottom=False, left=False)

    # Add axis label
    def unique(list): # Function to delete duplicates from list
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]

    ticks = unique(list(df_sub['month_id']))[::6] # Format tick frequency
    labels = unique(list(df_sub['month_str']))[::6] # Format tick labels
    

    # Adjust the margins
    ax1.margins(x=0.05)
    ax2.margins(x=0.05)
    ax3.margins(x=0.05)
    ax4.margins(x=0.05)

    ax1.set_xticks(ticks)
    ax2.set_xticks(ticks)
    ax3.set_xticks(ticks)
    ax4.set_xticks(ticks)
    ax1.set_xticklabels(labels)
    ax2.set_xticklabels(labels)
    ax3.set_xticklabels(labels)
    ax4.set_xticklabels(labels)
 
    # Set Colors
    n = len(models) #number of models
    norm = matplotlib.colors.Normalize(vmin=0, vmax=20)
    pal = plt.cm.tab20([0,12,13,14,16,17,18,19])
    #pal = plt.cm.tab20([19,18,17,16,14,13,12,0])

    # Plot
    x = df_sub["month_id"]
    plot1 = ax1.stackplot(x, *[ts for col, ts in df_models_2.iteritems()], labels=df_models_2, colors=pal)
    x1 = df_sub1["month_id"]
    plot1 = ax2.stackplot(x1, *[ts for col, ts in df_models1_2.iteritems()], colors=pal)
    x2 = df_sub2["month_id"]
    plot1 = ax3.stackplot(x2, *[ts for col, ts in df_models2_2.iteritems()], colors=pal)
    x3 = df_sub3["month_id"]
    plot1 = ax4.stackplot(x3, *[ts for col, ts in df_models3_2.iteritems()], colors=pal)
    
    # Plot Titles
    ax1.set_xlabel(f"(a) {countryname_t}")
    ax2.set_xlabel(f"(b) {countryname_t1}")
    ax3.set_xlabel(f"(c) {countryname_t2}")
    ax4.set_xlabel(f"(d) {countryname_t3}")

    # Plot legend
    handels,labels = ax1.get_legend_handles_labels()

    # Plot legend
    fig.legend(reversed(handels),reversed(labels),
        loc="center right",
        borderaxespad=0.3,
        labelspacing=1.2,
        bbox_to_anchor=(0,0.55,0.98,0),
        frameon=True,
        title=f'Level of Analysis: cm\nRun: {run_id}\n \nModels')

    # Layout
    plt.style.context('ggplot')
    
    add_logos_stacks_grid(fig=fig, fig_scale=0.15)

    #Save fig.
    plt.savefig(path, dpi=300,bbox_inches="tight")
    plt.close()
    print(f"Wrote {path}") 


def plot_cum(df, model, countries, step_start, step_end, run_id, path):

    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subset
    df_sub = df.loc[t_start:t_end]
    df_sub = df_sub.filter(items=[model,'month_str'])
    df_sub = df_sub.swaplevel().loc[countries].sort_index()
    df_month = df.loc[t_start:t_end].reset_index()

    # Calculate cumulative probabilities
    df_sub['np'] = 1-df_sub[model]
    df_sub['cp'] = df_sub.np.groupby(level=0).cumprod(axis=0)
    df_sub['p']  = 1-df_sub.cp

    # Names
    countrynames = list(df.swaplevel().loc[countries, 'country_name'].drop_duplicates()) # Return country name (string)
    countrynames.sort()
    countrynames_t = ', '.join(countrynames) # Return list of country names separated by commas and without brackets

    start = df.loc[t_start, 'month_str'].iloc[0]
    end = df.loc[t_end, 'month_str'].iloc[0]
    period = 'Period: ' + start + ' to ' + end

    model_name = model[3:10].replace('.',' ') # Return model name and outcome
    outcome = model_name[-2:] # Return outcome (sb,ns,os)

    # Set figure space
    fig, ax = plt.subplots(figsize=(18.5, 7.5))
    fig.subplots_adjust(
        right=1,
        top=0.8)
    plt.ylim([0, 1])

    # Remove plot framelines
    for spine in plt.gca().spines.values():
        spine.set_visible(False)

    # Format grid lines
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Format ticks
    plt.tick_params(colors='black', labelsize=14, bottom=False, left=False)

    # Add axis label
    def unique(list): # Function to delete duplicates from list
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]

    ticks = unique(list(df_month['month_id']))[::3] # Format tick frequency
    labels = unique(list(df_month['month_str']))[::3] # Format tick labels

    # Adjust the margins
    ax.margins(x=0.03)

    plt.xticks(ticks,labels)
    plt.yticks(np.arange(0, 1.1, step=0.1))

    # Colors
    n = len(countries) #number of models
    colors = plt.cm.tab10(np.linspace(0, 1, n))

    # Plot
    for country,c in zip(countries, range(n)):
        df_country = df_sub.loc[country].reset_index()
        plt.plot(df_country['month_id'], df_country["p"],label=countrynames[c], color=colors[c])

    # Plot legend
    plt.legend(labels=["Burkina Faso","Mali","Cameroon"],
        loc=7,
        bbox_to_anchor=(0.95, 0, 0.25, 1),
        borderaxespad=0.2,
        title=f'Level of Analysis: cm\nModel: {model_name}\nRun: {run_id} \n \nCountries'
        )

    # Title
    #plt.title(f'Predicted probability trend for {countrynames_t}: \n{start} to {end}', fontsize=15, fontweight='bold')

    # Layout
    plt.style.context('ggplot')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    add_logos(fig=fig, fig_scale=0.15)

    #Save fig.
    plt.savefig(path, dpi=300)
    plt.close()
    print(f"Wrote {path}")

def plot_prob(df, model, countries, step_start, step_end, run_id, path):

    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subset
    df_sub = df.loc[t_start:t_end]
    df_sub = df_sub.filter(items=[model,'month_str'])
    df_sub = df_sub.swaplevel().loc[countries].sort_index()
    df_month = df.loc[t_start:t_end].reset_index()

    # Names
    countrynames = list(df.swaplevel().loc[countries, 'country_name'].drop_duplicates()) # Return country name (string)
    countrynames.sort()
    countrynames_t = ', '.join(countrynames) # Return list of country names separated by commas and without brackets

    start = df.loc[t_start, 'month_str'].iloc[0]
    end = df.loc[t_end, 'month_str'].iloc[0]
    period = 'Period: ' + start + ' to ' + end

    model_name = model[3:10].replace('.',' ') # Return model name and outcome
    outcome = model_name[-2:] # Return outcome (sb,ns,os)

    # Set figure space
    fig, ax = plt.subplots(figsize=(18.5, 7.5))
    fig.subplots_adjust(
        right=1,
        top=0.8)
    plt.ylim([0, 1])

    # Remove plot framelines
    for spine in plt.gca().spines.values():
        spine.set_visible(False)

    # Format grid lines
    ax.grid(
        which="major",
        axis="y",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )

    # Format ticks
    plt.tick_params(colors='black', labelsize=14, bottom=False, left=False)

    # Add axis label
    def unique(list): # Function to delete duplicates from list
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]

    ticks = unique(list(df_month['month_id']))[::3] # Format tick frequency
    labels = unique(list(df_month['month_str']))[::3] # Format tick labels

    # Adjust the margins
    ax.margins(x=0.03)

    plt.xticks(ticks,labels)
    plt.yticks(np.arange(0, 1.1, step=0.1))

    # Colors
    n = len(countries) #number of models
    colors = plt.cm.tab10(np.linspace(0, 1, n))

    # Plot
    for country,c in zip(countries, range(n)):
        df_country = df_sub.loc[country].reset_index()
        plt.plot(df_country['month_id'], df_country[model],label=countrynames[c], color=colors[c])

    # Legend
    plt.legend(labels=["Burkina Faso","Mali","Cameroon"],
        loc=7,
        bbox_to_anchor=(0.95, 0, 0.25, 1),
        borderaxespad=0.2,
        title=f'Level of Analysis: cm\nModel: {model_name}\nRun: {run_id} \n \nCountries'
        )

    # Title
    #plt.title(f'Predicted probability trend for {countrynames_t}: \n{start} to {end}', fontsize=15, fontweight='bold')

    # Layout
    plt.style.context('ggplot')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    add_logos(fig=fig, fig_scale=0.15)

    #Save fig.
    plt.savefig(path, dpi=300)
    plt.close()
    print(f"Wrote {path}")

def plot_prob_models(df, countries, models, step_start, step_end):
    """Plot probability for specified country and multiple models for specified time period"""
    
    # Steps to months
    first_t = df.index.levels[0].min()
    t_start = first_t+step_start-1
    t_end = first_t+step_end-1

    # Subset
    df_sub = df.loc[t_start:t_end]
    df_sub = df_sub.filter(items=[models,'month_str'])
    df_sub = df_sub.swaplevel().loc[countries].sort_index()
    df_month = df.loc[t_start:t_end].reset_index()

    
    # Month
    df_month = df.loc[t_start:t_end, 'month_str'].reset_index()
    
    # Names
    countryname = df.swaplevel().loc[country_id, 'country_name'].iloc[0] #Return country name 
    
    start = df.loc[t_start, 'month_str'].iloc[0] 
    end = df.loc[t_end, 'month_str'].iloc[0] 
    period = 'Period: ' + start + ' to ' + end
    
    modelnames = [n[6:].replace('_',' ') for n in cols_sc]
    outcome = [n[3:5] for n in cols_sc][1]
    
    # Set Size
    fig, ax = plt.subplots(figsize=(14, 7.5))
    
    # Remove frame     
    for spine in plt.gca().spines.values():
        spine.set_visible(False)
    
    # Change background color
    plt.grid(color='grey', linestyle='dotted')

    # Format ticks   
    plt.tick_params(colors='dimgrey', labelsize=14, bottom=False, left=False)
    plt.xticks(range(0,len(df_sub)))
    
    def unique(list): # Function to delete duplicates from list 
        seen = set()
        return [x for x in list if not (x in seen or seen.add(x))]
    
    ticks = unique(list(df_month['month_id']))[::1] # Format tick frequency
    labels = unique(list(df_month['month_str']))[::1] # Format tick labels
    plt.xticks(ticks,labels, rotation = 90)
    
    # Colors 
    n = len(models) # Number of models
    colors = plt.cm.tab20(np.linspace(0, 1, n))
    
    # Plot
    for model,c in zip(models, range(n)):
        df_models = df_sub[model].reset_index()
        plt.plot(df_models['month_id'], df_models[model], label= modelnames[c], color=colors[c]) 
    
    # Legend
    plt.legend(loc='center right', bbox_to_anchor=(1, 0, 0.25, 1), title=f'Models {outcome}')
    
    # Title
    plt.title(f'Predicted probability trend for {countryname}: \n{start} to {end}', fontsize=15, fontweight='bold')
    
    # Layout
    plt.style.context('ggplot')
    plt.tight_layout() # Make sure that legend is not cut in half when saving as .png

