""" One Step Ahead forecasting """

# TODO: Check column lists for duplicates
# pylint: disable=too-many-arguments

import logging

import itertools
import warnings

import numpy as np

from views.utils import datautils

Logger = logging.getLogger(__name__)


def _check_no_duplicate_features(features):
    if len(set(features)) != len(features):
        raise RuntimeError(f"Duplicates in features {features}")


def _make_s_predictions(df, colname_prediction, times):
    """ Make an indexed dataframe with a single col of NaNs

    Used for holding predictions
    """

    df_predictions = df.loc[times, []].copy()
    df_predictions[colname_prediction] = np.nan
    s_predictions = df_predictions[colname_prediction]
    s_predictions.name = colname_prediction
    return s_predictions


def fit(
    df,
    estimator,
    outcome,
    features,
    stepsize,
    t_start,
    t_end,
    share_ones=1.0,
    share_zeros=1.0,
):
    """ Fit estimator on stepsize shifted data

    Args:
        df: A multiindexed pandas dataframe containing outcome
            and features as cols
        estimator: An estimator with an implemented .fit(X, y) method
        outcome: column to use as Y
        features: list of columns
        stepsize: Shifting step distance
        t_start:
        t_end:
        shares_one: Shares of rows with col_outcome=1 to keep
        shares_zeros: Shares of rows with col_outcome=0 to keep
    Returns:
        estimator: A fitted instance of estimator
    """

    _check_no_duplicate_features(features)

    # Subset times
    df = df.loc[t_start:t_end]
    len_df = len(df)

    # Shift features
    df_step = df[features].groupby(level=1).shift(stepsize)

    # Don't shift outcome
    df_step[outcome] = df[outcome]

    df_step = df_step.dropna()
    len_df_step_postdrop = len(df_step)

    if not (share_ones == share_zeros == 1.0):
        df_step = datautils.resample(
            df_step,
            cols=[outcome],
            share_positives=share_ones,
            share_negatives=share_zeros,
        )
    len_df_step_postdsamp = len(df_step)

    Logger.info(
        f"Training with step: {stepsize}, "
        f"len_df: {len_df}, "
        f"len_df_step_postdrop: {len_df_step_postdrop} "
        f"len_df_step_postdsamp: {len_df_step_postdsamp} "
    )
    y_train = np.asarray(df_step[outcome])
    X_train = np.asarray(df_step[features])
    estimator.fit(X_train, y_train)
    return estimator


def predict_step(
    s_predictions,
    df_features,
    estimator,
    colname_prediction,
    features,
    steplen,
    t_predict,
):
    """ Insert predictions into df_predictions

    Args:
        df_predictions: Dataframe for storing the predictions in
        df_features: Dataframe containing features for prediction
        estimator: An object with a predict_proba(X_t) or predict(X_t)
                   method
        colname_prediction: String colname where to store prediction
        features: List of features to use
        steplen: Integer length of step, i.e. the time difference
                 between feature observations and prediction.
        t_predict: Time of prediction

    Returns:
        df_predictions: Updated df_predictions containing predictions

    Predictions are made to t_predict using features from df_
    """

    def predict(X_t, estimator, s_predictions, t_predict):
        # Build (t, g) index tuples for assigning the predictions
        groups_X_t = X_t.index.values
        tuples_pred = list(itertools.product([t_predict], groups_X_t))

        try:
            y_predicted = estimator.predict_proba(X_t)[:, 1]
        except AttributeError:
            y_predicted = estimator.predict(X_t)

        s_predictions.loc[tuples_pred] = y_predicted

        return s_predictions

    _check_no_duplicate_features(features)

    # @TODO: why is steplen not int here?
    t_base_step = t_predict - int(steplen)
    X_t = df_features.loc[t_base_step, features].dropna()

    if len(X_t) > 0:
        s_predictions = predict(X_t, estimator, s_predictions, t_predict)
    else:
        missing = datautils.get_share_missing_str(
            df_features.loc[t_base_step, features]
        )
        msg = (
            f"No data for prediction for {colname_prediction} "
            f"from t_base_step {t_base_step} into t_predict {t_predict} "
            "missing: \n"
            f"{missing}"
        )
        warnings.warn(msg)

    return s_predictions


def predict_semt(df, estimator, steplen, colname_prediction, features, times):
    """ Predict with single estimator multiple times.

    This is useful for the calibration/evaluation case,
    not for true forecasting.

    Args:
        df: Dataframe containing features needed for prediction
        estimator: An object with a predict_proba(X) or predict(X) method
        steplen: Step length in time.
        colname_prediction: Name of the prediction col to write
        features: List of features to use
        times: List of time-level index values to predict for
    Returns:
        df_predictions: Dataframe containing single column of predictions
    """

    _check_no_duplicate_features(features)

    s_predictions = _make_s_predictions(df, colname_prediction, times)

    steplen = int(steplen)
    times_X = [time - steplen for time in times]
    df_X = df.loc[times_X, features]
    df_X = df_X.dropna()

    # If we have any data go ahead and predict
    if len(df_X) > 0:
        # Try predict_proba first
        try:
            y_predicted = estimator.predict_proba(df_X)[:, 1]
        # Fallback to predict if predict_proba not available
        except AttributeError:
            y_predicted = estimator.predict(df_X)

        ix_X = df_X.index.values
        ix_prediction = [(time + steplen, group) for time, group in ix_X]
        s_predictions.loc[ix_prediction] = y_predicted

    else:
        missing = datautils.get_share_missing_str(df.loc[times_X, features])
        msg = (
            f"No data for prediction for {colname_prediction} "
            "missing: \n"
            f"{missing}"
        )
        warnings.warn(msg)

    return s_predictions


def predict_memt(df, estimators, colname_prediction, features, times):
    """ Predict multiple estimators for multiple times.

    This is useful for true forecasting. Each key in the estimators
    dict is a step length / time horizon

    Args:
        df: Dataframe containing features needed for prediction
        estimators: Dictionary of steplen:estimator pairs where
                    estimator is an object with a predict(X) or
                    predict_proba(X) method.
        colname_prediction: Name of the prediction col to write
        features: List of features to use
        times: List of time-level index values to predict for
    Returns:
        df_predictions: Dataframe containing single column of predictions
    """

    _check_no_duplicate_features(features)

    s_predictions = _make_s_predictions(df, colname_prediction, times)
    df_features = df

    t_start = min(times)

    for steplen in estimators.keys():
        estimator = estimators[steplen]
        steplen = int(steplen)
        # For this steplength, which month do we want predictions for?
        # This assumes we want the time one before prediction starts
        # as the base times
        # @TODO: why is steplen not int here?
        t_predict = t_start + steplen - 1
        s_predictions = predict_step(
            s_predictions,
            df_features,
            estimator,
            colname_prediction,
            features,
            steplen,
            t_predict,
        )

    s_predictions = datautils.interpolate(s_predictions, extrapolate=True)
    s_predictions = s_predictions.loc[times]

    return s_predictions
