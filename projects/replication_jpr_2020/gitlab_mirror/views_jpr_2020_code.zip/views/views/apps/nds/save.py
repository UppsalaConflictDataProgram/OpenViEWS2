import os
import shutil

from views.utils import pyutils


def store_agg(dir_scratch, dir_results_run, run_id):
    path_agg_in = os.path.join(dir_scratch, "aggregate", "aggregated.hdf5")
    fname_agg_out = f"{run_id}.hdf5"
    path_agg_out = os.path.join(dir_results_run, fname_agg_out)
    shutil.copy(path_agg_in, path_agg_out)
    print(f"Copied {path_agg_in} to {path_agg_out}")


def store_estimates(dir_scratch, dir_results_run):
    dir_train = os.path.join(dir_scratch, "train")
    destination = os.path.join(dir_results_run, "train")
    shutil.copytree(
        dir_train, destination, ignore=shutil.ignore_patterns("*.hdf5")
    )
    print(f"Copied {dir_train} to {destination} excluding .hdf5 files")


def store_sim0(dir_scratch, dir_results_run):

    dir_sim = os.path.join(dir_scratch, "sim")
    path_sim0 = os.path.join(dir_results_run, "sim0_allvars.hdf5")
    for root, _, files in os.walk(dir_sim):
        for file in files:
            if file == "sim0_allvars.hdf5":
                path_in = os.path.join(root, file)
                shutil.copy(path_in, path_sim0)
                print(f"Copied {path_in} to {path_sim0}")


def save_results(dir_scratch, dir_results, run_id):
    dir_results_run = os.path.join(dir_results, run_id)

    # Make sure dir_results exists
    pyutils.create_dir(dir_results)
    # Recreate dir_results_run to overwrite any existing results for this run_id
    pyutils.delete_dir(dir_results_run)
    pyutils.create_dir(dir_results_run)

    store_agg(dir_scratch, dir_results_run, run_id)
    store_estimates(dir_scratch, dir_results_run)
    store_sim0(dir_scratch, dir_results_run)

    print(f"Fininshed writing results to {dir_results_run}")
