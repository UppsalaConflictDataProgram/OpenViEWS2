from subprocess import call
from utils import make_dirstructure
import argparse
import multiprocessing as mp
import os
import shutil

from views.utils import pyutils, config

import prep, ts, spatial, transforms, train, sim, merger, aggregate, save


def get_run_id_from_paramfile(path_paramfile):
    params = pyutils.load_json(path_paramfile)
    return params["run_id"]


def get_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--dir_input",
        type=str,
        help="directory to read data from",
        required=True,
    )
    parser.add_argument(
        "--dir_results",
        type=str,
        help="directory to store results in",
        required=True,
    )
    parser.add_argument(
        "--path_paramfile",
        type=str,
        help="directory where the paramfile lives",
        required=True,
    )

    args_main = parser.parse_args()
    dir_input = args_main.dir_input
    path_paramfile = args_main.path_paramfile
    run_id = get_run_id_from_paramfile(path_paramfile)
    dir_results = args_main.dir_results

    return dir_input, path_paramfile, run_id, dir_results


dir_input, path_paramfile, run_id, dir_results = get_args()

dir_scratch = config.CONFIG["dirs"]["dir_scratch"]
dir_scratch = os.path.join(dir_scratch, run_id)

# Init rundir and copy in paramfile
make_dirstructure(dir_scratch)
shutil.copy(path_paramfile, os.path.join(dir_scratch, "params.json"))

# Run stages in sequence
prep.main_prep(dir_scratch, dir_input)
ts.main_ts(dir_scratch)
spatial.main_spat(dir_scratch)
transforms.main_transforms(dir_scratch)
train.main_train(dir_scratch)
sim.main_sim(dir_scratch)
merger.merger_main(dir_scratch)
aggregate.aggregate_main(dir_scratch)
save.save_results(dir_scratch, dir_results, run_id)
