echo "Removing existing dynasim env"
conda remove --name dynasim --all --yes
echo "Creating env from environment.yml"
conda env create -f dynasim.yaml
cd ~/gitlab/views/
conda activate dynasim
python setup.py develop
