""" Refresh all monthly data except GED and ACLED. """
import subprocess
import logging
from views.utils import pyutils

from views.apps.jdata.fetch import fetch
from views.apps.jdata.flat import flat
from views.apps.jdata.load import load
from views.apps.jdata.transforms import transforms
from views.apps.jdata.impute import impute

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)
Logger = logging.getLogger(__name__)


def run_fetch():
    """ Fetch monthly updated sources """
    fetch.fetch_monthly_sources()


def run_load():
    """ Load monthly updated sources """
    load.load_monthly()

def run_impute():
    """ Run imputations of monthly sources """
    impute.impute_monthly()

def run_transform():
    """ Create python transforms """
    transforms.make_transforms()

def run_flatten():
    """ Create flat views """
    flat.flatten()


def main():
    run_fetch()
    run_load()
    run_impute()
    run_transform()
    run_flatten()

if __name__ == "__main__":
    main()
