""" Load priogrid data

This loader deals with
* Extending yearly series into the future with last seen values (ffill)
* Combining _s and _y resource placers
* Interpolating less-than-annual observations


"""

import json
import tempfile
import os
import logging
import multiprocessing as mp

import pandas as pd

from views.utils import dbutils, datautils, pyutils
from views.apps.jdata.load import utils
from views.apps.jdata.fetch import fetchutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)


Logger = logging.getLogger(__name__)


def _inserts_vinfs_data_to_df(tempdir, df, vinfs, ids, drops):
    """ Insert data from varinfos into df in parallel """

    with mp.Pool(processes=4, maxtasksperchild=1) as pool:

        results = [
            pool.apply_async(_vinf_to_s, args=(tempdir, vinf, ids, drops))
            for vinf in vinfs
        ]
        result_series = [res.get() for res in results]

    for s in result_series:
        Logger.debug(f"Inserting {s.name}")
        df[s.name] = s

    df = df.sort_index()

    return df


def _vinf_to_s(tempdir, vinf, ids, drops=None):
    """ Get a single series from a varinfo """

    varname = vinf["name"]

    path_json = os.path.join(tempdir, f"{varname}.json")
    Logger.debug(f"Building df from {path_json}")
    with open(path_json, "r") as f:
        data_dict = json.load(f)

    df = pd.DataFrame.from_dict(data_dict["cells"])
    df = df.rename(columns={"value": varname})
    df = df.set_index(ids)
    if drops:
        df = df.drop(columns=drops)

    s = df[varname]
    s.name = varname

    return s


def _prepare(df, spec):
    """ Preparations before pushing """

    def ffill(df, spec):
        for col in [col for col in spec["cols_ffill"] if col in df.columns]:
            df[col] = df[col].groupby(level=0).fillna(method="ffill")
        return df

    def fill_nulls_to_zero(df, spec):
        """ Cols with _y and _s have nulls for zeros, fill with 0"""

        for col in spec["nulls_to_zero"]:
            if col in df.columns:
                df[col] = df[col].fillna(0)
        return df

    df = ffill(df, spec)
    df = fill_nulls_to_zero(df, spec)

    return df


def load_initial_pgdata():
    """ Creates the raw pgdata.yearly, static, basegrid and core """

    Logger.info(f"Started load_initial_pgdata()")
    name = "pgdata"
    spec = utils.load_specfile(name)
    path_tar = utils.path_to_latest_archive(name)

    dbutils.recreate_schema(name)

    with tempfile.TemporaryDirectory() as tempdir:

        fetchutils.extract_all_files(
            path_archive=path_tar, dir_destination=tempdir
        )

        path_varinfos = os.path.join(tempdir, spec["fname_varinfos"])
        path_basegrid = os.path.join(tempdir, spec["fname_basegrid"])

        with open(path_varinfos, "r") as f:
            varinfos = json.load(f)
        with open(path_basegrid, "r") as f:
            basegrid = json.load(f)

        msg = f"Loaded {len(varinfos)} varinfos"
        Logger.debug(msg)

        varinfos_static = [vi for vi in varinfos if vi["type"] == "static"]
        varinfos_yearly = [vi for vi in varinfos if vi["type"] == "yearly"]
        varinfos_core = [vi for vi in varinfos if vi["type"] == "core"]
        varinfos_core = list(
            filter(
                lambda x: x["name"] not in spec["excludes_core"], varinfos_core
            )
        )

        Logger.debug(f"Found {len(varinfos_static)} static varinfos")
        Logger.debug(f"Found {len(varinfos_yearly)} yearly varinfos")
        Logger.debug(f"Found {len(varinfos_core)} core varinfos")

        # Build the indices for the dfs
        y_start = min([vinf["startYear"] for vinf in varinfos_yearly])
        y_end = max([vinf["endYear"] for vinf in varinfos_yearly])
        years = list(range(y_start, y_end + 1))
        gids = [cell["gid"] for cell in basegrid]
        ix_pgy = pd.MultiIndex.from_product(
            [gids, years], names=["gid", "year"]
        )
        ix_pg = pd.Index(gids, name="gid")

        df_static = pd.DataFrame(index=ix_pg)
        df_yearly = pd.DataFrame(index=ix_pgy)
        df_core = pd.DataFrame(index=ix_pg)
        dbutils.df_to_db(df=df_core, fqtable=spec["fqtable_basegrid"])
        Logger.info(f"Started building initial pgdata frames")
        df_static = _inserts_vinfs_data_to_df(
            tempdir=tempdir,
            df=df_static,
            vinfs=varinfos_static,
            ids=["gid"],
            drops=["year"],
        )
        df_static = _prepare(df_static, spec)

        df_yearly = _inserts_vinfs_data_to_df(
            tempdir=tempdir,
            df=df_yearly,
            vinfs=varinfos_yearly,
            ids=["gid", "year"],
            drops=None,
        )
        df_yearly = _prepare(df_yearly, spec)

        df_core = _inserts_vinfs_data_to_df(
            tempdir=tempdir,
            df=df_core,
            vinfs=varinfos_core,
            ids=["gid"],
            drops=["year"],
        )
        df_core = _prepare(df_core, spec)

        dbutils.df_to_db(df=df_static, fqtable=spec["fqtable_static"])
        dbutils.df_to_db(df=df_yearly, fqtable=spec["fqtable_yearly"])
        dbutils.df_to_db(df=df_core, fqtable=spec["fqtable_core"])
        Logger.info(f"Finished load_initial_pgdata()")


def load_pgdata():
    """ Creates the staged and ready pgdata.pgy """

    def interpolate_pgdy_extent():
        msg = "Ipolating pgdata.pgdy_extent to pgdata.pgdy_extent_li"
        Logger.info(msg)
        df = dbutils.db_to_df_fast("pgdata.pgdy_extent", ids=["year", "pg_id"])
        Logger.info("Fetched pgdata.pgdy_extent")
        df = datautils.interpolate(df)
        Logger.info("Interpolated pgdata.pgdy_extent")
        dbutils.df_to_db(df, fqtable="pgdata.pgdy_extent_li")
        Logger.info("Pushed to pgdata.pgdy_extent_li")

    Logger.info(f"Started load_pgdata()")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_queries = os.path.join(this_dir, "queries", "pgdata")

    # Join pgdata.yearly to staging.priogrid_year to create yearly extent
    path_query = os.path.join(dir_queries, "create_pgdy_extent.sql")
    dbutils.execute_query_from_file(path_query)

    # Interpolate pgdy_extent and push to pgdata.pgdy_extent_li
    interpolate_pgdy_extent()

    path_query = os.path.join(dir_queries, "create_pgdata_pgy.sql")
    dbutils.execute_query_from_file(path_query)
    msg = "Created pgdata.pgy from joining pgdy_extent_li to pgdata.static"
    Logger.info(msg)
    Logger.info(f"Finished load_pgdata()")


if __name__ == "__main__":
    load_initial_pgdata()
    load_pgdata()
