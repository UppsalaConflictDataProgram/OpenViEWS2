""" Loader for historic IMF WEO reports from Oct 2007 onward. "
Note that in contrast to the regular WEO loader, this is country-year-month
according to the publication date.
"""

import logging
import pandas as pd

from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    #dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleanup IMF WEO")


def load_imfweo_hist():
    """ Load latest IMF WEO historical. Cleanup done in fetcher for
    this special case."""
    Logger.info("Starting IMF WEO import")
    dbutils.recreate_schema("imfweo_hist")
    spec = utils.load_specfile("imfweo_hist")
    df = utils.load_df_from_only_csv_in_tar(
        path_tar=utils.path_to_latest_archive("imfweo_hist")
    )

    # Push to raw.
    df.set_index(["year", "month", "iso"], inplace=True)
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])

    # Stage to cm level.
    utils.stage_data(spec)
    utils.interpolate_data(spec)
    _cleanup(spec)

    Logger.info("Finished IMF WEO historic import")


if __name__ == "__main__":
    load_imfweo_hist()
