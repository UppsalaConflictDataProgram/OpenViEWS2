# Data loaders

This application contains data loaders for the internal ViEWS database.
The name jdata is for janus-data, janus is our internal database server.

Structure:

* ./fetch/ contains fetch.py that fetches the latest version of all sources to the local machine.
* ./load/ contains one python script per source to load.
* ./impute/ contains run_imputations.py that runs the imputations
* ./transforms/ contains the python implemented transformations
* ./flat/ contains flat.py that creates the views in the flat schema that are read by the pipeline.

For a monthly update run
* fetch/fetch.py
* load/icgcw.py
* load/reign.py
* load/spei.py
* impute/impute.py
* flat/flat.py

fetch.py fetches monthly updated sources by default but has an --all command line argument.
If passed fetch.py will download all sources, not just monthly.


## TODO

* SIDE https://icr.ethz.ch/data/side/
* cropdata, integrate PV's work.
* Health data http://www.healthdata.org/
* Famine https://fews.net/fews-data/333