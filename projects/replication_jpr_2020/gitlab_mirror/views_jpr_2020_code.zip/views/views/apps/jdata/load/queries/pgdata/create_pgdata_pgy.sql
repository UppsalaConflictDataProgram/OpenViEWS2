CREATE TABLE pgdata.pgy AS
SELECT
pgy.priogrid_year_id,
pgy.pg_id,
pgy.year,
pgy.agri_ih,
pgy.barren_ih,
pgy.bdist1,
pgy.bdist2,
pgy.bdist3,
pgy.capdist,
pgy.droughtcrop_speibase,
pgy.droughtcrop_speigdm,
pgy.droughtcrop_spi,
pgy.droughtend_speibase,
pgy.droughtend_speigdm,
pgy.droughtend_spi,
pgy.droughtstart_speibase,
pgy.droughtstart_speigdm,
pgy.droughtstart_spi,
pgy.droughtyr_speibase,
pgy.droughtyr_speigdm,
pgy.droughtyr_spi,
pgy.drug_y,
pgy.excluded,
pgy.forest_ih,
pgy.gcp_mer,
pgy.gcp_ppp,
pgy.gcp_qual,
pgy.grass_ih,
pgy.gwarea,
pgy.irrig_max,
pgy.irrig_min,
pgy.irrig_sd,
pgy.irrig_sum,
pgy.nlights_calib_mean,
pgy.nlights_max,
pgy.nlights_mean,
pgy.nlights_min,
pgy.nlights_sd,
pgy.pasture_ih,
pgy.pop_gpw_max,
pgy.pop_gpw_min,
pgy.pop_gpw_sd,
pgy.pop_gpw_sum,
pgy.pop_hyd_max,
pgy.pop_hyd_min,
pgy.pop_hyd_sd,
pgy.pop_hyd_sum,
pgy.prec_gpcc,
pgy.prec_gpcp,
pgy.savanna_ih,
pgy.shrub_ih,
pgy.temp,
pgy.urban_ih,
pgy.water_ih,
pg.agri_gc,
pg.aquaveg_gc,
pg.barren_gc,
pg.cmr_max,
pg.cmr_mean,
pg.cmr_min,
pg.cmr_sd,
pg.forest_gc,
pg.growend,
pg.growstart,
pg.harvarea,
pg.herb_gc,
pg.imr_max,
pg.imr_mean,
pg.imr_min,
pg.imr_sd,
pg.landarea,
pg.maincrop,
pg.mountains_mean,
pg.rainseas,
pg.shrub_gc,
pg.ttime_max,
pg.ttime_mean,
pg.ttime_min,
pg.ttime_sd,
pg.urban_gc,
pg.water_gc,
-- Combine _s and _y after all the filling and extrapolating
GREATEST(pg.diamprim_s, pgy.diamprim_y) AS diamprim,
GREATEST(pg.diamsec_s, pgy.diamsec_y) AS diamsec,
GREATEST(pg.gem_s, pgy.gem_y) AS gem,
GREATEST(pg.goldplacer_s, pgy.goldplacer_y) AS goldplacer,
GREATEST(pg.goldsurface_s, pgy.goldsurface_y) AS goldsurface,
GREATEST(pg.goldvein_s, pgy.goldvein_y) AS goldvein,
GREATEST(pg.petroleum_s, pgy.petroleum_y) AS petroleum
FROM
pgdata.pgdy_extent_li AS pgy
LEFT JOIN pgdata.static AS pg
ON pgy.pg_id=pg.gid;

CREATE INDEX ON pgdata.pgy(priogrid_year_id);
CREATE INDEX ON pgdata.pgy(year);
CREATE INDEX ON pgdata.pgy(pg_id);
CREATE INDEX ON pgdata.pgy(pg_id, year);
CREATE INDEX ON pgdata.pgy(year, pg_id);

DROP TABLE pgdata.basegrid;
DROP TABLE pgdata.core;
DROP TABLE pgdata.pgdy_extent;
DROP TABLE pgdata.pgdy_extent_li;
DROP TABLE pgdata.static;
DROP TABLE pgdata.yearly;