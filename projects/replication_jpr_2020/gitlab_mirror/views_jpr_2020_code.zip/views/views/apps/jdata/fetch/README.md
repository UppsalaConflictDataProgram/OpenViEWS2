# Fetch

Fetch is the ViEWS component that fetches raw data from external sources.
A task to fetch() is simply "fetch latest data from source" where source
is any of our external data sources.

The output of fetch is always a timestamped and compressed directory in
permanent file storage.
The task.json passed to fetch() should also be stored next to this compressed
dir for future reference.
A info.json should also be written next to the compressed directory
with any interesting stats about the fetch that can be easily deduced, such as

* Number of columns
* Dataset versions
* Number of rows
* Last seen event
* Etc.

The directory structure should be roughly:

/$storage/data/raw/$sourcename/$timestamp/data.tar.xz
/$storage/data/raw/$sourcename/$timestamp/task.json
/$storage/data/raw/$sourcename/$timestamp/info.json

An important principle is that these files, once determined to be
non-duplicates, should NEVER be written to again.
These are the sacred input files.
From these we read into the database to make our usable data but we never edit
them directly.

After fetching they should be:

* Made public and downloadable directly from us
* Backed up to cold storage

Anyone wishing to replicate our work should be able to fetch these from us,
run our code and get almost identical results.
This is our replication data.
We can't trust external download links to stay around for people to
reassemble our data in the future.

## Why?

The idea is to maintain an archive of our input data instead of trying to
maintain historic state of our database or in dumps of various tables at
different stages.

The state of our working data used to produce our forecasts at any time must be
possible to reconstruct by running the data construction pipelines from scratch
with a date as the only paramter.
The pipelines can then load the latest raw data from up to that date.
Current production runs of the data construction pipeline will simply run with
the current date, using all the latest data.

Currently it is very much possible for us to run ad-hoc queries that alter our
tables.
This breaks our reproducibility and reduces our transparency.

We can of course cache the intermediate stages of the data, no-need to recompute
derived datasets for inputs that haven't changed.
The point is that it should be possible and easy for anyone to rebuild from
scratch.

If we don't do this we will never be fully reproducible.

This also makes developing our data pipelines easier and more transparent.
If we can safely re-run each step or drop our entire database without danger of
losing data we will be able to develop much faster.

## Storage economy

We should adhere to:

* Compress heavily by default
* Never store duplicate dumps

Duplicate dumps can be found by checking the previous fetch of a source.
If that previous fetch is identical to the current we delete the current.
This gives us an assurance that "$source hasn't changed since $timestamp" and
saves us storage space.


## Source specifics
Possible parameters to fetch are

* API version numbers
* Start/end dates
* Whatever else is appropriate for the source

In my view these parameters should be as inclusive as possible, meaning
as early start dates as possible for things like GED and ACLED that might
alter the past.
Just getting the latest data instead of a full copy leaves us vulnerable to
changing history in the sources and complicated incremental filling based on
many dumps.

## Sources

Implemented sources are

* GADM
* GED
* ACLED
* PRIOGRID
* WDI
* cshapes
* GeoEPR
* reign
* icgcw

### Manual sources

#### VDEM

* Downloaded from https://www.v-dem.net/en/data/data-version-9/
* Downloaded all files and compressed to .tar.xz using
`tar -cJf data.tar.xz< *` where you downloaded the files.


