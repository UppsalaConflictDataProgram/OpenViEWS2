import argparse
import os
import logging
from views.utils import pyutils, dbutils, datautils
from views.apps.impute import impute

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
Logger = logging.getLogger(__name__)

def fetch_all_from_args():
    """ True if --all passed as command line arg """

    parser = argparse.ArgumentParser()
    parser.add_argument("--all", action="store_true", help="Impute all sources")

    args = parser.parse_args()
    fetch_all = args.all

    return fetch_all



def create_raw_data_views():
    """ Just run the queries in create_raw_data_views.sql in this dir """
    Logger.info("Started create_raw_data_views()")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_query = os.path.join(this_dir, "create_raw_data_views.sql")
    dbutils.execute_query_from_file(path_query)
    Logger.info("Finished create_raw_data_views()")


def run_imputation(fqtable_in, fqtables_out, ids):
    """ Run an imputation

    Fetch data from fqtable_in, interpolate and extrapolate it,
    then impute the remaining missingness and write that to
    fqtables_out. ids must be specified.
    """
    if not len(ids) == 2:
        msg = "Interpolation needs index set like [timevar, groupvar]"
        raise RuntimeError(msg)

    df = dbutils.db_to_df_fast(fqtable=fqtable_in, ids=ids)
    df = datautils.interpolate(df)
    df = datautils.fill_forwards_backwards(df)
    # Number of imputations is number of output tables
    n_imp = len(fqtables_out)
    mice_generator = impute.impute_mice_generator(df, n_imp)
    for fqtable_out, df_imp in zip(fqtables_out, mice_generator):
        dbutils.df_to_db(df=df_imp, fqtable=fqtable_out, drop_cascade=True)


def impute_monthly():
    Logger.info(f"Running monthly imputations")

    create_raw_data_views()

    path_spec = os.path.join(os.path.dirname(os.path.abspath(__file__)), "spec.yaml")
    spec = pyutils.load_yaml(path_spec)

    keys_todo = spec["todo"]["monthly"]
    for key in keys_todo:
        run_imputation(**spec["imputations"][key])


def impute_all():
    Logger.info(f"Running all imputations")

    create_raw_data_views()

    path_spec = os.path.join(os.path.dirname(os.path.abspath(__file__)), "spec.yaml")
    spec = pyutils.load_yaml(path_spec)

    keys_todo = spec["todo"]["all"]
    for key in keys_todo:
        run_imputation(**spec["imputations"][key])

def main():
    if fetch_all_from_args():
        impute_all()
    else:
        impute_monthly()


if __name__ == "__main__":
    main()
