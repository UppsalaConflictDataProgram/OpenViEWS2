import os
import logging

from views.apps.jdata.common import utils
from views.apps.transforms import api as tr_api

from views.utils import pyutils, dbutils, datautils

Logger = logging.getLogger(__name__)


def _get_cols_source(transforms):
    """ Get a list of source columns needed for a list of Tranforms """

    all_names = [transform.colname for transform in transforms]
    all_cols = []
    for transform in transforms:
        for col in transform.cols:
            all_cols.append(col)

    all_cols = pyutils.dedup_list(all_cols)
    cols_source = [col for col in all_cols if not col in all_names]
    cols_source = sorted(cols_source)

    return cols_source


def _order_transforms(transforms):
    """ Order transformations so they are done in dependency order """

    def names(tasks):
        return [task.name for task in tasks]

    ordered = list()
    while transforms:
        progress = False
        for task in transforms:
            print(f"{task.name}")
            # if task has deps in the other transforms that haven't been solved themselves wait
            if any(
                [
                    col in names(transforms) and col not in names(ordered)
                    for col in task.cols
                ]
            ):
                pass
            else:
                ordered.append(task)
                transforms.remove(task)
                progress = True
        if not progress:
            raise RuntimeError(f"No progress")

    return ordered


def build_transforms_by_spec_to_database(spec):
    # Build the Transformer instances list from the spec
    transforms = [
        tr_api.Transformer(name, spec)
        for name, spec in spec["transforms"].items()
    ]
    transforms = _order_transforms(transforms)
    # Figure out which dependent columns to fetch
    cols_source = _get_cols_source(transforms)

    # Fetch the geometry
    gdf_geom = dbutils.db_to_gdf(
        query=spec["geometry"]["query"], groupvar=spec["geometry"]["groupvar"],
    )

    # Do all the transformations for each table pair
    for table_pair in spec["table_pairs"]:
        gdf = gdf_geom.join(
            dbutils.db_to_df(
                fqtable=table_pair["input"],
                columns=cols_source,
                ids=[spec["timevar"], spec["groupvar"]],
            )
        )

        if spec["balance_index"]:
            idx_prebalance = gdf.index
            gdf = datautils.balance_df_panel_index(
                gdf, timevar=spec["timevar"], groupvar=spec["groupvar"]
            )

        for i, transform in enumerate(transforms):
            Logger.info(f"Started {i}/{len(transforms)}: {transform.name}")
            gdf[transform.name] = transform.compute(gdf)

        # Just keep the transforms we computed, not source cols
        df = gdf[[transform.name for transform in transforms]]

        if spec["balance_index"]:
            df = df.reindex(idx_prebalance)

        dbutils.df_to_db(df=df, fqtable=table_pair["output"])


def make_transforms():
    this_dir = os.path.dirname(__file__)

    # init raw data views
    dbutils.execute_query_from_file(
        os.path.join(this_dir, "queries", "cm_raw.sql")
    )
    dbutils.execute_query_from_file(
        os.path.join(this_dir, "queries", "pgm_raw.sql")
    )

    # Build transforms according to spec
    build_transforms_by_spec_to_database(utils.load_specfile("transforms_cm"))
    build_transforms_by_spec_to_database(utils.load_specfile("transforms_pgm"))

    # Drop the raw views
    fqviews_to_drop = [
        "transforms.pgm_africa_1_raw",
        "transforms.cm_global_1_raw",
        "transforms.cm_africa_1_raw",
    ]
    for fqviews in fqviews_to_drop:
        dbutils.drop_view(fqviews)


if __name__ == "__main__":
    make_transforms()
