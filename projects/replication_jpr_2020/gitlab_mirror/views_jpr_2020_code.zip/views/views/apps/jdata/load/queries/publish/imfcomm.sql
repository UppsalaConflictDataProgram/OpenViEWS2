DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS
SELECT
m.id as month_id,
${cols_data}
FROM
staging.month as m
LEFT JOIN
${fqtable_data_raw} AS raw
ON m.month = raw.month
AND m.year = raw.year;