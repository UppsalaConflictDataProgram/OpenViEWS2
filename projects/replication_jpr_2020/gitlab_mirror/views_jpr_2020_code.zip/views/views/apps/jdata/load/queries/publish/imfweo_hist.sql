-- Query to create public table of IMF WEO data to be read into main datasets.
-- Join using isoab to IMF countrycodes.

DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS

WITH cm AS (
        SELECT cm.id AS country_month_id,
               cm.month_id,
               cm.country_id,
               c.isoab,
               m.month,
               m.year_id AS year
        FROM staging.country_month AS cm
             INNER JOIN staging.country AS c
                 ON c.id = cm.country_id
             INNER JOIN staging.month AS m
                 ON m.id = cm.month_id
    )
SELECT
cm.country_month_id,
cm.month_id,
cm.country_id,
${cols_data}
FROM cm
LEFT JOIN
${fqtable_data_raw} AS imfweo_hist
ON cm.isoab=imfweo_hist.iso
AND cm.year=imfweo_hist.year
AND cm.month=imfweo_hist.month;
