DROP TABLE IF EXISTS vdem.cy_staged;
CREATE TABLE vdem.cy_staged AS
WITH
vdem AS (
    SELECT
    data.*,
    meta.cowcode,
    meta.country_text_id
    FROM
    vdem.meta_raw AS meta
    INNER JOIN
    vdem.data_raw AS data
    ON meta.country_id=data.country_id
    AND
    meta.year=data.year
),
cy AS (
    SELECT cy.id AS country_year_id,
           cy.country_id,
           cy.year_id AS year,
           c.isoab
    FROM staging.country_year AS cy
    INNER JOIN staging.country AS c
        ON cy.country_id=c.id
)
SELECT
cy.country_year_id,
cy.country_id,
cy.year,
${cols_data}
FROM cy LEFT JOIN vdem
-- ON cy.gwcode=data.cowcode
ON cy.isoab=vdem.country_text_id
AND
cy.year = vdem.year;