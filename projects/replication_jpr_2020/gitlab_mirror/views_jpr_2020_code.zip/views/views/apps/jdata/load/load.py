import sys
import logging
import multiprocessing as mp

from views.utils import pyutils
from views.apps.jdata.load import (
    fvp,
    icgcw,
    pgdata,
    polity,
    reign,
    spei,
    vdem,
    wdi,
)

Logger = logging.getLogger(__name__)


def load_monthly():
    """ Load the three monthly sources in their own processes """

    p_icgcw = mp.Process(target=icgcw.load_icgcw)
    p_reign = mp.Process(target=reign.load_reign)
    p_spei = mp.Process(target=spei.load_spei)

    p_icgcw.start()
    p_reign.start()
    p_spei.start()

    p_icgcw.join()
    p_reign.join()
    p_spei.join()

    Logger.info("Finished loading all sources")
