""" Polity loader """

import logging
import tempfile

import pandas as pd

from views.apps.data.fetch import fetchutils
from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils


if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    dbutils.drop_table(spec["fqtable_data_raw"])
    Logger.info("Cleaned up ICGCW")


def load_polity():
    """ Load Polity """

    Logger.info("Starting loading Polity")
    spec = utils.load_specfile("polity")
    path_tar = utils.path_to_latest_archive(name_dataset="polity")

    with tempfile.TemporaryDirectory() as tempdir:
        path = fetchutils.extract_file(
            path_archive=path_tar,
            filename=spec["fname"],
            dir_destination=tempdir,
        )
        df = pd.read_excel(path)

    df = df.rename(columns=spec["renames"])
    df = df.set_index([spec["timevar"], spec["groupvar_raw"]]).sort_index()

    dbutils.recreate_schema("polity")
    dbutils.df_to_db(df=df, fqtable=spec["fqtable_data_raw"])
    utils.stage_data(spec)
    utils.impute_data(spec)
    _cleanup(spec)

    Logger.info("Finished loading polity")


if __name__ == "__main__":
    load_polity()
