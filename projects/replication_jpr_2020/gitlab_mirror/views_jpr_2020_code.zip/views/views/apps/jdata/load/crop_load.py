import logging
import pandas as pd 
from views.utils import dbutils, datautils, pyutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)

##general function with all steps
#load data on crops and growing season
def load_growseas():
    dbutils.recreate_schema("growseas")
    path = "/Users/paola/Documents/Data/agr/harv-growseas-irr-rainf-feb2020.csv" 
    upload_raw(path)
    add_pg_id()
    attach()
    spei()
    speidummy()
    interpolate()
    dummies()
    dummies6()


##upload raw data - annual level - containing growing season info from MIRCA (around year 2000) and info on crops from MAPSPAM (available for years 2000,2005,2010)
def upload_raw(path):
    df = pd.read_csv(path)

    cols = [
        "lon",
        "lat",
        "year",
        "gsmm1",
        "gsmm2",
        "gsmm3",
        "gsmm4",
        "gsmm5",
        "gsmm6",
        "gsmm7",
        "gsmm8",
        "gsmm9",
        "gsmm10",
        "gsmm11",
        "gsmm12",
        "irr_maincrops",
        "rainf_maincrops",
        "harvarea_maincrops"
        ]
    df = df[cols]
    dbutils.df_to_db(df = df, fqtable= "growseas.raw", write_index=False)

    ##add priogrid id by converting lon lat to pg id


def add_pg_id():
    query = """
    CREATE TABLE growseas.raw_with_pg_id AS
    SELECT priogrid(lat, lon) AS pg_id,
        growseas.lon,
        growseas.lat,
        growseas.year,
        growseas.gsmm1,
        growseas.gsmm2,
        growseas.gsmm3,
        growseas.gsmm4,
        growseas.gsmm5,
        growseas.gsmm6,
        growseas.gsmm7,
        growseas.gsmm8,
        growseas.gsmm9,
        growseas.gsmm10,
        growseas.gsmm11,
        growseas.gsmm12,
        growseas.irr_maincrops,
        growseas.rainf_maincrops,
        growseas.harvarea_maincrops
        FROM growseas.raw AS growseas;
    """
    dbutils.execute_query(query)

##attach the year reference so to obtain pg_year_id

def attach():
    query = """
    CREATE TABLE growseas.attached AS
        SELECT pgy.id AS priogrid_year_id,
               pgy.priogrid_gid AS pg_id,
               pgy.year_id AS year,
               growseas.gsmm1,
               growseas.gsmm2,
               growseas.gsmm3,
               growseas.gsmm4,
               growseas.gsmm5,
               growseas.gsmm6,
               growseas.gsmm7,
               growseas.gsmm8,
               growseas.gsmm9,
               growseas.gsmm10,
               growseas.gsmm11,
               growseas.gsmm12,
               growseas.irr_maincrops,
               growseas.rainf_maincrops,
               growseas.harvarea_maincrops
    FROM staging.priogrid_year AS pgy
    LEFT JOIN growseas.raw_with_pg_id AS growseas ON pgy.priogrid_gid=growseas.pg_id AND pgy.year_id = growseas.year;
    """
    dbutils.execute_query(query)

    query = """
    CREATE TABLE growseas.attached AS
        SELECT pgy.id AS priogrid_year_id,
               pgy.priogrid_gid AS pg_id,
               pgy.year_id AS year,
               growseas.gsmm1,
               growseas.gsmm2,
               growseas.gsmm3,
               growseas.gsmm4,
               growseas.gsmm5,
               growseas.gsmm6,
               growseas.gsmm7,
               growseas.gsmm8,
               growseas.gsmm9,
               growseas.gsmm10,
               growseas.gsmm11,
               growseas.gsmm12,
               growseas.irr_maincrops,
               growseas.rainf_maincrops,
               growseas.harvarea_maincrops
    FROM staging.priogrid_year AS pgy
    LEFT JOIN growseas.raw AS data ON pgy.priogrid_gid=data.gid AND pgy.year_id = data.year;

    SELECT COUNT(*) AS count FROM growseas.attached GROUP BY priogrid_year_id ORDER BY count DESC;

    CREATE VIEW growseas.myview AS SELECT
    growseas.year, pg.gid, pg.geom, growseas.gsmm1, growseas.gsmm2, growseas.gsmm3, growseas.gsmm4, growseas.gsmm5, growseas.gsmm6, 
    growseas.gsmm7, growseas.gsmm8, growseas.gsmm9, growseas.gsmm10, growseas.gsmm11, growseas.gsmm12, growseas.irr_maincrops, 
    growseas.rainf_maincrops, growseas.harvarea_maincrops
    FROM staging.priogrid AS pg LEFT JOIN growseas.attached AS growseas ON pg.gid=growseas.pg_id;
    """

##select the gs info for year 2000 and create a dummy 0-1 for all months that fall into growing season    

def spei():
    query = """
    SELECT pg_id,
           gsmm1,
           gsmm2,
           gsmm3,
           gsmm4,
           gsmm5,
           gsmm6,
           gsmm7,
           gsmm8,
           gsmm9,
           gsmm10,
           gsmm11,
           gsmm12
    FROM growseas.attached
    WHERE year = 2000;
    """
    df = dbutils.query_to_df(query)
    df = df.set_index(['pg_id'])

    dfs = []
    for month in range(1,13):
        df_m = df.copy()
        df_m["month"] = month
        colname = f"gsmm{month}"
        df_m["growseasdummy"] = df[colname]
        dfs.append(df_m)

    df = pd.concat(dfs)
    df = df[["month", "growseasdummy"]]
    dbutils.df_to_db(df, fqtable="growseas.constant")

##we merge the table with the dummy variable back with pgm to obtain info for each priogrid month
##all growseas dummies will be copied for each month priogrid (no matter the year)

    query = """
    DROP TABLE IF EXISTS growseas.pgm;
    CREATE TABLE growseas.pgm AS SELECT pgm.id AS priogrid_month_id,
                                        pgm.priogrid_gid AS pg_id,
                                        pgm.month_id,
                                        const.growseasdummy
    FROM staging.priogrid_month AS pgm
        INNER JOIN staging.month AS m ON m.id=pgm.month_id
        LEFT JOIN growseas.constant AS const
            ON const.pg_id=pgm.priogrid_gid AND const.month=m.month;
    """
    dbutils.execute_query(query)

    ##join with the SPEI data to be able to compute the dummies for drought

def speidummy():    
    query = """
    DROP TABLE IF EXISTS growseas.drought;
    CREATE TABLE growseas.drought AS
    SELECT spei.priogrid_month_id,
               spei.pg_id,          
               spei.month_id, 
               spei.spei_1, 
               spei.spei_2, 
               spei.spei_3,
               spei.spei_4, 
               spei.spei_5, 
               spei.spei_6,
               spei.spei_7, 
               spei.spei_8, 
               spei.spei_9,
               spei.spei_10, 
               spei.spei_11, 
               spei.spei_12,
               spei.spei_13,
               spei.spei_15,
               spei.spei_16,
               spei.spei_17,
               spei.spei_18,
               spei.spei_19,
               spei.spei_20,
               spei.spei_21,
               spei.spei_22,
               spei.spei_23,
               spei.spei_24,
               spei.spei_25,
               spei.spei_26,
               spei.spei_27,
               spei.spei_28,
               spei.spei_29,
               spei.spei_30,
               spei.spei_31,
               spei.spei_32,
               spei.spei_33,
               spei.spei_34,
               spei.spei_35,
               spei.spei_36,
               spei.spei_37,
               spei.spei_38,
               spei.spei_39,
               spei.spei_40,
               spei.spei_41,
               spei.spei_42,
               spei.spei_43,
               spei.spei_44,
               spei.spei_45,
               spei.spei_46,
               spei.spei_47,
               spei.spei_48, 
               gs.growseasdummy
    FROM spei.pgm AS spei
    JOIN growseas.pgm AS gs
    ON spei.priogrid_month_id = gs.priogrid_month_id
        """
##
    dbutils.execute_query(query)

##join with year pg id to attach the other variables I need
##as the other variables like crop irr and rainf are at the yearly level
##and during the construction of the dummy for gs they have been left behind
##now I first attach the pg_year_id reference and then the id allows me to 
##join the annual variables with spei and growseas dummy variables

    query = """
    DROP TABLE IF EXISTS growseas.year;
    CREATE TABLE growseas.year AS
        SELECT pgm.priogrid_year_id,
               pgm.priogrid_gid,
               gs.*
    FROM staging.priogrid_month AS pgm
    LEFT JOIN growseas.drought AS gs ON gs.pg_id = pgm.priogrid_gid AND gs.priogrid_month_id = pgm.id AND gs.month_id = pgm.month_id;
    """
    dbutils.execute_query(query)

    ##join with grows attached to obtain the other variables
    ##before joining the original annual data with crops back with my new variables (gs dummy and spei) 
    ## I INTERPOLATE by year pgid to fill in missing values


def interpolate():
    df = dbutils.db_to_df(fqtable="growseas.attached", ids=["year", "pg_id"])
    df = df.sort_index()
    print("starting ipolate")
    df = datautils.interpolate(df)
    print("fininshed ipolate")
    dbutils.df_to_db(df=df, fqtable="growseas.interpolated")

##Then once interpolated, I use the interpolated dataset to join it with gs dummy and spei (table 'interpolated' is the interpolated version of 'attached')
##and growseas.year is the table growseas.drought (the one with gsdummy and spei) containig also the identifier for year 

    query = """
    DROP TABLE IF EXISTS growseas.growseason;
    CREATE TABLE growseas.growseason AS
        SELECT gs.*,
            gsa.irr_maincrops,
            gsa.rainf_maincrops,
            gsa.harvarea_maincrops       
        FROM growseas.year AS gs
        LEFT JOIN growseas.interpolated AS gsa ON gs.priogrid_year_id = gsa.priogrid_year_id;
        """
    dbutils.execute_query(query)

## I create a variable that tells me how long was the growing season and how long compared to the year (proportion of gs as ratio of the entire year)

def dummies():
    query = """
    DROP TABLE IF EXISTS growseas.growseasonlength;
    CREATE TABLE growseas.growseasonlength AS
    select gs.*,  l.growseasprop FROM
    (SELECT priogrid_year_id,
    SUM (growseasdummy)/12 AS growseasprop
    FROM growseas.growseason AS gs
    group by priogrid_year_id)
    l LEFT JOIN growseas.growseason AS gs ON l.priogrid_year_id = gs.priogrid_year_id;
    """
    dbutils.execute_query(query)

##create different dummies by using spei values
           
##create dummy for modest drought spei3

    query = """
    DROP TABLE IF EXISTS growseas.dr_mod;
    CREATE TABLE growseas.dr_mod AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_3 <= -0.5 AND gs.spei_3 >= -1 THEN 1 
      ELSE 0 END AS dr_mod
      from growseas.growseasonlength AS gs
      """
    dbutils.execute_query(query)

#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgsmod;
    CREATE TABLE growseas.drgsmod AS
    SELECT gs.*,
      CASE WHEN gs.dr_mod = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_mod_gs
      from growseas.dr_mod AS gs
      """
    dbutils.execute_query(query)

##create dummy for moderate drought

    query = """
    DROP TABLE IF EXISTS growseas.dr_moder;
    CREATE TABLE growseas.dr_moder AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_3 <= -1 AND gs.spei_3 >= -1.5 THEN 1 
      ELSE 0 END AS dr_moder
      from growseas.drgsmod AS gs
      """
    dbutils.execute_query(query)

#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgsmoder;
    CREATE TABLE growseas.drgsmoder AS
    SELECT gs.*,
      CASE WHEN gs.dr_moder = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_moder_gs
      from growseas.dr_moder AS gs
      """
    dbutils.execute_query(query)


##create dummy for severe drought

    query = """
    DROP TABLE IF EXISTS growseas.dr_severe;
    CREATE TABLE growseas.dr_severe AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_3 <= -2 THEN 1 
      ELSE 0 END AS dr_sev
      from growseas.drgsmoder AS gs
      """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.drought
    """
    dbutils.execute_query(query)
    
    query = """
    DROP TABLE IF EXISTS growseas.droughtdummy
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.droughtdummygs
    """
    dbutils.execute_query(query)
    
    query = """
    DROP TABLE IF EXISTS growseas.dr_mod
    """
    dbutils.execute_query(query)
    
    query = """
    DROP TABLE IF EXISTS growseas.drgsmod
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.dr_moder
    """
    dbutils.execute_query(query)
    
    query = """
    DROP TABLE IF EXISTS growseas.drgsmoder
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.growseasonprop
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.growseasonlength
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.growseason
    """
    dbutils.execute_query(query)
    
#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgs_severe;
    CREATE TABLE growseas.drgs_severe AS
    SELECT gs.*,
      CASE WHEN gs.dr_sev = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_sev_gs
      from growseas.dr_severe AS gs
      """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.dr_severe
    """
    dbutils.execute_query(query)

    query = """
    ALTER TABLE growseas.drgs_severe RENAME TO drought;
    """
    dbutils.execute_query(query) 

##Repeat same for spei_6

def dummies6():
    query = """
    DROP TABLE IF EXISTS growseas.dr_mod;
    CREATE TABLE growseas.dr_mod AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_6 <= -0.5 AND gs.spei_6 >= -1 THEN 1 
      ELSE 0 END AS dr_mod6
      from growseas.drought AS gs
      """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.drought
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.droughtdummy
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.droughtdummygs
    """
    dbutils.execute_query(query)

#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgsmod;
    CREATE TABLE growseas.drgsmod AS
    SELECT gs.*,
      CASE WHEN gs.dr_mod6 = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_mod_gs6
      from growseas.dr_mod AS gs
      """
    dbutils.execute_query(query)

        
    query = """
    DROP TABLE IF EXISTS growseas.dr_mod
    """
    dbutils.execute_query(query)
    

##create dummy for moderate drought

    query = """
    DROP TABLE IF EXISTS growseas.dr_moder;
    CREATE TABLE growseas.dr_moder AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_6 <= -1 AND gs.spei_6 >= -1.5 THEN 1 
      ELSE 0 END AS dr_moder6
      from growseas.drgsmod AS gs
      """
    dbutils.execute_query(query)

#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgsmoder;
    CREATE TABLE growseas.drgsmoder AS
    SELECT gs.*,
      CASE WHEN gs.dr_moder6 = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_moder_gs6
      from growseas.dr_moder AS gs
      """
    dbutils.execute_query(query)


##create dummy for severe drought

    query = """
    DROP TABLE IF EXISTS growseas.dr_severe;
    CREATE TABLE growseas.dr_severe AS
    SELECT gs.*,
      CASE 
      WHEN gs.spei_6 <= -2 THEN 1 
      ELSE 0 END AS dr_sev6
      from growseas.drgsmoder AS gs
      """
    dbutils.execute_query(query)


##drop tables to save space
    query = """
    DROP TABLE IF EXISTS growseas.drgsmod
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.dr_moder
    """
    dbutils.execute_query(query)
    
    query = """
    DROP TABLE IF EXISTS growseas.drgsmoder
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.clim_hist
    """
    dbutils.execute_query(query)

    
#combine drought dummies with growing season

    query = """
    DROP TABLE IF EXISTS growseas.drgs_severe;
    CREATE TABLE growseas.drgs_severe AS
    SELECT gs.*,
      CASE WHEN gs.dr_sev6 = '1' AND gs.growseasdummy = '1' THEN 1 
      ELSE 0 END AS dr_sev_gs6
      from growseas.dr_severe AS gs
      """
    dbutils.execute_query(query)

##drop useless tables 

    
    query = """
    DROP TABLE IF EXISTS growseas.dr_severe
    """
    dbutils.execute_query(query)

    query = """
    UPDATE growseas.drgs_severe 
    SET growseasprop = 0 WHERE growseasprop IS NULL;
      """
    dbutils.execute_query(query)

    
    query = """
    DROP TABLE IF EXISTS growseas.raw_with_pg_id
    """
    dbutils.execute_query(query)

    query = """
    DROP VIEW IF EXISTS growseas.climate
    """
    dbutils.execute_query(query)

    query = """
    ALTER TABLE growseas.drgs_severe RENAME to drought;
    """
    dbutils.execute_query(query)

    query = """
    DROP TABLE IF EXISTS growseas.drgs_severe
    """
    dbutils.execute_query(query)


    query = """
    DROP VIEW IF EXISTS growseas.climate;
    CREATE VIEW growseas.climate AS
    SELECT flat.*,
           gs.priogrid_year_id,
           gs.priogrid_month_id, 
           gs.growseasdummy, 
           gs.irr_maincrops, 
           gs.rainf_maincrops,
           gs.growseasprop,
           gs.dr_mod, 
           gs.dr_mod_gs, 
           gs.dr_moder, 
           gs.dr_moder_gs, 
           gs.dr_sev, 
           gs.dr_sev_gs,
           gs.dr_mod6, 
           gs.dr_mod_gs6, 
           gs.dr_moder6, 
           gs.dr_moder_gs6, 
           gs.dr_sev6, 
           gs.dr_sev_gs6
    FROM flat.pgm_africa_1 AS flat
    LEFT JOIN growseas.drought as gs
    ON flat.pg_id = gs.pg_id AND flat.month_id = gs.month_id
    WHERE flat.month_id <= 519
    """
    dbutils.execute_query(query)

  
if __name__ == "__main__":
    load_growseas()


