""" World development indicators


Reads WDI from dir_data_raw, subsets cols and pushes to db.

"""

import logging

from views.utils import dbutils, pyutils
from views.apps.jdata.load import utils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleaned up FVP")


def load_fvp():
    """ Load FVP data """

    Logger.info("Starting FVP import")
    dbutils.recreate_schema("fvp")
    spec = utils.load_specfile(name_dataset="fvp")
    path_data_tar = utils.path_to_latest_archive(name_dataset="fvp")

    df = utils.load_df_from_only_csv_in_tar(path_tar=path_data_tar)
    df = df.drop(columns=spec["cols_drop"])
    df = df.rename(columns=lambda col: col.lower())
    df = df.set_index([spec["timevar_raw"], spec["groupvar_raw"]])
    df = df[spec["cols_data"]]

    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])
    Logger.info("Finished FVP raw import")

    utils.stage_data(spec)
    utils.interpolate_data(spec)
    # utils.impute_data(spec)
    _cleanup(spec)
    Logger.info("FVP data ready.")


if __name__ == "__main__":
    load_fvp()
