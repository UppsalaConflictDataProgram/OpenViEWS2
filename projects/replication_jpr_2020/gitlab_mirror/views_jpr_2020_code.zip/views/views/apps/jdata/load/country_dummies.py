""" Country dummies loader """

import logging
import tempfile

import pandas as pd

from views.apps.data.fetch import fetchutils
from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils


if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def load_country_dummies():
    """ Load Polity """

    Logger.info("Starting loading Country dummies")
    spec = utils.load_specfile("country_dummies")
    dbutils.recreate_schema("cdummies")

    df = dbutils.db_to_df(fqtable="staging.country", columns=["id"])
    df = df.rename(columns={"id": "country_id"})
    df_dummies = pd.get_dummies(df["country_id"])
    df_dummies = df_dummies.add_prefix(prefix="cdum_")
    df = df.join(df_dummies)
    df = df.set_index(["country_id"])

    dbutils.df_to_db(df, fqtable="cdummies.c")
    dbutils.create_table_index(
        fqtable="cdummies.c", cols=["country_id"], unique=True
    )

    Logger.info("Finished loading country dummies")


if __name__ == "__main__":
    load_country_dummies()
