CREATE TABLE ${fqtable_staged} AS
    WITH cm AS (
        SELECT cm.id AS country_month_id,
               cm.month_id,
               cm.country_id,
               c.name AS country_name,
               m.year_id AS year,
               m.month
        FROM staging.country_month AS cm
        INNER JOIN staging.country AS c
        ON cm.country_id=c.id
        INNER JOIN staging.month AS m
        ON m.id=cm.month_id

    )
SELECT
  cm.country_month_id,
  cm.month_id,
  cm.country_id,
  alerts,
  opportunities,
  deteriorated,
  improved,
  unobserved
  FROM
  cm
  LEFT JOIN
  ${fqtable_data_raw} AS raw
  ON raw.name=cm.country_name
  AND raw.month=cm.month
  AND raw.year=cm.year;