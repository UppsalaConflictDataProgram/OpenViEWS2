""" Common fetch utils """
import os
import datetime
import shutil
import tarfile
import zipfile
import tempfile
import logging

import requests

from views.utils import pyutils
from views.utils.config import CONFIG

Logger = logging.getLogger(__name__)
DIR_RAW = CONFIG["dirs"]["dir_data_raw"]


def utc_now_hour():
    """ Get a UTC hourly time like 20180101-13 """
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H")


def utc_now_minute():
    """ Get a UTC minutely time like 20180101-1337 """
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H%M")


def utc_now():
    """ Get the current UTC time as 20180101-133759"""
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")


def fetch_url_to_file(url, path):
    """ Fetch the file at url to path """

    with requests.get(url, stream=True) as response:
        # total_length = response.headers.get('content-length')
        Logger.info(f"Fetching {url} to {path}")
        with open(path, "wb") as f:
            shutil.copyfileobj(response.raw, f)


def compress_file(path_source, path_destination):
    """ Write a single file to tar.xz archive

    Args:
        path_source: path to file to compress
        path_destination: path to archive

    Returns:
        None
    """

    name = os.path.basename(path_source)
    with tarfile.open(path_destination, mode="w:xz") as f:
        msg = f"Adding {path_source} to {path_destination} under name {name}"
        Logger.debug(msg)
        # Setting arcname lets us discard the source dir location
        f.add(path_source, arcname=name)


def compress_files(paths_sources, path_destination):
    """ Write a list of files to tar.xz archive

    Args:
        paths_sources: list of paths to file to compress
        path_destination: path to archive

    Returns:
        None
    """

    with tarfile.open(path_destination, mode="w:xz") as f:
        for path_source in paths_sources:
            name = os.path.basename(path_source)
            msg = (
                f"Compressing {path_source} "
                f"to {path_destination} "
                f"as {name}"
            )
            Logger.debug(msg)
            # Setting arcname lets us discard the source dir location
            f.add(path_source, arcname=name)

    msg = f"Compressed {len(paths_sources)} files to {path_destination}"
    Logger.info(msg)


def extract_file(path_archive, filename, dir_destination):
    """ Extract a file from a tar archive

    Args:
        path_archive: path to the tar archive
        filename: Name of file in archive to extract
        dir_destination: Destination directory
    Returns:
        path_destination: path to the extracted file
    """

    Logger.info(f"Extracting {filename} from {path_archive}")
    with tarfile.open(path_archive, "r") as f:
        f.extract(filename, path=dir_destination)

    path_destination = os.path.join(dir_destination, filename)
    return path_destination


def extract_all_files(path_archive, dir_destination):
    """ Extract all files in .tar archive """

    Logger.info(f"Extracting all files from {path_archive}")
    with tarfile.open(path_archive, "r") as f:
        f.extractall(path=dir_destination)


def unpack_zipfile(path_zip, destination):
    """ Unpack a zipfile

    Args:
        path_zip: Path to the zipfile
        destination: Destination directory
    Returns:
        None
    """

    Logger.info(f"Unpacking {path_zip}")
    with zipfile.ZipFile(path_zip, "r") as f:

        msg = f"Extracting {f.namelist()} from {path_zip} to {destination}"
        Logger.debug(msg)
        f.extractall(path=destination)


def fetch_file_to_archive(name_dataset, url):
    """ Fetch a file from a URL to a compressed archive in DIR_RAW

    Args:
        name_dataset: Name of directory to store under
        url: URL to the file
    Returns:
        None
    """

    now = utc_now()

    dir_fetch = os.path.join(DIR_RAW, name_dataset, now)
    fname_fetch = "data.tar.xz"
    path_fetch = os.path.join(dir_fetch, fname_fetch)
    pyutils.create_dir(dir_fetch)

    with tempfile.TemporaryDirectory() as tempdir:

        # Fetch the sourcefile to tempdir path_source
        fname_source = url.split("/")[-1]  # pull filename from URL
        path_source = os.path.join(tempdir, fname_source)
        fetch_url_to_file(url, path_source)

        compress_file(path_source=path_source, path_destination=path_fetch)
    Logger.info(f"Wrote {path_fetch}")


def create_path_fetch(name, version=None):
    """ Create a timestamped destination path for a source

    The naming convention for fetched source archives is

    {DIR_RAW}/{name}/{timestamp}/data.tar.xz

    This function creates the directory structure and returns the full
    path to data.tar.xz

    Args:
        name: Name of the source
    Returns:
        path_fetch: Path to a tar.xz
    """

    now = utc_now()
    if version:
        ver_uscored = version.replace(".", "_")
        dir_fetch = os.path.join(DIR_RAW, name, ver_uscored, now)
    else:
        dir_fetch = os.path.join(DIR_RAW, name, now)
    fname_fetch = "data.tar.xz"
    path_fetch = os.path.join(dir_fetch, fname_fetch)
    pyutils.create_dir(dir_fetch)

    return path_fetch


def create_path_stream_archive(name):
    """ Create a timestamped destination path for a streaming source

    The naming convention for streaming source is

    {DIR_RAW}/{name}/{name}-{timestamp}.tar.xz

    This function creates the directory structure and returns the
    full path to {name}-{timestamp}.tar.xz

    Args:
        name: Name of source
    Returns:
        path_fetch: Path to {name}-{timestamp}.tar.xz
    """

    dir_fetch = os.path.join(DIR_RAW, name)
    fname_fetch = f"{name}-{utc_now_hour()}.tar.xz"
    pyutils.create_dir(dir_fetch)
    path_fetch = os.path.join(dir_fetch, fname_fetch)

    return path_fetch
