""" Loader for GeoPKO """

import logging

from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils, datautils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    #dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleanup GeoPKO")


def fix_columns(df):
    """ Fixes typos in column names, replaces periods for underscores. """
    df = df.rename(columns=lambda x: x.lower()).rename_axis(None)
    df = df.rename(columns=lambda x: x.replace("y.", "y")).rename_axis(None)
    df = df.rename(columns=lambda x: x.replace("..", "_")).rename_axis(None)
    df = df.rename(columns=lambda x: x.replace(".", "_")).rename_axis(None)
    return df


def fix_dtypes(df):
    """ Fixes mixed data types for specified columns. """
    for column in df.columns:
        if (df[column] == "unknown").any():
            if "name" not in column:
                df = df.replace({column: {"unknown": None}})
                df = df.replace({column: {"unkown": None}})  # Also a typo here
                df[column] = df[column].astype("float64")

    for column in df.columns:
        if (df[column] == "?").any():
            df = df.replace({column: {"?": 0}})
            df[column] = df[column].astype("float64")
    return df


def fill_forwards(df, varlist=False):
    """ Fill missing values by forwards then backwards filling, by group """

    # If no varlist is passed use all columns
    if not varlist:
        varlist = list(df.columns)

    datautils.assert_df_has_multiindex(df)
    df.sort_index(inplace=True)
    # group by groupvar and forward fill then backward fill
    df[varlist] = df[varlist].groupby(level=1).fillna(method="ffill")
    return df


def interpolate_geopko(spec, pgm=False):
    """ Interpolate fqtable_staged into fqtable_interpolated.
    Altered column names at staging in the case of pgm."""

    Logger.info(f"Starting interpolation for {spec['name']}")
    timevar = spec["timevar"]
    groupvar = spec["groupvar"]
    ids = [timevar, groupvar]
    if pgm:
        cols = spec["cols_interpolate"] + [spec["loa_id"]]
    else:
        cols = spec["cols_data"] + [spec["loa_id"]]

    df = dbutils.db_to_df(fqtable=spec["fqtable_staged"], ids=ids, columns=cols)

    if spec["interpolate_method"] == "linear":
        df = datautils.interpolate(df)
    elif spec["interpolate_method"] == "fill":
        df = fill_forwards(df)

    # Fill unobserved with 0.
    df = df.fillna(0)

    dbutils.df_to_db(df=df, fqtable=spec["fqtable_interpolated"])
    dbutils.create_table_index(
        fqtable=spec["fqtable_interpolated"], cols=[spec["loa_id"]], unique=True
    )
    Logger.info(f"Finished interpolation for {spec['name']}")


def load_geopko():
    """ Load GeoPKO """

    Logger.info("Starting GeoPKO import")

    dbutils.recreate_schema("geopko")

    # Using the cm specfile as the baseline for raw here.
    spec = utils.load_specfile("geopko_cm")
    df = utils.load_df_from_only_csv_in_tar(
        path_tar=utils.path_to_latest_archive("geopko_cm")
    )
    # Some cleanup and push raw.
    df = fix_columns(df)
    df = fix_dtypes(df)
    df = df.set_index(spec["ids_raw"])
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])

    # Stage to cm level.
    utils.stage_data(spec)
    interpolate_geopko(spec)
    _cleanup(spec)

    # Stage to pgm level.
    spec = utils.load_specfile("geopko_pgm")
    utils.stage_data(spec)
    interpolate_geopko(spec, pgm=True)
    _cleanup(spec)

    Logger.info("Finished GeoPKO (cm, pgm) import")


if __name__ == "__main__":
    load_geopko()
