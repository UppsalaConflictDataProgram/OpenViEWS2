""" Common utilities for data sources """

import os
import logging

import yaml

Logger = logging.getLogger(__name__)


def load_specfile(name_dataset):
    """ Load the data specfile """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_spec = os.path.join(this_dir, "..", "specs", f"{name_dataset}.yaml")

    with open(path_spec, "r") as f:
        spec = yaml.safe_load(f)

    Logger.info(f"Read specfile at {path_spec}")

    return spec
