""" This module contains one fetch function for each source """

import os
import tempfile
import json
import logging

from bs4 import BeautifulSoup
import requests

from views.utils.config import CONFIG

from views.apps.data.common import utils
from views.apps.data.fetch import fetchutils
from views.apps.data.fetch import acled, ged, icgcw, pgdata

DIR_RAW = CONFIG["dirs"]["dir_data_raw"]


Logger = logging.getLogger(__name__)


def fetch_source_simply(name_dataset):
    """ Simply download the dataset by the url parameter in its spec

    Use this method for all data sources that are a simple single-file
    download.

    """
    Logger.info(f"Fetching {name_dataset}")
    spec = utils.load_specfile(name_dataset)
    fetchutils.fetch_file_to_archive(name_dataset, url=spec["url"])
    Logger.info(f"Finished fetching {name_dataset}")


def fetch_wdi():
    """ Fetch WDI data """
    fetch_source_simply("wdi")


def fetch_vdem():
    """ Fetch VDEM """
    fetch_source_simply("vdem")


def fetch_imfcomm():
    """ Fetch refugee by origin data from wb """
    fetch_source_simply("imfcomm")


def fetch_reign():
    """ Fetch REIGN data """

    def get_latest_data_url(url_report):
        html_doc = requests.get(url_report).content
        soup = BeautifulSoup(html_doc, "html5lib")
        container = soup.find("div", {"class": "post-container"})
        url_data = container.find("a", href=True)["href"]
        Logger.info(f"url_data: {url_data}")

        if not url_data.endswith(".csv"):
            raise RuntimeError(f"Reign link doesn't look like .csv {url_data}")

        return url_data

    spec = utils.load_specfile("reign")
    name_dataset = spec["name"]
    Logger.info(f"Fetching {spec['name']}")
    url_data = get_latest_data_url(url_report=spec["url_report"])
    fetchutils.fetch_file_to_archive(name_dataset=name_dataset, url=url_data)
    Logger.info(f"Finished fetching {name_dataset}")


def fetch_icgcw():
    """ Fetch International Crisis Group Crisis Watch """
    name = "icgcw"
    Logger.info(f"Fetching {name}")
    icgcw.fetch_icgcw()
    Logger.info(f"Finished fetching {name}")


def fetch_polity():
    """ Fetch polity """
    fetch_source_simply("polity")


def fetch_spei():
    """ Fetch SPEI global drought monitor

    No Selenium needed, I found the direct links.
    """

    spec = utils.load_specfile("spei")
    path_fetch = fetchutils.create_path_fetch("spei")

    with tempfile.TemporaryDirectory() as tempdir:

        # Fetch them all to tempdir
        paths = []
        for url in spec["urls"]:
            fname = url.split("/")[-1]
            path = os.path.join(tempdir, fname)
            fetchutils.fetch_url_to_file(url, path)
            paths.append(path)

        fetchutils.compress_files(paths, path_fetch)


def fetch_geopko():
    """ Fetch GeoPKO data """

    def get_latest_data_url(url_report):
        html_doc = requests.get(url_report).content
        soup = BeautifulSoup(html_doc, "html")
        container = soup.find("div", {"class": "articleText"})
        # NOTE: assuming position here.
        url_data = container.find_all("a", href=True)[2]["href"]
        url_full = "https://pcr.uu.se" + url_data
        Logger.info(f"url_full: {url_full}")

        if not url_data.endswith(".csv"):
            raise RuntimeError(f"GeoPKO link doesn't look like .csv {url_full}")

        return url_full

    spec = utils.load_specfile("geopko_cm")
    name_dataset = spec["name"]
    Logger.info(f"Fetching {spec['name']}")
    url_data = get_latest_data_url(url_report=spec["url_report"])
    fetchutils.fetch_file_to_archive(name_dataset=name_dataset, url=url_data)
    Logger.info(f"Finished fetching {name_dataset}")
