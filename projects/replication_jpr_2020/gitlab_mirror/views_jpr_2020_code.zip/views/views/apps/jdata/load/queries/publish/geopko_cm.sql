CREATE TABLE geopko.cm_staged AS
    WITH cm AS (
        SELECT cm.id AS country_month_id,
               cm.month_id,
               cm.country_id,
               c.gwcode AS gwno,
               m.month,
               m.year_id AS year
        FROM staging.country_month AS cm
             INNER JOIN staging.country AS c
                 ON c.id = cm.country_id
             INNER JOIN staging.month AS m
                 ON m.id = cm.month_id
    )
SELECT
cm.country_month_id,
cm.month_id,
cm.country_id,
SUM(geopko.no_troops::integer) AS no_troops,
MAX(geopko.rpf::integer) AS rpf,
SUM(geopko.rpf_no::integer) AS rpf_no,
MAX(geopko.res::integer) AS res,
SUM(geopko.res_no::integer) AS res_no,
MAX(geopko.fp::integer) AS fp,
SUM(geopko.fp_no::integer) AS fp_no,
MAX(geopko.unpol_dummy::integer) AS unpol_dummy,
MAX(geopko.unmo_dummy::integer) AS unmo_dummy,
MAX(geopko.no_tcc::integer) AS no_tcc
FROM cm
    LEFT JOIN ${fqtable_data_raw} AS geopko
ON geopko.gwno=cm.gwno
AND geopko.year=cm.year
AND geopko.month=cm.month
GROUP BY cm.country_month_id, cm.month_id, cm.country_id;