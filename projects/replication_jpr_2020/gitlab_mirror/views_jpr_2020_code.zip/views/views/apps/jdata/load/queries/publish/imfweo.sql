-- Query to create public table of IMF WEO data to be read into main datasets.
-- Join using isoab to IMF countrycodes.

DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE ${fqtable_staged} AS

WITH cy AS (
    SELECT cy.id AS country_year_id,
           cy.country_id,
           cy.year_id AS year,
           c.isoab
    FROM staging.country_year AS cy
         INNER JOIN staging.country AS c
            ON cy.country_id=c.id
)
SELECT
cy.country_year_id,
cy.country_id,
cy.year,
${cols_data}
FROM
cy
LEFT JOIN
${fqtable_data_raw} AS imfweo
ON cy.isoab=imfweo.iso
AND
cy.year=imfweo.year;
