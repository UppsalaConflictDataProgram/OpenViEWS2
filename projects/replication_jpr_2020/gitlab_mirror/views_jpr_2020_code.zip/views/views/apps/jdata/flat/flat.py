""" Create flat tables for loading by clients

See data/specs/flat.yaml for controls
"""
import os
import sys
import logging

from views.utils import dbutils, pyutils
from views.apps.data.load import utils

if __name__ == "__main__":
    logging.basicConfig(
        stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
    )

Logger = logging.getLogger(__name__)


def flatten():
    """ Create flattened tables as defined by specs/flat.yaml """
    Logger.info("Started flattening.")
    this_dir = os.path.dirname(os.path.abspath(__file__))
    fnames = ["cm.sql", "pgm.sql"]
    for fname in fnames:
        path = os.path.join(this_dir, fname)
        dbutils.execute_query_from_file(path)
    Logger.info("Finished flattening.")


if __name__ == "__main__":
    flatten()
