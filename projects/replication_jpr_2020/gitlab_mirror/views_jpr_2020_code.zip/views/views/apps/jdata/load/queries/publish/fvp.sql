DROP TABLE IF EXISTS ${fqtable_staged};
CREATE TABLE fvp.cy_staged AS
WITH cy AS (
    SELECT cy.id      AS country_year_id,
           cy.country_id,
           cy.year_id AS year,
           c.gwcode   AS gwno
    FROM staging.country_year AS cy
             INNER JOIN staging.country AS c
                        ON cy.country_id = c.id
)
SELECT cy.country_year_id,
       cy.country_id,
       cy.year,
       ${cols_data}
FROM cy
         LEFT JOIN fvp.raw AS fvp
                   ON cy.gwno = fvp.gwno
                       AND
                      cy.year = fvp.year;
