CREATE TABLE reign.cm_staged AS
    WITH cm AS (
        SELECT cm.id AS country_month_id,
               cm.month_id,
               cm.country_id,
               c.gwcode AS gwno,
               m.month,
               m.year_id AS year
        FROM staging.country_month AS cm
             INNER JOIN staging.country AS c
                 ON c.id = cm.country_id
             INNER JOIN staging.month AS m
                 ON m.id = cm.month_id
    )
SELECT
cm.country_month_id,
cm.month_id,
cm.country_id,
elected,
age,
male,
militarycareer,
tenure_months,
anticipation,
ref_ant,
leg_ant,
exec_ant,
irreg_lead_ant,
election_now,
election_recent,
leg_recent,
exec_recent,
lead_recent,
ref_recent,
direct_recent,
indirect_recent,
victory_recent,
defeat_recent,
change_recent,
nochange_recent,
delayed,
lastelection,
loss,
irregular,
prev_conflict,
pt_suc,
pt_attempt,
precip,
couprisk,
pctile_risk,
gov_dominant_party,
gov_foreign_occupied,
gov_indirect_military,
gov_military,
gov_military_personal,
gov_monarchy,
gov_oligarchy,
gov_parliamentary_democracy,
gov_party_military,
gov_party_personal,
gov_party_personal_military_hybrid,
gov_personal_dictatorship,
gov_presidential_democracy,
gov_provisional_civilian,
gov_provisional_military,
gov_warlordism
FROM cm
    LEFT JOIN reign.raw AS reign
ON reign.ccode=cm.gwno
AND reign.year=cm.year
AND reign.month=cm.month;