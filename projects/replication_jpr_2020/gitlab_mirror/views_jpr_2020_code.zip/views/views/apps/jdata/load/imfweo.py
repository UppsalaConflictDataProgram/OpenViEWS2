""" Loader for biannual IMF WEO reports """

import logging
import pandas as pd

from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    #dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleanup IMF WEO")


def fix_columns(df):
    """ Fixes typos in column names, replaces periods for underscores. """
    df = df.rename(columns=lambda x: x.lower()).rename_axis(None)
    df = df.rename(columns=lambda x: "_".join(x.split(" ")))
    df = df.rename(columns=lambda x: x.replace("-", "_"))
    df = df.rename(columns=lambda x: x.replace("/", "_"))
    return df


def fix_dtypes(df):
    """ Fixes dtypes. """
    df = df.apply(lambda x: pd.to_numeric(x, downcast="float"))
    timevar = df.index.get_level_values(0).astype(int)
    groupvar = df.index.get_level_values(1).astype(str)
    df.index = [timevar, groupvar]
    return df


def fix_typos(df):
    """ Fixes for typos in the data. """
    df = df.replace("--", None)
    df = df.apply(lambda x: x.str.strip('"'))
    df = df.apply(lambda x: x.str.replace(',', ''))
    return df


def load_imfweo():
    """ Load latest IMF WEO """
    Logger.info("Starting IMF WEO import")
    dbutils.recreate_schema("imfweo")
    spec = utils.load_specfile("imfweo")
    df = utils.load_df_from_only_xls_in_tar(
        path_tar=utils.path_to_latest_archive("imfweo")
    )
    # Some cleanup and push raw.
    df = fix_columns(df)
    df = df[df["iso"].notna()]

    # Subset, melt, and unstack.
    yearcols = list(df.columns[9:-1])
    cols = ["iso", "weo_subject_code"] + yearcols
    df = df[cols]
    df = (df.melt(['iso', 'weo_subject_code'], var_name='year')
        .set_index(['year', 'iso', 'weo_subject_code'])['value']
        .unstack())

    # Lower the columns again.
    df = df.rename(columns=lambda x: x.lower())

    # Remove data typos.
    Logger.info("Fixing typos in the data. New ones may arise.")
    df = fix_typos(df)

    # Fix dtypes.
    df = fix_dtypes(df)

    # Push to raw.
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])

    # Stage to cm level.
    utils.stage_data(spec)
    utils.interpolate_data(spec)
    _cleanup(spec)

    Logger.info("Finished IMF WEO cy import")


if __name__ == "__main__":
    load_imfweo()
