""" Loader for REIGN """

import logging

import pandas as pd

from views.apps.jdata.load import utils
from views.utils import dbutils, pyutils

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.INFO)

Logger = logging.getLogger(__name__)


def _cleanup(spec):
    dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleanup up REIGN")


def fix_ccodes(df, spec):
    """ Fix country codes as defined by spec ccode_replaces """
    Logger.info("Fixing ccodes")
    fixes = spec["ccode_replaces"]
    for fix_name, values in fixes.items():
        old = values["old"]
        new = values["new"]
        df.loc[df.ccode == values["old"], "ccode"] = values["new"]
        Logger.debug(f"Replaced ccode {old} with {new} for {fix_name}")

    Logger.info("Dropping duplicate country-months for leadership changes.")
    dropdup_cols = ["ccode", "year", "month"]
    # Some messages are too big even for debug...
    # msg = df[df.duplicated(subset=dropdup_cols, keep=False)].to_string()
    # Logger.debug(msg)
    df = df.sort_values("tenure_months")
    len_df_predrop = len(df)
    df = df.drop_duplicates(subset=dropdup_cols, keep="first")
    len_df_postdrop = len(df)

    Logger.info(f"Dropped {len_df_predrop - len_df_postdrop} duplicate obs")

    return df


def encode_govt_dummies(df):
    """ Encode government dummies """
    Logger.info("Encoding reign government dummies")

    def cleanup_govtype_name(name):
        """ Remove " ", "-", "/" from government type strings """
        name = name.lower()
        name = name.replace(" ", "_").replace("-", "_").replace("/", "_")
        name = name.replace("__", "_").replace("__", "_")
        return name

    df["government"] = df["government"].apply(cleanup_govtype_name)
    df_gov = pd.get_dummies(df["government"], prefix="gov")
    Logger.info(f"Adding dummy cols {list(df_gov.columns)}")
    df = df.join(df_gov)
    return df


def load_reign():
    """ Load REIGN """

    Logger.info("Starting REIGN import")

    dbutils.recreate_schema("reign")
    spec = utils.load_specfile("reign")
    df = utils.load_df_from_only_csv_in_tar(
        path_tar=utils.path_to_latest_archive("reign")
    )
    df = fix_ccodes(df, spec)
    df = df.set_index(spec["ids_raw"])
    df = encode_govt_dummies(df)
    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])
    utils.stage_data(spec)
    utils.interpolate_data(spec)
    # utils.impute_data(spec)
    _cleanup(spec)

    Logger.info("Finished REIGN import")


if __name__ == "__main__":
    load_reign()
