CREATE TABLE geopko.pgm_staged AS
    WITH pgm AS (
        SELECT pgm.id as pg_month_id,
               pgm.month_id,
               pgm.priogrid_gid as pg_id,
               m.month,
               m.year_id AS year
        FROM staging.priogrid_month AS pgm
             INNER JOIN staging.month AS m
                 ON m.id = pgm.month_id
    )
SELECT
pgm.pg_month_id,
pgm.month_id,
pgm.pg_id,
SUM(geopko.no_troops::integer) AS no_troops,
MAX(geopko.rpf::integer) AS rpf,
SUM(geopko.rpf_no::integer) AS rpf_no,
MAX(geopko.res::integer) AS res,
SUM(geopko.res_no::integer) AS res_no,
MAX(geopko.fp::integer) AS fp,
SUM(geopko.fp_no::integer) AS fp_no,
MAX(geopko.unpol_dummy::integer) AS unpol_dummy,
MAX(geopko.unmo_dummy::integer) AS unmo_dummy,
MAX(CASE WHEN hq=1 THEN 1 ELSE 0 END) AS tcc_hq,
MAX(CASE WHEN hq=2 THEN 1 ELSE 0 END) AS sector_hq,
MAX(CASE WHEN hq=3 THEN 1 ELSE 0 END) AS mission_hq,
MAX(geopko.lo::integer) AS lo,
MAX(geopko.no_tcc::integer) AS no_tcc
FROM pgm
    LEFT JOIN ${fqtable_data_raw} AS geopko
ON geopko.prioid=pgm.pg_id
AND geopko.year=pgm.year
AND geopko.month=pgm.month
GROUP BY pgm.pg_month_id, pgm.month_id,
pgm.pg_id;