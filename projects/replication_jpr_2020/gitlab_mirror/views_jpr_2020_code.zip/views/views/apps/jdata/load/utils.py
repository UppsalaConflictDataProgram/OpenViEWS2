""" Data loader utilities """

import os
import tempfile
import logging
import string
import subprocess
import json
import yaml
import pandas as pd

from views.apps.data.fetch import fetchutils
from views.apps.impute import impute
from views.utils import dbutils, datautils, config

Logger = logging.getLogger(__name__)


def invoke_shp2pgsql(fqtable, path_shp, srid=4326):
    """ Push shapefile to db table

    I tried a few wrappers on geopandas and geoalchemy but why
    reinvent the wheel?

    @TODO: Rewrite using shell=False and subprocess pipes
    """
    psql_string = config.CONFIG["db"]["psql_string"]
    cmd = f"shp2pgsql -D -s {srid} -I {path_shp} {fqtable} | {psql_string}"
    result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    Logger.info(f"shp2pgsql output: {result}")

    schema, _ = dbutils.unpack_fqtable(fqtable)

    # Raise if we didn't push successfully
    if not fqtable in dbutils.list_tables_in_schema(schema):
        msg = (
            "Something wen't wrong with shp2pgsql, is it installed? "
            "Is your psql_string set correctly in your config file?"
        )
        raise RuntimeError(msg)


def impute_data(spec):
    """ Impute data according to spec
    @TODO: Finish docstring
    """

    Logger.info(f"Starting imputation for {spec['name']}")

    workers = {"amelia": impute.impute_amelia, "mice": impute.impute_mice}

    timevar, groupvar = spec["timevar"], spec["groupvar"]

    Logger.info(f"Found {len(spec['impute'].keys())} imputation specs.")

    for name_impute, spec_impute in spec["impute"].items():

        Logger.info(f"Starting impute called {name_impute}")

        # Select a worker, Amelia or MICE
        worker = workers[spec_impute["worker"]]
        Logger.info(f"Using worker {worker.__name__}")

        fqtable_in = spec_impute["fqtable_in"]
        fqtables_out = spec_impute["fqtables_out"]

        Logger.info(f"fqtable_in: {fqtable_in}")
        Logger.info(f"fqtables_out: {fqtables_out}")

        # Do the work
        df = dbutils.db_to_df(fqtable=fqtable_in, ids=[timevar, groupvar])
        dfs = worker(df=df, n_imp=len(fqtables_out))

        # Push results to db
        for df_imputed, fqtable_out in zip(dfs, fqtables_out):
            dbutils.df_to_db(df=df_imputed, fqtable=fqtable_out)
            # Build loa_id indices so joining them to flat is faster
            dbutils.create_table_index(
                fqtable_out, [spec["loa_id"]], unique=True
            )

        Logger.info(f"Finished impute called {name_impute}")

    Logger.info(f"Finished imputing {spec['name']}")


def interpolate_data(spec):
    """ Interpolate fqtable_staged into fqtable_interpolated """

    Logger.info(f"Starting interpolation for {spec['name']}")
    timevar = spec["timevar"]
    groupvar = spec["groupvar"]
    ids = [timevar, groupvar]
    cols = spec["cols_data"] + [spec["loa_id"]]

    df = dbutils.db_to_df(fqtable=spec["fqtable_staged"], ids=ids, columns=cols)

    if spec["interpolate_method"] == "linear":
        df = datautils.interpolate(df)
    elif spec["interpolate_method"] == "fill":
        df = datautils.fill_forwards_backwards(df)

    dbutils.df_to_db(
        df=df,
        fqtable=spec["fqtable_interpolated"],
        drop_cascade=True
    )
    dbutils.create_table_index(
        fqtable=spec["fqtable_interpolated"], cols=[spec["loa_id"]], unique=True
    )
    Logger.info(f"Finished interpolation for {spec['name']}")


def stage_data(spec):
    """ Stage data

    @TODO: Finish docstring
    """

    name_dataset = spec["name"]
    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_template = os.path.join(
        this_dir, "queries", "publish", f"{name_dataset}.sql"
    )
    with open(path_template, "r") as f:
        template_str = f.read()

    query_col_list = ",\n".join(spec["cols_data"])

    template = string.Template(template_str)
    values = {
        "cols_data": query_col_list,
        "fqtable_staged": spec["fqtable_staged"],
        "fqtable_data_raw": spec["fqtable_data_raw"],
    }
    query = template.substitute(values)

    dbutils.execute_query(query)
    dbutils.create_table_index(
        fqtable=spec["fqtable_staged"], cols=[spec["loa_id"]], unique=True
    )

    Logger.info(f"Created table {spec['fqtable_staged']}")


def load_specfile(name_dataset):
    """ Load a specfile for the specs dir """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    path_spec = os.path.join(this_dir, "..", "specs", f"{name_dataset}.yaml")

    with open(path_spec, "r") as f:
        spec = yaml.safe_load(f)

    Logger.info(f"Read specfile at {path_spec}")

    return spec


def path_to_latest_archive(name_dataset, version=None):
    """ Get the path to data.tar.xz from the latest fetch

    @TODO: Optional arg for "latest up to timestamp" to get older

    Args:
        name_dataset: name_dataset for the data, e.g. "wdi" or "vdem"
    Returns:
        path_latest: Path to latest data.tar.xz for the dataset
     """

    Logger.info(f"Finding latest fetch of {name_dataset}")

    dir_data_raw = config.CONFIG["dirs"]["dir_data_raw"]

    if version:
        ver_uscored = version.replace(".", "_")
        dir_fetch = os.path.join(dir_data_raw, name_dataset, ver_uscored)
    else:
        dir_fetch = os.path.join(dir_data_raw, name_dataset)

    with os.scandir(dir_fetch) as entries:
        paths = (entry.path for entry in entries)
        subdir_latest = sorted(paths).pop()

    path_latest = os.path.join(subdir_latest, "data.tar.xz")

    if not os.path.isfile(path_latest):
        raise RuntimeError(f"{path_latest} doesn't exist, fetch failed?")

    Logger.info(f"Found {path_latest}")

    return path_latest


def load_df_from_only_csv_in_tar(path_tar):
    """ Load a dataframe from the only .csv file in a .tar """

    Logger.info(f"Reading any .csv from {path_tar}")

    with tempfile.TemporaryDirectory() as tempdir:

        fetchutils.extract_all_files(
            path_archive=path_tar, dir_destination=tempdir
        )

        path_csv = False
        for root, _, files in os.walk(tempdir):
            for fname in files:
                print(fname)
                if fname.endswith(".csv"):
                    path_csv = os.path.join(root, fname)
                    break

        if path_csv:
            fname = os.path.basename(path_csv)
            Logger.info(f"Read {fname} from {path_tar}")
            df = pd.read_csv(path_csv, low_memory=False)
        else:
            msg = f"No .csv found in {path_tar} contents."
            raise RuntimeError(msg)

    return df


def load_df_from_only_xls_in_tar(path_tar):
    """ Load a dataframe from the only .xls(x) file in a .tar """

    Logger.info(f"Reading any .xls(x) from {path_tar}")

    with tempfile.TemporaryDirectory() as tempdir:

        fetchutils.extract_all_files(
            path_archive=path_tar, dir_destination=tempdir
        )

        path_xls = False
        for root, dirs, files in os.walk(tempdir):
            for fname in files:
                print(fname)
                if fname.endswith(".xlsx") or fname.endswith(".xls"):
                    path_xls = os.path.join(root, fname)
                    break

        if path_xls:
            fname = os.path.basename(path_xls)
            Logger.info(f"Read {fname} from {path_tar}")
            df = pd.read_excel(path_xls)
        else:
            msg = f"No .xls(x) found in {path_tar} contents."
            raise RuntimeError(msg)

    return df


def load_df_from_csv_in_zip_in_tar(path_tar, name_zip, name_csv):
    """ Get a dataframe from a csv in a zip in a tar """

    Logger.info(f"Reading {name_csv} from {name_zip} in {path_tar}")

    with tempfile.TemporaryDirectory() as tempdir:

        # Extract the zip from the .tar.xz
        path_zip = fetchutils.extract_file(
            path_archive=path_tar, filename=name_zip, dir_destination=tempdir
        )
        # Unpack the zip
        fetchutils.unpack_zipfile(path_zip=path_zip, destination=tempdir)

        # Get the path to the .csv that we unpacked
        path_csv = False
        for root, _, files in os.walk(tempdir):
            for fname in files:
                if fname == name_csv:
                    path_csv = os.path.join(root, fname)
                    break

        if path_csv:
            df = pd.read_csv(path_csv, low_memory=False)
        else:
            msg = f"{name_csv} wasn't found in the zip contents. "
            raise RuntimeError(msg)

        Logger.info(f"Read {name_csv} from {name_zip} in {path_tar}")

    return df


def do_recodes(df, recodes):
    """ Recode values in df based on recodes dict

    Recodes is a dict of form:

    colname:
        oldvalue1: newvalue1
        oldvalue2: newvalue2

    Args:
        df: Dataframe
        recodes: Dict of colname: {oldvalue: newvalue} nested dict
    Returns:
        df: Recoded dataframe

    """
    for colname, recode in recodes.items():
        Logger.debug(f"Recoding {colname} with {json.dumps(recode)}")
        df[colname] = df[colname].replace(recode)
    return df
