""" Fetch module for fetching raw sources """
import argparse
import sys
import logging
import multiprocessing as mp

from views.utils import pyutils
from views.apps.jdata.common import utils
from views.apps.jdata.fetch import sources
from views.utils.config import CONFIG

DIR_RAW = CONFIG["dirs"]["dir_data_raw"]

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.INFO
)
Logger = logging.getLogger(__name__)


def fetch_all_from_args():
    """ True if --all passed as command line arg """

    parser = argparse.ArgumentParser()
    parser.add_argument("--all", action="store_true", help="Fetch all sources")

    args = parser.parse_args()
    fetch_all = args.all

    return fetch_all


def fetch_source(source_name):
    """ Fetch source """

    # Source-name -> fetcher function mapping
    funcs = {
        "wdi": sources.fetch_wdi,
        "reign": sources.fetch_reign,
        "icgcw": sources.fetch_icgcw,
        "polity": sources.fetch_polity,
        "spei": sources.fetch_spei,
        "imfcomm": sources.fetch_imfcomm,
        "vdem": sources.fetch_vdem,
        "geopko": sources.fetch_geopko
    }
    Logger.info(f"Started fetching {source_name}")
    # Run the func for source_name
    funcs[source_name]()
    Logger.info(f"Finished fetching {source_name}")


def fetch_sources(sources_to_fetch):

    n_sources = len(sources_to_fetch)
    Logger.info(f"Started fetching {n_sources} sources")
    with mp.Pool(processes=n_sources, maxtasksperchild=1) as pool:
        responses = []
        for source_name in sources_to_fetch:
            responses.append(pool.apply_async(fetch_source, (source_name,)))

        for response in responses:
            response.get()

    Logger.info(f"Finished fetching {n_sources} sources.")


def sources_monthly():
    return utils.load_specfile("fetch")["sources"]["monthly"]


def sources_all():
    return utils.load_specfile("fetch")["sources"]["all"]


def fetch_all_sources():
    Logger.info(f"Fetching all sources")
    fetch_sources(sources_all())


def fetch_monthly_sources():
    Logger.info(f"Fetching monthly sources")
    fetch_sources(sources_monthly())


def main():
    """ Fetches all the latest sources to disk """

    pyutils.create_dir(DIR_RAW)

    # If --all passed, get the "all" list of sources to fetch
    if fetch_all_from_args():
        fetch_all_sources()
    # Else default to just the monthly sources
    else:
        fetch_monthly_sources()



if __name__ == "__main__":

    main()
