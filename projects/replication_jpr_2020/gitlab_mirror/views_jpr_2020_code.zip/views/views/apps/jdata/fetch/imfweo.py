"""IMF World Economic Outlook fetcher. Separate from the IMF API as these
are provided separately as .xls."""

# @TODO(Remco): Move commented out columns to meta table.
# @TODO(Remco): General rewrite and cleanup.

import logging
import datetime
import sys
import os
import tempfile
import io
from pathlib import Path
import pandas as pd
import requests
from xlwt import Workbook

from views.utils import pyutils
from views.apps.data.fetch import fetchutils
from views.utils.config import CONFIG
from views.apps.jdata.load import utils

DIR_RAW = CONFIG["dirs"]["dir_data_raw"]

logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.INFO
)

Logger = logging.getLogger(__name__)


def utc_now():
    """ Get the current UTC time as 20180101-133759"""
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")


def build_weo_data(date):
    """WEO is a particular case of 2 datasets provided as Excel files.
    Its URL changes according to the release date.
    """
    if date.month < 4:
        year = date.year - 1
        release_number = "02"
        file_base_name = f"WEOOct{year}all"
    elif date.month >= 4 and date.month < 10:
        year = date.year
        release_number = "01"
        file_base_name = f"WEOApr{year}all"
    else:
        assert date.month >= 10, date
        year = date.year
        release_number = "02"
        file_base_name = f"WEOOct{year}all"

    return (year, release_number, file_base_name)


def build_weo_url(date):
    """Build the WEO code and URL."""
    year, release_number, file_base_name = build_weo_data(date)
    base_url = f"https://www.imf.org/external/pubs/ft/weo/{year}/{release_number}/weodata/"
    dataset_url = f"{base_url}{file_base_name}.xls"
    return file_base_name, dataset_url


def convert_weo_datasets(path_source, tempdir, filename):
    """Restore xls file. For some reason it comes broken."""
    file = io.open(path_source, "r", encoding="utf-8")
    data = file.readlines()
    xldoc = Workbook()
    sheet = xldoc.add_sheet("Sheet1", cell_overwrite_ok=True)
    for i, row in enumerate(data):
        # Removing the '\n' which comes while reading the file using io.open
        # Getting the values after splitting using '\t'
        for j, val in enumerate(row.replace('\n', '').split('\t')):
            sheet.write(i, j, val)
    xldoc.save(os.path.join(tempdir, filename))
    Logger.info(f"Wrote {os.path.join(tempdir, filename)}")


def archive_weo(path_source, out_dir):
    """Archive restored xls file."""
    now = utc_now()
    dir_fetch = os.path.join(DIR_RAW, out_dir, now)
    fname_fetch = "data.tar.xz"
    path_fetch = os.path.join(dir_fetch, fname_fetch)
    pyutils.create_dir(dir_fetch)
    fetchutils.compress_file(
        path_source=path_source,
        path_destination=path_fetch
    )
    Logger.info(f"Wrote {path_fetch}")

    return path_fetch


def fetch_weo_data(date):
    """Download WEO datasets."""
    file_base_name, dataset_url = build_weo_url(date)
    file_base_name = f"{file_base_name}.xls"
    dataset_code = "imfweo"
    Logger.info("Fetching %r - %s", dataset_code, dataset_url)

    with tempfile.TemporaryDirectory() as tempdir:
        weo_response = requests.get(dataset_url)
        weo_xls_file = os.path.join(tempdir, dataset_code + ".xls")
        weo_xls_file = Path(weo_xls_file)
        with weo_xls_file.open("wt", encoding="utf-8") as f:
            f.write(weo_response.content.decode("latin1"))
        # Remove if bad content. @TODO(Remco): May be redundant.
        if weo_xls_file.stat().st_size < 50 * 1024:
            if "<br />" in weo_xls_file.read_text(
                encoding="utf-8"
            ):
                Logger.info("Bad HTML content, removing file.")
                weo_xls_file.unlink()
        else:
            # Convert text to properly functioning xls.
            convert_weo_datasets(weo_xls_file, tempdir, file_base_name)
            path_fetch = archive_weo(os.path.join(tempdir, file_base_name),
                                     "imfweo")

            return path_fetch


def build_dict(df, date):
    """Builds row dictionaries for IMF WEO historic forecasts data."""
    # Drop NA
    df = df[df['ISO'].notna()]
    # Set up year and month.
    try:
        previous_y = df[str(date.year - 1)]
    except KeyError:
        previous_y = [None for i in df["ISO"]]

    try:
        next_y = df[str(date.year + 1)]
    except KeyError:
        next_y = [None for i in df["ISO"]]

    try:
        next_y2 = df[str(date.year + 2)]
    except KeyError:
        next_y2 = [None for i in df["ISO"]]

    report = {
        "year": [date.year for i in df["ISO"]],
        "month": [date.month for i in df["ISO"]],
        "iso": df["ISO"],
        #"country": df["Country"],
        "subject": df["WEO Subject Code"],
        #"subject_descriptor": df["Subject Descriptor"],
        #"subject_note": df["Subject Notes"],
        #"unit": df["Units"],
        "tmin1": previous_y,
        "tcurrent": df[str(date.year)],
        "tplus1": next_y,
        "tplus2": next_y2,
    }
    return report


def cleanup_weohist(df, cols):
    """Fix typos and dtypes."""
    df = df.replace("--", None)
    df[cols] = df[cols].apply(lambda x: x.str.strip("'"))
    df[cols] = df[cols].apply(lambda x: x.str.strip('"'))
    df[cols] = df[cols].apply(lambda x: x.str.replace(',', ''))
    df[cols] = df[cols].astype(float)
    return df


def build():
    """Gets all historic IMF WEO publications available since October 2007.
    Buils historic IMF WEO forecasts dataset."""
    # Set up empty dataframe.
    historic = pd.DataFrame(
        columns=[
            "year",
            "month",
            "iso",
            #"country",
            "subject",
            #"subject_descriptor", move to meta
            #"subject_note", move to meta
            #"unit",
            "tmin1",
            "tcurrent",
            "tplus1",
            "tplus2"
        ]
    )
    # Set up fetch.
    Logger.info("Getting all available IMF WEO publications.")
    year = datetime.date.today().year
    startdate = datetime.date(2007, 10, 1)
    iterations = year - startdate.year
    #iterations = 1 # testing.

    for i in range(0, iterations + 1):
        delta = datetime.timedelta(days=i * 365)
        # Get April's publication.
        if i > 0:
            april = datetime.date(startdate.year, 5, 20) + delta
            try:
                path_tar = fetch_weo_data(april)
                df = utils.load_df_from_only_xls_in_tar(path_tar)
                row = build_dict(df, april)
                historic_sub = pd.DataFrame(row)
                historic = historic.append(
                    historic_sub,
                    ignore_index=True,
                    sort=False
                )
            except ValueError:
                pass
        # Get October's publication.
        october = datetime.date(startdate.year, 10, 20) + delta
        try:
            path_tar = fetch_weo_data(october)
            df = utils.load_df_from_only_xls_in_tar(path_tar)
            row = build_dict(df, october)
            historic_sub = pd.DataFrame(row)
            historic = historic.append(
                historic_sub,
                ignore_index=True,
                sort=False
            )
        except ValueError:
            pass

    # Clean up.
    values = ["tmin1", "tcurrent", "tplus1", "tplus2"]
    historic = cleanup_weohist(historic, values)

    # Pivot the data for all categories.
    historic = historic.pivot_table(
        index=["year", "month", "iso"],
        columns=["subject"],
        values=values
    )

    # Rename columns according to upper level.
    cols = ["_".join(reversed(col)).lower() for col in historic.columns.values]
    historic.columns = cols

    with tempfile.TemporaryDirectory() as tempdir:
        historic.to_csv(os.path.join(tempdir, "imfweo_hist.csv"))
        archive_weo(os.path.join(tempdir, "imfweo_hist.csv"),
                    "imfweo_hist")


if __name__ == "__main__":
    build()
