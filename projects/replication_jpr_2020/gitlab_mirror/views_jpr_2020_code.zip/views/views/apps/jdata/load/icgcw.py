""" International Crisis Group - Crisis Watch loader """
import logging
import re
import tempfile
import os
import sys

import joblib
import pandas as pd
from bs4 import BeautifulSoup

from views.apps.jdata.load import utils
from views.apps.jdata.fetch import fetchutils
from views.utils import dbutils, pyutils, datautils


if __name__ == "__main__":
    logging.basicConfig(
        stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
    )


Logger = logging.getLogger(__name__)


def _cleanup(spec):
    dbutils.drop_table(spec["fqtable_data_raw"])
    dbutils.drop_table(spec["fqtable_staged"])
    Logger.info("Cleaned up ICGCW")


def parse_page(path):
    """ CrisisWatch parser using bs4. Appends to dataframe and returns df """

    # get source document
    with open(path, "r", encoding="utf-8") as f:
        html_doc = f.read()
    soup = BeautifulSoup(html_doc, "html.parser")

    # loop over blocks
    search = {
        "class": "c-crisiswatch-entry [ o-container o-container--m u-pr ]"
    }
    entries = []
    for block in soup.find_all("div", search):
        # remove whitespace titles
        countryname = block.find("h3").text
        # remove unnecessary spacing

        # countryname = re.sub("^\s+|\s+$", "", countryname, flags=re.UNICODE)
        countryname = re.sub(r"^s+|s+$", "", countryname, flags=re.UNICODE)
        countryname = countryname.strip()
        entrydate = block.find("time").text
        # entries may have no text, so adding a try here
        try:
            cls_tag = {"class": "o-crisis-states__detail [ u-ptserif u-fs18 ]"}
            entrytext = block.find("div", cls_tag).text
            entrytext = entrytext.replace("\n\t", "")
        except:
            entrytext = ""
        # prepare dummies using list
        tblock = block.find("h3")
        updates = [update for update in tblock.find_all("use")]
        deteriorated = 1 if "#deteriorated" in str(updates) else 0
        improved = 1 if "#improved" in str(updates) else 0
        alert = 1 if "#risk-alert" in str(updates) else 0
        resolution = 1 if "#resolution" in str(updates) else 0
        unobserved = 0
        entry_data = {
            "date": entrydate,
            "name": countryname,
            "alerts": alert,
            "opportunities": resolution,
            "deteriorated": deteriorated,
            "improved": improved,
            "unobserved": unobserved,
            "text": entrytext,
        }
        entries.append(entry_data)

    Logger.debug(f"Read {len(entries)} entries from {path}")
    return entries


def parse_entries(path_tar, parallel=False):
    """ Parse all entries in path_tar """

    with tempfile.TemporaryDirectory() as tempdir:
        fetchutils.extract_all_files(
            path_archive=path_tar, dir_destination=tempdir
        )

        paths = []
        for root, _, files in os.walk(tempdir):
            for fname in files:
                path = os.path.join(root, fname)
                if fname.endswith(".html"):
                    paths.append(path)
                else:
                    msg = (
                        f"Found a file that wasn't .html. "
                        f"something broke for: {path}"
                    )
                    raise RuntimeError(msg)

        Logger.info(f"Found {len(paths)} files to parse")

        if parallel:
            Logger.info(f"Parsing {len(paths)} files in parallel")
            parsed_pages = joblib.Parallel(n_jobs=-1, verbose=10)(
                joblib.delayed(parse_page)(path) for path in paths
            )
        else:
            Logger.info(f"Parsing {len(paths)} files in sequence")
            parsed_pages = list(map(parse_page, sorted(paths)))
        parsed_entries = pyutils.flatten_list(parsed_pages)

    return parsed_entries


def do_renames(entries, spec):
    """ Do renames in spec["cname_fixes"] """

    for rename in spec["cname_fixes"]:
        old = rename["old"]
        new = rename["new"]
        count = 0
        for entry in entries:
            if entry["name"] == old:
                entry["name"] = new
                count = count + 1
        Logger.debug(f"Renamed {count} {old} to {new}.")

    return entries


def drop_unnamed_entries(entries):
    """ Drop entries that have empty name """

    def nonempty_name(entry):
        """ True if name not empty """
        if not entry["name"] == "":
            has_name = True
        else:
            has_name = False
            msg = f"Empty name in {entry}"
            Logger.debug(msg)
        return has_name

    len_predrop = len(entries)
    entries = list(filter(nonempty_name, entries))
    len_postdrop = len(entries)
    msg = f"Dropped {len_predrop - len_postdrop} entries for empty name"
    Logger.debug(msg)

    return entries


def drop_drops(entries, spec):
    """ Drop entries as by spec['drops'] """

    entries_wo_drops = [
        entry for entry in entries if not entry["name"] in spec["drops"]
    ]

    msg = f"Dropped {len(entries) - len(entries_wo_drops)} entries"
    Logger.debug(msg)

    return entries_wo_drops


def split_multi_country_entries(entries):
    """ Split entries by / """

    entries_w_splits = []
    done_splits = []
    for entry in entries:
        if "/" in entry["name"]:
            done_splits.append(entry["name"])
            for country_name in entry["name"].split("/"):
                new_entry = entry.copy()
                new_entry["name"] = country_name
                entries_w_splits.append(new_entry)
        else:
            entries_w_splits.append(entry.copy())

    done_splits = pyutils.dedup_list(done_splits)
    for split in done_splits:
        Logger.debug(f"Split {split}")
    msg = f"Splitting Created {len(entries_w_splits) - len(entries)}"
    Logger.debug(msg)

    return entries_w_splits


def debug_log_unique_names(entries):
    """ Put unique entry['name']'s in debug log """

    names = []
    for entry in entries:
        if entry["name"] not in names:
            names.append(entry["name"])

    Logger.debug(f"Found {len(names)} unique names:")
    for name in sorted(names):
        Logger.debug(f"{name}")


def drop_duplicate_country_months(df):
    """ Drop duplicated country months """

    # @TODO: replace with max() of indicators during month perhaps?
    len_predrop = len(df)
    df = df.sort_values(by=["year", "month", "name"])
    df = df.drop_duplicates(subset=["year", "month", "name"], keep="first")
    len_postdrop = len(df)
    Logger.info(f"Dropped {(len_predrop - len_postdrop)} duplicates")

    return df


def set_dates(df):
    """ Set year and month columns in df from date """

    df["year"] = pd.DatetimeIndex(df.date).year  # pylint: disable=no-member
    df["month"] = pd.DatetimeIndex(df.date).month  # pylint: disable=no-member

    return df


def interpolate_icgcw(spec):
    """ Interpolate ICGCW """

    Logger.info(f"Starting interpolation for {spec['name']}")
    timevar = spec["timevar"]
    groupvar = spec["groupvar"]
    ids = [timevar, groupvar]
    cols = spec["cols_data"]
    cols = cols + [spec["loa_id"]]

    df = dbutils.db_to_df(fqtable=spec["fqtable_staged"], ids=ids, columns=cols)

    if spec["interpolate_method"] == "linear":
        df = datautils.interpolate(df)
    elif spec["interpolate_method"] == "fill":
        df = datautils.fill_forwards_backwards(df)

    # Fill unobserved with ones and all others with 0
    df["unobserved"] = df["unobserved"].fillna(1)
    df = df.fillna(0)

    dbutils.df_to_db(df=df, fqtable=spec["fqtable_interpolated"])
    dbutils.create_table_index(
        fqtable=spec["fqtable_interpolated"], cols=[spec["loa_id"]]
    )
    Logger.info(f"Finished interpolation for {spec['name']}")


def load_icgcw():
    """ Load ICGCW """
    Logger.info("Starting ICGCW import")
    dbutils.recreate_schema("icgcw")
    spec = utils.load_specfile("icgcw")

    # Get all the entries as list of dicts
    entries = parse_entries(
        path_tar=utils.path_to_latest_archive("icgcw"), parallel=True
    )
    entries = drop_unnamed_entries(entries)

    # Some renames depend on splits so we do splits twice
    entries = split_multi_country_entries(entries)
    entries = do_renames(entries, spec)
    entries = split_multi_country_entries(entries)

    entries = drop_drops(entries, spec)

    debug_log_unique_names(entries)

    df = pd.DataFrame(entries)
    df = set_dates(df)
    df = drop_duplicate_country_months(df)
    df = df.set_index(["year", "month", "name"])

    dbutils.df_to_db(df, fqtable=spec["fqtable_data_raw"])

    utils.stage_data(spec)
    interpolate_icgcw(spec)
    _cleanup(spec)
    Logger.info("Fininshed loading ICGCW")


if __name__ == "__main__":
    load_icgcw()
