""" Aggregation module

Provides functionality for aggregating across many datasets.
Typically from predictions with the same temporal scope.

Because many parts (datasets) may be aggregated across, holding them all
fully in  memory at the same time becomes unfeasible.
So we use a 3-dimensional  numpy array stored in and HDF5 file as an
intermediary.
The three dimensions are part-row-column.


"""

import os
import tempfile
import random

import joblib
import h5py
import scipy.stats as spstats
import pandas as pd
import numpy as np

from views.utils import pyutils, datautils

N_CORES = 4
CHUNKSIZE = 1024


def compute_aggregate(statistic, path_merged, colnames, index):
    """ Calculate aggregate statistic for all variables in merged array

    Args:
        statistic: a dict containing name and optionally q:
                   supported values of statistic['name']:
                        "mean", "var", "skew", "kurtosis", "pctile".
                    if statistic['name'] is "pctile" then statistic['q']
                    must also be provided

        merged: numpy-array with dimensions [nsim, row, var]
        varnames: list of variable names in the input array (merged)
        index: indexes to assign to the finished percentiles

    Returns:
        output: A pandas DataFrame containing the chosen statistic for all
                variables in the merged array
    """

    with h5py.File(path_merged, "r") as f:
        merged = f["merged"]

        # Empty placeholder
        nrows = merged.shape[1]
        nvars = merged.shape[2]
        output = np.empty((nrows, nvars))

        # Iterate over chunksize of the rows at a time
        chunksize = CHUNKSIZE
        for rows in pyutils.chunker(range(nrows), chunksize):
            progress = rows[0] / nrows
            print("progress:", statistic, "\t", "%.3f" % progress)

            if statistic["stat"] == "mean":
                output[rows, :] = np.mean(merged[:, rows, :], axis=0)

            elif statistic["stat"] == "var":
                output[rows, :] = np.var(merged[:, rows, :], axis=0)

            elif statistic["stat"] == "skew":
                output[rows, :] = spstats.skew(merged[:, rows, :], axis=0)

            elif statistic["stat"] == "kurtosis":
                output[rows, :] = spstats.kurtosis(merged[:, rows, :], axis=0)

            elif statistic["stat"] == "pct":
                output[rows, :] = np.percentile(
                    merged[:, rows, :], q=statistic["q"], axis=0
                )

    # Create the variable names
    if statistic["stat"] == "pct":
        suffix = "_pct" + str(statistic["q"])
    else:
        suffix = "_" + statistic["stat"]

    colnames = [col + suffix for col in colnames]

    output = pd.DataFrame(output, columns=colnames, index=index)
    return output


def insert_parts_into_array_file(path_merged, paths_parts):
    """ Inserts dfs from hdf5 files into 3d numpy array in hdf5 file
    Args:
        path_merged: Path to hdf5 file holding the 3d numpy array
        paths_parts: List of paths to dataframes to insert
    Returns: None
    """

    def make_shape(path_sim, n_parts):
        placeholder_df = pd.read_hdf(path_sim, key="data")
        shp = placeholder_df.values.shape
        shp = list(shp)
        shp.insert(0, n_parts)
        return shp

    def make_placeholder_file(path_merged, shape, comp, chunks):
        with h5py.File(path_merged, "w") as f:
            f.create_dataset(
                "merged",
                tuple(shape),
                dtype="float64",
                compression=comp,
                chunks=chunks,
            )

    def insert_results(path_merged, paths_parts):
        def check_cols_match(cols_previous_part, cols_this_part):
            cols_match = list(cols_this_part) == list(cols_previous_part)
            if not cols_match:
                msg = (
                    "Cols need to match between parts to be merged"
                    f"Cols this part: {cols_this_part}"
                    f"Cols previous parts: {cols_previous_part}"
                )
                raise RuntimeError(msg)

        i = 0
        first_file = True
        with h5py.File(path_merged, "a") as f:
            result = f["merged"]
            for path_sim in paths_parts:
                df = pd.read_hdf(path_sim, key="data")
                cols_this_part = df.columns
                if not first_file:
                    check_cols_match(cols_previous_part, cols_this_part)
                    first_file = False
                cols_previous_part = cols_this_part
                result[i, :, :] = np.array(df.values, dtype=np.float64)
                i += 1

    n_parts = len(paths_parts)
    path_any_sim = paths_parts[0]
    shape = make_shape(path_any_sim, n_parts)

    compression = "lzf"
    chunks = (1, shape[1], shape[2])
    make_placeholder_file(path_merged, shape, compression, chunks)
    insert_results(path_merged, paths_parts)


def aggregate(
    path_aggregated, dirs_parts, pattern, stats, random_sample_share=1.0
):
    """ Compute aggregates of files in dirs_parts

    Args:
        path_aggregated: Output hdf5 file path
        dirs_parts: Directories in which to look for parts to aggregate
        pattern: Regex pattern for filenames of parts for inclusion
        stats: List of dicts of which stats to compute
        random_sample_share: Share of parts to include
    Returns: None
    """

    def sample_paths(paths_parts, random_sample_share):
        """ Draw a random sample of paths from paths_parts """
        if random_sample_share != 1.0:
            # Check we aren't supersampling
            if random_sample_share > 1.0:
                raise RuntimeError("Supersampling doesn't make sense here")

            n_parts_wanted = int(random_sample_share * len(paths_parts))
            paths_parts = random.sample(paths_parts, k=n_parts_wanted)

        return paths_parts

    # Do all the file work in a temp directory
    with tempfile.TemporaryDirectory() as dir_merged:

        # Find all the parts in dirs_parts
        paths_parts = []
        for dir_part in dirs_parts:
            paths_parts.extend(pyutils.get_paths_from_dir(dir_part))
        # Filter them to those whose filenames match pattern
        paths_parts = list(
            filter(
                lambda path: pyutils.fname_matches_pattern(path, pattern),
                paths_parts,
            )
        )

        # Do the sampling
        paths_parts = sample_paths(paths_parts, random_sample_share)

        # Insert the parts into the 3d array on file
        path_merged = os.path.join(dir_merged, "merged.hdf5")
        insert_parts_into_array_file(path_merged, paths_parts)

        # Get the index and colnames from the first part file
        # @TODO: Make sure all the parts have identical index and colnames
        index = datautils.get_df_index_from_file(paths_parts[0])
        colnames = datautils.get_df_colnames_from_file(paths_parts[0])

        # Get the stats into list of dfs
        dfs = joblib.Parallel(n_jobs=N_CORES)(
            joblib.delayed(compute_aggregate)(
                stat, path_merged, colnames, index
            )
            for stat in stats
        )

    # Merge the dfs into a single df and write to file
    df = datautils.merge_dfs(dfs)
    df.to_hdf(path_aggregated, key="data")
    print(f"Wrote {path_aggregated}")
