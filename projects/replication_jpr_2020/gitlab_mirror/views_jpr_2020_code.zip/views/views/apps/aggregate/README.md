# Aggregate

Aggregate allows computation of aggregate statistics across many
identically shaped panels.
Suitable for computing aggregates across dynasim simulations.