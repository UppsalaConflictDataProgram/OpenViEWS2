import copy
import numpy as np
import pandas as pd
from views.apps.osa import osa
from views.utils import datautils

import logging

Logger = logging.getLogger(__name__)


def make_model_dict(
    name,
    col_actual,
    steps,
    outcome,
    features=None,
    period_names=None,
    estimator=None,
    share_ones=1.0,
    share_zeros=1.0,
):
    """ Define a model dictionary """

    model = dict()

    model["cols_ss"] = {step: f"ss.{name}.{step}" for step in steps}
    model["col_sc"] = f"sc.{name}"
    model["name"] = name
    model["col_actual"] = col_actual
    model["steps"] = steps
    model["outcome"] = outcome
    model["share_ones"] = share_ones
    model["share_zeros"] = share_zeros

    if features:
        model["features"] = features
    else:
        model["features"] = []

    # If periods and estimators passed construct period/step nested estimators dict
    if period_names and estimator is not None:
        model["estimators"] = dict()
        for period in period_names:
            model["estimators"][period] = dict()
            for step in steps:
                model["estimators"][period][step] = copy.copy(estimator)

    return model


def fit_estimators(model, df, periods):

    for period_name, period in periods.items():
        for step in model["steps"]:
            Logger.info(
                f"Fitting model {model['name']} "
                f"period: {period_name} "
                f"step: {step} "
            )
            #
            estimator = model["estimators"][period_name][step]
            estimator = osa.fit(
                df=df,
                estimator=estimator,
                outcome=model["col_actual"],
                features=model["features"],
                stepsize=step,
                t_start=period["train"]["start"],
                t_end=period["train"]["end"],
                share_ones = model["share_ones"],
                share_zeros = model["share_zeros"],
            )
            model["estimators"][period_name][step] = estimator

    return model


def predict_by_periods(model, df, periods):

    # Init empty df_pred with index and empty cols to hold predictions
    df_pred = pd.DataFrame(index=df.index)
    cols = [model["cols_ss"][step] for step in model["steps"]]
    for col in cols:
        df_pred[col] = np.nan

    for period in periods:
        for step in model["steps"]:
            estimator = model["estimators"][period][step]
            times = [
                t
                for t in range(
                    periods[period]["predict"]["start"],
                    periods[period]["predict"]["end"]
                    + 1,  # range isn't inclusive so add 1
                )
            ]
            col = model["cols_ss"][step]
            Logger.info(
                f"Predict for {model['name']} "
                f"Period: {period} "
                f"step: {step} "
                f"len(times): {len(times)}"
            )
            s_prediction = osa.predict_semt(
                df=df,
                estimator=estimator,
                steplen=step,
                colname_prediction=model["cols_ss"][step],
                features=model["features"],
                times=times,
            )
            df_pred.loc[times, col] = s_prediction.loc[times]

    # Collect all ss predictions to one sc col
    df_pred[model["col_sc"]] = compute_sc_constituent_by_periods(
        df_pred, model, periods
    )

    return df_pred


def compute_sc_constituent_by_periods(df, model, periods):
    """ Compute sc series for model from ss cols by period """

    s_sc = pd.Series(index=df.index)
    for period_name, period in periods.items():
        t_start = period["predict"]["start"]
        t_end = period["predict"]["end"]
        Logger.info(f"Making sc. prediction for {period_name} from {t_start} to {t_end}")
        for step in model["steps"]:
            t = t_start + step - 1
            s_sc.loc[t] = df.loc[t, model["cols_ss"][step]].values
        s_sc.loc[t_start:t_end] = datautils.interpolate(s_sc.loc[t_start:t_end])

    s_sc.name = model["col_sc"]

    return s_sc


def compute_sc_constituent(df, model):
    """ Compute sc series for model from ss cols.
    Assumes df is time limited to period
    """
    steps = model["steps"]
    t_start = df.index.get_level_values(0).min()

    s_sc = pd.Series(index=df.index)

    for step in steps:
        t = t_start + step - 1
        col_ss_step = model["cols_ss"][step]
        s_sc.loc[t] = df.loc[t, col_ss_step].values

    s_sc.name = model["col_sc"]
    s_sc = datautils.interpolate(s_sc)

    return s_sc
