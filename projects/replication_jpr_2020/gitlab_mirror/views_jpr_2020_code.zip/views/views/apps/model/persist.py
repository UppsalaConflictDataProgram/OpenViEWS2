""" Model persistence interface """
import os
import logging
import tempfile
import json

import joblib
import sqlalchemy

from views.utils import pyutils, dbutils, config

Logger = logging.getLogger(__name__)


def _rebuild_metadata_schema():
    path_query = os.path.join(os.path.dirname(__file__), "schema.sql")
    dbutils.execute_query_from_file(path_query)


def drop_estimator_from_db(name_estimator):
    query = f"DELETE FROM metadata.estimator WHERE name=:name;"
    dbutils.execute_query(query, **{"name": name_estimator})

def drop_model_from_db(name_model):
    query = f"DELETE FROM metadata.model WHERE name=:name;"
    dbutils.execute_query(query, **{"name": name_model})



def register_model(name_model, loa, outcome, col_outcome, cols_shift, cols_noshift):
    """ Register a model in metadata.model """
    query_insert = """
    INSERT INTO metadata.model(
        name, loa, outcome, col_outcome, cols_shift, cols_noshift)
    VALUES(
        :name,
        :loa,
        :outcome,
        :col_outcome,
        :cols_shift,
        :cols_noshift
    )
    """
    params = {
        "name": name_model,
        "loa": loa,
        "outcome": outcome,
        "col_outcome": col_outcome,
        "cols_shift": cols_shift,
        "cols_noshift": cols_noshift,
    }
    dbutils.execute_query(query_insert, **params)

    model_id = get_model_id(name_model)
    return model_id


def register_estimator(
    model_id,
    name_estimator,
    step,
    path_pickle,
    train_end,
    extras,
    overwrite,
):

    query = """
    INSERT INTO
    metadata.estimator(
        model_id,
        name,
        step,
        path_pickle,
        train_end,
        extras
    )
    VALUES(
        :model_id,
        :name,
        :step,
        :path_pickle,
        :train_end,
        :extras
    )
    """

    params = {
        "model_id": model_id,
        "name": name_estimator,
        "step": step,
        "path_pickle": path_pickle,
        "train_end": train_end,
        "extras": json.dumps(extras),
    }

    # If overwrite delete any occurence with same name if it exists
    if overwrite:
        drop_estimator_from_db(name_estimator)

    # Insert the estimator
    try:
        dbutils.execute_query(query, **params)
    # Helpful message if estimator with same name already exists
    except sqlalchemy.exc.IntegrityError:
        msg = f"Estimator named {name_estimator} already in metadata.estimators"
        Logger.error(msg)
        raise RuntimeError(f"{msg}")


def get_model_id(name_model):
    query = "SELECT id FROM metadata.model WHERE name=:name;"
    params = {"name": name_model}
    model_id = dbutils.get_query_rows(query, **params)[0]["id"]

    return model_id


def model_is_registered(name_model):
    """ True if model with name_model exists in metadata.model """
    query = "SELECT COUNT(*) AS count FROM metadata.model WHERE name=:name"
    rows = dbutils.get_query_rows(query, **{"name": name_model})
    return rows[0]["count"] > 0

def get_model_info(model_id):
    query = "SELECT * FROM metadata.model WHERE id=:id"
    params = {"id": model_id}
    return dict(dbutils.get_query_rows(query, **params)[0])

def check_model_info(model_id, outcome, col_outcome, cols_shift, cols_noshift, loa):

    info = get_model_info(model_id)
    checks = [
        (info["outcome"], outcome),
        (info["col_outcome"], col_outcome),
        (info["cols_shift"], cols_shift),
        (info["cols_noshift"], cols_noshift),
        (info["loa"], loa),
    ]

    if all([check[0] == check[1] for check in checks]):
        Logger.debug(f"Model with id {model_id} passed checks.")
    else:
        for check in checks:
            if not check[0] == check[1]:
                logging.error(f"Model attribute {check[0]} != {check[1]}")
        raise RuntimeError(f"Model attributes don't match.")



def get_or_make_model_id(
    name_model, loa, outcome, col_outcome, cols_shift, cols_noshift
):
    """ Create a model in the db or fetch it's id """
    # Start by linkning to a model
    if model_is_registered(name_model):
        model_id = get_model_id(name_model)
    else:
        # Register the model if it isn't already registered
        model_id = register_model(name_model, loa, outcome, col_outcome, cols_shift, cols_noshift)

    return model_id


def register_estimator_in_db(
    name_model,
    name_estimator,
    path_pickle,
    step,
    outcome,
    col_outcome,
    cols_shift,
    cols_noshift,
    loa,
    train_end,
    overwrite=True,
    extras=None,
):

    # Set defaults
    if not extras:
        extras = dict()

    # Get model_id from name_model
    # Creates a new model entry if none exists
    model_id = get_or_make_model_id(
        name_model, loa, outcome, col_outcome, cols_shift, cols_noshift
    )

    # Make sure that the model info we supplied matches what was already there
    check_model_info(model_id, outcome, col_outcome, cols_shift, cols_noshift, loa)

    # Register this particular estimator
    register_estimator(
        model_id,
        name_estimator,
        step,
        path_pickle,
        train_end,
        extras,
        overwrite,
    )
