DROP SCHEMA IF EXISTS metadata CASCADE;
CREATE SCHEMA metadata;

CREATE TABLE metadata.model
(
    id           SERIAL PRIMARY KEY,
    name         TEXT UNIQUE NOT NULL,
    loa          TEXT        NOT NULL, -- cm/pgm
    outcome      TEXT        NOT NULL, -- sb/ns/os
    col_outcome  TEXT,                 -- ged_dummy_sb/etc
    cols_shift   TEXT ARRAY,           -- Features that are shifted
    cols_noshift TEXT ARRAY            -- Features that are not shifted
);

CREATE TABLE metadata.estimator
(
    id                SERIAL PRIMARY KEY,
    model_id          INTEGER REFERENCES metadata.model (id),
    -- We will access them by name so don't allow duplicates
    name              TEXT UNIQUE NOT NULL,
    step              INT         NOT NULL, -- Shift size step
    -- path to the pickled estimator
    path_pickle       TEXT        NOT NULL,
    --month_id of train_end
    train_end         INTEGER     NOT NULL REFERENCES staging.month (id),
    extras            JSON,                 -- dictionary to hold any extra information
    -- timestamp of when estimator was added to this table
    trained_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE VIEW metadata.estimator_info AS
SELECT model.id       AS model_id,
       model.name     AS model_name,
       estimator.name AS estimator_name,
       model.loa,
       model.outcome,
       model.col_outcome,
       model.cols_shift,
       model.cols_noshift,
       estimator.step,
       estimator.path_pickle,
       estimator.train_end,
       estimator.extras,
       estimator.trained_timestamp
FROM metadata.model AS model
         INNER JOIN metadata.estimator AS estimator
                    ON model.id = estimator.model_id;