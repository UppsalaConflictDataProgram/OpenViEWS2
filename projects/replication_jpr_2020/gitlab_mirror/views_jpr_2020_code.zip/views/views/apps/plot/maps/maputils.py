""" Utils for maps """

# @TODO: Rewrite
# pragma: no cover
# pylint: disable=all

import pandas as pd
import numpy as np

# pylint: disable=ungrouped-imports
import matplotlib
from matplotlib import pyplot as plt
from mpl_toolkits.basemap import Basemap
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection

from views.apps.plot.maps import settings

from data import runinfo

from views.utils import dbutils
from views.utils import statsutils


def make_df_events(df, job, extras):
    """ Make df of events

    Args:
        df: dataframe containing a bool col called actual
        job: map job dict
        extras: dict with priogrid entry containing dataframe with lat and lons
    Returns:
        df_events: df containing longitude and latitude of events
        """

    job_data = job["data"]

    df_events = None

    # @TODO: Events for CM
    # Only set events where we have an actual and for PGM
    name_actual = job_data["name_actual"]
    if name_actual and job_data["loa"] == "pgm":

        df_pg = extras["priogrid"]

        df_events = df[["actual"]]
        df_events = df_events[df_events["actual"] > 0]
        df_events = df_events.merge(df_pg, left_index=True, right_index=True)
        df_events = df_events[["longitude", "latitude"]]

    return df_events


def plot_events_on_map(bmap, events):
    """ Plot a list of coordinate tuples on a basemap

    Args:
        bmap: basemap instance
        events: list of tuples of coordinates to mark
    Returns:
        bmap: The modified basemap instance
    """

    for event in events:
        xcoord, ycoord = bmap(event[0], event[1])
        bmap.plot(
            xcoord,
            ycoord,
            marker=".",
            color="black",
            label="event",
            markersize=10,
        )
    return bmap


def get_events_t(df_events, t):
    """ Get events coordinate tuples from event coordinates df at time t

    Args:
        df_events: df containing longitude and latitude cols
        t: index value to get events for"""

    # Defaults to None so we can check for events and only plot if
    # bool(events) is True
    if isinstance(df_events, pd.DataFrame):
        cols = list(df_events.columns)
        if cols != ["longitude", "latitude"]:
            raise RuntimeError(f"df_events has wrong cols: {cols}")

        df_events = df_events.loc[t]
        events_t = [tuple(event) for event in df_events.values]
    else:
        events_t = None

    return events_t


def make_collection_pg(bmap, df_t, cmap, ticks_values, var_bounds):
    """ Make a mpl PatchCollection with shapes from bmap and values from df_t

    Args:
        bmap: A basemap with a shapefile loaded where 'GID' is the idvar
        df_t: single column dataframe with GID index
        cmap: a colormap
        ticks_values: tick values to set color limitss
        var_bounds:
    """
    patches = []
    colors = []
    df_t.sort_index(inplace=True)

    if len(list(df_t.columns)) > 1:
        msg = "make_collection_pg freaks out with more than one col in df_t"
        raise RuntimeError(msg)

    for info, shape in zip(bmap.GID_info, bmap.GID):
        gid = info["GID"]
        if gid in df_t.index.values:
            prob = df_t.loc[gid]
            patch = Polygon(np.array(shape), True)
            patches.append(patch)
            colors.append(prob)

    collection = PatchCollection(patches, zorder=2)
    collection.set_array(np.array(colors).flatten())
    collection.set_cmap(cmap)

    # If we have custom tick values, set the ticks as the colorlimit
    if ticks_values:
        collection.set_clim(np.min(ticks_values), np.max(ticks_values))
    else:
        collection.set_clim(var_bounds[0], var_bounds[1])

    return collection


def make_collection_cm(bmap, df_t, cmap, ticks_values, var_bounds):
    """ Make a mpl PatchCollection with shapes from bmap and values from df_t

    Args:
        bmap: A basemap with a shapefile loaded where 'GID' is the idvar
        df_t: single column dataframe with ID index
        cmap: a colormap
        ticks_values: tick values to set color limitss
        var_bounds:
    """

    patches = []
    colors = []

    if len(list(df_t.columns)) > 1:
        msg = "make_collection_pg freaks out with more than one col in df_t"
        raise RuntimeError(msg)

    for info, shape in zip(bmap.ID_info, bmap.ID):
        gid = info["ID"]
        if gid in df_t.index.values:
            prob = df_t.loc[gid]
            patch = Polygon(np.array(shape), True)
            patches.append(patch)
            colors.append(prob)

    collection = PatchCollection(patches, zorder=2)
    collection.set_array(np.array(colors).flatten())
    collection.set_cmap(cmap)

    # If we have custom tick values, set the ticks as the colorlimit
    if ticks_values:
        collection.set_clim(np.min(ticks_values), np.max(ticks_values))
    else:
        collection.set_clim(var_bounds[0], var_bounds[1])

    return collection


# pylint: disable=invalid-name
def shift_colormap(cmap, start=0, midpoint=0.5, stop=1.0, name="shiftedcmap"):
    """ Offset the center of a colormap.

    Function to offset the "center" of a colormap. Useful for
    data with a negative min and positive max and you want the
    middle of the colormap's dynamic range to be at zero
    Credit: #https://gist.github.com/phobson/7916777

    Args:
      cmap : The matplotlib colormap to be altered
      start : Offset from lowest point in the colormap's range.
          Defaults to 0.0 (no lower ofset). Should be between
          0.0 and 1.0.
      midpoint : The new center of the colormap. Defaults to
          0.5 (no shift). Should be between 0.0 and 1.0. In
          general, this should be  1 - vmax/(vmax + abs(vmin))
          For example if your data range from -15.0 to +5.0 and
          you want the center of the colormap at 0.0, `midpoint`
          should be set to  1 - 5/(5 + 15)) or 0.75
      stop : Offset from highets point in the colormap's range.
          Defaults to 1.0 (no upper ofset). Should be between
          0.0 and 1.0.
    """
    cdict = {"red": [], "green": [], "blue": [], "alpha": []}

    # regular index to compute the colors
    reg_index = np.linspace(start, stop, 257)

    # shifted index to match the data
    shift_index = np.hstack(
        [
            np.linspace(0.0, midpoint, 128, endpoint=False),
            np.linspace(midpoint, 1.0, 129, endpoint=True),
        ]
    )

    for ri, si in zip(reg_index, shift_index):
        r, g, b, a = cmap(ri)

        cdict["red"].append((si, r, r))
        cdict["green"].append((si, g, g))
        cdict["blue"].append((si, b, b))
        cdict["alpha"].append((si, a, a))

    newcmap = matplotlib.colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap


def get_map_bounds(crop):
    """ Get map bounds in dict (lon_min, lon_max, lat_min, lat_max) """

    bounds = settings.BOUNDS[crop]

    return bounds


def get_fig_size(bounds, scale=0.5):
    """scale=0.5 gives 0.5 inches per degree

    Args:
        bounds: dict with min and max of lon and lat
        scale: Scaling multiplier
        """

    width = bounds["lon_max"] - bounds["lon_min"]
    height = bounds["lat_max"] - bounds["lat_min"]
    size = (width * scale, height * scale)

    return size


def get_cmap(variable_scale):
    """ Get a plt cmap adjusted for your variable scale

    Args:
        var_scale: variable scale, can be "prob" or "logodds"

    Returns:
        cmap: an adjusted colormap
        """
    name_cmap = "rainbow"
    cmap = plt.get_cmap(name_cmap)

    # Defaults
    start = 0.0
    mid = 0.5
    stop = 1.0

    # If we're using probs set mid of cmap at 1%
    if variable_scale == "prob":
        mid = 0.01

    if variable_scale == "logodds":
        mid = 0.25

    cmap = plt.get_cmap(name_cmap)
    cmap = shift_colormap(cmap, start, mid, stop)

    return cmap


def fetch_df_geo_pgm():
    """Fetch df containing priogrid row/col and their lat/lon for subsetting"""

    table = "staging.priogrid"
    cols = ["gid", "row", "col", "latitude", "longitude", "in_africa"]
    df = dbutils.db_to_df(table, columns=cols)
    df["pg_id"] = df["gid"]
    del df["gid"]
    df.set_index(["pg_id"], inplace=True)
    return df


def get_basemap(projection, bounds):
    """ Get a basemap instance for chosen projection and bounds dict """

    def get_basemap_ortho(bounds):
        lon_mid = (bounds["lon_min"] + bounds["lon_max"]) / 2
        lat_mid = (bounds["lat_min"] + bounds["lat_max"]) / 2

        bmap = Basemap(
            projection="ortho",
            lat_0=lat_mid,
            lon_0=lon_mid,
            suppress_ticks=True,
        )
        return bmap

    def get_basemap_cyl(bounds):
        bmap = Basemap(
            llcrnrlon=bounds["lon_min"],
            llcrnrlat=bounds["lat_min"],
            urcrnrlon=bounds["lon_max"],
            urcrnrlat=bounds["lat_max"],
            resolution="i",
            projection="cyl",
            suppress_ticks=True,
        )
        return bmap

    def get_basemap_cyl_world():
        bmap = Basemap(
            llcrnrlon=-180,
            llcrnrlat=-57,  # South tip of South America
            urcrnrlon=180,
            urcrnrlat=85,
            resolution="i",
            projection="cyl",
            suppress_ticks=False,
        )
        return bmap

    if projection == "ortho":
        bmap = get_basemap_ortho(bounds)
    elif projection == "cyl":
        bmap = get_basemap_cyl(bounds)
    elif projection == "cyl_world":
        bmap = get_basemap_cyl_world()
    else:
        raise NotImplementedError

    return bmap


def make_ticks(var_scale):
    """ Make a tick dictionary with 'values' and 'labels' depending on var_scale

    Args:
        var_scale: "logodds", "prob" or "interval"
    Returns:
        ticks: dict with 'values' and 'labels'

    """

    def make_ticks_probs():
        """ Make probability ticks. """
        ticks_strings = []
        ticks = [
            0.001,
            0.01,
            0.02,
            0.05,
            0.1,
            0.2,
            0.3,
            0.4,
            0.5,
            0.6,
            0.7,
            0.8,
            0.9,
            0.99,
        ]

        for tick in ticks:
            ticks_strings.append(str(tick))

        return ticks, ticks_strings

    def make_ticks_logit():
        """ Make logistic ticks """
        ticks_logit = []
        ticks_strings = []
        ticks = [
            0.001,
            0.002,
            0.005,
            0.01,
            0.02,
            0.05,
            0.1,
            0.2,
            0.4,
            0.6,
            0.8,
            0.9,
            0.95,
            0.99,
        ]

        for tick in ticks:
            ticks_logit.append(statsutils.logit(tick))
            ticks_strings.append(statsutils.format_prob_to_pct(tick))

        # Make the lower than
        ticks_strings[0] = "<= " + ticks_strings[0]

        return ticks_logit, ticks_strings

    if var_scale == "logodds":
        values, labels = make_ticks_logit()
    elif var_scale == "prob":
        values, labels = make_ticks_probs()
    elif var_scale == "interval":
        values, labels = None, None
    else:
        msg = "Did you specify var_scale?"
        raise RuntimeError(msg)

    ticks = {}
    ticks["values"] = values
    ticks["labels"] = labels
    return ticks


def restrict_prob_lower_bound(df, bound):
    """ Cap all values in df to the lower bound """

    df[df < bound] = bound
    return df


def month_id_to_datestr(df_months, month_id):
    """ Combine 'year_id' and 'month' cols and return a datestring """

    datestr = (
        str(df_months.loc[month_id]["year_id"])
        + "-"
        + str(df_months.loc[month_id]["month"])
    )
    return datestr


# pylint: disable=too-many-locals
def make_boxes_logos(map_bounds):
    """ Custom box placement for EU-flag, ERC logo and ViEWS logo """

    lon_min = map_bounds["lon_min"]
    # lon_max = map_bounds['lon_max']
    lat_min = map_bounds["lat_min"]
    # lat_max = map_bounds['lat_max']

    w_eu = 6.705
    h_eu = 4.5
    w_erc = 4.7109375
    h_erc = 4.5
    # w_views = w_eu + w_erc + 1
    h_views = 4.024

    lon_start_eu = lon_min + 1
    lon_end_eu = lon_start_eu + w_eu
    lon_start_erc = lon_end_eu + 1
    lon_end_erc = lon_start_erc + w_erc
    lon_start_views = lon_start_eu
    lon_end_views = lon_end_erc

    lat_start_eu = lat_min + 1
    lat_end_eu = lat_start_eu + h_eu
    lat_start_erc = lat_start_eu
    lat_end_erc = lat_start_erc + h_erc
    lat_start_views = lat_end_eu + 1
    lat_end_views = lat_start_views + h_views

    lon_min_textbox = lon_start_views
    lat_min_textbox = lat_end_views + 1

    box_logo_eu = (lon_start_eu, lon_end_eu, lat_start_eu, lat_end_eu)
    box_logo_erc = (lon_start_erc, lon_end_erc, lat_start_erc, lat_end_erc)
    box_logo_views = (
        lon_start_views,
        lon_end_views,
        lat_start_views,
        lat_end_views,
    )

    lon_min_textbox = lon_start_views
    lat_min_textbox = lat_end_views + 1

    pos_text = (lon_min_textbox, lat_min_textbox)

    return box_logo_eu, box_logo_erc, box_logo_views, pos_text


def make_textbox(job):
    """ Make the metadata string that goes in the map textbox """

    mname = job["data"]["name_plotvar"]
    table = job["data"]["source_plotvar"]
    run_id = runinfo.RUNINFO["run_id"]

    text = f"Modelname: {mname}\nRun: {run_id}\nTable: {table}"

    return text


def plot_cbar(size, var_scale, collection, ticks):
    """ Plot the correct colorbar for the var_scale

    Args:
        size: size tuple, second element sets fontsize
        var_scale: "logodds" or "prob" use custom ticks, others use default
        collection: the patchcollection
        ticks: dict of tick values and tick-labels
    Returns:
        None
    """

    cbar_fontsize = size[1] / 2

    if var_scale in ["logodds", "prob"]:
        # if we're plotting logodds or probs set custom ticks
        cbar = plt.colorbar(
            collection, ticks=ticks["values"], fraction=0.046, pad=0.04
        )
        cbar.ax.set_yticklabels(ticks["labels"], size=cbar_fontsize)
    else:
        # else use default colorbar for interval variables
        cbar = plt.colorbar(collection, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=cbar_fontsize)
