""" Map plotting functions """

from matplotlib import pyplot as plt
import matplotlib.image as mpimg


from views.apps.plot.maps import settings
from views.apps.plot.maps import maputils

from views.utils import statsutils

# pylint: disable=too-many-locals
def plot_map_pgm(path, df_t, events, cmap, meta):
    """ Plot a PGM map """

    map_bounds = meta["map_bounds"]
    ticks = meta["ticks"]
    var_scale = meta["var_scale"]

    var_bounds = df_t["plotvar"].min(), df_t["plotvar"].max()
    size = maputils.get_fig_size(map_bounds)
    _, ax = plt.subplots(figsize=size)
    bmap = maputils.get_basemap(meta["proj"], map_bounds)

    if var_scale == "logodds":
        df_t = statsutils.logit(df_t)

    # read pg_shapefile for the collection
    bmap.readshapefile(
        shapefile=settings.PG_PATH_SHP,
        name=settings.PG_VARNAME_SHP,
        drawbounds=False,
    )

    # Fill the grids with color
    collection = maputils.make_collection_pg(
        bmap=bmap,
        df_t=df_t,
        cmap=cmap,
        ticks_values=ticks["values"],
        var_bounds=var_bounds,
    )
    ax.add_collection(collection)

    if events:
        maputils.plot_events_on_map(bmap, events)

    # Plot the grid on top of the colors
    bmap.readshapefile(
        shapefile=settings.PG_PATH_SHP,
        name=settings.PG_VARNAME_SHP,
        drawbounds=True,
    )

    # Draw the box around the map
    bmap.drawmapboundary()

    # Plot countries with thicker black line with thin white on top
    bmap.readshapefile(
        settings.C_PATH_SHP,
        settings.C_VARNAME_SHP,
        drawbounds=True,
        color="w",
        linewidth=2,
    )
    bmap.readshapefile(
        settings.C_PATH_SHP,
        settings.C_VARNAME_SHP,
        drawbounds=True,
        color="k",
        linewidth=1,
    )

    # Plot the colorbar
    maputils.plot_cbar(size, var_scale, collection, ticks)

    boxfunc = maputils.make_boxes_logos
    box_logo_eu, box_logo_erc, box_logo_views, pos_textbox = boxfunc(map_bounds)

    bbox = {"boxstyle": "square", "facecolor": "white"}
    plt.text(
        pos_textbox[0],
        pos_textbox[1],
        meta["text_box"],
        bbox=bbox,
        fontsize=size[1] * 0.5,
    )

    logo_eu = mpimg.imread(settings.PATH_LOGO_EU)
    logo_erc = mpimg.imread(settings.PATH_LOGO_ERC)
    logo_views = mpimg.imread(settings.PATH_LOGO_VIEWS)

    plt.imshow(logo_erc, extent=box_logo_erc)
    plt.imshow(logo_eu, extent=box_logo_eu)
    plt.imshow(logo_views, extent=box_logo_views)

    text_title = meta["title"]
    plt.figtext(0.5, 0.85, text_title, fontsize=size[1], ha="center")

    plt.savefig(path, bbox_inches="tight")
    print("wrote ", path)
    plt.close()


def plot_map_cm(path, df_t, events, cmap, meta):
    """ Plot a CM map """

    map_bounds = meta["map_bounds"]
    ticks = meta["ticks"]
    var_scale = meta["var_scale"]

    var_bounds = df_t["plotvar"].min(), df_t["plotvar"].max()
    size = maputils.get_fig_size(map_bounds)
    _, ax = plt.subplots(figsize=size)
    bmap = maputils.get_basemap(meta["proj"], map_bounds)

    if var_scale == "logodds":
        df_t = statsutils.logit(df_t)

    # read cm_shapefile for the collection
    bmap.readshapefile(
        shapefile=settings.C_PATH_SHP,
        name=settings.C_VARNAME_SHP,
        drawbounds=False,
    )

    # Fill the grids with color
    collection = maputils.make_collection_cm(
        bmap=bmap,
        df_t=df_t,
        cmap=cmap,
        ticks_values=ticks["values"],
        var_bounds=var_bounds,
    )
    ax.add_collection(collection)

    if events:
        maputils.plot_events_on_map(bmap, events)

    # Draw the box around the map
    bmap.drawmapboundary()

    # Plot countries with thicker black line with thin white on top
    bmap.readshapefile(
        settings.C_PATH_SHP,
        settings.C_VARNAME_SHP,
        drawbounds=True,
        color="w",
        linewidth=2,
    )
    bmap.readshapefile(
        settings.C_PATH_SHP,
        settings.C_VARNAME_SHP,
        drawbounds=True,
        color="k",
        linewidth=1,
    )

    # Plot the colorbar
    maputils.plot_cbar(size, var_scale, collection, ticks)

    boxfunc = maputils.make_boxes_logos
    box_logo_eu, box_logo_erc, box_logo_views, pos_textbox = boxfunc(map_bounds)

    bbox = {"boxstyle": "square", "facecolor": "white"}
    plt.text(
        pos_textbox[0],
        pos_textbox[1],
        meta["text_box"],
        bbox=bbox,
        fontsize=size[1] * 0.5,
    )

    logo_eu = mpimg.imread(settings.PATH_LOGO_EU)
    logo_erc = mpimg.imread(settings.PATH_LOGO_ERC)
    logo_views = mpimg.imread(settings.PATH_LOGO_VIEWS)
    plt.imshow(logo_erc, extent=box_logo_erc)
    plt.imshow(logo_eu, extent=box_logo_eu)
    plt.imshow(logo_views, extent=box_logo_views)

    text_title = meta["title"]
    plt.figtext(0.5, 0.85, text_title, fontsize=size[1], ha="center")

    plt.savefig(path, bbox_inches="tight")
    print("wrote ", path)
    plt.close()
