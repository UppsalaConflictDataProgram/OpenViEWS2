""" Mapping module """

import logging
import os
import tarfile
import tempfile

from matplotlib import colors, pyplot as plt, image as mpimg
from matplotlib.offsetbox import AnchoredText
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

import pandas as pd
import geopandas as gpd
import numpy as np

from views.utils import dbutils, statsutils, pyutils

Logger = logging.getLogger(__name__)

# Sets of pg_ids you might want to drop.
ID_SETS = {
    "africa_islands_pg_ids": [
        62356,
        99835,
        99836,
        100555,
        100556,
        101276,
        101287,
        122871,
        122872,
        150791,
        150792,
        150793,
        150794,
        151512,
        151513,
        151514,
        152235,
        152952,
        152955,
        153670,
        153671,
        153672,
        153675,
        154390,
        154391,
    ]
}

# Bounding boxes.
# @TODO: Add some country boxes here
# The form is xmin, xmax, ymin, ymax
BBOXES = {"mainland_africa": [-18.5, 52.0, -35.5, 38.0]}


class MapData:
    """ Class for holding geography and time data for plot_map() """

    @staticmethod
    def _get_gdf_cm():
        query = """
        SELECT id AS country_id, geom
        FROM staging.country
        WHERE gweyear=2016 AND gwemonth=6;
        """
        # query = "SELECT country_id, geom FROM staging.country;"
        groupvar = "country_id"
        return dbutils.db_to_gdf(query, groupvar)

    @staticmethod
    def _get_gdf_pgm():
        #query = "SELECT gid AS pg_id, geom FROM staging.priogrid;"
        # query = "SELECT pg_id, geom FROM staging.priogrid;"
        query = """
        SELECT pg.gid as pg_id, pg.geom, cpg.country_id
        FROM staging.priogrid AS pg, staging_test.cpgm AS cpg
        WHERE cpg.pg_id=pg.gid
        AND cpg.month_id=480;
        """  # Arbitrary month to just get the grid.
        groupvar = "pg_id"
        return dbutils.db_to_gdf(query, groupvar)

    @staticmethod
    def _get_months():
        query = (
            "SELECT id AS month_id, year_id AS year, month FROM staging.month"
        )
        # query = "SELECT month_id, year, month FROM staging.month"
        df = dbutils.query_to_df(query)
        df = df.set_index(["month_id"])
        df["date_str"] = df.year.astype(str) + "-" + df.month.astype(str)
        return df

    @staticmethod
    def _get_capitals():
        df = dbutils.query_to_df(
            """
            SELECT id as country_id, capname as name, caplong, caplat
            FROM staging.country
            WHERE gweyear = 2016;
            """
        )
        df = gpd.GeoDataFrame(
            df, geometry=gpd.points_from_xy(df["caplong"], df["caplat"])
        )
        return df

    def __init__(self, db=True):
        """ If source is "db" read data from db, else source is path
        to a directory with the data in files
        """
        if db:
            self.gdf_cm = MapData._get_gdf_cm()
            self.gdf_pgm = MapData._get_gdf_pgm()
            self.df_m = MapData._get_months()
            self.df_cap = MapData._get_capitals()
        else:
            Logger.info(f"db is False, run .load() to init from file")

    def gdf_from_s_t(self, s_patch):

        groupvar = s_patch.index.name
        if groupvar == "pg_id":
            gdf = self.gdf_pgm.join(s_patch, how="inner")
        elif groupvar == "country_id":
            gdf = self.gdf_cm.join(s_patch, how="inner")
        else:
            raise RuntimeError(f"Couldn't match groupvar {groupvar}")

        return gdf

    @staticmethod
    def _make_paths(tempdir):
        path_gdf_cm = os.path.join(tempdir, "df_cm.geojson")
        path_gdf_pgm = os.path.join(tempdir, "df_pgm.geojson")
        path_df_m = os.path.join(tempdir, "df_m.csv")

        return path_gdf_cm, path_gdf_pgm, path_df_m

    def dump(self, destination):
        with tempfile.TemporaryDirectory() as tempdir:

            path_gdf_cm, path_gdf_pgm, path_df_m = MapData._make_paths(tempdir)
            self.gdf_cm.reset_index().to_file(path_gdf_cm, driver="GeoJSON")
            self.gdf_pgm.reset_index().to_file(path_gdf_pgm, driver="GeoJSON")
            self.df_m.to_csv(path_df_m)

            with tarfile.open(destination, mode="w:xz") as f:
                for path in [path_gdf_cm, path_gdf_pgm, path_df_m]:
                    f.add(path, arcname=os.path.basename(path))
                Logger.info(f"Wrote {destination}")

    def load(self, path):

        with tempfile.TemporaryDirectory() as tempdir:
            with tarfile.open(path, "r") as f:
                f.extractall(path=tempdir)
            path_gdf_cm, path_gdf_pgm, path_df_m = MapData._make_paths(tempdir)
            self.gdf_cm = (
                gpd.read_file(path_gdf_cm)
                .set_index(["country_id"])
                .rename(columns={"geometry": "geom"})
                .set_geometry("geom")
            )
            self.gdf_pgm = (
                gpd.read_file(path_gdf_pgm)
                .set_index(["pg_id"])
                .rename(columns={"geometry": "geom"})
                .set_geometry("geom")
            )
            self.df_m = pd.read_csv(path_df_m).set_index(["month_id"])
            Logger.info(f"Loaded from {path}")


def get_gdf_edge_ids(gdf, n_min_x=0, n_max_x=0, n_min_y=0, n_max_y=0):
    """ Get ids of rows with most extreme geometries in each direction """

    # Call with these args to drop africas islands
    n_edges = {
        "pgm_africa": {"n_min_x": 16, "n_max_x": 8, "n_min_y": 1, "n_max_y": 0}
    }

    # Get ids of edge grids with sorted by min_x, max_x, min_y, max_y
    # Call sort_index() first to make it deterministic
    ids_min_x = gdf.sort_index().bounds.minx.sort_values(ascending=True).index
    ids_max_x = gdf.sort_index().bounds.maxx.sort_values(ascending=False).index
    ids_min_y = gdf.sort_index().bounds.miny.sort_values(ascending=True).index
    ids_max_y = gdf.sort_index().bounds.maxy.sort_values(ascending=False).index

    # Get ids of n most extreme grids to ids_edge
    ids_edge = []
    for n, ids in zip(
        [n_min_x, n_max_x, n_min_y, n_max_y],
        [ids_min_x, ids_max_x, ids_min_y, ids_max_y],
    ):
        ids_edge.append(list(ids[:n]))  # cast Int64Index to list

    ids_edge = pyutils.flatten_list(ids_edge)
    return ids_edge


def get_bbox(gdf, padding=0.5):
    """ Make bounding box from gdf """
    min_x = gdf.bounds.minx.min() - padding
    max_x = gdf.bounds.maxx.max() + padding
    min_y = gdf.bounds.miny.min() - padding
    max_y = gdf.bounds.maxy.max() + padding
    bbox = (min_x, max_x, min_y, max_y)
    return bbox


def get_figsize(bbox, scale):
    """ Get figsize tuple given scaler """
    size_x = (bbox[1] - bbox[0]) * scale
    size_y = (bbox[3] - bbox[2]) * scale
    size = (size_x, size_y)
    return size


def get_fig_ax(figsize, bbox):
    """ Get limited and figsized fig, ax from figsize and bbox """
    # Setup ax with size
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_xlim((bbox[0], bbox[1]))
    ax.set_ylim((bbox[2], bbox[3]))
    return fig, ax


def adjust_axlims(ax, bbox):
    """ Limit axes to provided bbox """
    # Setup ax with size
    ax.set_xlim((bbox[0], bbox[1]))
    ax.set_ylim((bbox[2], bbox[3]))
    return ax


def add_textbox_to_ax(
    fig,
    ax,
    text,
    textsize,
    corner="lower left",
    corner_offset=0.3,
    textbox_pad=0.4
):
    """ Add bounded white textbox to ax, with url and logo.

    Args:
        text (str): Text to draw in box.
        corner (str): Location of anchored textbox.
        fontsize (int): Font size.
        corner_offset (float): How far from each corner to draw box. Note the
            other elements (url and logo) depend on this.
        textbox_pad (float): Padding inside the main textbox.
    Returns:
        None
    """
    # Set anchored textbox.
    text = AnchoredText(
        text,
        loc=corner,
        pad=textbox_pad,
        borderpad=corner_offset,
        prop={"fontsize": textsize - 5})
    text.patch.set(alpha=0.8)
    ax.add_artist(text)

    # Once textbox is drawn up, get bbox coordinates for that.
    renderer = fig.canvas.renderer
    coords = ax.transData.inverted().transform(text.get_window_extent(renderer))

    # Params depending on selected corner. Use the coords to inset the url.
    # Coords[0][0]: xmin, [0][1]: ymin, [1][0]: xmax, [1][1]: ymax.
    # TODO: Offset looks dependent on parent size.
    cornerparams = {
        "lower left": {
            "xy": (coords[0][0], coords[1][1]),
            "offset": (0, 2),
            "ha": "left",
            "va": "bottom"
        },
        "lower right": {
            "xy": (coords[1][0], coords[1][1]),
            "offset": (0, 2),
            "ha": "right",
            "va": "bottom"
        },
    }

    if corner not in cornerparams:
        raise KeyError(f"{corner} is not a valid corner (yet).")

    style = dict(
        facecolor='white',
        alpha=0,
        edgecolor='red', # For testing.
        boxstyle='square, pad=0'
    )
    text = ax.annotate(
        "http://views.pcr.uu.se",
        xy=cornerparams[corner]["xy"],
        xytext=cornerparams[corner]["offset"],
        textcoords="offset points",
        fontsize=textsize - 5,
        bbox=style,
        ha=cornerparams[corner]["ha"],
        va=cornerparams[corner]["va"],
    )

    # Again once textbox is drawn up, get bbox coordinates for that.
    text_bbox = text.get_bbox_patch()
    fig.canvas.draw()
    urlcoords = ax.transAxes.inverted().transform(text_bbox.get_window_extent())

    # Add the ViEWS logo.
    this_dir = os.path.dirname(__file__)
    path_logo_views = os.path.join(
        this_dir,
        "..",
        "..",
        "logos",
        "views_transparent.png"
    )
    logo_views = mpimg.imread(path_logo_views)

    # TODO(Remco): Logo getting squashed with higher fig_scale.
    # Coords[0][0] xmin, [0][1] ymin, [1][0] xmax, [1][1] ymax.
    urlheight = urlcoords[1][1] - urlcoords[0][1]
    urlwidth = urlcoords[1][0] - urlcoords[0][0]

    inset = ax.inset_axes(
        bounds=[urlcoords[0][0], urlcoords[1][1], urlwidth, urlheight * 3.7],
    )
    inset.axis("off")
    inset.imshow(logo_views, interpolation="none", aspect='auto')


# pylint: disable=invalid-name
def shift_colormap(cmap, start=0, midpoint=0.5, stop=1.0, name="shiftedcmap"):
    """ Offset the center of a colormap.

    Function to offset the "center" of a colormap. Useful for
    data with a negative min and positive max and you want the
    middle of the colormap's dynamic range to be at zero
    Credit: #https://gist.github.com/phobson/7916777

    ViEWS shifted rainbow: [0, 0.25, 1]

    Args:
      cmap : The matplotlib colormap to be altered
      start : Offset from lowest point in the colormap's range.
          Defaults to 0.0 (no lower ofset). Should be between
          0.0 and 1.0.
      midpoint : The new center of the colormap. Defaults to
          0.5 (no shift). Should be between 0.0 and 1.0. In
          general, this should be  1 - vmax/(vmax + abs(vmin))
          For example if your data range from -15.0 to +5.0 and
          you want the center of the colormap at 0.0, `midpoint`
          should be set to  1 - 5/(5 + 15)) or 0.75
      stop : Offset from highets point in the colormap's range.
          Defaults to 1.0 (no upper ofset). Should be between
          0.0 and 1.0.
    """
    cdict = {"red": [], "green": [], "blue": [], "alpha": []}

    # regular index to compute the colors
    reg_index = np.linspace(start, stop, 257)

    # shifted index to match the data
    shift_index = np.hstack(
        [
            np.linspace(0.0, midpoint, 128, endpoint=False),
            np.linspace(midpoint, 1.0, 129, endpoint=True),
        ]
    )

    for ri, si in zip(reg_index, shift_index):
        r, g, b, a = cmap(ri)

        cdict["red"].append((si, r, r))
        cdict["green"].append((si, g, g))
        cdict["blue"].append((si, b, b))
        cdict["alpha"].append((si, a, a))

    newcmap = colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap


def make_ticks_logit():
    """ Make logistic ticks """
    ticks_logit = []
    ticks_strings = []
    ticks = [
        0.001,
        0.002,
        0.005,
        0.01,
        0.02,
        0.05,
        0.1,
        0.2,
        0.4,
        0.6,
        0.8,
        0.9,
        0.95,
        0.99,
    ]

    for tick in ticks:
        ticks_logit.append(statsutils.logit(tick))
        ticks_strings.append(statsutils.format_prob_to_pct(tick))

    # Make the lower than for 0.001
    ticks_strings[0] = "<= " + ticks_strings[0]

    return ticks_logit, ticks_strings


def make_ticks(var_scale="interval"):
    """ Make a tick dictionary with 'values' and 'labels' depending on var_scale

    Args:
        var_scale: "logodds", "prob" or "interval"
    Returns:
        ticks: dict with 'values' and 'labels'
    """
    def make_ticks_logit():
        """ Make logistic ticks """
        ticks_logit = []
        ticks_strings = []
        ticks = [
            0.001,
            0.002,
            0.005,
            0.01,
            0.02,
            0.05,
            0.1,
            0.2,
            0.4,
            0.6,
            0.8,
            0.9,
            0.95,
            0.99,
        ]

        for tick in ticks:
            ticks_logit.append(statsutils.logit(tick))
            ticks_strings.append(statsutils.format_prob_to_pct(tick))

        # Make the lower than for 0.001
        ticks_strings[0] = "<= " + ticks_strings[0]

        return ticks_logit, ticks_strings

    def make_ticks_probs():
        ticks_strings = []
        ticks_probs = [0.001, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99]

        for tick in ticks_probs:
            ticks_strings.append(str(tick))

        return ticks_probs, ticks_strings

    def make_ticks_cm_delta():
        ticks_strings = []
        ticks_delta = [-1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1]

        for tick in ticks_delta:
            ticks_strings.append(str(tick))

        return ticks_delta, ticks_strings

    def make_ticks_pgm_delta():
        ticks_strings = []
        ticks_delta = [-0.4, -0.2, 0, 0.2, 0.4]

        for tick in ticks_delta:
            ticks_strings.append(str(tick))

        return ticks_delta, ticks_strings

    if var_scale == "logodds":
        values, labels = make_ticks_logit()
    elif var_scale == "prob":
        values, labels = make_ticks_probs()
    elif var_scale == "cm_delta":
        values, labels = make_ticks_cm_delta()
    elif var_scale == "pgm_delta":
        values, labels = make_ticks_pgm_delta()
    elif var_scale == "interval":
        values, labels = None, None

    ticks = {"values": values, "labels": labels}

    return ticks


def plot_map(
    mapdata,
    s_patch,
    t=None,
    run_id="development",
    s_marker=None,
    country_id=None,
    add_capitals=False,
    logodds=True,
    categorical=False,
    bbox=None,
    bbox_pad=None,
    cmap=None,
    vmin=None,
    vmax=None,
    tick_values=None,
    tick_labels=None,
    fig_scale=0.5,
    dpi=300,
    cbar_width="5%",
    textsize=15,
    size_cborder=0.2,
    size_gridborder=0.2,
    drops=None,
    textbox=None,
    textbox_corner="lower left",
    title=None,
    path=None,
):
    """
    Plot a map.
    #TODO(Remco): Assuming default if cmap not provided is clunky.
    #TODO(Remco): Allow for specification of colors by category.

    Args:
        mapdata (views.apps.plot.maps.MapData) : Object with map geometries
            and month dataframe.
        s_patch (pd.Series): The data to plot as colored patches.
        t: (int): time index (month_id).
        run_id (str): String of identifier of run to put into default textbox.
            Not used if explicit textbox is provided under the textbox arg.
        s_marker (pd.Series): Data to plot as markers for data>0.
        country_id (int): Country_id to subset.
        logodds (bool): Transform s_patch to logodds before plotting.
        categorical (bool): Set to True if data to plot is categorical. Series
            can be either float/int or str.
        bbox (str or list or tuple): Name of bounding box in
            fancy.BBOXES if str or bounding box tuple or list of form
            (xmin, xmax, ymin, ymax).
        bbox_pad (list or tuple): Coordinate padding to add to bbox, per
            (xmin, xmax, ymin, ymax).
        cmap (str or matplotlib cmap): Colormap to use. Defaults to (shifted)
            rainbow with either logodds or prob scales.
        vmin (float): Minimum to map the data to.
        vmax (float): Maximum to map the data to.
        tick_values (list): List of selected ticks to show in colorbar.
        tick_values (list): List of strings for the selected ticks.
        fig_scale (float): Figure size scaler.
        dpi (int): Dots per inch, defaults to 300. Lower to reduce file size.
        cbar_width (str): Percentage of figure space for colorbar ax to take.
        textsize (int): Base text size for all text on plot. Title is textsize
            +10.
        size_cborder (float): country border size scale.
        size_gridborder (float): priogrid border size scale.
        drops (list): groupvar index values to drop for s_patch.
        textbox (str): Text to add to textbox. Flexible to lines added with \n.
        title (str): Title to add to the figure.
        path (str): Destination to write figure file.
    Returns:
        None
    """
    # Copy data we're going to use to plot so we don't mess with callers data
    s_patch_t = s_patch.copy()

    indices = s_patch.index.names
    if country_id is not None:
        if "pg_id" in indices:
            # Get pg_ids associated with country.
            cpgm = mapdata.gdf_pgm
            cpgm = cpgm.loc[cpgm.country_id == country_id].index.unique()
            subset = s_patch_t.index.get_level_values("pg_id").isin(cpgm)
            s_patch_t = s_patch_t[subset]
        if "country_id" in indices:
            csub = s_patch_t.index.get_level_values('country_id') == country_id
            s_patch_t = s_patch_t.loc[csub]

    if t is not None:
        s_patch_t = s_patch_t.loc[t]

    # Log transform if requested.
    if logodds:
        # Check we aren't logoddsing non probabilities
        if s_patch_t.max() > 1 or s_patch_t.min() < 0:
            msg = f"data in s_patch outside 0=<x=<1 with logodds=True"
            raise RuntimeError(msg)
        s_patch_t = statsutils.prob_to_logodds(s_patch_t)
        # Set up default ticks for logodds.
        ticks = make_ticks("logodds")
        vmin = min(ticks["values"])
        vmax = max(ticks["values"])
        tick_values = ticks["values"]

    gdf_patch = mapdata.gdf_from_s_t(s_patch_t)

    # Drop any ids provided in drops
    if drops:
        gdf_patch = gdf_patch.drop(drops)

    # If no bbox in parameters get one that matches the data
    if not bbox:
        bbox = get_bbox(gdf_patch)
    # If string, look it up in the BBOXES dictionary of bboxes
    elif isinstance(bbox, str):
        bbox = BBOXES[bbox]
    elif isinstance(bbox) in [list, tuple]:
        pass  # Keep the bbox as a list/tuple
    else:
        raise RuntimeError(f"bbox should be list, tuple or str, bbox: {bbox}")

    # If supplied, add padding to bbox to patch.
    if bbox_pad is not None:
        bbox = [i + j for i, j in zip(bbox_pad, bbox)]

    # Set up figure space.
    fig, ax = plt.subplots(figsize=(20 * fig_scale, 20 * fig_scale))
    ax = adjust_axlims(ax, bbox)

    # Set up vmin, vmax.
    if not categorical:
        vmin = s_patch_t.min() if not vmin else vmin
        vmax = s_patch_t.max() if not vmax else vmax

    # Else, set up defaults (standard ViEWS rainbow scheme).
    if not cmap:
        if logodds:
            cmap = plt.get_cmap("rainbow")
            cmap = shift_colormap(cmap, 0.0, 0.25, 1.0)
            ticks = make_ticks("logodds")
            vmin = min(ticks["values"])
            vmax = max(ticks["values"])
            tick_values = ticks["values"]
            tick_labels = ticks["labels"]
        else:
            ticks = make_ticks("prob")
            cmap = "rainbow"
            # if vmin and vmax in interval [0,1]
            if vmin >= 0 and vmax <= 1:
                vmin, vmax = 0, 1 # set color limits to 0,1
            tick_values = ticks["values"]
            tick_labels = ticks["labels"]

    # Plot.
    if categorical:
        legend = True
        legend_kwds = {
            #'loc': 'upper left',
            #'bbox_to_anchor': (1.01, 1),
            'borderaxespad': 0.2,
            'fontsize': textsize - 2,
            'frameon': True,
            'fancybox': False,
            'edgecolor': "black",
            'framealpha': 0.8
        }
    else:
        legend = False
        legend_kwds = None

    plot = gdf_patch.plot(
        ax=ax,
        column=s_patch.name,
        edgecolor="black",
        linewidth=size_gridborder,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        categorical=categorical,
        legend=legend,
        legend_kwds=legend_kwds
    )

    if not categorical:
        # Make ax for colorbar.
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size=cbar_width, pad=0.1)

        # Manual alterations to the colorbar.
        sm = plt.cm.ScalarMappable(
            cmap=cmap, norm=plt.Normalize(vmin=vmin, vmax=vmax)
        )
        sm._A = []
        cbar = plt.colorbar(sm, cax=cax, ticks=tick_values)
        cax.tick_params(labelsize=textsize)

    # Assume ticks are labels if only values are provided.
    if tick_labels is not None:
        if tick_values is not None:
            cbar.set_ticklabels(tick_labels)
        else:
            raise RuntimeError("Need tick values to match labels to.")

    # Remove axis ticks.
    ax.tick_params(
        top=False,
        bottom=False,
        left=False,
        right=False,
        labelleft=False,
        labelbottom=False
    )

    # Plot country borders.
    geom_c = mapdata.gdf_cm.copy()
    if country_id:
        csub = geom_c.index.get_level_values('country_id') == country_id
        geom_c = geom_c.loc[csub]
    else:
        # If we'd want to plot only the gdf's countries' borders:
        #countries = gdf_patch.index.get_level_values('country_id').unique()
        #geom_c = geom_c.loc[countries]
        geom_c = geom_c.cx[bbox[0] : bbox[1], bbox[2] : bbox[3]]

    geom_c.geom.boundary.plot(
        ax=ax,
        edgecolor="black",
        facecolor="none",
        linewidth=2.0 * size_cborder,
    )
    geom_c.geom.boundary.plot(
        ax=ax,
        edgecolor="white",
        facecolor="none",
        linewidth=0.7 * size_cborder,
    )

    # Plot markers on top of colour patches if we have any > 0.
    if s_marker is not None:
        s_marker_t = s_marker.loc[t].copy() if t else s_marker.copy()
        s_marker_t = s_marker_t[s_marker_t > 0]
        gdf_marker = mapdata.gdf_from_s_t(s_marker_t)
        gdf_marker.centroid.plot(
            ax=ax, marker=".", markersize=100, color="black"
        )

    # Plot capitals if add_capitals is true.
    if add_capitals:
        capitals = mapdata.df_cap.copy()
        # Subset to the selected geographic area.
        capitals = capitals.cx[bbox[0] : bbox[1], bbox[2] : bbox[3]]  # type: ignore
        if country_id is not None:
            capitals = capitals[capitals["country_id"] == country_id]
        capitals.plot(ax=ax, color="black", alpha=0.5, label=capitals["name"])
        # By default, add labels.
        # TODO: Make optional. Add adjusttext.
        for x, y, label in zip(
            capitals.geometry.x, capitals.geometry.y, capitals["name"]
        ):
            ax.text(
                x=x,
                y=y,
                s=label,
                horizontalalignment="left",
                verticalalignment="bottom",
                fontsize=textsize - 2,
            )

    # Add textbox and url/logo.
    if t and not textbox:
        textbox = f"Run: {run_id} \nName: {s_patch_t.name} \nMonth: {t}"
    if not t and not textbox:
        raise RuntimeError("Please add a textbox.")

    add_textbox_to_ax(
        fig=fig,
        ax=ax,
        text=textbox,
        textsize=textsize,
        corner=textbox_corner
    )

    # Title.
    if title:
        ax.set_title(title, fontsize=textsize + 3, pad=15)
    else:
        if t:
            date_str = mapdata.df_m.loc[t, "date_str"]
            title = date_str
            ax.set_title(title, fontsize=textsize + 10, pad=15)

    # Save map to path.
    if path:
        fig.savefig(path, bbox_inches="tight", dpi=dpi)
        Logger.info(f"Wrote {path}.")
        plt.close(fig)
