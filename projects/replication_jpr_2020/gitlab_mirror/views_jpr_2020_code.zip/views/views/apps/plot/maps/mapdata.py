""" Module for reading map data """

# @TODO: Rewrite
# pragma: no cover
# pylint: disable=all

import pandas as pd

from views.utils import dbutils
from data import loas
from views.apps.plot.maps import settings


def _get_ids(job_data):
    """ Wrapper for the slightly ugly id getting """

    return loas.LOAS[job_data["loa"]]["ids"]


def _get_data_from_db(job_data):
    """ Fetch map data from db """

    ids = _get_ids(job_data)
    plotvar = job_data["name_plotvar"]

    df = dbutils.db_to_df(
        job_data["source_plotvar"], columns=[plotvar], ids=ids
    )

    # If we have a name of an actual to plot
    name_actual = job_data["name_actual"]
    if name_actual:
        df_actual = dbutils.db_to_df(
            job_data["source_actual"], columns=[name_actual], ids=ids
        )

        df = df.merge(df_actual, how="left", left_index=True, right_index=True)
    return df


def _get_data_from_file(job_data):
    """ Fetch map data from file """

    def flexiset_index(df, ids):
        """ Whatever the state of the index, make it so """

        df.reset_index(inplace=True)
        df.set_index(ids, inplace=True)
        return df

    ids = _get_ids(job_data)
    plotvar = job_data["name_plotvar"]

    # Get only the plotvar with ids from source_plotvar and set the ids
    df = pd.read_hdf(job_data["source_plotvar"])
    df.reset_index(inplace=True)
    df.set_index(ids, inplace=True)
    df = df[[plotvar]]

    # If we have a name of an actual to plot
    name_actual = job_data["name_actual"]
    if name_actual:
        df_actual = pd.read_hdf(job_data["source_actual"])
        df_actual = flexiset_index(df_actual, ids)
        # Keep only the col we want
        df_actual = df_actual[[name_actual]]
        df = df.merge(df_actual, left_index=True, right_index=True)

    return df


def _get_times_db(job_data):

    df = None
    timevar = loas.LOAS[job_data["loa"]]["timevar"]
    if timevar == "month_id":
        df = dbutils.db_to_df(settings.FQ_MONTHS, ids=[timevar])

    return df


def _get_times_file(job_data):

    df = None
    timevar = loas.LOAS[job_data["loa"]]["timevar"]
    if timevar == "month_id":
        df = pd.read_hdf(settings.PATH_MONTHS)

    return df


def _get_priogrid_db(job_data):

    df = None
    # If it's PGM get the lon-lats for grids
    if job_data["loa"] == "pgm":
        ids = [loas.LOAS["pgm"]["groupvar"]]
        df = dbutils.db_to_df(settings.FQ_PRIOGRID, ids=ids)

    return df


def _get_priogrid_file(job_data):

    df = None
    # If it's PGM get the lon-lats for grids
    if job_data["loa"] == "pgm":
        df = pd.read_hdf(settings.PATH_PRIOGRID)

    return df


def get_data(job):
    """ Fetch data needed for job """

    job_data = job["data"]

    source = job_data["source"]
    if source == "db":
        df = _get_data_from_db(job_data)
    elif source == "file":
        df = _get_data_from_file(job_data)
    else:
        msg = f"Unrecognized data source {source}"
        raise RuntimeError(msg)

    df.rename(columns={job["data"]["name_plotvar"]: "plotvar"}, inplace=True)

    if job_data["name_actual"]:
        df.rename(columns={job_data["name_actual"]: "actual"}, inplace=True)

    df.sort_index(inplace=True)

    return df


def get_extras(job):
    """ Fetch extras like month_id to year-month table and priogrid latlons."""
    job_data = job["data"]

    extras = {}

    source = job_data["source"]
    if source == "db":
        extras["times"] = _get_times_db(job_data)
        extras["priogrid"] = _get_priogrid_db(job_data)
    elif source == "file":
        extras["times"] = _get_times_file(job_data)
        extras["priogrid"] = _get_priogrid_file(job_data)

    else:
        msg = f"Unrecognized data source {source}"
        raise RuntimeError(msg)

    return extras
