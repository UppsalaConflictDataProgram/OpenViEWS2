""" Utilities for plotting with geopandas.

For usage see notebooks/plots/maps_convenient.ipynb
"""

import os

import yaml
import pandas as pd
import geopandas as gpd
import ipywidgets as widgets

from views.utils import dbutils
from views.utils import config


# @TODO: Move to datautils
def _get_times(df):
    return sorted(list(set(df.index.get_level_values(0))))


# @TODO: Move to datautils


def _get_times_not_missing(df, col):
    """ Get a sorted list of unique time indices where col not missing """
    return sorted(list(set(df[~df[col].isnull()].index.get_level_values(0))))


def _groupvar_from_loa(loa):
    if loa == "cm":
        groupvar = "country_id"
    elif loa == "pgm":
        groupvar = "pg_id"
    else:
        raise RuntimeError(f"Unrecgnised loa {loa}")

    return groupvar


# @TODO: Move somewhere?
def _get_dir_runs():
    return config.CONFIG["dirs"]["dir_runs"]


# @TODO: Move somewhere?
def _get_dir_datasets(name_run):
    """ Get path to datets dir of name_run """
    return os.path.join(_get_dir_runs(), name_run, "datasets")


def gdf_geometry_from_db(loa):
    """ Get a GeoPandas Dataframe with id and geometry column for loa

    Args:
        loa: Level of analysis. Either "pgm" or "cm"
    Returns:
        gdf: GeoDataFrame with index set as groupvar and geometry col
    """

    def gdf_query_from_loa(loa):
        if loa == "cm":
            query = "SELECT id AS country_id, geom "
            query += "FROM staging.country WHERE gweyear=2016 AND gwemonth=6;"
        elif loa == "pgm":
            query = "SELECT gid AS pg_id, geom FROM staging.priogrid;"
        else:
            raise RuntimeError(f"Unrecgnised loa {loa}")

        return query

    groupvar = _groupvar_from_loa(loa)
    query = gdf_query_from_loa(loa)
    gdf = gpd.GeoDataFrame.from_postgis(
        query, dbutils.make_engine(), geom_col="geom"
    )
    gdf = gdf.set_index([groupvar])
    return gdf


def gdf_from_db(fqtable, loa, timevar="month_id"):
    """ Get a GeoDataFrame with data and geometry from db"""

    groupvar = _groupvar_from_loa(loa)
    df = dbutils.db_to_df(fqtable, ids=[timevar, groupvar])
    gdf = gdf_geometry_from_db(loa)
    gdf = gdf.join(df, how="inner")

    return gdf


def gdf_from_local(name_run, name_dataset):
    """ Get a GeoDataFrame with local run data and geometry from db

    The geometry to fetch is inferred from the loa of the run
    specfile.

    Args:
        name_run: Name of the run to lookup in dir_runs
        name_dataset: Name of the dataset to load
    Returns:
        gdf: A GeoDataFrame with geometry and the dataset from the run

    """
    dir_runs = config.CONFIG["dirs"]["dir_runs"]
    path_spec = os.path.join(dir_runs, name_run, "spec.yaml")
    with open(path_spec, "r") as f:
        spec = yaml.safe_load(f)
    loa = spec["loa"]
    path_dataset = os.path.join(
        _get_dir_runs(), name_run, "datasets", name_dataset
    )

    gdf = gdf_geometry_from_db(loa)
    df = pd.read_hdf(path_dataset)
    gdf = gdf.join(df, how="inner")
    return gdf


def cols_sans_geom(df):
    """ Get all cols in in df except "geom" """
    return [col for col in df.columns if not col == "geom"]


def get_dropdown_runs():
    """ Dropdown to choose runs on local machine """
    dir_runs = config.CONFIG["dirs"]["dir_runs"]
    names_runs = [
        dirr
        for dirr in os.listdir(dir_runs)
        if os.path.isdir(os.path.join(dir_runs, dirr))
    ]

    dropdown_runs = widgets.Dropdown(
        options=names_runs, value=names_runs[0], description="Runs:"
    )

    return dropdown_runs


def get_dropdown_datasets(name_run):
    """ Dropdown for chosing dataset from a local run """
    fnames = os.listdir(_get_dir_datasets(name_run))

    dropdown_datasets = widgets.Dropdown(
        options=fnames, value=fnames[0], description="Datasets:"
    )

    return dropdown_datasets


def get_dropdown_times(df, col):
    """ Dropdown of times with data for col in df """

    times = _get_times_not_missing(df, col)
    if times:
        default = times[-1]
        dropdown = widgets.Dropdown(
            options=times, value=default, description="Time:"
        )
    else:
        dropdown = None
        print("Column f{col} has no values for any time")

    return dropdown


def get_dropdown_cols(df):
    """ Dropdown for cols in df except geom"""
    cols = cols_sans_geom(df)
    dropdown = widgets.Dropdown(
        options=cols, value=cols[0], description="Col to plot:"
    )
    return dropdown


def get_dropdown_modes():
    """ Dropdown for choice between db or local """
    modes = ["db", "local"]
    dropdown = widgets.Dropdown(
        options=modes, value=modes[0], description="Mode:"
    )
    return dropdown


def get_dropdown_schemas(default_schema="landed"):
    """ Dropdown for schemas in database """
    schemas = dbutils.list_schemas_in_db()
    dropdown = widgets.Dropdown(
        options=schemas, value=default_schema, description="Schema:"
    )
    return dropdown


def get_dropdown_tables(schema):
    """ Dropdown of tables in schema """
    tables = dbutils.list_tables_in_schema(schema)
    dropdown = widgets.Dropdown(
        options=tables, value=tables[0], description="Table:"
    )
    return dropdown


def get_dropdown_loas():
    """ Dropdown for choice between cm and pgm """
    loas = ["cm", "pgm"]
    dropdown = widgets.Dropdown(options=loas, value=loas[0], description="LOA:")
    return dropdown


def get_dropdown_logitbool():
    """ Dropdown for choice between True or False """
    bools = [True, False]
    dropdown = widgets.Dropdown(options=bools, value=True, description="Logit?")
    return dropdown
