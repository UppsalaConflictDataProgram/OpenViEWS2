""" Main worker for mapmaking, call with a job and it delivers """

import os

from views.apps.plot.maps import mapdata
from views.apps.plot.maps import maputils
from views.apps.plot.maps import plot


def _plotfunc_switcher(job):
    """ Given a job description return the correct plotting function """

    if job["data"]["loa"] == "pgm":
        plotfunc = plot.plot_map_pgm
    elif job["data"]["loa"] == "cm":
        plotfunc = plot.plot_map_cm

    return plotfunc


# pylint: disable=too-many-locals
def worker(job):
    """ Main map worker

    Job values:
        name:
        destination: destination directory
        proj: "cyl" or "orth"
        crop: "africa" or "world"
        var_scale: "logodds", "interval" or "prob"
        data:
            source: "file" or "db"
            loa: "pgm" or "cm"
            source_plotvar: path or db-table
            source_actual: path or db-table
            name_plotvar: colname of var to plot
            name_actual: colname of actual events
            transform: list of transformations


    Args:
        job: dict with job parameters"""
    df = mapdata.get_data(job)
    extras = mapdata.get_extras(job)

    map_bounds = maputils.get_map_bounds(crop=job["crop"])
    cmap = maputils.get_cmap(job["var_scale"])
    ticks = maputils.make_ticks(job["var_scale"])

    times = sorted(list(set(df.index.get_level_values(0))))
    text_box = maputils.make_textbox(job)

    df_events = maputils.make_df_events(df, job, extras)

    for t in times[0:1]:

        t = int(t)

        df_t = df.loc[t]

        fname = f"{job['name']}_{t}.png"
        path = os.path.join(job["destination"], fname)
        datestr = maputils.month_id_to_datestr(extras["times"], t)
        title = datestr
        events = maputils.get_events_t(df_events, t)

        meta = {
            "path": path,
            "proj": job["proj"],
            "var_scale": job["var_scale"],
            "map_bounds": map_bounds,
            "ticks": ticks,
            "title": title,
            "text_box": text_box,
        }

        plotfunc = _plotfunc_switcher(job)

        plotfunc(
            path=path,
            df_t=df_t[["plotvar"]],
            events=events,
            cmap=cmap,
            meta=meta,
        )
