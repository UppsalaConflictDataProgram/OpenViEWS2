import pandas as pd
import numpy as np
import logging
import matplotlib.pyplot as plt
from views.utils import dbutils
from views.apps.evaluate import eval_data

Logger = logging.getLogger(__name__)


def plot_dumbbell(df, col_a, col_b, col_label, title, to_path):
    """Plots vertical dumbbell chart for selected deltas.

    Args:
        df: Pd dataframe containing the data to plot.
        col_a (str): "Previous" data to plot. Column name in df.
        col_b (str): "Current" data to plot. Column name in df.
        col_label (str): Column name in df of label to plot.
        title (str): Title to give to figure.
        to_path (str): Full path including filename and extension.

    Returns:
        Writes figure to to_path.
    """

    df["delta"] = df[col_b] - df[col_a]

    ordered_df = df.sort_values(by='delta')
    my_range = range(1, len(df.index) + 1)

    # Plot.
    fig, ax = plt.subplots(figsize=(10, 12))
    plt.hlines(
        y=my_range,
        xmin=ordered_df[col_a],
        xmax=ordered_df[col_b],
        color='grey',
        alpha=0.4
    )
    plt.scatter(
        ordered_df[col_a],
        my_range,
        color='red',
        alpha=0.4,
        label=col_a
    )
    plt.scatter(
        ordered_df[col_b],
        my_range,
        color='red',
        alpha=1,
        label=col_b
    )
    ax.grid(
        which="major",
        axis="x",
        linestyle="--",
        dashes=(2, 3),
        lw=1,
        color="black",
        alpha=0.2,
    )
    plt.legend(loc="upper left", prop={'size': 9})

    # Add yticks, axis label, title.
    plt.yticks(my_range, ordered_df[col_label], size=11)
    plt.xlabel('Predicted probability', size=14)
    plt.title(
        title,
        loc='left',
        size=15
    )
    plt.tight_layout()
    plt.savefig(to_path, dpi=250)
    Logger.info(f"Saved figure to {to_path}.")
    plt.close()
