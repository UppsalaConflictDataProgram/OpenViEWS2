""" Constants for maps """


BOUNDS = {
    "africa": {
        "lon_min": -18.25,
        "lon_max": 51.75,
        "lat_min": -34.75,
        "lat_max": 37.75,
    },
    "world": {"lon_min": -180, "lon_max": 180, "lat_min": -57, "lat_max": 85},
}

C_VARNAME_SHP = "ID"
C_PATH_SHP = "/storage/runs/current/ds/input/cm/spatial/country"
PG_VARNAME_SHP = "GID"
PG_PATH_SHP = "/storage/runs/current/ds/input/pgm/spatial/priogrid"

FQ_MONTHS = "maps.maps_months"
FQ_PRIOGRID = "maps.maps_priogrid"
PATH_MONTHS = "/storage/temp/maps/workdata/df_months.hdf5"
PATH_PRIOGRID = "/storage/temp/maps/workdata/df_priogrid.hdf5"

PATH_LOGO_EU = "/storage/static/logos/eu.png"
PATH_LOGO_ERC = "/storage/static/logos/erc.png"
PATH_LOGO_VIEWS = "/storage/static/logos/views.png"
