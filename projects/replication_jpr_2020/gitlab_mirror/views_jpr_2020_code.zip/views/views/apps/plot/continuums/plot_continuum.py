""" Continuum plot module """

# pylint: skip-file

import colorsys
import os
import numpy as np
from adjustText import adjust_text
import matplotlib.pyplot as plt
from matplotlib import patches
from views.apps.survey import survey_generator as sg
from views.apps.survey import summary_generator as smg


def get_rgb(value):
    """Gets rgb value from 0-100 set range"""

    rgb = colorsys.hsv_to_rgb(value / 150.0, 1.0, 1.0)
    rgb = tuple([round(255 * x) for x in rgb])
    rgb = "#%02x%02x%02x" % rgb

    return rgb


def split_string(line, spaces=7):
    """Splits string according to number of spaces"""

    n = spaces
    groups = line.split(" ")
    groups = [" ".join(groups[i : i + n]) for i in range(0, len(groups), n)]
    joined = "\n".join(groups)

    return joined


def build_continuum_dict(issue_id, interview=False):
    """Builds continuum dict as input for continuum figure"""

    continuum_dict = {}

    # put issue base into dict
    if interview is True:
        issue_base_rows = smg.get_issue_base_interview(issue_id)
    else:
        issue_base_rows = sg.get_issue_base(issue_id)

    # labels
    left_extreme = split_string(issue_base_rows[0]["left_extreme"])
    left_extreme = "$\\bf{Extreme\\ A}$ \n" + left_extreme
    right_extreme = split_string(issue_base_rows[0]["right_extreme"])
    right_extreme = "$\\bf{Extreme\\ B}$ \n" + right_extreme
    status_quo = split_string(issue_base_rows[0]["status_quo"])
    status_quo = "$\\bf{Status\\ quo}$" + f"\n{status_quo}"

    # put in dict
    continuum_dict[left_extreme] = 0
    continuum_dict[right_extreme] = 100
    continuum_dict[status_quo] = issue_base_rows[0]["status_quo_location"]

    # put issue stakeholder into dict
    if interview is True:
        issue_stakeholder_rows = smg.get_issue_stakeholder_interview(issue_id)
    else:
        issue_stakeholder_rows = sg.get_issue_stakeholder(issue_id)

    # get names
    for row in issue_stakeholder_rows:
        if interview is True:
            name = smg.get_stakeholder_name_interview(row["stakeholder_id"])
        else:
            name = sg.get_stakeholder_name(row["stakeholder_id"])
        name = name.replace(" ", "\\ ")
        label = "$\\bf{{{name}}}$".format(name=name) + f"\n{row['label']}"
        label = split_string(label)
        continuum_dict[label] = row["position"]

    return continuum_dict


def plot_continuum(issue_id, interview=False):
    """Plots continuum for a particular issue-stakeholder set"""

    continuum_dict = build_continuum_dict(issue_id, interview)

    # get information for title
    if interview is True:
        issue_name = smg.get_issue_base_interview(issue_id)
        issue_name = issue_name[0]["name"]
        interview_id = smg.get_interview_id_from_issue(issue_id)
        country_name = smg.get_country_name_interview(interview_id)
    else:
        issue_name = sg.get_issue_base(issue_id)
        issue_name = issue_name[0]["name"]
        survey_id = sg.get_survey_id_from_issue(issue_id)
        round_id = sg.get_round_id_from_survey(survey_id)
        country_name = sg.get_country_name(survey_id)

    # set figure
    fig, ax = plt.subplots(figsize=(14, 5))

    # empty list to store text annotations; used for adjust_text()
    texts = []

    # location list
    xy_main = []

    # plot markers and text annotations
    for name, location in continuum_dict.items():
        if (location, 0) in xy_main:
            xy_sub = [i for i in xy_main if i[0] == location]
            y = max(xy_sub, key=lambda x: x[1])[1]
            y = y + 1
        else:
            y = 0

        # plot with wiggle to avoid sticking behavior (not 100%)
        texts.append(
            plt.text(
                location + np.random.random() / 1000,
                y + np.random.random() / 1000,
                name,
                fontsize=8,
            )
        )
        plt.plot(
            location,
            y,
            marker="o",
            markersize=25,
            color=get_rgb(location),
            alpha=0.5,
        )
        xy_main.append((location, y))

    # set x-axis to middle of figure and hide other axes
    ax.spines["left"].set_position("center")
    ax.spines["right"].set_color("none")
    ax.spines["bottom"].set_position("center")
    ax.spines["bottom"].set_color("#505050")
    ax.spines["top"].set_color("none")
    ax.spines["left"].set_color("none")
    ax.spines["left"].set_smart_bounds(True)

    # set ax properties (lims, ticks, thickness)
    ax.set_xlim(-2.5, 102.5)
    plt.setp(ax.spines.values(), linewidth=4)
    ax.set_xticks([i for i in range(0, 105, 5)])
    ax.set_ylim(-5, 5)
    ax.tick_params(length=5)
    ax.set_yticks([])

    # create virtual space around axis and ticks to repel against
    patch = patches.Rectangle((-2.5, -0.6), 105, 0.8, fill=False, alpha=0)
    ax.add_patch(patch)

    # repel function, with arrow properties set inside
    adjust_text(
        texts,
        autoalign=False,
        ha="left",
        va="center",
        add_objects=[patch],
        force_objects=(0, 1.5),
        only_move={"points": "x", "text": "y", "objects": "y"},
        expand_text=(1, 1.5),
        force_text=(0.1, 1),
        expand_points=(1.2, 1),
        force_points=(0.3, 0),
        arrowprops=dict(arrowstyle="-|>", color="black", lw=0.7),
    )

    # get path
    this_dir = os.path.dirname(os.path.abspath(__file__))

    # add title and save
    if interview is True:
        expert_foreign_id = smg.get_expert_foreign_id_interview(interview_id)

        title = f"{country_name}, issue '{issue_name}', {expert_foreign_id}, interview"
        filename = f"issue_{country_name.lower()}_{expert_foreign_id}_{issue_id}_interview.pdf"
        print(title)

        plt.title(
            split_string(title), loc="left", fontsize=14, fontweight="bold"
        )
        plt.savefig(f"{this_dir}/{filename}", bbox_inches="tight")
        # duplicate with only issue_id as marker
        plt.savefig(f"{this_dir}/{issue_id}.pdf", bbox_inches="tight")
        plt.close("all")

    else:
        expert_id = sg.get_expert_id_from_survey(survey_id)
        expert_foreign_id = sg.get_expert_foreign_id(expert_id)

        title = f"{country_name}, issue '{issue_name}', {expert_foreign_id} r{round_id}"
        print(title)
        plt.title(
            split_string(title), loc="left", fontsize=14, fontweight="bold"
        )
        plt.savefig(
            f"issue_{country_name.lower()}_{expert_foreign_id}_{issue_id}_r{round_id}.pdf",
            bbox_inches="tight",
        )
        plt.close("all")

    # returning the dir for summary report generation
    return this_dir


def main():
    """Main function generating continuums for all issues recorded"""

    # interviews
    issue_ids = smg.get_all_issue_ids_interview()
    for i in issue_ids:
        plot_continuum(issue_id=i, interview=True)

    # survey responses
    issue_ids = sg.get_all_issue_ids()
    for i in issue_ids:
        plot_continuum(issue_id=i, interview=False)


if __name__ == "__main__":
    main()
