import json

import psutil

import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from views.apps.ensemble import calibrate, ebma
from views.utils import pyutils, datautils


def modelname_from_step_prediction_name(step_prediction_name):
    return step_prediction_name.replace("ss.", "").split(".")[0]


def interpolate_weights(weights_by_step):
    """ Interpolate weights by step """

    steps = list(weights_by_step.keys())
    df_w = pd.DataFrame(weights_by_step)
    df_w = df_w.T
    df_w.index.name = "step"
    df_w = df_w.reindex(list(range(min(steps), max(steps) + 1))).interpolate()
    df_w_json = df_w.T.to_json()
    filled_weights_by_step = json.loads(df_w_json)
    return filled_weights_by_step


def make_ensemble_dict(name, outcome, col_actual, models, steps):
    """ Defines names and structures for ensemble dictionary

    Args:
        name: Descriptive name
        outcome: sb/ns/os, does nothing
        col_actual: Name of actual column to calibrate/evaluate against
        models: list of constituent model columns
        steps: list of steps
    Returns:
        ensemble: dictionary of names

    """

    ensemble = dict()

    ensemble["name"] = name
    ensemble["outcome"] = outcome
    ensemble["col_actual"] = col_actual
    ensemble["models"] = models
    ensemble["steps"] = steps

    # Get names of ss cols for all models by step
    ensemble["cols_constituent_ss"] = {
        step: [f"ss.{model}.{step}" for model in models] for step in steps
    }

    # Name ebma columns, both ss and sc
    ensemble["col_ebma_sc"] = f"sc_ebma.{name}"
    ensemble["col_ebma_ss"] = {step: f"ss_ebma.{name}.{step}" for step in steps}

    # Name unweighted average columns
    ensemble["col_avg_sc"] = f"sc_avg.{name}"
    ensemble["col_avg_ss"] = {step: f"ss_avg.{name}.{step}" for step in steps}

    # Name unweighted average columns
    ensemble["col_rfstack_sc"] = f"sc_rfstack.{name}"
    ensemble["col_rfstack_ss"] = {
        step: f"ss_rfstack.{name}.{step}" for step in steps
    }

    ensemble["weights_ebma_ab"] = None
    ensemble["weights_ebma_bc"] = None
    ensemble["weights_ebma_bc_ipolated"] = None

    return ensemble


def ss_ebma(ensemble, df_calib, df_test):
    """ Step-specific EBMA """

    weights_by_step = {}
    predictions_by_step = {}
    col_actual = ensemble["col_actual"]

    for step in ensemble["steps"]:

        # The constituent model cols for this step
        cols_ss_step = ensemble["cols_constituent_ss"][step]
        # The name of this steps ebma_ss predictions
        name_ebma_step = ensemble["col_ebma_ss"][step]

        s_ebma, weights = ebma.ebma(
            df_calib=df_calib[cols_ss_step],
            df_test=df_test[cols_ss_step],
            s_calib_actual=df_calib[col_actual],
        )

        # Weights from ebma have the step number attached, remove it
        weights = {
            modelname_from_step_prediction_name(key): value
            for key, value in weights.items()
        }
        # Store weights and predictions in by-step dict
        weights_by_step[step] = weights
        predictions_by_step[name_ebma_step] = s_ebma

    # Make the dictionary of prediction series into a dataframe
    df_prediction_by_step = pd.DataFrame(predictions_by_step)

    return weights_by_step, df_prediction_by_step


def sc_ebma(ensemble, df_test):
    """ Step combined EBMA steps by selecting and interpolating
        step specific EBMA predictions
    """

    steps = ensemble["steps"]
    t_start = df_test.index.levels[0].min()

    # Series to hold our predictions
    s_ebma = pd.Series(index=df_test.index)

    for step in steps:
        # For step 1 predict into t_start
        t = t_start + step - 1
        col_ebma_step = ensemble["col_ebma_ss"][step]

        # Put average of calibrated constituent models for t in t
        s_ebma.loc[t] = df_test.loc[t, col_ebma_step].values

    s_ebma.name = ensemble["col_ebma_sc"]
    # We only have step-specific predictions, interpolate them
    s_ebma = datautils.interpolate(s_ebma)

    return s_ebma


def ss_calibrated_unweighted_average(ensemble, df_calib, df_test):
    """ Step specific calibrated unweighted average """

    col_actual = ensemble["col_actual"]
    steps = ensemble["steps"]
    predictions_by_step = dict()

    for step in steps:
        cols_ss_step = ensemble["cols_constituent_ss"][step]
        col_avg_ss = ensemble["col_avg_ss"][step]

        df_test_calibrated = calibrate.calibrate_models(
            df_calib=df_calib[cols_ss_step],
            df_test=df_test[cols_ss_step],
            s_calib_actual=df_calib[col_actual],
        )

        s_avg = df_test_calibrated.mean(axis=1)
        predictions_by_step[col_avg_ss] = s_avg

    df_predictions_by_step = pd.DataFrame(predictions_by_step)

    return df_predictions_by_step


def sc_calibrated_unweighted_average(ensemble, df_calib, df_test):
    """ Step combined calibrated unweighted average """

    col_actual = ensemble["col_actual"]
    steps = ensemble["steps"]
    t_start = df_test.index.levels[0].min()

    # Series to hold our predictions
    s_avg = pd.Series(index=df_test.index)

    for step in steps:
        # For step 1 predict into t_start
        t = t_start + step - 1

        cols_ss_step = ensemble["cols_constituent_ss"][step]

        # Calibrate constituent models for this step
        df_test_calibrated = calibrate.calibrate_models(
            df_calib=df_calib[cols_ss_step],
            df_test=df_test[cols_ss_step],
            s_calib_actual=df_calib[col_actual],
        )

        # Put average of calibrated constituent models for t in t
        s_avg.loc[t] = df_test_calibrated.mean(axis=1).loc[t].values

    s_avg.name = ensemble["col_avg_sc"]
    # We only have step-specific predictions, interpolate them
    s_avg = datautils.interpolate(s_avg)

    return s_avg


def ss_rfstack(ensemble, df_calib, df_test, n_estimators=1000):
    """ Step-specific Random Forest stack """
    col_actual = ensemble["col_actual"]
    steps = ensemble["steps"]
    predictions_by_step = dict()
    feature_importances = dict()

    s_calib_actual = df_calib[col_actual]

    for step in steps:
        cols_ss_step = ensemble["cols_constituent_ss"][step]
        col_rfstack = ensemble["col_rfstack_ss"][step]

        # Estimate a random forest
        est = RandomForestClassifier(
            n_estimators=n_estimators, n_jobs=psutil.cpu_count(logical=False)
        )
        est.fit(df_calib[cols_ss_step], s_calib_actual)

        # Predict with it into calib and test
        y_calib = est.predict_proba(df_calib[cols_ss_step])[:, 1]
        y_test = est.predict_proba(df_test[cols_ss_step])[:, 1]

        # Cast to series, set names and indexes
        y_calib = pd.Series(y_calib, index=df_calib.index, name="rfstack")
        y_test = pd.Series(y_test, index=df_test.index, name="rfstack")

        # Calibrate the predictions
        df_rfstack_test_calibrated = calibrate.calibrate_models(
            df_calib=pd.DataFrame(y_calib),
            df_test=pd.DataFrame(y_test),
            s_calib_actual=s_calib_actual,
        )

        # calibrate models gives a dataframe,
        # cast to series and set indexes
        s_rfstack_test = df_rfstack_test_calibrated["rfstack"]
        s_rfstack_test.index = df_test.index
        s_rfstack_test.name = col_rfstack

        predictions_by_step[col_rfstack] = s_rfstack_test

        fi = {
            key: value
            for key, value in zip(list(cols_ss_step), est.feature_importances_)
        }
        feature_importances[step] = fi

    df_predictions_by_step = pd.DataFrame(predictions_by_step)

    return df_predictions_by_step, feature_importances


def sc_rfstack(ensemble, df_test):
    """ Combine steps of Random Forest Stack """

    steps = ensemble["steps"]
    t_start = df_test.index.levels[0].min()

    # Series to hold our predictions
    s_rfstack = pd.Series(index=df_test.index)

    for step in steps:
        # For step 1 predict into t_start
        t = t_start + step - 1
        col_rfstack_step = ensemble["col_rfstack_ss"][step]

        # Put average of calibrated constituent models for t in t
        s_rfstack.loc[t] = df_test.loc[t, col_rfstack_step].values

    s_rfstack.name = ensemble["col_rfstack_sc"]
    # We only have step-specific predictions, interpolate them
    s_rfstack = datautils.interpolate(s_rfstack)

    return s_rfstack
