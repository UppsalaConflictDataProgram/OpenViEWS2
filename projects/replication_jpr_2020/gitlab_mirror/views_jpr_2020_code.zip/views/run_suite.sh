#!/bin/zsh

TIMEFORMAT=%R

# conda activate doesnt work properly in scripts
# sue absolute path to bin of tools instead
conda_env_dir="$HOME/miniconda3/envs/views/bin"

# Run black for formatting
echo "BLACK"
time $conda_env_dir/black --line-length 80 ./views/

# Run the tests
echo "TESTS"
$conda_env_dir/coverage erase
VIEWS_MODE=test
find views/tests/ -name 'test_*.py' -exec echo {}  \; -exec $conda_env_dir/coverage run -a {} \;
echo "-------------------------------------------------------------"

# Show coverage report
echo "TEST COVERAGE REPORT:"
$conda_env_dir/coverage report -m
echo "-------------------------------------------------------------"

# Show pylint
echo "LINTS"
time find ./views/ -name '*.py' | xargs $conda_env_dir/pylint
wait

# Show git status
echo "GIT"
git status
