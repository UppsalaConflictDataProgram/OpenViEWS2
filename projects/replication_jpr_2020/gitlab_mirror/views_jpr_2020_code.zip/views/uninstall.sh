#!/bin/bash
echo "Activating env"
source activate views
echo "Running python setup.py develop --uninstall"
python setup.py develop --uninstall
echo "Running source deactivate"
source deactivate
echo "Running conda remove --name views --all --yes"
conda remove --name views --all --yes
