#python ~/gitlab/views/views/apps/nds/main.py --path_paramfile ~/gitlab/views/runs/r_2020_02_02/ds/paramfile_pgm_c.json --dir_input ~/views/test/ds/input --dir_results ~/views/test/ds/results

python ~/gitlab/views/views/apps/nds/main.py --path_paramfile ~/gitlab/views/runs/r_2020_02_02/ds/paramfile_cm_c.json --dir_input ~/views/test/ds/input --dir_results ~/views/test/ds/results