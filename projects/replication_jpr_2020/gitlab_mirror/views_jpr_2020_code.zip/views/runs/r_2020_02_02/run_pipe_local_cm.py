import os
import logging

from views.utils import pyutils
from views.apps.pipe import manager

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
Logger = logging.getLogger(__name__)

this_dir = os.path.dirname(__file__)

manager.run_specfile(
    path_spec=os.path.join(this_dir, "cm.yaml"), mode="normal",
)
