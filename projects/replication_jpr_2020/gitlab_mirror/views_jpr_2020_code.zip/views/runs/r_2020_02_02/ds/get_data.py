from views.apps.transforms import translib, spatial
from views.utils import dbutils


def _get_pgm_data():
    cols = [
        "acled_dummy_pr",
        "ged_best_ns",
        "ged_best_os",
        "ged_best_sb",
        "ged_dummy_ns",
        "ged_dummy_os",
        "ged_dummy_sb",
        "pgd_agri_ih",
        "pgd_barren_ih",
        "pgd_bdist3",
        "pgd_capdist",
        "pgd_diamsec",
        "pgd_excluded",
        "pgd_forest_ih",
        "pgd_gcp_mer",
        "pgd_imr_mean",
        "pgd_mountains_mean",
        "pgd_pasture_ih",
        "pgd_petroleum",
        "pgd_pop_gpw_sum",
        "pgd_savanna_ih",
        "pgd_urban_ih",
        "pgd_ttime_mean",
        "pgd_shrub_ih"
    ]

    ids_pgm = ["month_id", "pg_id"]
    df = dbutils.db_to_df_fast(fqtable="flat.pgm_africa_1", columns=cols, ids=ids_pgm)



    gdf_geom = dbutils.db_to_gdf(query="SELECT gid AS pg_id, geom FROM staging.priogrid", groupvar="pg_id")

    gdf = gdf_geom.join(df)

    df['dist_pgd_diamsec'] = spatial.distance_to_event(gdf, event_col="pgd_diamsec")
    df['dist_pgd_petroleum'] = spatial.distance_to_event(gdf, event_col="pgd_petroleum")
    df['greq_25_ged_best_sb'] = translib.greater_or_equal(df['ged_best_sb'], value=25)
    df['greq_25_ged_best_ns'] = translib.greater_or_equal(df['ged_best_ns'], value=25)
    df['greq_25_ged_best_os'] = translib.greater_or_equal(df['ged_best_os'], value=25)
    df['dummy_pgd_excluded'] = translib.greater_or_equal(df['pgd_excluded'], value=1)

    df['ln_pgd_pop_gpw_sum'] = translib.natural_log(df['pgd_pop_gpw_sum'])
    df['ln_pgd_bdist3'] = translib.natural_log(df['pgd_bdist3'])
    df['ln_pgd_ttime_mean'] = translib.natural_log(df['pgd_ttime_mean'])
    df['ln_dist_pgd_diamsec'] = translib.natural_log(df['dist_pgd_diamsec'])
    df['ln_dist_pgd_petroleum'] = translib.natural_log(df['dist_pgd_petroleum'])
    df['ln_pgd_capdist'] = translib.natural_log(df['pgd_capdist'])


    path = "/Users/frehoy/views/test/ds/input/pgm/data/pgm_africa.hdf5"
    df.reset_index().to_hdf(path, key='data')

def get_pgm_data():
    cols = [
    "acled_dummy_pr",
    "ged_best_ns",
    "ged_best_os",
    "ged_best_sb",
    "ged_dummy_ns",
    "ged_dummy_os",
    "ged_dummy_sb",
    "pgd_agri_ih",
    "pgd_barren_ih",
    "pgd_bdist3",
    "pgd_capdist",
    "pgd_diamsec",
    "pgd_excluded",
    "pgd_forest_ih",
    "pgd_gcp_mer",
    "pgd_imr_mean",
    "pgd_mountains_mean",
    "pgd_pasture_ih",
    "pgd_petroleum",
    "pgd_pop_gpw_sum",
    "pgd_savanna_ih",
    "pgd_urban_ih",
    "pgd_ttime_mean",
    "pgd_shrub_ih",
    "spdist_pgd_diamsec",
    "spdist_pgd_petroleum",
    "greq_25_ged_best_sb",
    "greq_25_ged_best_ns",
    "greq_25_ged_best_os",
    "pgd_excluded",
    "pgd_pop_gpw_sum",
    "pgd_bdist3",
    "pgd_ttime_mean",
    "pgd_capdist",
    ]

    df = dbutils.db_to_df_fast(
        fqtable="flat.pgm_africa_1",
        ids=["month_id", "pg_id"],
        columns=cols,
        )

    df['dummy_pgd_excluded'] = translib.greater_or_equal(df['pgd_excluded'], value=1)
    df['ln_pgd_pop_gpw_sum'] = translib.natural_log(df['pgd_pop_gpw_sum'])
    df['ln_pgd_bdist3'] = translib.natural_log(df['pgd_bdist3'])
    df['ln_pgd_ttime_mean'] = translib.natural_log(df['pgd_ttime_mean'])
    df['ln_spdist_pgd_diamsec'] = translib.natural_log(df['spdist_pgd_diamsec'])
    df['ln_spdist_pgd_petroleum'] = translib.natural_log(df['spdist_pgd_petroleum'])
    df['ln_pgd_capdist'] = translib.natural_log(df['pgd_capdist'])

    path = "/Users/frehoy/views/test/ds/input/pgm/data/pgm_africa.hdf5"
    df.sort_index().reset_index().to_hdf(path, key="data")

def get_cm_data():
    cols = [
    "ged_dummy_ns",
    "ged_dummy_os",
    "ged_dummy_sb",
    "ged_best_ns",
    "ged_best_os",
    "ged_best_sb",
    "greq_25_ged_best_ns",
    "greq_25_ged_best_os",
    "greq_25_ged_best_sb",
    "greq_25_ged_best_ns",
    "greq_25_ged_best_os",
    "greq_25_ged_best_sb",
    "fvp_fvp_demo",
    "fvp_fvp_semi",
    "fvp_grgdpcap_nonoilrent",
    "fvp_grgdpcap_oilrent",
    "fvp_lngdpcap_nonoilrent",
    "fvp_lngdpcap_oilrent",
    "fvp_prop_excluded",
    "fvp_ssp2_edu_sec_15_24_prop",
    "fvp_ssp2_urban_share_iiasa",
    "fvp_population200",
    "fvp_timesinceregimechange",
    ]

    df = dbutils.db_to_df_fast(
        fqtable="flat.cm_africa_1",
        ids=["month_id", "country_id"],
        columns=cols,
    )

    df["greq_500_ged_best_any"] = 0
    df["sum_ged_best_any"] = df["ged_best_sb"] + df["ged_best_ns"] + df["ged_best_os"]
    df.loc[df["sum_ged_best_any"]>500, "greq_500_ged_best_any"] = 1
    path = "/Users/frehoy/views/test/ds/input/cm/data/cm_africa.hdf5"
    df.sort_index().reset_index().to_hdf(path, key="data")


if __name__ == "__main__":
    get_cm_data()
    get_pgm_data()