""" Run after the 108 are fininshed to collect and push to db """
from views.utils import datautils, dbutils
import pandas as pd
import make_108


def path_result(run_id):
    return f"~/views/test/ds/runs/{run_id}/aggregate/aggregated.hdf5"


def preprop_df(df, renames):
    """ Clean up the simulation names and assign the step column """

    # Subset to only wanted columns
    df = df[cols_want]
    # Strip _mean from the name
    df = df.rename(columns=renames)
    # df = df.rename(
    #     columns=lambda col: col.replace("_mean", "").replace("p_", "")
    # )

    # Assign the step column.
    # Step is how far into the future each row of predictions is
    df = df.reset_index()
    df["step"] = df.month_id - df.month_id.min() + 1
    df = df.set_index(["month_id", "country_id"])

    return df


def prepare_full(path, cols, renames):
    """ Load and cleanup the full runs """
    df = pd.read_hdf(path)
    df = df[cols]
    df = df.rename(columns=renames)
    # df = df.rename(
    #     columns=lambda col: col.replace("_mean", "").replace("p_", "")
    # )
    df = df.add_prefix("memt.")
    return df


slots = make_108.make_slots(397)

cols_want = [
    "p_greq_25_ged_best_ns_mean",
    "p_greq_25_ged_best_os_mean",
    "p_greq_25_ged_best_sb_mean",
    "p_ged_dummy_sb_mean",
    "p_ged_dummy_ns_mean",
    "p_ged_dummy_os_mean",
    "p_greq_500_ged_best_any_mean",
]

cols_want_pgm = [
    "p_greq_25_ged_best_ns_mean",
    "p_greq_25_ged_best_os_mean",
    "p_greq_25_ged_best_sb_mean",
    "p_ged_dummy_sb_mean",
    "p_ged_dummy_ns_mean",
    "p_ged_dummy_os_mean",
]

renames_cm = {
    "p_greq_25_ged_best_ns_mean" : "ns_ds_25",
    "p_greq_25_ged_best_os_mean" : "os_ds_25",
    "p_greq_25_ged_best_sb_mean" : "sb_ds_25",
    "p_ged_dummy_sb_mean" : "sb_ds_dummy",
    "p_ged_dummy_ns_mean" : "ns_ds_dummy",
    "p_ged_dummy_os_mean" : "os_ds_dummy",
    "p_greq_500_ged_best_any_mean" : "any_ds_500",
}

renames_pgm = {
    "p_greq_25_ged_best_ns_mean" : "ns_ds_25",
    "p_greq_25_ged_best_os_mean" : "os_ds_25",
    "p_greq_25_ged_best_sb_mean" : "sb_ds_25",
    "p_ged_dummy_sb_mean" : "sb_ds_dummy",
    "p_ged_dummy_ns_mean" : "ns_ds_dummy",
    "p_ged_dummy_os_mean" : "os_ds_dummy",
}




dfs = []
for slot in slots:
    path_df = path_result(slot["run_id"])
    df = pd.read_hdf(path_df)
    df = preprop_df(df, renames_cm)
    dfs.append(df)

df = pd.concat(dfs)
df = df.reset_index().set_index(["step"])

df_steps = []
for step in range(1, 37):
    df_step = df.loc[step].copy()
    df_step = df_step.reset_index().set_index(["month_id", "country_id"])
    df_step = df_step.add_suffix(f".{step}")
    df_step = df_step.drop(columns=[f"step.{step}"])
    df_steps.append(df_step)

df = datautils.merge_dfs(df_steps)
df = df.add_prefix("semt.")

# Load full 1000-sim runs for a, b and c
df_a_full = prepare_full(
    "/Users/frehoy/views/test/ds/runs/cm_v2_a/aggregate/aggregated.hdf5",
    cols_want,
    renames_cm
)
df_b_full = prepare_full(
    "/Users/frehoy/views/test/ds/runs/cm_v2_b/aggregate/aggregated.hdf5",
    cols_want,
    renames_cm
)
df_c = prepare_full(
    "/Users/frehoy/views/test/ds/results/r_2020_02_02_ds_cm_c/r_2020_02_02_ds_cm_c.hdf5",
    cols_want,
    renames_cm
)


# Subset to prediction period of each period
df_a = df.loc[397:432]
df_b = df.loc[433:468]
df_c = df_c.loc[481:518]

# Join in the full 1000 simulation runs for A and B
df_a = df_a.join(df_a_full)
df_b = df_b.join(df_b_full)


#dbutils.df_to_db(df=df_a, fqtable="newpipe.ds_cm_africa_1_a")
#dbutils.df_to_db(df=df_b, fqtable="newpipe.ds_cm_africa_1_b")
dbutils.df_to_db(df=df_c, fqtable="newpipe.ds_cm_africa_1_c_r2020_02_02")
# dbutils.df_to_db(
#     df=prepare_full(
#         "/Users/frehoy/views/test/ds/results/pgm_v0_a/pgm_v0_a.hdf5",
#         cols_want_pgm,
#         renames_pgm,
#     ),
#     fqtable="newpipe.ds_pgm_africa_1_a",
# )
# dbutils.df_to_db(
#     df=prepare_full(
#         "/Users/frehoy/views/test/ds/results/pgm_v0_b/pgm_v0_b.hdf5",
#         cols_want_pgm,
#         renames_pgm,
#     ),
#     fqtable="newpipe.ds_pgm_africa_1_b",
# )
dbutils.df_to_db(
    df=prepare_full(
        "/Users/frehoy/views/test/ds/results/r_2020_02_02_ds_pgm_c/r_2020_02_02_ds_pgm_c.hdf5",
        cols_want_pgm,
        renames_pgm,
    ),
    fqtable="newpipe.ds_pgm_africa_1_c_r2020_02_02",
)
print("Done")
