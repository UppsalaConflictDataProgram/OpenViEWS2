"""

Generate ds paramfiles to make every s-step ahead prediction for
each t of periods A and B.


periods:
  A: # Calibration period for B
  start: 397  # 2013-01
  end: 432    # 2015-12,
  B:  # Evaluation period. Calibration for C.
  start: 433  # 2016-01,
  end: 468    # 2018-12, last month yearly data
"""


import string
import os
import sys
from subprocess import call

from views.utils import pyutils


def make_slots(first_t_first_period):
    """ Make 107 time slots for simulation

    The goal is to produce time slots for simulation so that each
    time t in the two periods A and B get a S-step ahead prediction
    for each S in (1..36)
    """

    sim_start_first = first_t_first_period-35

    train_start = 121
    slots = []
    for slot_number, sim_start in enumerate(range(sim_start_first, sim_start_first+107)):
        sim_end = sim_start + 35
        train_end = sim_start - 1
        run_id = f"cm_v2_slot_{slot_number}"
        slot = {
            "run_id": run_id,
            "sim_start": sim_start,
            "sim_end": sim_end,
            "train_start": train_start,
            "train_end": train_end
        }
        slots.append(slot)
    return slots

def make_paramfiles(slots):

    this_dir = os.path.dirname(__file__)
    path_template = os.path.join(this_dir, "..", "paramfile_templates", "cm_v2.json")
    with open(path_template, "r") as f:
        template = string.Template(f.read())

    dir_paramfiles = pyutils.resole_vars_and_home("~/views/test/ds/paramfiles")
    paths_paramfiles = []
    for slot in slots:

        params = template.substitute(**slot)
        fname = slot["run_id"] + ".json"
        path_paramfile = os.path.join(dir_paramfiles, fname)
        with open(path_paramfile, "w") as f:
            f.write(params)
        #print(f"Wrote {path_paramfile}")
        paths_paramfiles.append(path_paramfile)

    return paths_paramfiles




def main():

    first_t_first_period = 397

    slots = make_slots(first_t_first_period)
    pyutils.pprint(slots)
    paths_paramfiles = make_paramfiles(slots)


    runfile_header = """
    conda activate views

    cd ~/gitlab/views/views/apps/ds

    echo "Done?"
    """

    run_template = "python main.py  --dir_scratch ~/views/test/ds/runs/ --dir_input ~/views/test/ds/input --path_paramfile ${path_paramfile} \n"
    run_template = string.Template(run_template)

    runfile = runfile_header
    for path_paramfile in paths_paramfiles:
        runfile += run_template.substitute({"path_paramfile": path_paramfile})
    this_dir = os.path.dirname(__file__)
    path_runfile = os.path.join(this_dir, "runfile_108.sh")
    with open(path_runfile, "w") as f:
        f.write(runfile)
    print(f"Wrote {path_runfile}")

if __name__ == "__main__":
    main()