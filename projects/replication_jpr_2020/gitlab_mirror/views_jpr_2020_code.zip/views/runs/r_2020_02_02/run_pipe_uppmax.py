import logging
from views.utils import pyutils
from views.apps.slurm_broker import slurm_broker

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
Logger = logging.getLogger(__name__)

cmd_cm = (
    "~/miniconda3/envs/views/bin/python "
    "~/gitlab/views/views/apps/pipe/manager.py "
    "--slurm "
    "--tasks_per_seq_job 100 "
    "--hours_per_job 12 "
    "--path_specfile ~/gitlab/views/runs/r_2020_02_02/cm.yaml "
)
cmd_pgm = (
    "~/miniconda3/envs/views/bin/python "
    "~/gitlab/views/views/apps/pipe/manager.py "
    "--slurm "
    "--tasks_per_seq_job 5 "
    "--hours_per_job 24 "
    "--path_specfile ~/gitlab/views/runs/r_2020_02_02/pgm.yaml "
)

slurm_broker.run_command(cmd_cm, hours=24 * 7, cores=1, jobtype="core")
slurm_broker.run_command(cmd_pgm, hours=24 * 7, cores=1, jobtype="core")
