import logging


import os
from views.utils import pyutils, datautils, dbutils, config
from views.apps.defparser import solver



logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)

def get_outcomes_from_spec(spec):
    models = spec['formulas']
    outcomes = pyutils.dedup_list([model['lhs'] for model in models.values()])
    return outcomes

def publish_run(path_spec, dir_runs):

    spec = pyutils.load_yaml(path_spec)
    tasks=solver.tasks(defis=solver.defis(spec), specs=spec)
    name_run = spec['name']


    for name_dataset, dataset in tasks['datasets'].items():
        if "_predict" in name_dataset:
            t_start = dataset['times']['start']
            t_end = dataset['times']['end']
            fname = f"{name_dataset}.parquet"
            fqtable = f"newpipe.{name_dataset.lower()}_{name_run}"
            dir_datasets = os.path.join(dir_runs, name_run, "datasets")
            path_dataset = os.path.join(dir_datasets, fname)

            # Load dataset
            all_cols = datautils.list_columns_in_parquet(path_dataset)
            cols = [col for col in all_cols if col.startswith("semt.")]
            cols = cols + get_outcomes_from_spec(spec)
            df = datautils.load_parquet(path_dataset, cols=cols)
            df.sort_index(inplace=True)

            # Subset times
            df = df.loc[t_start:t_end] # Subset times

            # Push to db
            dbutils.df_to_db(df, fqtable)
            for col in df.columns:
                print(col)
            print(fqtable)

def main():
    dir_runs = os.path.join(config.CONFIG["dirs"]["dir_runs"])
    this_dir = os.path.dirname(__file__)
    path_spec_pgm = os.path.join(this_dir, "pgm.yaml")
    path_spec_cm = os.path.join(this_dir, "cm.yaml")
    publish_run(path_spec_pgm, dir_runs)
    publish_run(path_spec_cm, dir_runs)


if __name__ == "__main__":
    main()