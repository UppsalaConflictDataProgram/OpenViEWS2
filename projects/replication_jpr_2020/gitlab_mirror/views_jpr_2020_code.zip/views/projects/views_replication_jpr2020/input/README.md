# Input data

These files contain the input data used to make the predictions in the jpr_2020_rr/master.ipynb notebook.

They were manually collected from:
/Users/frehoy/views/prod/runs/cm_r_2020_02_02/datasets/cm_africa_1_C_train.parquet
/Users/frehoy/views/prod/runs/pgm_r_2020_02_02/datasets/pgm_africa_1_C_train.parquet
/Users/frehoy/views/scratch/cache_model_development/df_flat.parquet
/Users/frehoy/views/scratch/cache_model_development/df_preflight.parquet

and converted to .csv by collect.py


