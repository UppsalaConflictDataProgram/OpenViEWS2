# Views JPR 2020 article replication

This directory contains code, intermediate predictions and input data for the ViEWS JPR 2020 paper.

All the necessary source code for replication can be found at https://github.com/UppsalaConflictDataProgram/OpenViEWS2/tree/master/projects/replication\_jpr\_2020/gitlab_mirror/ .
This location contains a copy of an internal git repository used during development that has all the code used in building the results for the paper.
Paths to code mentioned below should be read relative to this directory.

Data in this package were collected using the collect.py script contained in this package.

All the main results in the paper were produced by the jupyter notebook notebooks/papers/jpr\_2020\_rr/JPR_2020_notebook_final.ipynb, it is where you should start if you wish to replicate the paper.

To replicate the final ensemble predictions and published figures copy and alter the notebook in notebooks/papers/jpr\_2020\_rr/master.ipynb to point to the .csv files contained in the /predictions/ directory of this data package, instead of the views database, and then run it.

Replicating constituent model predictions takes considerable manual intervention and compute resources as we have tailored the system quite closely to our infrastructure of supercomputing resources and internal database server.
All necessary data and code are available herein, though you must adapt it yourself to run it locally.

To replicate the underlying predictions that went into the notebook:

* Use the data provided in /input/ of this data pack for cm and pgm respecitvely.
* For newpipe.[cm, pgm]\_africa\_1\_[a,b]\_predict see projects/run\_aug/ for the specification and views/apps/pipe/manager.py for how to run them.
* For newpipe.[cm, pgm]\_africa\_1\_[c]\_predict see runs/r\_2020\_02\_02/ for specification and views/apps/pipe/manager.py for how to run them.
* for newpipe.ds\_[cm, pgm]\_africa\_1\_[a, b] see projects/run\_aug/ds/
* for newpipe.ds\_[cm, pgm]\_africa\_1\_[c\_r\_2020\_02\_02] see runs/r\_2020\_02\_02/ds
* For the XGBoost predictions see /projects/xgboost/



