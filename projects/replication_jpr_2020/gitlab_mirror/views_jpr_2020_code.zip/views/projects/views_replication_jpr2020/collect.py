from views.utils import dbutils, pyutils, datautils

# Collect all tables that went in to jpr_2020_rr/master.ipynb
fqtables = [
    # OSA
    "newpipe.pgm_africa_1_a_predict",
    "newpipe.pgm_africa_1_b_predict",
    "newpipe.pgm_africa_1_c_predict_pgm_r_2020_02_02",
    "newpipe.cm_africa_1_a_predict",
    "newpipe.cm_africa_1_b_predict",
    "newpipe.cm_africa_1_c_predict_cm_r_2020_02_02",
    # DS
    "newpipe.ds_cm_africa_1_a",
    "newpipe.ds_cm_africa_1_b",
    "newpipe.ds_cm_africa_1_c_r2020_02_02",
    "newpipe.ds_pgm_africa_1_a",
    "newpipe.ds_pgm_africa_1_b",
    "newpipe.ds_pgm_africa_1_c_r2020_02_02",
    # Globally trained
    "newpipe.cm_hh_a_predict_fh",
    "newpipe.cm_hh_b_predict_fh",
    "newpipe.cm_hh_c_predict_r_2020_02_02"
]
pyutils.create_dir("predictions")
for fqtable in fqtables:
    print(f"Fetching {fqtable}")
    dbutils.db_to_df(fqtable).to_csv(f"predictions/{fqtable}.csv")

# Include XGBoost predictions
fqtables_xgboost = [
    "flat_materialized.ns_ta_pbc_1",
    "flat_materialized.ns_ta_pbc_12",
    "flat_materialized.ns_ta_pbc_24",
    "flat_materialized.ns_ta_pbc_3",
    "flat_materialized.ns_ta_pbc_36",
    "flat_materialized.ns_ta_pbc_6",
    "flat_materialized.ns_ta_pc_1",
    "flat_materialized.ns_ta_pc_12",
    "flat_materialized.ns_ta_pc_24",
    "flat_materialized.ns_ta_pc_3",
    "flat_materialized.ns_ta_pc_36",
    "flat_materialized.ns_ta_pc_6",
    "flat_materialized.ns_ta_pf_1",
    "flat_materialized.ns_ta_pf_12",
    "flat_materialized.ns_ta_pf_24",
    "flat_materialized.ns_ta_pf_3",
    "flat_materialized.ns_ta_pf_36",
    "flat_materialized.ns_ta_pf_6",
    "flat_materialized.ns_tab_pc_1",
    "flat_materialized.ns_tab_pc_12",
    "flat_materialized.ns_tab_pc_24",
    "flat_materialized.ns_tab_pc_3",
    "flat_materialized.ns_tab_pc_36",
    "flat_materialized.ns_tab_pc_6",
    "flat_materialized.ns_tab_pf_1",
    "flat_materialized.ns_tab_pf_12",
    "flat_materialized.ns_tab_pf_24",
    "flat_materialized.ns_tab_pf_3",
    "flat_materialized.ns_tab_pf_36",
    "flat_materialized.ns_tab_pf_6",
    "flat_materialized.ns_tabc_pf_1",
    "flat_materialized.ns_tabc_pf_12",
    "flat_materialized.ns_tabc_pf_24",
    "flat_materialized.ns_tabc_pf_3",
    "flat_materialized.ns_tabc_pf_36",
    "flat_materialized.ns_tabc_pf_6",
    "flat_materialized.os_ta_pbc_1",
    "flat_materialized.os_ta_pbc_12",
    "flat_materialized.os_ta_pbc_24",
    "flat_materialized.os_ta_pbc_3",
    "flat_materialized.os_ta_pbc_36",
    "flat_materialized.os_ta_pbc_6",
    "flat_materialized.os_ta_pc_1",
    "flat_materialized.os_ta_pc_12",
    "flat_materialized.os_ta_pc_24",
    "flat_materialized.os_ta_pc_3",
    "flat_materialized.os_ta_pc_36",
    "flat_materialized.os_ta_pc_6",
    "flat_materialized.os_ta_pf_1",
    "flat_materialized.os_ta_pf_12",
    "flat_materialized.os_ta_pf_24",
    "flat_materialized.os_ta_pf_3",
    "flat_materialized.os_ta_pf_36",
    "flat_materialized.os_ta_pf_6",
    "flat_materialized.os_tab_pc_1",
    "flat_materialized.os_tab_pc_12",
    "flat_materialized.os_tab_pc_24",
    "flat_materialized.os_tab_pc_3",
    "flat_materialized.os_tab_pc_36",
    "flat_materialized.os_tab_pc_6",
    "flat_materialized.os_tab_pf_1",
    "flat_materialized.os_tab_pf_12",
    "flat_materialized.os_tab_pf_24",
    "flat_materialized.os_tab_pf_3",
    "flat_materialized.os_tab_pf_36",
    "flat_materialized.os_tab_pf_6",
    "flat_materialized.os_tabc_pf_1",
    "flat_materialized.os_tabc_pf_12",
    "flat_materialized.os_tabc_pf_24",
    "flat_materialized.os_tabc_pf_3",
    "flat_materialized.os_tabc_pf_36",
    "flat_materialized.os_tabc_pf_6",
    "flat_materialized.sb_ta_pbc_1",
    "flat_materialized.sb_ta_pbc_12",
    "flat_materialized.sb_ta_pbc_24",
    "flat_materialized.sb_ta_pbc_3",
    "flat_materialized.sb_ta_pbc_36",
    "flat_materialized.sb_ta_pbc_6",
    "flat_materialized.sb_ta_pc_1",
    "flat_materialized.sb_ta_pc_12",
    "flat_materialized.sb_ta_pc_24",
    "flat_materialized.sb_ta_pc_3",
    "flat_materialized.sb_ta_pc_36",
    "flat_materialized.sb_ta_pc_6",
    "flat_materialized.sb_ta_pf_1",
    "flat_materialized.sb_ta_pf_12",
    "flat_materialized.sb_ta_pf_24",
    "flat_materialized.sb_ta_pf_3",
    "flat_materialized.sb_ta_pf_36",
    "flat_materialized.sb_ta_pf_6",
    "flat_materialized.sb_tab_pc_1",
    "flat_materialized.sb_tab_pc_12",
    "flat_materialized.sb_tab_pc_24",
    "flat_materialized.sb_tab_pc_3",
    "flat_materialized.sb_tab_pc_36",
    "flat_materialized.sb_tab_pc_6",
    "flat_materialized.sb_tab_pf_1",
    "flat_materialized.sb_tab_pf_12",
    "flat_materialized.sb_tab_pf_24",
    "flat_materialized.sb_tab_pf_3",
    "flat_materialized.sb_tab_pf_36",
    "flat_materialized.sb_tab_pf_6",
    "flat_materialized.sb_tabc_pf_1",
    "flat_materialized.sb_tabc_pf_12",
    "flat_materialized.sb_tabc_pf_24",
    "flat_materialized.sb_tabc_pf_3",
    "flat_materialized.sb_tabc_pf_36",
    "flat_materialized.sb_tabc_pf_6",
]
pyutils.create_dir("predictions/xgboost")
for fqtable in fqtables_xgboost:
    print(f"Fetching {fqtable}")
    dbutils.db_to_df(fqtable).to_csv(f"predictions/xgboost/{fqtable}.csv")



# Get links for crosslevel model
dbutils.query_to_df("""
SELECT pgm.priogrid_gid AS pg_id,
   cm.country_id
FROM staging.priogrid_month AS pgm
     INNER JOIN staging.country_month AS cm ON pgm.country_month_id = cm.id
--- Month 500 arbitrary choice
WHERE pgm.month_id = 500;
"""
                   ).to_csv("input/links.csv")



# Convert manually collected input data to .csv
path_in = "input/cm_africa_1_C_train.parquet"
path_out = "input/cm_africa_1_C_train.csv"
datautils.load_parquet(path_in).to_csv(path_out)
path_in = "input/pgm_africa_1_C_train.parquet"
path_out = "input/pgm_africa_1_C_train.csv"
datautils.load_parquet(path_in).to_csv(path_out)
path_in = "input/df_flat.parquet"
path_out = "input/df_flat.csv"
datautils.load_parquet(path_in).to_csv(path_out)
path_in = "input/df_preflight.parquet"
path_out = "input/df_preflight.csv"
datautils.load_parquet(path_in).to_csv(path_out)






