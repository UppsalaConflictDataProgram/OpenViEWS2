import os
import numpy as np
from views.utils import datautils, dbutils, pyutils, config
from views.apps.plot.maps.fancy import fancy
import multiprocessing as mp

mapdata = fancy.MapData()

ids_pgm = ["month_id", "pg_id"]
ids_cm = ["month_id", "country_id"]

dir_plots_predictions = os.path.join(config.CONFIG['dirs']['dir_scratch'], "plots", "jpr_2020")
dir_plots_features = os.path.join(config.CONFIG['dirs']['dir_scratch'], "plots", "jpr_2020", "features")
pyutils.create_dir(dir_plots_predictions)
pyutils.create_dir(dir_plots_features)

df_pgm_c = dbutils.db_to_df("newpipe.pgm_africa_1_c_predict_calibrated", ids=ids_pgm)
df_pgm_c = df_pgm_c.join(dbutils.db_to_df("newpipe.pgm_africa_1_c_ensemble", ids=ids_pgm))
df_pgm_c_features = dbutils.db_to_df("newpipe.pgm_africa_1_c_features", ids=ids_pgm)
# df_pgm_c_features = datautils.load_parquet("/Users/frehoy/views/rackham/runs/pgm_run/datasets/pgm_africa_1_C_predict.parquet")

# df_pgm_c_features = df_pgm_c_features[
#     [col for col in df_pgm_c_features.columns
#     if not col.startswith("semt.")
#     and not col.startswith("memt.")]
#     ]

#times_c = df_pgm_c.index.levels[0].values
times_c = [477, 482, 483, 488, 500, 512]
times_features = [476]

def plot_prediction(mapdata, df, col, t, dir_plots):
    fancy.plot_map(mapdata = mapdata,
                   s_patch = df[col],
                   t=t,
                   path=os.path.join(dir_plots, f"{col.strip('memt.')}_{t}-pgm.png")
                  )

def plot_feature(mapdata, df, col, t, dir_plots):
  fancy.plot_map(mapdata = mapdata,
                 s_patch = df[col],
                 t=t,
                 path=os.path.join(dir_plots, f"feat_{col}_{t}-pgm.png"),
                 logodds=False,
                )


# def plot_stdist(mapdata):
#     cols_features = datautils.list_columns_in_parquet("/Users/frehoy/views/rackham/runs/pgm_run/datasets/pgm_africa_1_C_predict.parquet")
#     cols_stime = [col for col in cols_features if "stdist" in col]
#     df_pgm_c_stime = datautils.load_parquet("/Users/frehoy/views/rackham/runs/pgm_run/datasets/pgm_africa_1_C_predict.parquet", cols=cols_stime)
#     df_pgm_c_stime
#     df = df_pgm_c_stime
#     df = np.log(df+1)

#     df = df.add_prefix("ln_")

#     plotdir = "/Users/frehoy/views/scratch/plots/jpr_2020/features/select/"
#     for col in df.columns:
#         for t in [477]:
#             fancy.plot_map(mapdata, s_patch = df[col], t=t, logodds=False, bbox="mainland_africa", path=f"{plotdir}/feat_{col}_{t}-pgm.png")


plot_stdist(mapdata)

with mp.Pool(processes=6) as pool:
    results = []

    # for col in df_pgm_c.columns:
    #     for t in times_c:
    #         results.append(pool.apply_async(plot_prediction, (mapdata, df_pgm_c[[col]], col, t, dir_plots_predictions, )))

    for col in df_pgm_c_features.columns:
        for t in times_features:
            results.append(
                pool.apply_async(
                    plot_feature,
                    (mapdata, df_pgm_c_features[[col]], col, t, dir_plots_features, )
                    )
                )

    for result in results:
        result.get()

