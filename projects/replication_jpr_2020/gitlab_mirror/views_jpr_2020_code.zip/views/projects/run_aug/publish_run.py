import logging


import os
from views.utils import pyutils, datautils, dbutils
from views.apps.defparser import solver
fname_spec = "pgm.yaml"
path_spec = os.path.join("specs", fname_spec)

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)

def get_outcomes_from_spec(spec):
    models = spec['formulas']
    outcomes = pyutils.dedup_list([model['lhs'] for model in models.values()])
    return outcomes


spec = pyutils.load_yaml(path_spec)
tasks=solver.tasks(defis=solver.defis(spec), specs=spec)
name_run = spec['name']

dir_runs = pyutils.resole_vars_and_home("~/views/rackham/runs")
for key, value in tasks['datasets'].items():
    name_dataset = key
    if "_predict" in name_dataset:
        t_start = value['times']['start']
        t_end = value['times']['end']
        fname = f"{name_dataset}.parquet"
        fqtable = f"newpipe.{name_dataset.lower()}"
        dir_datasets = os.path.join(dir_runs, name_run, "datasets")
        path_dataset = os.path.join(dir_datasets, fname)

        # Load dataset
        df = datautils.load_parquet(path_dataset)

        # Subset times
        df = df.loc[t_start:t_end] # Subset times

        # Keep outcomes and predictions, discard features.
        cols = [col for col in df.columns if "semt" in col or "memt" in col]
        cols = cols + get_outcomes_from_spec(spec)
        df = df[cols]

        # Push to db
        dbutils.df_to_db(df, fqtable)





