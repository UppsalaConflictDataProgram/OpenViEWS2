# Periodisation

Using 3 periods.

## A
A is the calibration window for B.
It covers the three years befor B
## B
B is the latest 3 years with final yearly-release data.
B is the evaluation window for models.
B is also the calibration window for C
## C
C is the true forecast.
It is the first month after the month of latest data and 37 months into the future.
It is trained on data up to the latest monthly data.

A
2013-1      397
2015-12     432
B
2016-01     433
2018-12     468
C
2019-08     477
2022-09     514

