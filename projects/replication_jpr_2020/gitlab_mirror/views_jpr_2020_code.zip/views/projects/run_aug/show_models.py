import json
from views.apps.pipeline import utils

tasks = utils.get_tasks("spec_cm.yaml")

tasks_models = [task for task in tasks.values()
                if task['task_type'] == "train"]

for model in tasks_models:
    print(json.dumps(model, indent=2))