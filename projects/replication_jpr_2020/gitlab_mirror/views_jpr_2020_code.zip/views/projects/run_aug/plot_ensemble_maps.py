import multiprocessing as mp
from views.utils import dbutils
from views.apps.plot.maps.fancy import fancy

mapdata = fancy.MapData()
ids_cm = ["month_id", "country_id"]
ids_pgm = ["month_id", "pg_id"]
cols_actuals_cm = [
        "ged_tx_sb_25",
        "ged_tx_ns_25",
        "ged_tx_os_25",
    ]
cols_actuals_pgm = [
        "ged_dummy_sb",
        "ged_dummy_ns",
        "ged_dummy_os",
    ]

df_pgm_b =    dbutils.db_to_df(
    fqtable="pgm_africa_1_b_ensemble",
    ids=ids_pgm
    )
df_pgm_c =    dbutils.db_to_df(
    fqtable="pgm_africa_1_c_ensemble",
    ids=ids_pgm
    )
df_cm_b =    dbutils.db_to_df(
    fqtable="cm_africa_1_b_ensemble",
    ids=ids_cm
    )
df_cm_c =    dbutils.db_to_df(
    fqtable="cm_africa_1_c_ensemble",
    ids=ids_cm
    )

df_cm_actuals = dbutils.db_to_df(
    fqtable="preflight.flight_cm",
    ids=ids_cm,
    columns=cols_actuals_cm)

df_cm_b = df_cm_b.join(df_cm_actuals, how='inner')
df_cm_c = df_cm_c.join(df_cm_actuals, how='inner')

# join in pgm actuals
df_pgm_actuals = dbutils.db_to_df(
    fqtable="preflight.flight_pgm",
    ids=ids_pgm,
    columns=cols_actuals_pgm)
df_pgm_b = df_pgm_b.join(df_pgm_actuals, how='inner')
df_pgm_c = df_pgm_c.join(df_pgm_actuals, how='inner')


