
models = [
]
main_outcome = 'ged_tx_sb_25'
# Done
m_confhist2019 = {
    'name': "confhist2019",
    'features': feat_confhist2019,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# done
m_neibhist  = {
    'name': "neibhist",
    'features': feat_neibhist,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# done
m_cfshort = {
    'name': "cfshort",
    'features': feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# done
m_cflong_rf = {
    'name': "cflong_rf",
    'features': feat_cflong,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': main_outcome
}
# TODO
m_cflong_rfreg = {
    'name': "cflong_rfreg",
    'features': feat_cflong,
    'estimator': RandomForestRegressor(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': 'ged_best_sb'
}
# TODO
m_cflong_lasso = {
    'name': "cflong_lasso",
    'features': feat_cflong,
    'estimator': linear_model.Lasso(copy_X=True, fit_intercept = True, max_iter = 1000),
    'outcome': 'ged_best_sb'
}
#TODO
m_cfsvd_rf = {
    'name': "cfsvd_rf",
    'features': feat_cfsvd,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': main_outcome
}
#TODO
m_cfsvd_gb = {
    'name': "cfsvd_gb",
    'features': feat_cfsvd,
    'estimator': GradientBoostingClassifier(n_estimators= 1000, max_leaf_nodes=4, max_depth=None, random_state=2,
                   min_samples_split=5,learning_rate=0.1, subsample=0.5),
    'outcome': main_outcome
}
# DONE
m_acled_v = {
    'name': "acled_v",
    'features': feat_acled_v,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_base2019 = {
    'name': "base2019",
    'features': feat_base2019,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_acled_pr = {
    'name': "acled_pr",
    'features': feat_acled_pr,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=2, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_vdem = {
    'name': "vdem",
    'features': feat_vdem,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# TODO
m_vdemLasso = {
    'name': 'vdemLasso',
    'features': feat_vdem,
    'estimator': linear_model.Lasso(copy_X=True, fit_intercept = True, max_iter = 1000),
    'outcome': 'ged_best_sb'
}
# DONE
m_vdemconf = {
    'name': "vdemconf",
    'features': feat_vdem + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_vdem_hlc = {
    'name': "vdem_hlc",
    'features': feat_vdem_hlc,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=3, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_inst2019 = {
    'name': "inst2019",
    'features': feat_inst2019,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_inst = {
    'name': "inst",
    'features': feat_inst,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# DONE
m_instconf = {
    'name': "instconf",
    'features': feat_inst + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_demog = {
    'name': "demog",
    'features': feat_demog,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# done
m_demogconf = {
    'name': "demogconf",
    'features': feat_demog + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_econ = {
    'name': "econ",
    'features': feat_econ,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_econconf = {
    'name': "econconf",
    'features': feat_econ + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_reign = {
    'name': "reign",
    'features': feat_reign,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_reignconf = {
    'name': "reignconf",
    'features': feat_reign + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# done
m_couprisk = {
    'name': "couprisk",
    'features': feat_couprisk,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=2, n_jobs=4),
    'outcome': main_outcome
}
# done
m_coupriskconf = {
    'name': "coupriskconf",
    'features': feat_couprisk + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# done
m_icgcw = {
    'name': "icgcw",
    'features': feat_icgcw,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=3, n_jobs=4),
    'outcome': main_outcome
}
# done
m_icgcwconf = {
    'name': "icgcwconf",
    'features': feat_icgcw + feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=8, n_jobs=4),
    'outcome': main_outcome
}
# TODO
m_cnt = {
    'name': "cnt",
    'features': feat_cnt,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=10, n_jobs=4),
    'outcome': main_outcome
}
# TODO
m_cycles = {
    'name': "cycles",
    'features': feat_cycles,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
# TODO
m_decades = {
    'name': "decades",
    'features': feat_decades,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=2, n_jobs=4),
    'outcome': main_outcome
}
# Done
m_all = {
    'name': "all",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': main_outcome
}
m_allsvd = {
    'name': "allsvd",
    'features': feat_allsvd,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': main_outcome
}
m_allLasso = {
    'name': 'allLasso',
    'features': feat_all,
    'estimator': linear_model.Lasso(copy_X=True, fit_intercept = True, max_iter = 1000),
    'outcome': 'ged_best_sb'
}
m_baseLogit = {
    'name': "baseLogit",
    'features': feat_base2019,
    'estimator': LogisticRegression(random_state=0, solver='lbfgs', max_iter = 500, multi_class='auto'),
    'outcome': main_outcome
}
m_allGBoost = {
    'name': "allGBoost",
    'features': feat_all,
    'estimator': GradientBoostingClassifier(n_estimators= 1000, max_leaf_nodes=4, max_depth=None, random_state=2,
                   min_samples_split=5,learning_rate=0.1, subsample=0.5),
    'outcome': main_outcome
}
m_allAdaBoost = {
    'name': "allAdaBoost",
    'features': feat_all,
    'estimator': AdaBoostClassifier(n_estimators=100),
    'outcome': main_outcome
}

m_allXGBoost = {
    'name': "allXGBoost",
    'features': feat_all,
    'estimator': XGBClassifier(),
    'outcome': main_outcome
}
m_allLogit = {
    'name': "allLogit",
    'features': feat_all,
    'estimator': LogisticRegression(random_state=0, penalty = 'l1', C= 0.1, solver='liblinear', max_iter = 500, multi_class='auto'),
    'outcome': main_outcome
}
m_allRFreg = {
    'name': "allRFreg",
    'features': feat_all,
    'estimator': RandomForestRegressor(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': 'ged_best_sb'
}
m_onset1all = {
    'name': "onsetlall",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=20, n_jobs=4),
    'outcome': "onset24_tx_sb_1"
}
m_onset100all = {
    'name': "onset100all",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=200, max_features=20, n_jobs=4),
    'outcome': "onset24_tx_sb_100"
}
m_onset5all = {
    'name': "onset5all",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=200, max_features=20, n_jobs=4),
    'outcome': "onset24_tx_sb_5"
}
m_onset5Boost = {
    'name': "onset5all_gb",
    'features': feat_all,
    'estimator': GradientBoostingClassifier(n_estimators= 1000, max_leaf_nodes=4, max_depth=None, random_state=2,
                   min_samples_split=5,learning_rate=0.1, subsample=0.5),
    'outcome': "onset24_tx_sb_5"
}
m_inc500allsvd = {
    'name': "inc500allsvd",
    'features': feat_allsvd,
    'estimator': RandomForestClassifier(n_estimators=200, max_features=20, n_jobs=4),
    'outcome': "ged_tx_sb_500"
}
m_inc100all = {
    'name': "inc100all",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=200, max_features=20, n_jobs=4),
    'outcome': "ged_tx_sb_100"
}
# Done
m_inc1all = {
    'name': "inc1all",
    'features': feat_all,
    'estimator': RandomForestClassifier(n_estimators=200, max_features=20, n_jobs=4),
    'outcome': "ged_dummy_sb"
}
m_cfshortXGBoost = {
    'name': "cfshortXGBoost",
    'features': feat_cfshort,
    'estimator': RandomForestClassifier(n_estimators=100, max_features=5, n_jobs=4),
    'outcome': main_outcome
}
m_cfshortLasso = {
    'name': 'chshortLasso',
    'features': feat_cfshort,
    'estimator': linear_model.Lasso(copy_X=True, fit_intercept = True, max_iter = 1000),
    'outcome': 'ged_best_sb'
}


countervars = [
    'ged_months_since_last_sb',
    'ged_months_since_last_ns',
    'ged_months_since_last_os',
    'ged_months_since_last_sb_lag1',
    'ged_months_since_last_ns_lag1',
    'ged_months_since_last_os_lag1',
    'acled_months_since_last_sb',
    'acled_months_since_last_ns',
    'acled_months_since_last_os',
    'acled_months_since_last_pr',
    'acled_months_since_last_sb_lag1',
    'acled_months_since_last_ns_lag1',
    'acled_months_since_last_os_lag1',
    'acled_months_since_last_pr_lag1',
    'ged_months_since_last_sb_tx5',
    'ged_months_since_last_ns_tx5',
    'ged_months_since_last_os_tx5',
    'ged_months_since_last_sb_lag1_tx5',
    'ged_months_since_last_ns_lag1_tx5',
    'ged_months_since_last_os_lag1_tx5',
    'ged_months_since_last_sb_tx25',
    'ged_months_since_last_ns_tx25',
    'ged_months_since_last_os_tx25',
    'ged_months_since_last_sb_lag1_tx25',
    'ged_months_since_last_ns_lag1_tx25',
    'ged_months_since_last_os_lag1_tx25',
    'ged_months_since_last_sb_tx100',
    'ged_months_since_last_ns_tx100',
    'ged_months_since_last_os_tx100',
    'ged_months_since_last_sb_lag1_tx100',
    'ged_months_since_last_ns_lag1_tx100',
    'ged_months_since_last_os_lag1_tx100',
    'ged_months_since_last_sb_tx500',
    'ged_months_since_last_ns_tx500',
    'ged_months_since_last_os_tx500',
    'ged_months_since_last_sb_lag1_tx500',
    'ged_months_since_last_ns_lag1_tx500',
    'ged_months_since_last_os_lag1_tx500',
]

fatalitiesvars = [
    'ged_dummy_sb',
    'ged_dummy_ns',
    'ged_dummy_os',
    'severity_sb',
    'severity_ns',
    'severity_os',
    'ged_best_sb',
    'ged_best_ns',
    'ged_best_os',
    'ged_best_sb_lag1',
    'ged_best_ns_lag1',
    'ged_best_os_lag1',
    'ged_best_sb_lag1_tlag1',
    'ged_best_ns_lag1_tlag1',
    'ged_best_os_lag1_tlag1',
    'acled_count_sb_lag1',
    'acled_count_ns_lag1',
    'acled_count_os_lag1',
    'acled_count_pr_lag1',
    'ged_minor_sb',
    'ged_medium_sb',
    'ged_major_sb',
    'ged_minor_ns',
    'ged_medium_ns',
    'ged_major_ns',
    'ged_minor_os',
    'ged_medium_os',
    'ged_major_os',
    'bigbinnedseverity_sb',
    'bigbinnedseverity_ns',
    'bigbinnedseverity_os',
    'onset_sb_24',
    'onset_ns_24',
    'onset_os_24',
    'ged_tx_sb_1',
    'ged_tx_sb_5',
    'ged_tx_sb_25',
    'ged_tx_sb_100',
    'ged_tx_sb_500',
    'ged_tx_ns_1',
    'ged_tx_ns_5',
    'ged_tx_ns_25',
    'ged_tx_ns_100',
    'ged_tx_ns_500',
    'ged_tx_os_1',
    'ged_tx_os_5',
    'ged_tx_os_25',
    'ged_tx_os_100',
    'ged_tx_os_500',
    'ged_tx_sb_1_tlag1',
    'ged_tx_sb_5_tlag1',
    'ged_tx_sb_25_tlag1',
    'ged_tx_sb_100_tlag1',
    'ged_tx_sb_500_tlag1',
    'ged_tx_ns_1_tlag1',
    'ged_tx_ns_5_tlag1',
    'ged_tx_ns_25_tlag1',
    'ged_tx_ns_100_tlag1',
    'ged_tx_ns_500_tlag1',
    'ged_tx_os_1_tlag1',
    'ged_tx_os_5_tlag1',
    'ged_tx_os_25_tlag1',
    'ged_tx_os_100_tlag1',
    'ged_tx_os_500_tlag1',
    'ged_tx_sb_1_tlag2',
    'ged_tx_sb_5_tlag2',
    'ged_tx_sb_25_tlag2',
    'ged_tx_sb_100_tlag2',
    'ged_tx_sb_500_tlag2',
    'ged_tx_ns_1_tlag2',
    'ged_tx_ns_5_tlag2',
    'ged_tx_ns_25_tlag2',
    'ged_tx_ns_100_tlag2',
    'ged_tx_ns_500_tlag2',
    'ged_tx_os_1_tlag2',
    'ged_tx_os_5_tlag2',
    'ged_tx_os_25_tlag2',
    'ged_tx_os_100_tlag2',
    'ged_tx_os_500_tlag2',
    'ged_tx_sb_1_tlag3',
    'ged_tx_sb_5_tlag3',
    'ged_tx_sb_25_tlag3',
    'ged_tx_sb_100_tlag3',
    'ged_tx_sb_500_tlag3',
    'ged_tx_ns_1_tlag3',
    'ged_tx_ns_5_tlag3',
    'ged_tx_ns_25_tlag3',
    'ged_tx_ns_100_tlag3',
    'ged_tx_ns_500_tlag3',
    'ged_tx_os_1_tlag3',
    'ged_tx_os_5_tlag3',
    'ged_tx_os_25_tlag3',
    'ged_tx_os_100_tlag3',
    'ged_tx_os_500_tlag3',
    'ged_tx_sb_1_tlag4',
    'ged_tx_sb_5_tlag4',
    'ged_tx_sb_25_tlag4',
    'ged_tx_sb_100_tlag4',
    'ged_tx_sb_500_tlag4',
    'ged_tx_ns_1_tlag4',
    'ged_tx_ns_5_tlag4',
    'ged_tx_ns_25_tlag4',
    'ged_tx_ns_100_tlag4',
    'ged_tx_ns_500_tlag4',
    'ged_tx_os_1_tlag4',
    'ged_tx_os_5_tlag4',
    'ged_tx_os_25_tlag4',
    'ged_tx_os_100_tlag4',
    'ged_tx_os_500_tlag4',
    'ged_tx_sb_1_tlag5',
    'ged_tx_sb_5_tlag5',
    'ged_tx_sb_25_tlag5',
    'ged_tx_sb_100_tlag5',
    'ged_tx_sb_500_tlag5',
    'ged_tx_ns_1_tlag5',
    'ged_tx_ns_5_tlag5',
    'ged_tx_ns_25_tlag5',
    'ged_tx_ns_100_tlag5',
    'ged_tx_ns_500_tlag5',
    'ged_tx_os_1_tlag5',
    'ged_tx_os_5_tlag5',
    'ged_tx_os_25_tlag5',
    'ged_tx_os_100_tlag5',
    'ged_tx_os_500_tlag5',
    'ged_tx_sb_1_tlag6',
    'ged_tx_sb_5_tlag6',
    'ged_tx_sb_25_tlag6',
    'ged_tx_sb_100_tlag6',
    'ged_tx_sb_500_tlag6',
    'ged_tx_ns_1_tlag6',
    'ged_tx_ns_5_tlag6',
    'ged_tx_ns_25_tlag6',
    'ged_tx_ns_100_tlag6',
    'ged_tx_ns_500_tlag6',
    'ged_tx_os_1_tlag6',
    'ged_tx_os_5_tlag6',
    'ged_tx_os_25_tlag6',
    'ged_tx_os_100_tlag6',
    'ged_tx_os_500_tlag6',
    'ged_tx_sb_1_tlag7',
    'ged_tx_sb_5_tlag7',
    'ged_tx_sb_25_tlag7',
    'ged_tx_sb_100_tlag7',
    'ged_tx_sb_500_tlag7',
    'ged_tx_ns_1_tlag7',
    'ged_tx_ns_5_tlag7',
    'ged_tx_ns_25_tlag7',
    'ged_tx_ns_100_tlag7',
    'ged_tx_ns_500_tlag7',
    'ged_tx_os_1_tlag7',
    'ged_tx_os_5_tlag7',
    'ged_tx_os_25_tlag7',
    'ged_tx_os_100_tlag7',
    'ged_tx_os_500_tlag7',
    'ged_tx_sb_1_tlag8',
    'ged_tx_sb_5_tlag8',
    'ged_tx_sb_25_tlag8',
    'ged_tx_sb_100_tlag8',
    'ged_tx_sb_500_tlag8',
    'ged_tx_ns_1_tlag8',
    'ged_tx_ns_5_tlag8',
    'ged_tx_ns_25_tlag8',
    'ged_tx_ns_100_tlag8',
    'ged_tx_ns_500_tlag8',
    'ged_tx_os_1_tlag8',
    'ged_tx_os_5_tlag8',
    'ged_tx_os_25_tlag8',
    'ged_tx_os_100_tlag8',
    'ged_tx_os_500_tlag8',
    'ged_tx_sb_1_tlag9',
    'ged_tx_sb_5_tlag9',
    'ged_tx_sb_25_tlag9',
    'ged_tx_sb_100_tlag9',
    'ged_tx_sb_500_tlag9',
    'ged_tx_ns_1_tlag9',
    'ged_tx_ns_5_tlag9',
    'ged_tx_ns_25_tlag9',
    'ged_tx_ns_100_tlag9',
    'ged_tx_ns_500_tlag9',
    'ged_tx_os_1_tlag9',
    'ged_tx_os_5_tlag9',
    'ged_tx_os_25_tlag9',
    'ged_tx_os_100_tlag9',
    'ged_tx_os_500_tlag9',
    'ged_tx_sb_1_tlag10',
    'ged_tx_sb_5_tlag10',
    'ged_tx_sb_25_tlag10',
    'ged_tx_sb_100_tlag10',
    'ged_tx_sb_500_tlag10',
    'ged_tx_ns_1_tlag10',
    'ged_tx_ns_5_tlag10',
    'ged_tx_ns_25_tlag10',
    'ged_tx_ns_100_tlag10',
    'ged_tx_ns_500_tlag10',
    'ged_tx_os_1_tlag10',
    'ged_tx_os_5_tlag10',
    'ged_tx_os_25_tlag10',
    'ged_tx_os_100_tlag10',
    'ged_tx_os_500_tlag10',
    'ged_tx_sb_1_tlag11',
    'ged_tx_sb_5_tlag11',
    'ged_tx_sb_25_tlag11',
    'ged_tx_sb_100_tlag11',
    'ged_tx_sb_500_tlag11',
    'ged_tx_ns_1_tlag11',
    'ged_tx_ns_5_tlag11',
    'ged_tx_ns_25_tlag11',
    'ged_tx_ns_100_tlag11',
    'ged_tx_ns_500_tlag11',
    'ged_tx_os_1_tlag11',
    'ged_tx_os_5_tlag11',
    'ged_tx_os_25_tlag11',
    'ged_tx_os_100_tlag11',
    'ged_tx_os_500_tlag11',
    'ged_tx_sb_1_tlag12',
    'ged_tx_sb_5_tlag12',
    'ged_tx_sb_25_tlag12',
    'ged_tx_sb_100_tlag12',
    'ged_tx_sb_500_tlag12',
    'ged_tx_ns_1_tlag12',
    'ged_tx_ns_5_tlag12',
    'ged_tx_ns_25_tlag12',
    'ged_tx_ns_100_tlag12',
    'ged_tx_ns_500_tlag12',
    'ged_tx_os_1_tlag12',
    'ged_tx_os_5_tlag12',
    'ged_tx_os_25_tlag12',
    'ged_tx_os_100_tlag12',
    'ged_tx_os_500_tlag12',
    'onset24_tx_sb_1',
    'onset24_tx_sb_5',
    'onset24_tx_sb_25',
    'onset24_tx_sb_100',
    'onset24_tx_sb_500',
    'onset24_tx_ns_1',
    'onset24_tx_ns_5',
    'onset24_tx_ns_25',
    'onset24_tx_ns_100',
    'onset24_tx_ns_500',
    'onset24_tx_os_1',
    'onset24_tx_os_5',
    'onset24_tx_os_25',
    'onset24_tx_os_100',
    'onset24_tx_os_500',
]

countryids = [
    'gwcode',
    'country_name'
]

newvars = [
 'rgn_leader',
 'rgn_elected',
 'rgn_age',
 'rgn_male',
 'rgn_militarycareer',
 'rgn_tenure_months',
 'rgn_government',
 'rgn_anticipation',
 'rgn_ref_ant',
 'rgn_leg_ant',
 'rgn_exec_ant',
 'rgn_irreg_lead_ant',
 'rgn_election_now',
 'rgn_election_recent',
 'rgn_leg_recent',
 'rgn_exec_recent',
 'rgn_lead_recent',
 'rgn_ref_recent',
 'rgn_direct_recent',
 'rgn_indirect_recent',
 'rgn_victory_recent',
 'rgn_defeat_recent',
 'rgn_change_recent',
 'rgn_nochange_recent',
 'rgn_delayed',
 'rgn_lastelection',
 'rgn_loss',
 'rgn_irregular',
 'rgn_prev_conflict',
 'rgn_pt_suc',
 'rgn_pt_attempt',
 'rgn_precip',
 'rgn_couprisk',
 'rgn_pctile_risk',
 'icgcw_alerts',
 'icgcw_opportunities',
 'icgcw_deteriorated',
 'icgcw_improved',
]

feat_confhist2019 = [
    'ged_tx_sb_1_tlag1',
    'ged_tx_sb_1_tlag2',
    'ged_tx_sb_1_tlag3',
    'ged_tx_sb_1_tlag4',
    'ged_tx_sb_1_tlag5',
    'ged_tx_sb_1_tlag6',
    'ged_tx_sb_1_tlag7',
    'ged_tx_sb_1_tlag8',
    'ged_tx_sb_1_tlag9',
    'ged_tx_sb_1_tlag10',
    'ged_tx_sb_1_tlag11',
    'ged_tx_sb_1_tlag12',
    'ged_best_ns_lag1',
    'ged_best_os_lag1',
    'ged_months_since_last_sb',
    'ged_months_since_last_ns',
    'ged_months_since_last_os',
]

feat_neibhist = [
    'ged_months_since_last_sb_lag1_tx5',
    'ged_months_since_last_ns_lag1_tx5',
    'ged_months_since_last_os_lag1_tx5',
    'ged_months_since_last_sb_lag1_tx25',
    'ged_months_since_last_ns_lag1_tx25',
    'ged_months_since_last_os_lag1_tx25',
    'ged_months_since_last_sb_lag1_tx100',
    'ged_months_since_last_ns_lag1_tx100',
    'ged_months_since_last_os_lag1_tx100',
    'ged_months_since_last_sb_lag1_tx500',
    'ged_months_since_last_ns_lag1_tx500',
    'ged_months_since_last_os_lag1_tx500',
    'ged_best_sb_lag1',
    'ged_best_ns_lag1',
    'ged_best_os_lag1',
    'ged_best_sb_lag1_tlag1',
    'ged_best_ns_lag1_tlag1',
    'ged_best_os_lag1_tlag1',
    'acled_months_since_last_sb_lag1',
    'acled_months_since_last_ns_lag1',
    'acled_months_since_last_os_lag1',
    'acled_count_sb_lag1',
    'acled_count_ns_lag1',
    'acled_count_os_lag1',
]

# Simpler confhist model
feat_confhist = [
    'ged_best_sb_lag1',
    'ged_best_ns_lag1',
    'ged_best_os_lag1',
    'ged_best_sb_lag1_tlag1',
    'ged_best_ns_lag1_tlag1',
    'ged_best_os_lag1_tlag1',
    'ged_months_since_last_sb',
    'ged_months_since_last_ns',
    'ged_months_since_last_os',
    'ged_months_since_last_sb_lag1',
    'ged_months_since_last_ns_lag1',
    'ged_months_since_last_os_lag1',
]

# Parsimoneous new confhist model
feat_cfshort = [
    'ged_months_since_last_sb',
    'ged_months_since_last_ns',
    'ged_months_since_last_os',
    'ged_tx_sb_1_tlag1',
    'ged_tx_sb_1_tlag2',
    'ged_tx_sb_1_tlag3',
    'ged_best_sb_lag1',
    'ged_best_ns_lag1',
    'ged_best_os_lag1',
    'ged_months_since_last_sb_tx25',
    'ged_months_since_last_ns_tx25',
    'ged_months_since_last_os_tx25',
    'ged_months_since_last_sb_tx500',
    'ged_months_since_last_ns_tx500',
    'ged_months_since_last_os_tx500',
    'ged_months_since_last_sb_lag1_tx100',
    'ged_months_since_last_ns_lag1_tx100',
    'ged_months_since_last_os_lag1_tx100',
    'ged_best_sb_lag1_tlag1',
    'ged_best_ns_lag1_tlag1',
    'ged_best_os_lag1_tlag1',
    'ged_months_since_last_sb_lag1',
    'ged_months_since_last_ns_lag1',
    'ged_months_since_last_os_lag1',
]

# Non-pruned version of confhist2:
# Consider to take out all ***_500_tlag > 1, all ***_100_tlag > 3, all ***_25_tlag > 6,  all ***_5_tlag > 9,
#ged_tx_sb_25_tlag8ged_tx_ns_1_tlag8
feat_cflong = [
    'ged_months_since_last_sb',
    'ged_months_since_last_ns',
    'ged_months_since_last_os',
    'ged_tx_ns_100_tlag1',
    'ged_tx_ns_100_tlag10',
    'ged_tx_ns_100_tlag11',
    'ged_tx_ns_100_tlag12',
    'ged_tx_ns_100_tlag2',
    'ged_tx_ns_100_tlag3',
    'ged_tx_ns_100_tlag4',
    'ged_tx_ns_100_tlag5',
    'ged_tx_ns_100_tlag6',
    'ged_tx_ns_100_tlag7',
    'ged_tx_ns_100_tlag8',
    'ged_tx_ns_100_tlag9',
    'ged_tx_ns_1_tlag1',
    'ged_tx_ns_1_tlag10',
    'ged_tx_ns_1_tlag11',
    'ged_tx_ns_1_tlag12',
    'ged_tx_ns_1_tlag2',
    'ged_tx_ns_1_tlag3',
    'ged_tx_ns_1_tlag4',
    'ged_tx_ns_1_tlag5',
    'ged_tx_ns_1_tlag6',
    'ged_tx_ns_1_tlag7',
    'ged_tx_ns_1_tlag8',
    'ged_tx_ns_1_tlag9',
    'ged_tx_ns_25_tlag1',
    'ged_tx_ns_25_tlag10',
    'ged_tx_ns_25_tlag11',
    'ged_tx_ns_25_tlag12',
    'ged_tx_ns_25_tlag2',
    'ged_tx_ns_25_tlag3',
    'ged_tx_ns_25_tlag4',
    'ged_tx_ns_25_tlag5',
    'ged_tx_ns_25_tlag6',
    'ged_tx_ns_25_tlag7',
    'ged_tx_ns_25_tlag8',
    'ged_tx_ns_25_tlag9',
    'ged_tx_ns_500_tlag1',
    'ged_tx_ns_500_tlag10',
    'ged_tx_ns_500_tlag11',
    'ged_tx_ns_500_tlag12',
    'ged_tx_ns_500_tlag2',
    'ged_tx_ns_500_tlag3',
    'ged_tx_ns_500_tlag4',
    'ged_tx_ns_500_tlag5',
    'ged_tx_ns_500_tlag6',
    'ged_tx_ns_500_tlag7',
    'ged_tx_ns_500_tlag8',
    'ged_tx_ns_500_tlag9',
    'ged_tx_ns_5_tlag1',
    'ged_tx_ns_5_tlag10',
    'ged_tx_ns_5_tlag11',
    'ged_tx_ns_5_tlag12',
    'ged_tx_ns_5_tlag2',
    'ged_tx_ns_5_tlag3',
    'ged_tx_ns_5_tlag4',
    'ged_tx_ns_5_tlag5',
    'ged_tx_ns_5_tlag6',
    'ged_tx_ns_5_tlag7',
    'ged_tx_ns_5_tlag8',
    'ged_tx_ns_5_tlag9',
    'ged_tx_os_100_tlag1',
    'ged_tx_os_100_tlag10',
    'ged_tx_os_100_tlag11',
    'ged_tx_os_100_tlag12',
    'ged_tx_os_100_tlag2',
    'ged_tx_os_100_tlag3',
    'ged_tx_os_100_tlag4',
    'ged_tx_os_100_tlag5',
    'ged_tx_os_100_tlag6',
    'ged_tx_os_100_tlag7',
    'ged_tx_os_100_tlag8',
    'ged_tx_os_100_tlag9',
    'ged_tx_os_1_tlag1',
    'ged_tx_os_1_tlag10',
    'ged_tx_os_1_tlag11',
    'ged_tx_os_1_tlag12',
    'ged_tx_os_1_tlag2',
    'ged_tx_os_1_tlag3',
    'ged_tx_os_1_tlag4',
    'ged_tx_os_1_tlag5',
    'ged_tx_os_1_tlag6',
    'ged_tx_os_1_tlag7',
    'ged_tx_os_1_tlag8',
    'ged_tx_os_1_tlag9',
    'ged_tx_os_25_tlag1',
    'ged_tx_os_25_tlag10',
    'ged_tx_os_25_tlag11',
    'ged_tx_os_25_tlag12',
    'ged_tx_os_25_tlag2',
    'ged_tx_os_25_tlag3',
    'ged_tx_os_25_tlag4',
    'ged_tx_os_25_tlag5',
    'ged_tx_os_25_tlag6',
    'ged_tx_os_25_tlag7',
    'ged_tx_os_25_tlag8',
    'ged_tx_os_25_tlag9',
    'ged_tx_os_500_tlag1',
    'ged_tx_os_500_tlag10',
    'ged_tx_os_500_tlag11',
    'ged_tx_os_500_tlag12',
    'ged_tx_os_500_tlag2',
    'ged_tx_os_500_tlag3',
    'ged_tx_os_500_tlag4',
    'ged_tx_os_500_tlag5',
    'ged_tx_os_500_tlag6',
    'ged_tx_os_500_tlag7',
    'ged_tx_os_500_tlag8',
    'ged_tx_os_500_tlag9',
    'ged_tx_os_5_tlag1',
    'ged_tx_os_5_tlag10',
    'ged_tx_os_5_tlag11',
    'ged_tx_os_5_tlag12',
    'ged_tx_os_5_tlag2',
    'ged_tx_os_5_tlag3',
    'ged_tx_os_5_tlag4',
    'ged_tx_os_5_tlag5',
    'ged_tx_os_5_tlag6',
    'ged_tx_os_5_tlag7',
    'ged_tx_os_5_tlag8',
    'ged_tx_os_5_tlag9',
    'ged_tx_sb_100_tlag1',
    'ged_tx_sb_100_tlag10',
    'ged_tx_sb_100_tlag11',
    'ged_tx_sb_100_tlag12',
    'ged_tx_sb_100_tlag2',
    'ged_tx_sb_100_tlag3',
    'ged_tx_sb_100_tlag4',
    'ged_tx_sb_100_tlag5',
    'ged_tx_sb_100_tlag6',
    'ged_tx_sb_100_tlag7',
    'ged_tx_sb_100_tlag8',
    'ged_tx_sb_100_tlag9',
    'ged_tx_sb_1_tlag1',
    'ged_tx_sb_1_tlag10',
    'ged_tx_sb_1_tlag11',
    'ged_tx_sb_1_tlag12',
    'ged_tx_sb_1_tlag2',
    'ged_tx_sb_1_tlag3',
    'ged_tx_sb_1_tlag4',
    'ged_tx_sb_1_tlag5',
    'ged_tx_sb_1_tlag6',
    'ged_tx_sb_1_tlag7',
    'ged_tx_sb_1_tlag8',
    'ged_tx_sb_1_tlag9',
    'ged_tx_sb_25_tlag1',
    'ged_tx_sb_25_tlag10',
    'ged_tx_sb_25_tlag11',
    'ged_tx_sb_25_tlag12',
    'ged_tx_sb_25_tlag2',
    'ged_tx_sb_25_tlag3',
    'ged_tx_sb_25_tlag4',
    'ged_tx_sb_25_tlag5',
    'ged_tx_sb_25_tlag6',
    'ged_tx_sb_25_tlag7',
    'ged_tx_sb_25_tlag8',
    'ged_tx_sb_25_tlag9',
    'ged_tx_sb_500_tlag1',
    'ged_tx_sb_500_tlag10',
    'ged_tx_sb_500_tlag11',
    'ged_tx_sb_500_tlag12',
    'ged_tx_sb_500_tlag2',
    'ged_tx_sb_500_tlag3',
    'ged_tx_sb_500_tlag4',
    'ged_tx_sb_500_tlag5',
    'ged_tx_sb_500_tlag6',
    'ged_tx_sb_500_tlag7',
    'ged_tx_sb_500_tlag8',
    'ged_tx_sb_500_tlag9',
    'ged_tx_sb_5_tlag1',
    'ged_tx_sb_5_tlag10',
    'ged_tx_sb_5_tlag11',
    'ged_tx_sb_5_tlag12',
    'ged_tx_sb_5_tlag2',
    'ged_tx_sb_5_tlag3',
    'ged_tx_sb_5_tlag4',
    'ged_tx_sb_5_tlag5',
    'ged_tx_sb_5_tlag6',
    'ged_tx_sb_5_tlag7',
    'ged_tx_sb_5_tlag8',
    'ged_tx_sb_5_tlag9',
    'ged_months_since_last_sb_tx5',
    'ged_months_since_last_ns_tx5',
    'ged_months_since_last_os_tx5',
    'ged_months_since_last_sb_lag1_tx5',
    'ged_months_since_last_ns_lag1_tx5',
    'ged_months_since_last_os_lag1_tx5',
    'ged_months_since_last_sb_tx25',
    'ged_months_since_last_ns_tx25',
    'ged_months_since_last_os_tx25',
    'ged_months_since_last_sb_lag1_tx25',
    'ged_months_since_last_ns_lag1_tx25',
    'ged_months_since_last_os_lag1_tx25',
    'ged_months_since_last_sb_tx100',
    'ged_months_since_last_ns_tx100',
    'ged_months_since_last_os_tx100',
    'ged_months_since_last_sb_lag1_tx100',
    'ged_months_since_last_ns_lag1_tx100',
    'ged_months_since_last_os_lag1_tx100',
    'ged_months_since_last_sb_tx500',
    'ged_months_since_last_ns_tx500',
    'ged_months_since_last_os_tx500',
    'ged_months_since_last_sb_lag1_tx500',
    'ged_months_since_last_ns_lag1_tx500',
    'ged_months_since_last_os_lag1_tx500',
]

feat_acled_v = [
    'acled_count_sb_lag1',
    'acled_count_ns_lag1',
    'acled_count_os_lag1',
    'acled_months_since_last_sb',
    'acled_months_since_last_ns',
    'acled_months_since_last_os',
    'acled_months_since_last_sb_lag1',
    'acled_months_since_last_ns_lag1',
    'acled_months_since_last_os_lag1',
]

feat_acled_pr = [
    'acled_count_pr_lag1',
    'acled_months_since_last_pr',
    'acled_months_since_last_pr_lag1',
]

# Non-pruned version of feat_vdem
# Consider to take out v2x_el_elecpres, v2x_el_elecparl, v2x_hosinter, v2x_suffr, v2x_elecreg, v2x_ex_elecreg,
# v2x_lg_elecreg, v2x_lg_leginter
feat_vdem = [
 'v2x_api',
 'v2x_civlib',
 'v2x_clphy',
 'v2x_clpol',
 'v2x_clpriv',
 'v2x_corr',
 'v2x_cspart',
 'v2x_delibdem',
 'v2x_edcomp_thick',
 'v2x_egal',
 'v2x_egaldem',
 'v2x_elecreg',
 'v2x_execorr',
 'v2x_feduni',
 'v2x_frassoc_thick',
 'v2x_freexp',
 'v2x_freexp_thick',
 'v2x_gencl',
 'v2x_gencs',
 'v2x_gender',
 'v2x_genpp',
 'v2x_hosinter',
 'v2x_jucon',
 'v2x_libdem',
 'v2x_liberal',
 'v2x_mpi',
 'v2x_partip',
 'v2x_partipdem',
 'v2x_polyarchy',
 'v2x_pubcorr',
 'v2x_suffr',
 'v2x_cl_rol',
 'v2x_cs_ccsi',
 'v2x_dd_dd',
 'v2x_dl_delib',
 'v2x_eg_eqdr',
 'v2x_eg_eqprotec',
 'v2x_el_elecparl',
 'v2x_el_elecpres',
 'v2x_el_frefair',
 'v2x_el_locelec',
 'v2x_el_regelec',
 'v2x_ex_elecreg',
 'v2x_lg_elecreg',
 'v2x_lg_legcon',
 'v2x_lg_leginter',
 'v2x_me_altinf',
 'v2x_ps_party'
]

# High-level v dem mocel
feat_vdem_hlc = [
 'v2x_delibdem',
 'v2x_egaldem',
 'v2x_libdem',
 'v2x_partipdem',
 'v2x_polyarchy'
]

feat_inst2019 = [
 'fvp_prop_excluded',
 'fvp_semi',
 'fvp_demo',
 'fvp_timeindep',
 'fvp_timesincepreindepwar',
 'fvp_timesinceregimechange',
]

# More extensive institutional model
feat_inst = [
 'fvp_prop_excluded',
 'fvp_semi',
 'fvp_demo',
 'fvp_timeindep',
 'fvp_timesincepreindepwar',
 'fvp_timesinceregimechange',
 'fvp_prop_discriminated',
 'fvp_prop_dominant',
 'fvp_prop_irrelevant',
 'fvp_prop_powerless',
 'fvp_indepyear',
]

feat_demog = [
 'fvp_population200',
 'ssp2_edu_sec_15_24_prop',
 'ssp2_urban_share_iiasa',
 'fvp_grpop200',
 'fvp_sp_dyn_imrt_in',
 'fvp_sp_dyn_tfrt_in',
]

feat_econ = [
 'fvp_grgdpcap_nonoilrent',
 'fvp_grgdpcap_oilrent',
 'fvp_lngdpcap_nonoilrent',
 'fvp_lngdpcap_oilrent',
 'fvp_lngdp200',
 'fvp_lngdppercapita200',

]


feat_base_ext = [
 'fvp_grgdpcap_nonoilrent',
 'fvp_grgdpcap_oilrent',
 'fvp_lngdpcap_nonoilrent',
 'fvp_lngdpcap_oilrent',
 'fvp_population200',
 'ssp2_edu_sec_15_24_prop',
 'ssp2_urban_share_iiasa',
]
feat_base2019 = feat_confhist2019 + feat_inst2019 + feat_base_ext


feat_reign = [
# 'rgn_leader',
 'rgn_elected',
 'rgn_age',
 'rgn_male',
 'rgn_militarycareer',
 'rgn_tenure_months',
# 'rgn_government',
 'rgn_anticipation',
 'rgn_ref_ant',
 'rgn_leg_ant',
 'rgn_exec_ant',
 'rgn_irreg_lead_ant',
 'rgn_election_now',
 'rgn_election_recent',
 'rgn_leg_recent',
 'rgn_exec_recent',
 'rgn_lead_recent',
 'rgn_ref_recent',
 'rgn_direct_recent',
 'rgn_indirect_recent',
 'rgn_victory_recent',
 'rgn_defeat_recent',
 'rgn_change_recent',
 'rgn_nochange_recent',
 'rgn_delayed',
 'rgn_lastelection',
 'rgn_loss',
 'rgn_irregular',
# 'rgn_prev_conflict',
 'rgn_pt_suc',
 'rgn_pt_attempt',
]

feat_couprisk  = [
 'rgn_precip',
 'rgn_couprisk',
 'rgn_pctile_risk',
]


feat_icgcw = [
 'icgcw_alerts',
 'icgcw_opportunities',
 'icgcw_deteriorated',
 'icgcw_improved',
]