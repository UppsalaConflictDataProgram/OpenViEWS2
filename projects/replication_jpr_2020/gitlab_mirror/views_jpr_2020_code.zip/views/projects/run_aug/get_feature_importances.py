
import os
import logging

from views.apps.evaluate import feature_importance as fi

from views.utils import pyutils
Logger = logging.getLogger(__name__)

def main():
    """ Get feature importances for cm_run and pgm_run runs """

    this_dir = os.path.dirname(os.path.abspath(__file__))
    dir_featimps = os.path.join(this_dir, "feature_importances")
    pyutils.create_dir(dir_featimps)
    fi.write_feature_importances_to_file(
        path=os.path.join(dir_featimps, "cm_run.json"),
        dir_run="~/views/rackham/runs/cm_run"
        )
    fi.write_feature_importances_to_file(
        path=os.path.join(dir_featimps, "pgm_run.json"),
        dir_run="~/views/rackham/runs/pgm_run"
        )
    Logger.info("Done making feature importances.")

if __name__ == "__main__":
    logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)
    main()
