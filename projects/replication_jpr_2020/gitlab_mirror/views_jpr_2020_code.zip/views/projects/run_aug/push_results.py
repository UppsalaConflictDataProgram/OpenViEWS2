import pandas as pd
import sys
import logging
import os
from views.utils import dbutils, pyutils, datautils
logging.basicConfig(
    stream=sys.stdout, format=pyutils.LOGFORMAT, level=logging.DEBUG
)
Logger = logging.getLogger(__name__)


times = {
    'cm_africa_1_A_predict': (397, 432),
    'cm_africa_1_B_predict': (433, 468),
    'cm_africa_1_C_predict': (477, 514),
    'pgm_africa_1_A_predict': (397, 432),
    'pgm_africa_1_B_predict': (433, 468),
    'pgm_africa_1_C_predict': (477, 514) # UPDATE TO 514!
}


runs = {
    # "/Users/frehoy/views/rackham/runs/cm_run/datasets": [
    #         "cm_africa_1_A_predict",
    #         "cm_africa_1_B_predict",
    #         "cm_africa_1_C_predict"
    # ],
    "/Users/frehoy/views/rackham/runs/models_pgm_v02/datasets": [
        "pgm_africa_1_A_predict",
        "pgm_africa_1_B_predict",
        "pgm_africa_1_C_predict"
    ]
}

for run_location, datasets in runs.items():
    print(run_location)
    print(datasets)
    for dataset in datasets:
        fname = f"{dataset}.parquet"
        path = os.path.join(run_location, fname)

        df = datautils.load_parquet(path)
        fqtable = f"newpipe.{dataset.lower()}"

        cols_pred = [col for col in df.columns if "semt" in col or "memt" in col]
        cols_25 = ["greq_25_ged_best_sb", "greq_25_ged_best_ns", "greq_25_ged_best_os"]
        cols_outcomes = ["ged_dummy_sb", "ged_dummy_ns", "ged_dummy_os", "acled_dummy_pr"]
        cols_onsets = ["ged_onset24_sb_25", "ged_onset24_ns_25", "ged_onset24_os_25" ]
        cols_100 = ["greq_100_ged_best_sb", "greq_100_ged_best_ns", "greq_100_ged_best_os"]
        cols_all = cols_outcomes + cols_25 + cols_pred + cols_onsets + cols_100
        df = df[cols_all]

        limits = times[dataset]
        df = df.loc[limits[0]:limits[1]]
        print(df.head())
        print(df.tail())
        dbutils.df_to_db(df=df, fqtable=fqtable, copy=True)
