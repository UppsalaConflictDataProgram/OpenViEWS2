conda activate dynasim

cd ~/gitlab/views/views/apps/ds

python main.py  --dir_scratch ~/views/test/ds/runs/ \
                --dir_input ~/views/test/ds/input \
                --path_paramfile ~/gitlab/views/projects/run_aug/ds/paramfiles/cm_v1.json \
