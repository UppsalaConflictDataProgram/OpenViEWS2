from views.apps.transforms import translib, spatial
from views.utils import dbutils

cols = [
    "acled_dummy_pr",
    "ged_best_ns",
    "ged_best_os",
    "ged_best_sb",
    "ged_dummy_ns",
    "ged_dummy_os",
    "ged_dummy_sb",
    "pgd_agri_ih",
    "pgd_barren_ih",
    "pgd_bdist3",
    "pgd_capdist",
    "pgd_diamsec",
    "pgd_excluded",
    "pgd_forest_ih",
    "pgd_gcp_mer",
    "pgd_imr_mean",
    "pgd_mountains_mean",
    "pgd_pasture_ih",
    "pgd_petroleum",
    "pgd_pop_gpw_sum",
    "pgd_savanna_ih",
    "pgd_urban_ih",
    "pgd_ttime_mean",
    "pgd_shrub_ih"
]

ids_pgm = ["month_id", "pg_id"]
df = dbutils.db_to_df_fast(fqtable="flat.pgm_africa_1", columns=cols, ids=ids_pgm)



gdf_geom = dbutils.db_to_gdf(query="SELECT gid AS pg_id, geom FROM staging.priogrid", groupvar="pg_id")

gdf = gdf_geom.join(df)

df['dist_pgd_diamsec'] = spatial.distance_to_event(gdf, event_col="pgd_diamsec")
df['dist_pgd_petroleum'] = spatial.distance_to_event(gdf, event_col="pgd_petroleum")
df['greq_25_ged_best_sb'] = translib.greater_or_equal(df['ged_best_sb'], value=25)
df['greq_25_ged_best_ns'] = translib.greater_or_equal(df['ged_best_ns'], value=25)
df['greq_25_ged_best_os'] = translib.greater_or_equal(df['ged_best_os'], value=25)
df['dummy_pgd_excluded'] = translib.greater_or_equal(df['pgd_excluded'], value=1)

df['ln_pgd_pop_gpw_sum'] = translib.natural_log(df['pgd_pop_gpw_sum'])
df['ln_pgd_bdist3'] = translib.natural_log(df['pgd_bdist3'])
df['ln_pgd_ttime_mean'] = translib.natural_log(df['pgd_ttime_mean'])
df['ln_dist_pgd_diamsec'] = translib.natural_log(df['dist_pgd_diamsec'])
df['ln_dist_pgd_petroleum'] = translib.natural_log(df['dist_pgd_petroleum'])
df['ln_pgd_capdist'] = translib.natural_log(df['pgd_capdist'])


path = "/Users/frehoy/views/test/ds/input/pgm/data/pgm_africa.hdf5"
df.reset_index().to_hdf(path, key='data')