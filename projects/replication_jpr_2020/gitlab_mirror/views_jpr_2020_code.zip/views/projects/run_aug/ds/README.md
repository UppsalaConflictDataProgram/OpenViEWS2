# 108

The goal is to have predictions at each step s in S:(1..36) into the future for both time periods A:(397...432) and B: (433:468).
A step s is how far into the future each prediction is, from the perspective of the predicting method. For dynasim s=1 is for the first t of simulation.

The goal is to have as much predicted data as possible to answer the question
"How well does this dynasim specification predict s months into the future" in order to weight ensembles differently for different s.

To do this we first create time slots.
Each slot is 36 times long.
The first gives s=36 predictions for the first t in A.
For the first slot the first 35 times of prediction are essentially wasted as they fall before the beginning of the A period.
The next slot gives s=36 predictions for the second t in A and s=35 prediction for the first t in A, and so on until the last slot gives predictions for s=1 for the last slot in B.
By moving the window forward one t at a time we produce s-ahead forecasts for all 36 s in S for each t in A and B.

In practice this is done by using the paramfiles in paramfile_templates and substituting the time limits in it through scripts/make_108.py.
The paramfiles are then run and the results collected with scripts/collect_108.py