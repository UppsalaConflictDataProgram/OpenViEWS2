# Resize all image files in the current directory IN PLACE to 33% of original size
# This will alter the input files destructively so use with caution.
mogrify -resize 50% *