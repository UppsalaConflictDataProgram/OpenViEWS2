import glob
import joblib
import multiprocessing as mp

glob_pickles = "/Users/frehoy/views/rackham/runs/pgm_run/trains/*"

def read(path):
    try:
        _ = joblib.load(path)
        print(f"ok {path}")
    except:
        print(f"failed reading {path}")
        raise
paths = list(glob.glob(glob_pickles))
with mp.Pool(processes=12) as pool:
    results = [pool.apply_async(read, (path, )) for path in paths]
    for result in results:
        result.get()

