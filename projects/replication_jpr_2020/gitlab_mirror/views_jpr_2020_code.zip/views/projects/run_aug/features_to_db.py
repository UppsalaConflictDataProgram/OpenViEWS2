import logging


import os
from views.utils import pyutils, datautils, dbutils
from views.apps.defparser import solver
fname_spec = "pgm.yaml"
path_spec = os.path.join("specs", fname_spec)

logging.basicConfig(format=pyutils.LOGFORMAT, level=logging.DEBUG)

df = datautils.load_parquet(pyutils.resole_vars_and_home("~/views/rackham/runs/pgm_run/datasets/pgm_africa_1_C_predict.parquet"))
df = df[[col for col in df.columns if not col.startswith("semt.") and not col.startswith("memt.")]]
df = df.loc[396:514]
dbutils.df_to_db(df, fqtable="newpipe.pgm_africa_1_c_features")
