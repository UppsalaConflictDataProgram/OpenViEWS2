import os
import pandas as pd
from views.utils import dbutils

ddir = "/Users/frehoy/views/test/runs/models_pgm_v01/datasets"

datasets = [
    "pgm_africa_0_A_predict",
    "pgm_africa_0_B_predict",
    "pgm_africa_0_C_predict",
]

cols_outcome = [
    "ged_dummy_sb",
    "ged_dummy_ns",
    "ged_dummy_os",
    "acled_dummy_pr"
    ]

times = {
    'pgm_africa_0_A_predict' : (397, 432),
    'pgm_africa_0_B_predict' : (433, 468),
    'pgm_africa_0_C_predict' : (476, 513)
}



for dataset in datasets:
    fname = f"{dataset}.parquet"
    path = os.path.join(ddir, fname)
    fqtable = f"newpipe.{dataset}".lower()
    print(fqtable)
    df = pd.read_parquet(path)
    cols_pred = [
        col for col in sorted(df.columns) if "memt." in col or "semt." in col
        ]
    cols_want = cols_outcome + cols_pred
    df = df[cols_want]

    limits = times[dataset]
    df = df.loc[limits[0]:limits[1]]
    print(f"read {path}")
    dbutils.df_to_db(df, fqtable)
    print(f"pushed {fqtable}")

print("done")

