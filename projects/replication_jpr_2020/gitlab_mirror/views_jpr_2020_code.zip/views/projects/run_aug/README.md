# August run in the new pipeline

This project is an attempt to run the new pipeline for actual use.
The name run_aug doesn't really make sense any more, but that's when it was supposed to be finished.
Oh well.
