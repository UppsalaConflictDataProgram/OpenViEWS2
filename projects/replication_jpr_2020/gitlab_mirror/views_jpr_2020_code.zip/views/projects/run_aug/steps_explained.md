# Partitioning. verbose example

This is a simplified and verbose example of the partitioning strategy employed by ViEWS.

## Setup

Let X denote features/independent variables
Let Y denote our outcomes.

We have three time periods: A B and C.
For this example, let

    A: 6-11
    B: 12-17
    C: 18-23

We have data of X and Y from time 0 to time 17.
C is the unknown future for which we have no data.

I have chosen not to call A,B or C names like calibration, testing, forecasting or evaluation as they have multiple uses.

For this example we have 3 steps ahead s for which we fit models: 1, 3 and 6.
A step indicates how many units of time into the future a model is trained to predict.

## Model sets

For 3 steps and 3 time periods we train 9 sets of models:

model_A_1, model_A_3, model_A_6,
model_B_1, model_B_3, model_B_6,
model_C_1, model_C_3, model_C_6.

Each of these model sets contains a number of models, with differing feature sets and estimation and forecasting algorithms but with shared training period and step.

For example, model_A_1 is the set of constituent models for predicting into the A period with step size = 1.

## Shifting and partitioning


### Training

Model sets are trained for each period and for each step.

model_A_1 is trained on data shifted 1 time unit, limited by the beginning of the A period.
Shifting refers to aligning outcomes y_t to outcomes x_(t-step)

Thus, model_A_1 is trained on the following data

    y_1, x_0
    y_2, x_1
    y_3, x_2
    y_4, x_3
    y_5, x_4

model_B_1 is trained on the following data

    y_1, x_0
    y_2, x_1
    y_3, x_2
    y_4, x_3
    y_5, x_4
    y_6, x_5
    y_7, x_6
    y_8, x_7
    y_9, x_8
    y_10, x_9
    y_11, x_10
    y_12, x_11

model_C_1 is trained on the following data

    y_1, x_0
    y_2, x_1
    y_3, x_2
    y_4, x_3
    y_5, x_4
    y_6, x_5
    y_7, x_6
    y_8, x_7
    y_9, x_8
    y_10, x_9
    y_11, x_10
    y_12, x_11
    y_13, x_12
    y_14, x_13
    y_15, x_14
    y_16, x_15
    y_17, x_16

Increasing the step to 3 we shift the features X further from our outcomes.

model_A_3:

    y_3, x_0
    y_4, x_1
    y_5, x_2

model_B_3:

    y_3, x_0
    y_4, x_1
    y_5, x_2
    y_6, x_3
    y_7, x_4
    y_8, x_5
    y_9, x_6
    y_10, x_7
    y_11, x_8


model_C_3:

    y_3, x_0
    y_4, x_1
    y_5, x_2
    y_6, x_3
    y_7, x_4
    (...)
    y_17, x_14

And finally for step 6

Model_A_6 is trained on

    y_6, x_0

Model_B_6 is trained on

    y_6, x_0
    y_7, x_1
    y_8, x_2
    y_9, x_3
    y_10, x_4
    y_11, x_5

Model_C_6 is trained on

    y_6, x_0
    y_7, x_1
    y_8, x_2
    y_9, x_3
    y_10, x_4
    y_11, x_5
    y_12, x_6
    y_13, x_7
    y_14, x_8
    y_15, x_9
    y_16, x_10
    y_17, x_11


### Prediction

We now have 9 trained sets of models, one for each combination of the periods A,B,C and each step ahead s: (1, 3, 6).

Below are the predicitons we make for models.

I will show predictions in this format

Y_time_step = model_period_step * X_time

where * denotes the appropriate prediction function for the underlying estimator.

For s=1

    Y_6_1 = model_A_1 * X_5     # First A
    Y_7_1 = model_A_1 * X_6
    Y_8_1 = model_A_1 * X_7
    Y_9_1 = model_A_1 * X_8
    Y_10_1 = model_A_1 * X_9
    Y_11_1 = model_A_1 * x_10   # Last A
    Y_12_1 = model_B_1 * X_11   # First B
    Y_13_1 = model_B_1 * X_12
    Y_14_1 = model_B_1 * X_13
    Y_15_1 = model_B_1 * X_14
    Y_16_1 = model_B_1 * X_15
    Y_17_1 = model_B_1 * X_16   # Last B
    Y_18_1 = model_C_1 * X_17   # First C

We can't predict Y_19_1 with model_C1 * X_18 because X_18 is in the future.

For s=3

    Y_6_3 = model_A_3 * X_3
    Y_7_3 = model_A_3 * X_4
    Y_8_3 = model_A_3 * X_5
    Y_9_3 = model_A_3 * X_6
    Y_10_3 = model_A_3 * X_7
    Y_11_3 = model_A_3 * X_8
    Y_12_3 = model_B_3 * X_9
    Y_13_3 = model_B_3 * X_10
    Y_14_3 = model_B_3 * X_11
    Y_15_3 = model_B_3 * X_12
    Y_16_3 = model_B_3 * X_13
    Y_17_3 = model_B_3 * X_14
    Y_18_3 = model_C_3 * X_15 # Discard
    Y_19_3 = model_C_3 * X_16 # Discard
    Y_20_3 = model_C_3 * X_17

Y_18_3 and Y_19_3 are marked with # Discard as they are not used anywhere.

For s=3 we can get predictions of Y only to time 20 because data for X only goes to time 17 as the future starts in 18.

For s=6

    Y_6_6 = model_A_6  * X_0
    Y_7_6 = model_A_6  * X_1
    Y_8_6 = model_A_6  * X_2
    Y_9_6 = model_A_6  * X_3
    Y_10_6 = model_A_6 * X_4
    Y_11_6 = model_A_6 * X_5
    Y_12_6 = model_B_6 * X_6
    Y_13_6 = model_B_6 * X_7
    Y_14_6 = model_B_6 * X_8
    Y_15_6 = model_B_6 * X_9
    Y_16_6 = model_B_6 * X_10
    Y_17_6 = model_B_6 * X_11
    Y_18_6 = model_C_6 * X_12 # Discard
    Y_19_6 = model_C_6 * X_13 # Discard
    Y_20_6 = model_C_6 * X_14 # Discard
    Y_21_6 = model_C_6 * X_15 # Discard
    Y_22_6 = model_C_6 * X_16 # Discard
    Y_23_6 = model_C_6 * X_17

For s=6 we can get predictions of Y all the way to time 23.
Y_18_6 - Y_22_6 are marked with # Discard as they are note used anywhere.

We then compute our interpolated predictions for the C partition, our constituent model forecast.
These become our constituent model forecasts.

    Y_18_ipol = y_18_1
    Y_19_ipol = interpolate
    Y_20_ipol = Y_20_3
    Y_21_ipol = interpolate
    Y_22_ipol = interpolate
    Y_23_ipol = Y_23_6

We also compute the same interpolated step predictions for B:

    Y_12_6_ipol = Y_12_1
    Y_13_6_ipol = ipol
    Y_14_6_ipol = Y_14_3
    Y_15_6_ipol = interpolate
    Y_16_6_ipol = interpolate
    Y_17_6_ipol = Y_17_6


For each time in A and B we now have 3 different sets of predictions of Y, one for each step s.
For each time in B and C we also have a single interpolated prediction.

## Estimate ensemble weights with EBMA

We now estimate our EBMA weights and produce our per-step EBMA predictions.
This is done separately by step, to allow for different models to have different weights at different steps ahead or forecasting horisons.

EBMA takes three parameters:

    * calibration data, which are constituent model predictions
    * calibration actuals, which are actual outcomes matching the calibration data
    * test data, which are constituent model predictions on which to apply the EBMA weights and compute an ensemble predicted probability.

and produces two outputs:

    * A set of weights
    * EBMA predictions for the test data

For weights, they are computed as follows:

    y_12_ebma_1 - y_17_ebma_1, WAB_1 is computed by EBMA with the calibration actuals Y: Y_6  - Y_11, calibration predictions Y_6_1  - Y_11_1 and test predictions Y_12_1 - Y_17_1.
    y_12_ebma_3 - y_17_ebma_3, WAB_3 is computed by EBMA with the calibration actuals Y: Y_6  - Y_11, calibration predictions Y_6_3  - Y_11_3 and test predictions Y_12_3 - Y-17_3.
    y_12_ebma_6 - y_17_ebma_6, WAB_6 is computed by EBMA with the calibration actuals Y: Y_6  - Y_11, calibration predictions Y_6_6  - Y_11_6 and test predictions Y_12_6  - Y_17_6.
    WBC_1 is computed by EBMA with the calibration actuals Y: Y_12 - Y_17, calibration predictions Y_12_1 - Y_17_1 and no tests predictions.
    WBC_3 is computed by EBMA with the calibration actuals Y: Y_12 - Y_17, calibration predictions Y_12_3 - Y_17_3 and no tests predictions.
    WBC_6 is computed by EBMA with the calibration actuals Y: Y_12 - Y_17, calibration predictions Y_12_6 - Y_17_6 and no tests predictions.

Model predictions and actuals from A are used to compute weights AB and model predictions and actuals from B are used to compute weights BC.
Note the absence of test set predictions for the BC EBMA, as we don't have enough per step predictions for the C period.

In the process of estimating the weights we also get EBMA predictions for each step.
These can be used to evaluate the performance of the EBMA for each step.
More on per-step evaluation in "Evaluating models at each step".


These weights are then interpolated.

    WAB_1 = WAB_1
    WAB_2 = interpolated
    WAB_3 = WAB_3
    WAB_4 = interpolated
    WAB_5 = interpolated
    WAB_6 = WAB_6

and the same way for BC

    WBC_1 = WBC_1
    WBC_2 = interpolated
    WBC_3 = WBC_3
    WBC_4 = interpolated
    WBC_5 = interpolated
    WBC_6 = WBC_6

We now have a complete set of weights for each step, including the interpoltaed steps, to apply to the constituent models.

## Calibrating constituent model predictions

We then calibrate the interpolated constituent model predictions.
We do this by partition, so by A/B/C.
Predictions in B are calibrated by their corresponding predictions in A.
Predictions in C are calibrated by their corresponding predictions in B.

A set of calibration logit models is fitted on actual outcome versus our interpolated prediction.

For AB_calibration the calibration parameters are estimated on

    Y_12, Y_12_ipol
    Y_13, Y_13_ipol
    Y_14, Y_14_ipol
    Y_15, Y_15_ipol
    Y_16, Y_16_ipol
    Y_17, Y_17_ipol

And for BC_calibration

    Y_18, Y_18_ipol
    Y_19, Y_19_ipol
    Y_20, Y_20_ipol
    Y_21, Y_21_ipol
    Y_22, Y_22_ipol
    Y_23, Y_23_ipol

Note: In a later revision we probably want to do this calibration by step. For now it is done by period.

## EBMA forecast with per-step weights

The calibration parameters from these models are then applied to the interpolated predictions:

    Y_12_ipol_calibrated = Y_12_ipol * AB_calibration
    Y_13_ipol_calibrated = Y_13_ipol * AB_calibration
    Y_14_ipol_calibrated = Y_14_ipol * AB_calibration
    Y_15_ipol_calibrated = Y_15_ipol * AB_calibration
    Y_16_ipol_calibrated = Y_16_ipol * AB_calibration
    Y_17_ipol_calibrated = Y_17_ipol * AB_calibration
    Y_18_ipol_calibrated = Y_18_ipol * BC_calibration
    Y_19_ipol_calibrated = Y_19_ipol * BC_calibration
    Y_20_ipol_calibrated = Y_20_ipol * BC_calibration
    Y_21_ipol_calibrated = Y_21_ipol * BC_calibration
    Y_22_ipol_calibrated = Y_22_ipol * BC_calibration
    Y_23_ipol_calibrated = Y_23_ipol * BC_calibration

And to get our EBMA predictions we apply our EBMA weights:

    Y_12_ebma = Y_12_ipol_calibrated * WAB_1
    Y_13_ebma = Y_13_ipol_calibrated * WAB_2
    Y_14_ebma = Y_14_ipol_calibrated * WAB_3
    Y_15_ebma = Y_15_ipol_calibrated * WAB_4
    Y_16_ebma = Y_16_ipol_calibrated * WAB_5
    Y_17_ebma = Y_17_ipol_calibrated * WAB_6
    Y_18_ebma = Y_18_ipol_calibrated * WBC_1
    Y_19_ebma = Y_19_ipol_calibrated * WBC_2
    Y_20_ebma = Y_20_ipol_calibrated * WBC_3
    Y_21_ebma = Y_21_ipol_calibrated * WBC_4
    Y_22_ebma = Y_22_ipol_calibrated * WBC_5
    Y_23_ebma = Y_23_ipol_calibrated * WBC_6

These 6 final predictions are our EBMA forecasts for the C partition, our forecast of the future.


## Evaluating models at each step

This setup of training and storing each model set for each step and period also allow us to evaluate predictive performance of constituent models separetely for each step.
For example, we can find the set of performance metrics for s=1 models by comparing them over the combination of predicted and actuals

    Y_12, Y_12_1
    Y_13, Y_13_1
    Y_14, Y_14_1
    Y_15, Y_15_1
    Y_16, Y_16_1
    Y_17, Y_17_1

and separately compute the evaluation metrics for s=3 models

    Y_12, Y_12_3
    Y_13, Y_13_3
    Y_14, Y_14_3
    Y_15, Y_15_3
    Y_16, Y_16_3
    Y_17, Y_17_3

In the same way we can take the predictions we got while estimating EBMA and evaluate them per-step in the same way.

    y_12, y_12_ebma_1
    y_13, y_13_ebma_1
    y_14, y_14_ebma_1
    y_15, y_15_ebma_1
    y_16, y_16_ebma_1
    y_17, y_17_ebma_1

    (...)

    y_12, y_12_ebma_1
    y_13, y_13_ebma_1
    y_14, y_14_ebma_1
    y_15, y_15_ebma_1
    y_16, y_16_ebma_1
    y_17, y_17_ebma_1

