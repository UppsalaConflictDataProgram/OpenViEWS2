import os
import numpy as np
from views.utils import datautils, dbutils, pyutils, config
from views.apps.plot.maps.fancy import fancy
import multiprocessing as mp


def col_to_title(col, t, mapdata, s):
    outcome = col[0:2]
    col_sans_prefix = col[3:]
    name = NAMES[col_sans_prefix]
    date = mapdata.df_m.loc[t, "date_str"]
    title = f"{outcome.upper()}, {name}, {date}, s={s}"
    return title


def plot_map(mapdata, df, col, t, destination, s):
    try:
        fname = f"{col}_{t}.png"
        path = os.path.join(destination, fname)
        fancy.plot_map(
            mapdata=mapdata,
            s_patch=df[col],
            t=t,
            path=path,
            title=col_to_title(col, t, mapdata, s),
            bbox="mainland_africa"
        )
    except:
        print(f"Couldnt plot {col} {t}")


NAMES = {
    "100_all": "All features, 100+ deaths",
    "acled_protest": "ACLED Protest",
    "acled_violence": "ACLED Violence",
    "all": "All features",
    "all_25": "All features, 25+ deaths",
    "allthemes": "All themes",
    "cdummies": "Country dummies",
    "cflong": "Conflict History",
    "demog": "Demography",
    "ds_25": "Dynasim, 25+ deaths",
    "ds_dummy": "Dynasim, 1+ deaths",
    "econ": "Economics",
    "hist_legacy": "Conflict history",
    "icgcw": "Crisis Watch",
    "inst": "Institutions",
    "neibhist": "Neighbors history",
    "onset24_100_all": "Onset, 100+ deaths",
    "onset24_1_all": "Onset 1+ deaths",
    "onset24_25_all": "Onset, 25+ deaths",
    "onset24_5_all": "Onset 5+ deaths",
    "pgd_natural": "Natural Geography",
    "pgd_social": "Social Geography",
    "reign": "REIGN",
    "reign_coups": "REIGN coups",
    "reign_drought": "REIGN drought",
    "spei_full": "SPEI Only",
    "speisubset_leghist": "SPEI and history",
    "sptime": "Spacetime",
    "sptime_and_all_themes": "Spacetime and all themes",
    "vdem": "VDEM",
    "vdem_high": "VDEM High",
    "average": "Ensemble Average",
    "ebma": "EBMA",
}

mapdata = fancy.MapData()

ids_pgm = ["month_id", "pg_id"]
ids_cm = ["month_id", "country_id"]

renames_cm = {
    "mtebma_sb_all": "sb_ebma",
    "mtebma_ns_all": "ns_ebma",
    "mtebma_os_all": "os_ebma",
}

renames_pgm = {
    "avg_sb_all": "sb_average",
    "avg_ns_all": "ns_average",
    "avg_os_all": "os_average",
}

dir_maps_pgm = os.path.join(
    config.CONFIG["dirs"]["dir_scratch"], "plots", "jpr_2020", "maps", "pgm"
)
dir_maps_cm = os.path.join(
    config.CONFIG["dirs"]["dir_scratch"], "plots", "jpr_2020", "maps", "cm"
)
pyutils.create_dir(dir_maps_pgm)
pyutils.create_dir(dir_maps_cm)

# PGM: Get calibrated features, ensemble predictions and features
df_pgm_c = dbutils.db_to_df(
    "newpipe.pgm_africa_1_c_predict_calibrated", ids=ids_pgm
)
df_pgm_c = df_pgm_c.join(
    dbutils.db_to_df("newpipe.pgm_africa_1_c_ensemble", ids=ids_pgm)
)
df_pgm_c = df_pgm_c.rename(
    columns=lambda col: col.replace("memt.", "").replace(".", "_")
)
df_pgm_c = df_pgm_c.rename(columns=renames_pgm)

# CM: Get calibrated features, ensemble predictions
df_cm_c = dbutils.db_to_df(
    "newpipe.cm_africa_1_c_predict_calibrated", ids=ids_cm
)
df_cm_c = df_cm_c.join(
    dbutils.db_to_df("newpipe.cm_africa_1_c_ensemble", ids=ids_cm)
)
df_cm_c = df_cm_c.rename(
    columns=lambda col: col.replace("memt.", "").replace(".", "_")
)
df_cm_c = df_cm_c.rename(columns=renames_cm)


times = [477, 482, 483, 484, 488, 500, 512]

with mp.Pool(processes=12) as pool:
    results = []
    for col in df_cm_c.columns:
        for t in times:
            s = t - min(times) + 1
            results.append(
                pool.apply_async(
                    plot_map, (mapdata, df_cm_c[[col]], col, t, dir_maps_cm, s)
                )
            )

    for col in df_pgm_c.columns:
        for t in times:
            s = t - min(times) + 1
            results.append(
                pool.apply_async(
                    plot_map, (mapdata, df_pgm_c[[col]], col, t, dir_maps_pgm, s)
                )
            )


    for result in results:
        result.get()
