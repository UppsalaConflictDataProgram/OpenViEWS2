CREATE VIEW flat.pgm_africa_2 AS
SELECT
       a.*,
        lag(pgm.ged_best_sb_lag1, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag1,
        lag(pgm.ged_best_ns_lag1, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag1,
        lag(pgm.ged_best_os_lag1, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag1,
        lag(pgm.ged_best_sb_lag2, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag1,
        lag(pgm.ged_best_ns_lag2, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag1,
        lag(pgm.ged_best_os_lag2, 1) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag1,
        lag(pgm.ged_best_sb_lag1, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag2,
        lag(pgm.ged_best_ns_lag1, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag2,
        lag(pgm.ged_best_os_lag1, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag2,
        lag(pgm.ged_best_sb_lag2, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag2,
        lag(pgm.ged_best_ns_lag2, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag2,
        lag(pgm.ged_best_os_lag2, 2) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag2,
        lag(pgm.ged_best_sb_lag1, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag3,
        lag(pgm.ged_best_ns_lag1, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag3,
        lag(pgm.ged_best_os_lag1, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag3,
        lag(pgm.ged_best_sb_lag2, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag3,
        lag(pgm.ged_best_ns_lag2, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag3,
        lag(pgm.ged_best_os_lag2, 3) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag3,
        lag(pgm.ged_best_sb_lag1, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag4,
        lag(pgm.ged_best_ns_lag1, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag4,
        lag(pgm.ged_best_os_lag1, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag4,
        lag(pgm.ged_best_sb_lag2, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag4,
        lag(pgm.ged_best_ns_lag2, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag4,
        lag(pgm.ged_best_os_lag2, 4) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag4,
        lag(pgm.ged_best_sb_lag1, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag5,
        lag(pgm.ged_best_ns_lag1, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag5,
        lag(pgm.ged_best_os_lag1, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag5,
        lag(pgm.ged_best_sb_lag2, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag5,
        lag(pgm.ged_best_ns_lag2, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag5,
        lag(pgm.ged_best_os_lag2, 5) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag5,
        lag(pgm.ged_best_sb_lag1, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag6,
        lag(pgm.ged_best_ns_lag1, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag6,
        lag(pgm.ged_best_os_lag1, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag6,
        lag(pgm.ged_best_sb_lag2, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag6,
        lag(pgm.ged_best_ns_lag2, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag6,
        lag(pgm.ged_best_os_lag2, 6) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag6,
        lag(pgm.ged_best_sb_lag1, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag7,
        lag(pgm.ged_best_ns_lag1, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag7,
        lag(pgm.ged_best_os_lag1, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag7,
        lag(pgm.ged_best_sb_lag2, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag7,
        lag(pgm.ged_best_ns_lag2, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag7,
        lag(pgm.ged_best_os_lag2, 7) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag7,
        lag(pgm.ged_best_sb_lag1, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag8,
        lag(pgm.ged_best_ns_lag1, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag8,
        lag(pgm.ged_best_os_lag1, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag8,
        lag(pgm.ged_best_sb_lag2, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag8,
        lag(pgm.ged_best_ns_lag2, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag8,
        lag(pgm.ged_best_os_lag2, 8) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag8,
        lag(pgm.ged_best_sb_lag1, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag9,
        lag(pgm.ged_best_ns_lag1, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag9,
        lag(pgm.ged_best_os_lag1, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag9,
        lag(pgm.ged_best_sb_lag2, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag9,
        lag(pgm.ged_best_ns_lag2, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag9,
        lag(pgm.ged_best_os_lag2, 9) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag9,
        lag(pgm.ged_best_sb_lag1, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag10,
        lag(pgm.ged_best_ns_lag1, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag10,
        lag(pgm.ged_best_os_lag1, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag10,
        lag(pgm.ged_best_sb_lag2, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag10,
        lag(pgm.ged_best_ns_lag2, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag10,
        lag(pgm.ged_best_os_lag2, 10) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag10,
        lag(pgm.ged_best_sb_lag1, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag11,
        lag(pgm.ged_best_ns_lag1, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag11,
        lag(pgm.ged_best_os_lag1, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag11,
        lag(pgm.ged_best_sb_lag2, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag11,
        lag(pgm.ged_best_ns_lag2, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag11,
        lag(pgm.ged_best_os_lag2, 11) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag11,
        lag(pgm.ged_best_sb_lag1, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag1_tlag12,
        lag(pgm.ged_best_ns_lag1, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag1_tlag12,
        lag(pgm.ged_best_os_lag1, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag1_tlag12,
        lag(pgm.ged_best_sb_lag2, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_sb_lag2_tlag12,
        lag(pgm.ged_best_ns_lag2, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_ns_lag2_tlag12,
        lag(pgm.ged_best_os_lag2, 12) OVER (PARTITION BY pgm.pg_id ORDER BY pgm.month_id) as ged_best_os_lag2_tlag12
FROM
    flat.pgm_africa_1 a,
    preflight.flight_pgm pgm WHERE a.pg_id=pgm.pg_id AND a.month_id=pgm.pg_id;



CREATE VIEW flat.pgm_africa_2_month_1 AS
SELECT
  lead(ged_dummy_sb, 1) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 1) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 1) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 1) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;


CREATE VIEW flat.pgm_africa_2_month_3 AS
SELECT
  lead(ged_dummy_sb, 3) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 3) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 3) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 3) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;

CREATE VIEW flat.pgm_africa_2_month_6 AS
SELECT
  lead(ged_dummy_sb, 6) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 6) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 6) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 6) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;

CREATE VIEW flat.pgm_africa_2_month_9 AS
SELECT
  lead(ged_dummy_sb, 9) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 9) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 9) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 9) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;

CREATE VIEW flat.pgm_africa_2_month_12 AS
SELECT
  lead(ged_dummy_sb, 12) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 12) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 12) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 12) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;

CREATE VIEW flat.pgm_africa_2_month_24 AS
SELECT
  lead(ged_dummy_sb, 24) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 24) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 24) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 24) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;

CREATE VIEW flat.pgm_africa_2_month_36 AS
SELECT
  lead(ged_dummy_sb, 36) OVER (PARTITION BY pg_id ORDER BY month_id) as y_sb,
  lead(ged_dummy_ns, 36) OVER (PARTITION BY pg_id ORDER BY month_id) as y_ns,
  lead(ged_dummy_os, 36) OVER (PARTITION BY pg_id ORDER BY month_id) as y_os,
  lead(month_id, 36) OVER (PARTITION BY pg_id ORDER BY month_id) as y_month,
  *
FROM flat.pgm_africa_2;


SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_1_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_1 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_1 WHERE y_sb+y_ns+y_os>0)
UNION ALL
(SELECT * FROM flat.pgm_africa_2_month_1 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_3_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_3 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_3 WHERE y_sb+y_ns+y_os>0)
UNION ALL
(SELECT * FROM flat.pgm_africa_2_month_3 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_6_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_6 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_6 WHERE y_sb+y_ns+y_os>0)
UNION ALL
(SELECT * FROM flat.pgm_africa_2_month_6 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_9_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_9 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_9 WHERE y_sb+y_ns+y_os>0)
UNION ALL
 (SELECT * FROM flat.pgm_africa_2_month_9 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_12_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_12 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_12 WHERE y_sb+y_ns+y_os>0)
UNION ALL
(SELECT * FROM flat.pgm_africa_2_month_12 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_24_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_24 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_24 WHERE y_sb+y_ns+y_os>0)
UNION ALL
 (SELECT * FROM flat.pgm_africa_2_month_24 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);

CREATE VIEW flat.pgm_africa_2_month_36_down AS
with a as (SELECT count(*) as c FROM flat.pgm_africa_2_month_36 WHERE y_sb+y_ns+y_os=0)
(SELECT * FROM flat.pgm_africa_2_month_36 WHERE y_sb+y_ns+y_os>0)
UNION ALL
 (SELECT * FROM flat.pgm_africa_2_month_36 WHERE y_sb+y_ns+y_os=0 ORDER BY RANDOM() LIMIT (SELECT (c*0.1)::int FROM a));

SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_1d AS SELECT * FROM flat.pgm_africa_2_month_1_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_3d AS SELECT * FROM flat.pgm_africa_2_month_3_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_6d AS SELECT * FROM flat.pgm_africa_2_month_6_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_9d AS SELECT * FROM flat.pgm_africa_2_month_9_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_12d AS SELECT * FROM flat.pgm_africa_2_month_12_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_24d AS SELECT * FROM flat.pgm_africa_2_month_24_down;
SELECT setseed(0.1);
CREATE TABLE flat_materialized.afr_36d AS SELECT * FROM flat.pgm_africa_2_month_36_down;


CREATE TABLE flat_materialized.afr_1d_calib AS SELECT * FROM flat.pgm_africa_2_month_1 WHERE pgm_africa_2_month_1 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_3d_calib AS SELECT * FROM flat.pgm_africa_2_month_3 WHERE pgm_africa_2_month_3 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_6d_calib AS SELECT * FROM flat.pgm_africa_2_month_6 WHERE pgm_africa_2_month_6 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_9d_calib AS SELECT * FROM flat.pgm_africa_2_month_9 WHERE pgm_africa_2_month_9 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_12d_calib AS SELECT * FROM flat.pgm_africa_2_month_12 WHERE pgm_africa_2_month_12 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_24d_calib AS SELECT * FROM flat.pgm_africa_2_month_24 WHERE pgm_africa_2_month_24 IS NOT NULL AND y_month BETWEEN 396 AND 432;
CREATE TABLE flat_materialized.afr_36d_calib AS SELECT * FROM flat.pgm_africa_2_month_36 WHERE pgm_africa_2_month_36 IS NOT NULL AND y_month BETWEEN 396 AND 432;


CREATE TABLE flat_materialized.afr_1d_eval AS SELECT * FROM flat.pgm_africa_2_month_1 WHERE pgm_africa_2_month_1 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_3d_eval AS SELECT * FROM flat.pgm_africa_2_month_3 WHERE pgm_africa_2_month_3 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_6d_eval AS SELECT * FROM flat.pgm_africa_2_month_6 WHERE pgm_africa_2_month_6 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_9d_eval AS SELECT * FROM flat.pgm_africa_2_month_9 WHERE pgm_africa_2_month_9 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_12d_eval AS SELECT * FROM flat.pgm_africa_2_month_12 WHERE pgm_africa_2_month_12 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_24d_eval AS SELECT * FROM flat.pgm_africa_2_month_24 WHERE pgm_africa_2_month_24 IS NOT NULL AND y_month BETWEEN 433 AND 600;
CREATE TABLE flat_materialized.afr_36d_eval AS SELECT * FROM flat.pgm_africa_2_month_36 WHERE pgm_africa_2_month_36 IS NOT NULL AND y_month BETWEEN 433 AND 600;


CREATE OR REPLACE FUNCTION pg_schema_size(text) RETURNS BIGINT AS $$
SELECT SUM(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename)))::BIGINT FROM pg_tables WHERE schemaname = $1
$$ LANGUAGE SQL;

select pg_size_pretty(pg_schema_size('cand_paper'));
