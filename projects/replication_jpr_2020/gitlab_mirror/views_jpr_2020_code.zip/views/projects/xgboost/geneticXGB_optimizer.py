# flake8: noqa
# pylint: skip-file

import random
from functools import total_ordering
import bisect

import pandas as pd
import numpy as np
import pickle

import sys

import xgboost as xgb
from sklearn.metrics import (
    auc,
    roc_curve as roc,
    roc_auc_score as auc_roc,
    precision_recall_curve as pr,
    average_precision_score as auc_pr,
)
from sklearn.ensemble import RandomForestClassifier


class InstFunEvaluator:
    """Instrumented function evaluator"""

    def __init__(self, fun, param_grid_dic, log_level=0):
        """Initialize evaluator function and param_grid
        fun should be a function taking a single argument (implementing a dict interfase) and
            returning a float.
        param_grid_dic should an ordered dic with keys being parameter names
        each value in should be an array of valid values for the i-th argument of fun """

        # n_params = len(param_grid)

        self._fun = fun
        self._param_grid = list(param_grid_dic.values())
        self._param_names = list(param_grid_dic.keys())
        self._n_params = len(self._param_grid)

        # self._eval_cnt = 0
        self._eval_log = []
        self._log_level = log_level

    def from_idxs(self, x_idxs, extra=None):
        """Evaluate self.fun on parameters given by indices into each value of the
        param grid, that is for the d-th parameter use the x_idxs[d] value
        for the corresponding valid range of values"""

        param_dic = {
            self._param_names[d]: self._param_grid[d][x_idxs[d]]
            for d in range(self._n_params)
        }

        return self.eval_fun(param_dic, extra)

    def from_vals(self, val_arr, extra=None):
        param_dic = {
            name: val for name, val in zip(self._param_names, val_arr)
        }

        return self.eval_fun(self, param_dic, extra)

    def eval_fun(self, param_dic, extra=None):

        fun_val = self._fun(param_dic)

        if self._log_level > 0:
            print(param_dic, fun_val)

        # self._eval_cnt += 1
        eval_record = {
            "eval_cnt": self.eval_cnt(),
            "pars": param_dic,
            "extra": extra,
            "fun_val": fun_val,
        }

        self._eval_log.append(eval_record)

        return fun_val

    def eval_cnt(self):
        """Return total number of function evaluations so far"""
        return len(self._eval_log)

    def eval_log(self):
        """Return a list of dicts containing details about evaluations so far"""
        return self._eval_log

    def idxs_to_xs(self, x_idxs):
        return [self._param_grid[idx] for idx in x_idxs]


# -*- coding: utf-8 -*-


@total_ordering
class EvaluatedIndiv:
    def __init__(self, indiv, fitness, gen_num):
        self.indiv = indiv
        self.fitness = fitness
        self.gen_num = gen_num

    def __eq__(self, other):
        return (self.indiv == other.indiv) and (self.fitness == other.fitness)

    def __ne__(self, other):
        return not self.eq(other)

    def __lt__(self, other):
        return self.fitness > other.fitness

    def __str__(self):
        return "EvaluatedIndiv( indiv=%s, fitness=%.6g, gen_num=%d)" % (
            self.indiv,
            self.fitness,
            self.gen_num,
        )

    def fetch_genes(self):
        return self.indiv

    def __repr__(self):
        return str(self)


#%%


def genetic_algorithm(
    fitness_fun,
    genes_grid,
    init_pop=None,
    pop_size=10,
    n_gen=100,
    mutation_prob=0.1,
    normalize=None,
    seed=1337,
):
    """
    *** THIS CODE ADAPTED FROM AIMA3 (Russel & Norvig)
    *** MIT License
    Implementation of genetic algorithms logic tailored for hyper-parameter optimization:
    Section 4.2, Rusell & Norvig,   Artificial Intelligence a modern a approach, Prentice Hall, 3rd Edition
    http://aima.cs.berkeley.edu/
    A reference implementation where individuals are encoded as sequences is given here:
        https://github.com/aimacode/aima-python/blob/master/search.py
    See function genetic_algorithm and related ones.
    In our implementation, an **individual** is just a dictionary mapping parameter names to values,
    ej.   {  "num_trees" : 100,  "max_tree_depth": 5,  "min_leaf_split" : 5, ... }
    A fitness function is one that takes such a dictionary as a single argument
    and returns a fitness score. The objective is to _maximize_ the fitness function.
    Genetic algoritms assume these parameters have an order that makes sense for the cross-over
    operation. For a discussion on why this matters see page 128 of refence above.
    This order is specified through the param_names argument
    Parameters:
    init_pop: an initial list of individuals
    fitness_fun : a real-valued function that takes a dictionary as a single parameter
    mutation_prob : probability of mutating an individual
    genes_grid : an orderedDict with entries ('param_value' : [ list of possible values for param ] )
        the keys should be the for fitness
                 function in an order that makes sense for doing genetic
                 recombination (see comment above and recombine function)
    n_gen : number of generations
    Returns:
    """
    random.seed(seed)
    num_evaluations = 0

    gene_values = list(genes_grid.values())
    fun_eval = InstFunEvaluator(fitness_fun, genes_grid)
    print(fun_eval)
    print(fitness_fun)
    print(genes_grid)
    print("*" * 24)
    del genes_grid

    if init_pop is None:
        init_pop = init_population(pop_size, gene_values)

    pop_size = len(init_pop)

    print(init_pop)
    evaluated_pop = [
        EvaluatedIndiv(
            indiv=indiv, fitness=fun_eval.from_idxs(indiv), gen_num=0
        )
        for indiv in init_pop
    ]

    all_indivs = evaluated_pop.copy()

    num_evaluations += pop_size

    for gen_num in range(1, n_gen + 1):
        evaluated_pop = run_one_generation(
            evaluated_pop,
            fun_eval,
            gene_values,
            mutation_prob,
            normalize,
            gen_num,
        )
        all_indivs.extend(evaluated_pop)
        num_evaluations += pop_size

        print(
            "gen: %d best_indiv: %s, best_ever:%s"
            % (
                gen_num,
                max(evaluated_pop, key=lambda i: i.fitness),
                max(all_indivs, key=lambda i: i.fitness),
            )
        )
    # return all_indivs
    return sorted(all_indivs, key=lambda ei: ei.fitness, reverse=True)


def init_population(pop_size, gene_values):
    """Initializes population for genetic algorithm
    pop_size    :  Number of individuals in population
    gene_values   :  List of possible values for individuals
    state_length:  The length of each individual"""

    # n_genes = len(gene_names)

    def make_one():
        return [
            random.randrange(0, len(gene_values[d]))
            for d in range(len(gene_values))
        ]

    population = [make_one() for i in range(pop_size)]

    return population


def run_one_generation(
    evaluated_pop, fitness_fun, gene_values, mutation_prob, normalize, gen_num
):

    pop_size = len(evaluated_pop)

    new_evaluated_pop = []  # new population

    for i in range(pop_size):

        fitnesses = [evind.fitness for evind in evaluated_pop]

        if normalize is not None:
            fitnesses1 = normalize(fitnesses)
        else:
            fitnesses1 = fitnesses

        sampler = weighted_sampler(evaluated_pop, fitnesses1)

        father = sampler()
        mother = sampler()

        child0 = recombine(mother.indiv, father.indiv)
        mutated = mutate(child0, gene_values, mutation_prob)

        ev_indiv = EvaluatedIndiv(
            indiv=mutated,
            fitness=fitness_fun.from_idxs(mutated),
            gen_num=gen_num,
        )

        new_evaluated_pop.append(ev_indiv)

    return new_evaluated_pop


#%%


def recombine(mother, father):
    """Simulate sexual recombination of two dna's"""
    n_genes = len(mother)
    cut = random.randrange(0, n_genes)

    # take first cut values from mother's genes
    # last n -gebnes  values from father's genes
    # using generators because we are cool.

    child = mother[:cut] + father[cut:]

    return child


def mutate(indiv, gene_values, mutation_prob):

    if random.uniform(0, 1) >= mutation_prob:
        return indiv

    mutated_indiv = indiv.copy()
    g_idx = random.randrange(0, len(indiv))

    n_aleles = len(gene_values[g_idx])
    ale_idx = random.randrange(0, n_aleles)

    mutated_indiv[g_idx] = ale_idx

    return mutated_indiv


def weighted_sampler(seq, weights):
    """Return a random-sample function that picks from seq weighted by weights.
    Taken directly from: https://github.com/aimacode/aima-python/blob/master/utils.py"""
    totals = []
    for w in weights:
        totals.append(w + totals[-1] if totals else w)

    return lambda: seq[bisect.bisect(totals, random.uniform(0, totals[-1]))]


def normalizer(gamma, b):
    def normalize(fitnesses):

        min_f = min(fitnesses)
        max_f = max(fitnesses)
        denom = max_f - min_f

        return [(f - min_f) / (denom + 1e-6) ** gamma + b for f in fitnesses]

    return normalize


class memoize:
    def __init__(self, file=None, refresh=False, save_every_n=1):
        self.file = file
        self.save_every_n = save_every_n
        if file:
            try:
                with open(file, "rb") as f:
                    saved = pickle.load(f)
                    self.memo = saved[0]
                    self.fitness = saved[1]
            except:
                file = None
                pass

        if refresh or not file:
            self.memo = []
            self.fitness = []

    def lookup(self, dic):
        if dic in self.memo:
            lookup_index = self.memo.index(dic)
            organism = self.memo[lookup_index]
            fitness = self.fitness[lookup_index]
            return organism, fitness
        else:
            return None, None

    def save_organism(self, organism, fitness):
        self.memo.append(organism)
        self.fitness.append(fitness)
        if len(self.memo) % self.save_every_n == 0 and self.file:
            print("WRITING")
            with open(self.file, "wb") as f:
                pickle.dump((self.memo, self.fitness), f)


def wrap_xgb_fit(dic):
    np.random.seed(42)

    organism, fitness = memo.lookup(dic)
    if fitness:
        print("FOUND")
        return fitness

    print(dic)
    model = xgb.XGBClassifier(
        nthread=-1,
        random_state=42,
        n_estimators=dic["n_estimators"],
        learning_rate=dic["learning_rate"],
        max_depth=dic["max_depth"],
        min_child_weight=dic["min_child_weight"],
        gamma=dic["gamma"],
        colsample_bytree=dic["colsample_bytree"],
    )
    model.fit(
        X=X_train,
        y=y_train,
        eval_set=[(X_train, y_train), (X_calib, y_calib)],
        early_stopping_rounds=10,
        eval_metric="aucpr",
    )
    auc_out = auc_pr(y_calib, model.predict_proba(X_calib)[:, 1])

    memo.save_organism(dic, auc_out)

    return auc_out


def test2():
    from collections import OrderedDict

    genes_grid = OrderedDict(
        [
            ("n_estimators", [100, 250, 500, 1000]),
            ("learning_rate", [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]),
            ("max_depth", [3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40]),
            ("min_child_weight", [1, 3, 5, 7, 9, 10, 11, 13, 15, 20]),
            ("gamma", [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 1, 3, 5]),
            ("colsample_bytree", [0.3, 0.4, 0.5, 0.7]),
        ]
    )
    return genetic_algorithm(
        wrap_xgb_fit,
        genes_grid,
        init_pop=None,
        pop_size=50,
        n_gen=100,
        mutation_prob=0.1,
        seed=1337,
    )


try:
    cin_step = int(sys.argv[1])
except IndexError:
    print(
        "Usage is geneticXGB,py STEP LEVEL\n STEP=[1,3,6,12,23,36] \n LEVEL=['sb','ns','os']"
    )
    cin_step = 1

try:
    cin_yvar = "y_" + sys.argv[2]
except IndexError:
    cin_yvar = "y_sb"


print(f"Genetic Optimization Routine For {cin_step} step {cin_yvar}")

print("READING TRAINING AND TESTING DATA...")
base_train = pd.read_parquet(
    f"/proj/uppstore2019113/nobackup/projects/xgboost/prod_train_{cin_step}.parquet"
)
base_test = pd.read_parquet(
    f"/proj/uppstore2019113/nobackup/projects/xgboost/prod_test_{cin_step}.parquet"
)
base_calib = pd.read_parquet(
    f"/proj/uppstore2019113/nobackup/projects/xgboost/prod_calib_{cin_step}.parquet"
)
print("DATA READ...")


def make_data(y_var="y_sb"):
    print(f"Target var: {y_var}")
    print("*" * 24)
    print(
        f"Time span train: {base_train.y_month.min()} - {base_train.y_month.max()}"
    )
    print(
        f"Time span calib: {base_calib.y_month.min()} - {base_calib.y_month.max()}"
    )
    print(
        f"Time span calib: {base_test.y_month.min()} - {base_test.y_month.max()}"
    )
    print("*" * 24)

    y_train = base_train[y_var]
    X_train = base_train.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_train.vdem_e_regiongeo = X_train.vdem_e_regiongeo.astype("category")
    X_train = pd.get_dummies(X_train)

    base_calib.dropna(inplace=True)
    y_calib = base_calib[y_var]
    X_calib = base_calib.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_calib.vdem_e_regiongeo = X_calib.vdem_e_regiongeo.astype("category")
    X_calib = pd.get_dummies(X_calib)

    base_test.dropna(inplace=True)
    y_test = base_test[y_var]
    X_test = base_test.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_test.vdem_e_regiongeo = X_test.vdem_e_regiongeo.astype("category")
    X_test = pd.get_dummies(X_test)

    print(
        f"Shape train: {X_train.shape} : Positives {y_train.sum()}/{y_train.shape[0]}",
    )
    print(
        f"Shape calib: {X_calib.shape} : Positives {y_calib.sum()}/{y_calib.shape[0]}"
    )
    print(
        f"Shape calib: {X_test.shape} : Positives {y_test.sum()}/{y_test.shape[0]}"
    )
    return y_train, X_train, y_calib, X_calib, y_test, X_test


print("GENERATING DATASETS...")
y_train, X_train, y_calib, X_calib, y_test, X_test = make_data(cin_yvar)

print("INITIALIZING MEMO FILE...")
memo = memoize(file=f"memo_views_{cin_yvar}_{cin_step}.pickle", refresh=False)

organisms = test2()

print("DUMPING RESULTS...")
with open(f"organisms_{cin_yvar}_{cin_step}.pickle", "wb") as f:
    pickle.dump(organisms, f)
