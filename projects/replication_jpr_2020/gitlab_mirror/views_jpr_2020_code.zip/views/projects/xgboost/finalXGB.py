# flake8: noqa
# pylint: skip-file


import pandas as pd
import numpy as np

from sklearn.metrics import (
    auc,
    roc_curve as roc,
    roc_auc_score as auc_roc,
    precision_recall_curve as pr,
    average_precision_score as auc_pr,
)

import xgboost as xgb

import sys
import pickle

pd.options.mode.chained_assignment = None

try:
    cin_step = int(sys.argv[1])
except IndexError:
    print(
        "Usage is geneticXGB,py STEP LEVEL\n STEP=[1,3,6,12,23,36] \n LEVEL=['sb','ns','os']"
    )
    cin_step = 1

try:
    cin_yvar = "y_" + sys.argv[2]
except IndexError:
    cin_yvar = "y_sb"


features_path = "/proj/uppstore2019113/nobackup/projects/xgboost"
organisms_path = "/home/mihai/genetic/production"
storage_path = "/proj/uppstore2019113/nobackup/projects/xgboost/predictions"


class EvaluatedIndiv:
    def __init__(self, indiv, fitness, gen_num):
        self.indiv = indiv
        self.fitness = fitness
        self.gen_num = gen_num

    def __eq__(self, other):
        return (self.indiv == other.indiv) and (self.fitness == other.fitness)

    def __ne__(self, other):
        return not self.eq(other)

    def __lt__(self, other):
        return self.fitness > other.fitness

    def __str__(self):
        return "EvaluatedIndiv( indiv=%s, fitness=%.6g, gen_num=%d)" % (
            self.indiv,
            self.fitness,
            self.gen_num,
        )

    def fetch_genes(self):
        return self.indiv

    def __repr__(self):
        return str(self)


#%%


print(f"Postoptimization Prediction For {cin_step} step {cin_yvar}")

print("READING TRAINING AND TESTING DATA...")
base_train = pd.read_parquet(f"{features_path}/prod_train_{cin_step}.parquet")
base_test = pd.read_parquet(f"{features_path}/prod_test_{cin_step}.parquet")
base_calib = pd.read_parquet(f"{features_path}/prod_calib_{cin_step}.parquet")
base_fcast = pd.read_parquet(f"{features_path}/prod_fcast_{cin_step}.parquet")
print("DATA READ...")


def make_data(y_var="y_sb"):
    print(f"Target var: {y_var}")
    print("*" * 24)
    print(
        f"Time span train: {base_train.y_month.min()} - {base_train.y_month.max()}"
    )
    print(
        f"Time span calib: {base_calib.y_month.min()} - {base_calib.y_month.max()}"
    )
    print(
        f"Time span calib: {base_test.y_month.min()} - {base_test.y_month.max()}"
    )
    print(
        f"Time span fcast: {base_fcast.y_month.min()} - {base_fcast.y_month.max()}"
    )

    max_fcast_with_y = int(
        base_fcast[["y_month", y_var]].dropna().y_month.max()
    )
    print(f"Available y in fcast until : {max_fcast_with_y}")

    print("*" * 24)

    y_train = base_train[y_var]
    X_train = base_train.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_train.vdem_e_regiongeo = X_train.vdem_e_regiongeo.astype("category")
    X_train = pd.get_dummies(X_train)

    base_calib.dropna(inplace=True)
    y_calib = base_calib[y_var]
    X_calib = base_calib.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_calib.vdem_e_regiongeo = X_calib.vdem_e_regiongeo.astype("category")
    X_calib = pd.get_dummies(X_calib)

    base_test.dropna(inplace=True)
    y_test = base_test[y_var]
    X_test = base_test.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_test.vdem_e_regiongeo = X_test.vdem_e_regiongeo.astype("category")
    X_test = pd.get_dummies(X_test)

    base_candidates = base_fcast[base_fcast.y_month <= max_fcast_with_y]
    base_candidates = base_candidates[
        base_candidates.y_month > base_test.y_month.max()
    ]
    base_candidates.dropna(inplace=True)
    y_cand = base_candidates[y_var]
    X_cand = base_candidates.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_cand.vdem_e_regiongeo = X_cand.vdem_e_regiongeo.astype("category")
    X_cand = pd.get_dummies(X_cand)

    X_future = base_fcast[base_fcast.y_month > max_fcast_with_y]
    scaff_future = X_future[["pg_id", "y_month"]]
    X_future = X_future.drop(
        ["y_sb", "y_ns", "y_os", "y_month", "pg_id", "month_id"], axis=1
    )
    X_future.vdem_e_regiongeo = X_future.vdem_e_regiongeo.astype("category")
    X_future = pd.get_dummies(X_future)

    print(
        f"Shape train: {X_train.shape} : Positives {y_train.sum()}/{y_train.shape[0]}",
    )
    print(
        f"Shape calib: {X_calib.shape} : Positives {y_calib.sum()}/{y_calib.shape[0]}"
    )
    print(
        f"Shape calib: {X_test.shape} : Positives {y_test.sum()}/{y_test.shape[0]}"
    )
    return (
        y_train,
        X_train,
        y_calib,
        X_calib,
        y_test,
        X_test,
        y_cand,
        X_cand,
        X_future,
        scaff_future,
    )


print("GENERATING DATASETS...")
(
    y_train,
    X_train,
    y_calib,
    X_calib,
    y_test,
    X_test,
    y_cand,
    X_cand,
    X_future,
    scaff_future,
) = make_data(cin_yvar)


# organisms_y_os_6.pickle

print(
    f"""LOADING OPTIMIZATIONS FROM PICKLE:
organisms_{cin_yvar}_{cin_step}.pickle...
memo_views_{cin_yvar}_{cin_step}.pickle...
"""
)

try:
    with open(
        f"{organisms_path}/organisms_{cin_yvar}_{cin_step}.pickle", "rb"
    ) as f:
        gen = pickle.load(f)
        generations = [(i.fitness, i.gen_num) for i in gen]
        print("Organisms read... [OK]")
except:
    print("File cannot be loaded. Did you run the optimization routine?")

try:
    with open(
        f"{organisms_path}/memo_views_{cin_yvar}_{cin_step}.pickle", "rb"
    ) as f:
        memoizer = pickle.load(f)
        print("Memoizer list read... [OK]")
except:
    print("File cannot be loaded. Did you run the optimization routine?")


model = memoizer[0]
result = memoizer[1]
results2 = pd.DataFrame({"result": result, "model": model})
print("Best 5 models:\n")
print(
    results2.sort_values(by="result", ascending=False).model[0:5]
)  # .values)

print("\n" + "*" * 24 + "\nBest 5 models by performance:\n")
print(results2.sort_values(by="result", ascending=False).result[0:5])


print("Training on A. Predicting B and C...")
pred_tA_pB = base_calib[["pg_id", "y_month"]]
pred_tA_pC = base_test[["pg_id", "y_month"]]
pred_tA_pF = scaff_future.copy()

for i in range(0, 5):
    print("*" * 24)
    print("Training model: ", i)
    best_params = results2.model[i]
    print("Best params are:", best_params)

    model = xgb.XGBClassifier(nthread=-1, random_state=42, **best_params)
    model.fit(
        X=X_train,
        y=y_train,
        eval_set=[(X_train, y_train), (X_calib, y_calib)],
        early_stopping_rounds=10,
        eval_metric="aucpr",
    )

    print("Pickling object...")
    with open(
        f"{storage_path}/model_{cin_yvar}_{cin_step}_A_iter{i}.pickle", "wb"
    ) as f:
        pickle.dump(model, file=f)

    print("Evaluating model: ", i)
    pred_against_calib = model.predict_proba(X_calib)[:, 1]
    pred_against_test = model.predict_proba(X_test)[:, 1]
    pred_against_future = model.predict_proba(X_future)[:, 1]

    pr_against_calib = auc_pr(y_calib, pred_against_calib)
    pr_against_test = auc_pr(y_test, pred_against_test)

    roc_against_calib = auc_roc(y_calib, pred_against_calib)
    roc_against_test = auc_roc(y_test, pred_against_test)

    print(
        f"Trained on A. ROC+PR against B: {roc_against_calib}, {pr_against_calib}"
    )
    print(
        f"Trained on A. ROC+PR against C: {roc_against_test}, {pr_against_test}"
    )

    print("Storing predictions...")

    if i == 0:
        pred_tA_pB["y"] = y_calib
        pred_tA_pB["partition"] = "B"
        pred_tA_pC["y"] = y_test
        pred_tA_pC["partition"] = "C"

    pred_tA_pB[f"pred_{i}"] = pred_against_calib
    pred_tA_pC[f"pred_{i}"] = pred_against_test
    pred_tA_pF[f"pred_{i}"] = pred_against_future

    print("*" * 24)


pred_tA_pBC = pd.concat([pred_tA_pB, pred_tA_pC], axis=0, ignore_index=True)
pred_tA_pBC

pred_tA_pBC["pred_ensemble"] = pred_tA_pBC[
    ["pred_0", "pred_1", "pred_2", "pred_3", "pred_4"]
].mean(axis=1)
pred_tA_pF["pred_ensemble"] = pred_tA_pF[
    ["pred_0", "pred_1", "pred_2", "pred_3", "pred_4"]
].mean(axis=1)

pred_tA_pBC.to_parquet(
    f"{storage_path}/pred_tA_pBC_{cin_yvar}_{cin_step}.parquet"
)
pred_tA_pC.to_parquet(
    f"{storage_path}/pred_tA_pC_{cin_yvar}_{cin_step}.parquet"
)
pred_tA_pF.to_parquet(
    f"{storage_path}/pred_tA_pF_{cin_yvar}_{cin_step}.parquet"
)

for i in list(range(0, 5)) + ["ensemble"]:
    roc_score = auc_roc(pred_tA_pBC["y"], pred_tA_pBC[f"pred_{i}"])
    pr_score = auc_pr(pred_tA_pBC["y"], pred_tA_pBC[f"pred_{i}"])
    print(f"Scoring model {i} on BC: | ROC: {roc_score}, PR: {pr_score}")

# exit(0)

tr = X_train.copy()
tr["y"] = y_train

ca = X_calib.copy()
ca["y"] = y_calib

ca_1 = ca[ca.y == 1]
ca_0 = ca[ca.y == 0]

np.random.seed(42)
ca_0 = ca_0.sample(frac=0.1, replace=False, random_state=1102)

X_join = pd.concat([tr, ca_0, ca_1], axis=0, ignore_index=True)
y_join = X_join.y
X_join.drop(["y"], axis=1, inplace=True)


print("Training on A + B (10% down, assymetric). Predicting C...")
pred_tAB_pC = base_test[["pg_id", "y_month"]]
pred_tAB_pF = scaff_future.copy()


for i in range(0, 5):
    print("*" * 24)
    print("Training model: ", i)
    best_params = results2.model[i]
    print("Best params are:", best_params)

    model = xgb.XGBClassifier(nthread=-1, random_state=42, **best_params)
    model.fit(
        X=X_join,
        y=y_join,
        eval_set=[(X_join, y_join), (X_test, y_test)],
        early_stopping_rounds=10,
        eval_metric="aucpr",
    )

    print("Pickling object...")
    with open(
        f"{storage_path}/model_{cin_yvar}_{cin_step}_AB_iter{i}.pickle", "wb"
    ) as f:
        pickle.dump(model, file=f)

    print("Evaluating model: ", i)
    pred_against_test = model.predict_proba(X_test)[:, 1]
    pred_against_future = model.predict_proba(X_future)[:, 1]
    pr_against_test = auc_pr(y_test, pred_against_test)
    roc_against_test = auc_roc(y_test, pred_against_test)

    print(
        f"Trained on AB. ROC+PR against C: {roc_against_test}, {pr_against_test}"
    )

    print("Storing predictions...")

    if i == 0:
        pred_tAB_pC["y"] = y_test
        pred_tAB_pC["partition"] = "C"

    pred_tAB_pC[f"pred_{i}"] = pred_against_test
    pred_tAB_pF[f"pred_{i}"] = pred_against_future

    print("*" * 24)


pred_tAB_pC["pred_ensemble"] = pred_tAB_pC[
    ["pred_0", "pred_1", "pred_2", "pred_3", "pred_4"]
].mean(axis=1)
pred_tAB_pF["pred_ensemble"] = pred_tAB_pF[
    ["pred_0", "pred_1", "pred_2", "pred_3", "pred_4"]
].mean(axis=1)

pred_tAB_pC.to_parquet(
    f"{storage_path}/pred_tAB_pC_{cin_yvar}_{cin_step}.parquet"
)
pred_tAB_pF.to_parquet(
    f"{storage_path}/pred_tAB_pF_{cin_yvar}_{cin_step}.parquet"
)

for i in list(range(0, 5)) + ["ensemble"]:
    roc_score = auc_roc(pred_tAB_pC["y"], pred_tAB_pC[f"pred_{i}"])
    pr_score = auc_pr(pred_tAB_pC["y"], pred_tAB_pC[f"pred_{i}"])
    print(f"Scoring model {i} on C: | ROC: {roc_score}, PR: {pr_score}")

tf = X_join.copy()
tf["y"] = y_join

te = X_test.copy()
te["y"] = y_test

te_1 = te[te.y == 1]
te_0 = te[te.y == 0]

np.random.seed(42)
te_0 = te_0.sample(frac=0.1, replace=False, random_state=1102)
X_ft = pd.concat([tf, te_0, te_1], axis=0, ignore_index=True)

y_ft = X_ft.y
X_ft.drop(["y"], axis=1, inplace=True)

print(
    "Training on all we have, early stopping on cand. Predicting the FUTURE..."
)

pred_tABC_pF = scaff_future.copy()

for i in range(0, 5):
    print("*" * 24)
    print("Training model: ", i)
    best_params = results2.model[i]
    print("Best params are:", best_params)

    model = xgb.XGBClassifier(nthread=-1, random_state=42, **best_params)
    model.fit(
        X=X_ft,
        y=y_ft,
        eval_set=[(X_ft, y_ft), (X_cand, y_cand)],
        early_stopping_rounds=10,
        eval_metric="aucpr",
    )

    print("Pickling object...")
    with open(
        f"{storage_path}/model_{cin_yvar}_{cin_step}_ABC_iter{i}.pickle", "wb"
    ) as f:
        pickle.dump(model, file=f)

    print("Evaluating model: ", i)
    pred_against_test = model.predict_proba(X_cand)[:, 1]
    pred_against_future = model.predict_proba(X_future)[:, 1]

    pr_against_stop = auc_pr(y_cand, pred_against_test)
    roc_against_stop = auc_roc(y_cand, pred_against_test)

    pred_tABC_pF[f"pred_{i}"] = pred_against_future

    print(
        f"Trained on EVERYTHING. ROC+PR against CAND only: {roc_against_stop}, {pr_against_stop}"
    )

    print("*" * 24)

pred_tABC_pF["pred_ensemble"] = pred_tABC_pF[
    ["pred_0", "pred_1", "pred_2", "pred_3", "pred_4"]
].mean(axis=1)
pred_tABC_pF.to_parquet(
    f"{storage_path}/pred_tABC_pF_{cin_yvar}_{cin_step}.parquet"
)

print("Done. Good bye.")
