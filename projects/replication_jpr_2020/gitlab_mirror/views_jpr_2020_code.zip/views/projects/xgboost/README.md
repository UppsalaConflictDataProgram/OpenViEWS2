Xgboost production mode.
