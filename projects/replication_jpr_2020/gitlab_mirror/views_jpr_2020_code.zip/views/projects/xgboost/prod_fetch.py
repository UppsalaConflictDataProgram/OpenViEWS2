# flake8: noqa
# pylint: skip-file

import pandas as pd
import numpy as np
from sqlalchemy import text as sql_text, create_engine

# Set connection params for the ViEWS DB.
# The expectation is that the data is in the cand_paper schema

db_engine_name = "postgresql://mihai@130.238.55.70:5432/views"
engine = create_engine(db_engine_name)


def fetch_future_supplement(
    months_ahead="6", c=468, future=480, future_horizon=36
):
    """
    Will fetch the remaining ("candidate") data that was not used in the candidate-loop
    for training the final forecasting machine.

    Will also fetch the future data for forecasting to the true forecasting horizon.
    Here goes!
    """
    train_query = f"""SELECT * FROM flat_materialized.afr_{months_ahead}d WHERE y_month BETWEEN {c+1} AND {future}
                   AND afr_{months_ahead}d IS NOT NULL"""
    test_query = f"""SELECT * FROM flat_materialized.afr_{months_ahead}d_eval WHERE y_month BETWEEN {c+1} AND {future+37}"""
    with engine.connect() as con:
        print(
            f"Fetching train data SUPPLEMENT for {months_ahead} months ahead..."
        )
        train_data = pd.read_sql(train_query, con=con)
        print("Fetchig FORECAST data...")
        test_data = pd.read_sql(test_query, con=con)
        print("Train: ", train_data.shape)
        print("Forecast: ", test_data.shape)
        return train_data, test_data


c = 468
future = 481

path = "/proj/uppstore2019113/nobackup/projects/xgboost/"

train_supplement_1, forecast_supplement_1 = fetch_future_supplement("1")
train_supplement_1.to_parquet(path + "prod_supp_1.parquet")
forecast_supplement_1.to_parquet(path + "prod_fcast_1.parquet")

train_supplement_1 = ""
forecast_supplement_1 = ""


train_supplement_3, forecast_supplement_3 = fetch_future_supplement("3")
train_supplement_3.to_parquet(path + "prod_supp_3.parquet")
forecast_supplement_3.to_parquet(path + "prod_fcast_3.parquet")

train_supplement_3 = ""
forecast_supplement_3 = ""

train_supplement_6, forecast_supplement_6 = fetch_future_supplement("6")
train_supplement_6.to_parquet(path + "prod_supp_6.parquet")
forecast_supplement_6.to_parquet(path + "prod_fcast_6.parquet")

train_supplement_6 = ""
forecast_supplement_6 = ""

train_supplement_12, forecast_supplement_12 = fetch_future_supplement("12")
train_supplement_12.to_parquet(path + "prod_supp_12.parquet")
forecast_supplement_12.to_parquet(path + "prod_fcast_12.parquet")

train_supplement_12 = ""
forecast_supplement_12 = ""

train_supplement_24, forecast_supplement_24 = fetch_future_supplement("24")
train_supplement_24.to_parquet(path + "prod_supp_24.parquet")
forecast_supplement_24.to_parquet(path + "prod_fcast_24.parquet")

train_supplement_24 = ""
forecast_supplement_24 = ""

train_supplement_36, forecast_supplement_36 = fetch_future_supplement("36")
train_supplement_36.to_parquet(path + "prod_supp_36.parquet")
forecast_supplement_36.to_parquet(path + "prod_fcast_36.parquet")

print("Finished")
