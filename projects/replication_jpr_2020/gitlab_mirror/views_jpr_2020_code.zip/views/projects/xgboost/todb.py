# flake8: noqa
# pylint: skip-file

import pandas as pd
import numpy as np
from sqlalchemy import text as sql_text, create_engine

times = [1, 3, 6, 12, 24, 36]
# periods = ['tA_pC','tA_pF','tAB_pC','tAB_pF','tABC_pF']
periods = ["tA_pBC"]
loas = ["sb", "ns", "os"]
path = "/proj/uppstore2019113/nobackup/projects/xgboost/predictions"
db_engine_name = "postgresql://mihai@130.238.55.70:5432/views"
engine = create_engine(db_engine_name)
for time in times:
    for period in periods:
        for loa in loas:
            print(f"{period}_y_{loa}_{time}")
            df = pd.read_parquet(
                f"{path}/pred_{period}_y_{loa}_{time}.parquet"
            )
            with engine.connect() as con:
                df.to_sql(
                    name=f"{loa}_{period}_{time}".lower(),
                    schema="flat_materialized",
                    con=con,
                    if_exists="replace",
                    index=False,
                )
