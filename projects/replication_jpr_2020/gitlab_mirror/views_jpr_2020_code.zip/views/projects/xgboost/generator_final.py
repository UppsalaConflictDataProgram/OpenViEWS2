# flake8: noqa
# pylint: skip-file


months = [1, 3, 6, 12, 24, 36]
objs = ["sb", "os", "ns"]

for month in months:
    for obj in objs:
        template = f"""#!/bin/bash -l
#SBATCH -A snic2019-3-404
#SBATCH -p node
#SBATCH -t 3:00:00
#SBATCH -J views_xgb_run

date;
python -u finalXGB.py {month} {obj}
date;
"""
        print(template)
        with open(f"run{month}{obj}.sh", "w") as f:
            f.write(template)
